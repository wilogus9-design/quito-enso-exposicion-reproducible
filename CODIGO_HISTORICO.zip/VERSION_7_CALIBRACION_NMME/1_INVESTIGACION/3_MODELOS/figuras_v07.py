"""Figuras científicas reproducibles, vectoriales y sin interpolación visual del clima."""
import json
import numpy as np
import pandas as pd
import geopandas as gpd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
from calibracion_v07 import P,P6,D,F

G=F/'GRAFICOS'
COLORS={'Climatología':'#666666','Red ENSO':'#2166ac','NMME local':'#b35806'}


def save(fig,name):
    fig.savefig(G/(name+'.svg'),bbox_inches='tight');fig.savefig(G/(name+'.png'),dpi=300,bbox_inches='tight');plt.close(fig)


def main():
    G.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.family':'Arial','font.size':8,'axes.titlesize':8,'axes.labelsize':8,
                         'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,'svg.fonttype':'none'})
    data=pd.read_csv(F/'comparacion_NMME_misma_muestra.csv');data=data[data.corte_disponibilidad=='dia15']
    models={'Climatología':'climatologia__V06','Red ENSO':'red_ENSO__beta_PIT','NMME local':'NMME_local__beta_PIT'}
    groups=['Costa','Sierra','Amazonía','Quito canton','Quito grilla']
    domains=data.dominio.unique().tolist();groups=[g if g in domains else 'Amazonia' for g in groups]
    fig,axes=plt.subplots(1,2,figsize=(7.1,3.1),layout='constrained')
    for label,model in models.items():
        h=data[data.modelo==model].set_index('dominio').reindex(groups)
        axes[0].plot(range(5),h.crps,marker='o',label=label,color=COLORS[label],lw=1)
        axes[1].plot(range(5),h.cobertura80*100,marker='o',label=label,color=COLORS[label],lw=1)
    axes[1].axhline(80,color='black',ls='--',lw=.7)
    for ax in axes:
        ax.set_xticks(range(5),['Costa','Sierra','Amazonía','Quito\ncantón','Quito\ngrilla']);ax.spines[['top','right']].set_visible(False)
    axes[0].set_ylabel('CRPS (mm), menor es mejor');axes[1].set_ylabel('Cobertura del intervalo de 80 % (%)')
    axes[0].set_ylim(bottom=0);axes[1].set_ylim(0,100);axes[0].legend(frameon=False)
    save(fig,'figura_1_comparacion_dinamica')
    # Exactamente las mismas cuatro estaciones para transferencias directas en 2026.
    fig,axes=plt.subplots(1,2,figsize=(7.1,3.2),layout='constrained')
    tables=[pd.read_csv(F/'evaluacion_instrumental_promedio_estaciones.csv'),pd.read_csv(F/'reserva_2026_promedio_estaciones.csv')]
    corrected=[pd.read_csv(F/'SUBCAPTACION/evaluacion_instrumental_promedio_estaciones.csv'),pd.read_csv(F/'SUBCAPTACION/reserva_2026_promedio_estaciones.csv')]
    labels=['Climatología','Red ENSO','NMME local'];code={'Climatología':'climatologia_CHIRPS','Red ENSO':'red_ENSO','NMME local':'NMME_local'}
    for i,(table,corr) in enumerate(zip(tables,corrected)):
        x=np.arange(3);values=[table[(table.modelo==code[k])&(table.calibracion=='directa')].iloc[0].crps for k in labels]
        cv=[corr[(corr.modelo==code[k])&(corr.calibracion=='directa')].iloc[0].crps for k in labels]
        axes[i].bar(x-.15,values,width=.3,color=[COLORS[k] for k in labels],label='Referencia sin corrección')
        axes[i].bar(x+.15,cv,width=.3,color=[COLORS[k] for k in labels],hatch='///',alpha=.5,label='Referencia con subcaptación')
        axes[i].set_xticks(x,labels);axes[i].set_ylabel('CRPS (mm)');axes[i].set_ylim(0,125);axes[i].spines[['top','right']].set_visible(False)
        axes[i].set_title('2020–2025, cinco estaciones' if i==0 else 'Reserva 2026, cuatro estaciones y 13 casos')
    axes[0].legend(frameon=False,loc='upper left');save(fig,'figura_2_verificacion_instrumental')
    # Mapa de soportes y estaciones, con probabilidades climáticas, NO inundación.
    grid=json.loads((P6/'2_DATOS/PROCESADOS/grilla_lluvia.json').read_text());transform=grid['transform']
    nn=pd.read_csv(F/'pronostico_calibracion_fija_nov2026_ene2027.csv',dtype={'unit':str})
    nmme=pd.read_csv(F/'pronostico_NMME_local_nov2026_ene2027.csv',dtype={'unit':str})
    boundary=gpd.read_file(P.parents[1]/'VERSION_5_QUITO_10M/1_INVESTIGACION/2_DATOS/PROCESADOS/quito_limite.geojson').to_crs(4326)
    stations=pd.read_csv(F/'control_totales_instrumentales_EPMAPS.csv');selected=pd.read_csv(F/'estaciones_admitidas_evaluacion.csv');selected=selected[selected.admitido].codigo
    fig,axes=plt.subplots(1,2,figsize=(7.1,4.3),layout='constrained');norm=Normalize(0,1);cmap=plt.colormaps['YlGnBu']
    for ax,frame,model,title in zip(axes,[nn,nmme],['red_ENSO__beta_PIT','NMME_local__beta_PIT'],['Red ENSO, soporte 0.05°','NMME local, origen 1°']):
        values=frame[frame.modelo==model].set_index('unit').p_humedo
        for c in grid['cells']:
            x=transform[2]+c['col']*transform[0];y=transform[5]+(c['row']+1)*transform[4]
            ax.add_patch(Rectangle((x,y),transform[0],-transform[4],facecolor=cmap(norm(values[c['id']])),edgecolor='white',lw=.15))
        boundary.boundary.plot(ax=ax,color='black',lw=.6)
        s=stations[stations.codigo.isin(selected)];ax.scatter(s.lon,s.lat,s=15,c='white',edgecolors='black',lw=.7,zorder=4)
        for r in s.itertuples():ax.annotate(r.codigo,(r.lon,r.lat),xytext=(3,3),textcoords='offset points',fontsize=8)
        bounds=boundary.total_bounds;ax.set_xlim(bounds[0]-.01,bounds[2]+.01);ax.set_ylim(bounds[1]-.01,bounds[3]+.01)
        ax.set_title(title);ax.set_xlabel('Longitud (°)');ax.set_ylabel('Latitud (°)');ax.set_aspect('equal')
    fig.colorbar(ScalarMappable(norm=norm,cmap=cmap),ax=axes,label='Probabilidad de lluvia estacional > P80; no inundación',shrink=.8)
    save(fig,'figura_3_soportes_y_estaciones')


if __name__=='__main__':main()
