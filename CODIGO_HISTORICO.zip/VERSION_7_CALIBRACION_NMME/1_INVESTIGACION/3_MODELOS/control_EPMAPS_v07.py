"""Concilia cada total mensual con sus días, sin rellenar ni estimar faltantes.

Mes admitido: todos los días informados, valores no negativos y concordancia
entre el acumulado diario y el total mensual publicado (.5 mm + .5 %).
El portal no entrega flags instrumentales originales: control de consistencia,
no certificación metrológica ni de independencia respecto a CHIRPS.
"""
import json
import numpy as np
import pandas as pd
from fuentes_v07 import P,R,F
D=P/'2_DATOS/PROCESADOS'


def trace(path):
    obj=json.loads(path.read_text(encoding='utf-8'));graph=obj.get('grafico',obj)
    label=str(graph.get('layout',{}).get('yaxis',{}).get('title',''))
    if 'mm' not in label:raise ValueError('Unidad de precipitación no comprobada: '+path.name)
    data=next((x for x in graph.get('data',[]) if x.get('name')=='Valor'),None)
    if data is None:return None
    if len(data['x'])!=len(data['y']):raise ValueError('Fechas y valores diferentes')
    frame=pd.DataFrame({'date':pd.to_datetime(data['x'],errors='raise'),'rain_mm':pd.to_numeric(pd.Series(data['y']),errors='coerce')})
    if frame.date.duplicated().any():raise ValueError('Fechas repetidas: '+path.name)
    return frame


def main():
    folder=R/'EPMAPS';D.mkdir(parents=True,exist_ok=True)
    geo=json.loads((folder/'estaciones_geojson.json').read_text())
    meta={ft['properties']['codigo']:ft for ft in geo['features'] if ft.get('geometry',{}).get('type')=='Point'}
    audit=json.loads((F/'estado_lluvia_diaria_EPMAPS.json').read_text(encoding='utf-8'))
    records=[];daily_frames=[];stations=[]
    for item in audit:
        code=item['codigo'];coords=meta[code]['geometry']['coordinates']
        if 'archivo' not in item:continue
        daily=trace(P/item['archivo']);monthly=trace(folder/'SERIES_MENSUALES'/(code+'.json'))
        if daily is None or monthly is None:continue
        if not (daily.date.dt.hour.eq(0)&daily.date.dt.minute.eq(0)).all():raise ValueError('Registros no son días enteros')
        daily['codigo']=code;daily['valor_valido']=daily.rain_mm.notna()&daily.rain_mm.ge(0)
        daily['lluvia_valida_mm']=daily.rain_mm.where(daily.valor_valido)
        # Denominador real calendario, incluyendo días completamente ausentes del portal.
        idx=pd.date_range(daily.date.min(),min(daily.date.max(),pd.Timestamp('2026-09-30')),freq='D')
        full=daily.set_index('date').reindex(idx).rename_axis('date').reset_index();full['month']=full.date.dt.to_period('M').astype(str)
        stats=full.groupby('month').agg(dias_registrados=('rain_mm','count'),dias_validos=('lluvia_valida_mm','count'),
                                      suma_diaria_mm=('lluvia_valida_mm',lambda x:x.sum(min_count=1))).reset_index()
        stats['dias_esperados']=pd.PeriodIndex(stats.month,freq='M').days_in_month
        monthly['month']=monthly.date.dt.to_period('M').astype(str)
        if monthly.month.duplicated().any():raise ValueError('Mes duplicado')
        stats=stats.merge(monthly[['month','rain_mm']].rename(columns={'rain_mm':'total_mensual_publicado_mm'}),on='month',how='outer',validate='one_to_one')
        stats['codigo']=code;stats['nombre']=meta[code]['properties'].get('nombre');stats['lon']=coords[0];stats['lat']=coords[1]
        stats['dias_completos']=stats.dias_validos==stats.dias_esperados
        stats['diferencia_mm']=stats.suma_diaria_mm-stats.total_mensual_publicado_mm
        stats['tolerancia_mm']=.5+.005*stats.total_mensual_publicado_mm.abs()
        stats['coincide_total']=stats.diferencia_mm.abs()<=stats.tolerancia_mm
        stats['mes_admitido']=stats.dias_completos&stats.coincide_total&stats.total_mensual_publicado_mm.ge(0)
        stats['lluvia_mes_admitido_mm']=stats.total_mensual_publicado_mm.where(stats.mes_admitido)
        records.append(stats);daily_frames.append(daily)
        stations.append({'codigo':code,'nombre':stats.nombre.iloc[0],'lat':coords[1],'lon':coords[0],
                         'primer_mes':stats.month.min(),'ultimo_mes':stats.month.max(),'meses_publicados':int(stats.total_mensual_publicado_mm.notna().sum()),
                         'meses_dias_completos':int(stats.dias_completos.sum()),'meses_totales_coinciden':int(stats.coincide_total.sum()),
                         'meses_admitidos':int(stats.mes_admitido.sum()),'meses_admitidos_2020_2025':int((stats.mes_admitido&stats.month.between('2020-01','2025-12')).sum())})
    if not records:raise RuntimeError('No hay series diarias con unidad comprobada')
    allmonths=pd.concat(records,ignore_index=True);allmonths.to_parquet(D/'EPMAPS_meses_controlados.parquet',index=False)
    pd.concat(daily_frames,ignore_index=True).to_parquet(D/'EPMAPS_dias_publicados.parquet',index=False)
    s=pd.DataFrame(stations);s.to_csv(F/'control_totales_instrumentales_EPMAPS.csv',index=False)
    status={'estaciones_preseleccionadas':len(audit),'estaciones_con_datos':len(s),'meses_controlados':len(allmonths),
            'meses_admitidos':int(allmonths.mes_admitido.sum()),'flags_originales_del_instrumento_disponibles':False,
            'independencia_CHIRPS_demostrada':False,'imputacion':False,'tolerancia':'0.5 mm + 0.005 * total publicado',
            'seleccion':'dentro de Quito y >=60 meses previos a 2014, antes de calcular habilidad instrumental'}
    (F/'control_instrumental_EPMAPS.json').write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8')
    print(s.to_string(index=False),flush=True);print(status,flush=True)


if __name__=='__main__':main()
