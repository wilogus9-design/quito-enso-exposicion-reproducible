"""Rutas y variables servidas por la interfaz pública EPMAPS, sin autenticación."""
from fuentes_v07 import *
import re

def main():
    truststore.inject_into_ssl()
    for name,url in {
        'epmaps_mensual':'https://paramh2o.aguaquito.gob.ec/reportes/mensual_multianual/',
        'epmaps_consultas':'https://paramh2o.aguaquito.gob.ec/reportes/consultas/',
    }.items():
        result=download(name+'.html',url,R/'EPMAPS');print(result,flush=True)
        if not result['ok']:continue
        html=(R/'EPMAPS'/(name+'.html')).read_text(errors='replace')
        for block in re.findall(r'<select\b.*?</select>',html,re.S):
            print(block[:4500],flush=True)
        scripts=re.findall(r'<script[^>]+src=["\']([^"\']+)',html)
        print('Scripts',scripts,flush=True)

if __name__=='__main__':main()
