"""NMME emitido, mensual, acumulado exacto y posprocesamiento local separado.

No sustituye ensamble de miembros por media como si tuviera dispersión física.
Toda incertidumbre aquí proviene de residuos históricos locales.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
import sys
import json
import numpy as np
import pandas as pd
import rasterio
from urllib.parse import urljoin
from scipy.io import netcdf_file
from scipy.stats import beta as beta_distribution
import truststore
from fuentes_v07 import P,R,F,download,Links
from calibracion_v07 import P6,groups,fit_beta,pit,METRICS
sys.path.insert(0,str(P6/'3_MODELOS'))
from evaluar_v06 import scores
D=P/'2_DATOS/PROCESADOS'


def text_attribute(value):
    return value.decode('utf-8',errors='replace') if isinstance(value,bytes) else str(value)


def interpolate(field,lat,lon,units,nearest=False):
    """Coordenadas globales de 1°; interpolación convexa o vecino más cercano."""
    if np.all(np.diff(lat)<0):lat=lat[::-1];field=field[:,::-1,:]
    if np.all(np.diff(lon)<0):lon=lon[::-1];field=field[:,:,::-1]
    assert np.all(np.diff(lat)>0) and np.all(np.diff(lon)>0)
    x=units.lon.to_numpy();x=x%360 if np.min(lon)>=0 else x
    y=units.lat.to_numpy()
    if nearest:
        ix=np.abs(lon[:,None]-x).argmin(0);iy=np.abs(lat[:,None]-y).argmin(0)
        return field[:,iy,ix]
    ix=np.searchsorted(lon,x)-1;iy=np.searchsorted(lat,y)-1
    assert np.all((ix>=0)&(ix<len(lon)-1)&(iy>=0)&(iy<len(lat)-1))
    wx=(x-lon[ix])/(lon[ix+1]-lon[ix]);wy=(y-lat[iy])/(lat[iy+1]-lat[iy])
    return (field[:,iy,ix]*(1-wx)*(1-wy)+field[:,iy+1,ix]*(1-wx)*wy+
            field[:,iy,ix+1]*wx*(1-wy)+field[:,iy+1,ix+1]*wx*wy)


def parse_anomaly(path,target,units):
    with netcdf_file(path,'r',mmap=False) as nc:
        init=pd.Period('1960-01','M')+int(nc.variables['initial_time'].data[0])
        times=pd.PeriodIndex([pd.Period('1960-01','M')+int(i) for i in nc.variables['target'].data],freq='M')
        ids=times.get_indexer(pd.period_range(target,periods=3,freq='M'))
        if (ids<0).any():raise ValueError('Faltan meses objetivo')
        if init!=target-1:raise ValueError('Inicialización incompatible')
        v=nc.variables['fcst'];assert v.dimensions==('target','lat','lon')
        field=v.data[ids].astype(float); unit=text_attribute(v.units)
        for key in ['_FillValue','missing_value']:
            if key in v._attributes:field[field==v._attributes[key]]=np.nan
        if unit=='mm/s':field[np.abs(field)>=1]=np.nan
        factor={'mm/s':86400,'mm/day':1,'mm/d':1}.get(unit)
        if factor is None:raise ValueError('Unidad desconocida: '+unit)
        rain=interpolate(field,nc.variables['lat'].data,nc.variables['lon'].data,units)
        nearest=interpolate(field,nc.variables['lat'].data,nc.variables['lon'].data,units,nearest=True)
        days=np.array([period.days_in_month for period in times[ids]])
        values=(rain*days[:,None]*factor).sum(0); values_nearest=(nearest*days[:,None]*factor).sum(0)
        creation=text_attribute(nc._attributes.get('creation_date',''))
        created=pd.Timestamp(datetime.strptime(creation,'%a %b %d %H:%M:%S %Y')) if creation else pd.NaT
        cutoff=pd.Timestamp(str(init)+'-15 23:59:59')
        strict=pd.Timestamp(str(init)+'-09 23:59:59')
        info={'inicio_temporada':str(target),'inicializacion':str(init),'creacion_archivo':str(created),
              'disponible_corte15':bool(pd.notna(created) and created<=cutoff),
              'disponible_corte9':bool(pd.notna(created) and created<=strict),'unidad_original':unit,
              'target_meses':[str(v) for v in times[ids]],'dias':days.tolist(),'celdas_faltantes_locales':int(np.isnan(values).sum()),
              'grilla_grados':float(np.diff(nc.variables['lon'].data)[0])}
    return values,values_nearest,info


def grib_pds(path):
    """GRIB1 sección 1 según NCEP ON388; no supone el orden de los meses."""
    raw=path.read_bytes();pos=0;result=[]
    while pos<len(raw):
        start=raw.find(b'GRIB',pos)
        if start<0:break
        if raw[start+7]!=1:raise ValueError('No es GRIB1')
        size=int.from_bytes(raw[start+4:start+7],'big');pds=raw[start+8:start+36]
        if len(pds)<28:raise ValueError('PDS truncado')
        year=(pds[24]-1)*100+pds[12];init=pd.Period(year=year,month=pds[13],freq='M')
        if not (pds[8]==59 and pds[17]==3 and pds[20]==3 and pds[19]==pds[18]+1):
            raise ValueError('GRIB no documenta media de precipitación de un mes')
        result.append({'init':init,'target':init+int(pds[18]),'P1':int(pds[18]),'P2':int(pds[19]),'time_range':int(pds[20])})
        pos=start+size
    return result


def parse_grib(path,target,units):
    periods=grib_pds(path);times=pd.PeriodIndex([p['target'] for p in periods],freq='M')
    ids=times.get_indexer(pd.period_range(target,periods=3,freq='M'))
    if (ids<0).any() or any(p['init']!=target-1 for p in periods):raise ValueError('GRIB meses incompatibles')
    with rasterio.open(path) as raster:
        if raster.count!=len(periods):raise ValueError('Bandas y mensajes GRIB distintos')
        if not all(raster.tags(int(i+1)).get('GRIB_UNIT')=='[kg/m^2/s]' for i in ids):raise ValueError('Unidad GRIB inesperada')
        field=raster.read((ids+1).tolist(),masked=True).filled(np.nan).astype(float)
        lat=np.array([raster.xy(row,0)[1] for row in range(raster.height)])
        lon=np.array([raster.xy(0,col)[0] for col in range(raster.width)])
        days=np.array([t.days_in_month for t in times[ids]])
        rain=interpolate(field,lat,lon,units);near=interpolate(field,lat,lon,units,nearest=True)
    values=(rain*days[:,None]*86400).sum(0);values_near=(near*days[:,None]*86400).sum(0)
    return values,values_near,{'inicio_temporada':str(target),'inicializacion':str(target-1),'creacion_archivo':None,
            'disponible_corte15':None,'disponible_corte9':None,'unidad_original':'kg/m^2/s equivalente a mm/s de agua',
            'target_meses':[str(t) for t in times[ids]],'dias':days.tolist(),'celdas_faltantes_locales':int(np.isnan(values).sum()),
            'grilla_grados':1.,'formato':'GRIB1; meses leídos de PDS, no inferidos por orden'}


def main():
    truststore.inject_into_ssl();D.mkdir(parents=True,exist_ok=True);F.mkdir(parents=True,exist_ok=True)
    with np.load(P6/'2_DATOS/PROCESADOS/panel_v06.npz') as f:d={k:f[k] for k in f.files}
    units=pd.read_csv(P6/'2_DATOS/PROCESADOS/unidades.csv',dtype={'unit':str});domain=groups(units)
    dates=pd.PeriodIndex(d['months'],freq='M');end=dates+2;month=dates.month.to_numpy()
    bank=(dates.year>=2014)&(end.year<=2016);cal=(dates.year>=2017)&(end.year<=2019);test=d['test']
    targets=list(dates[bank|cal|test])+[pd.Period('2026-11','M')]
    def fetch(target):
        init=target-1;stamp=f'{init.year}{init.month:02d}'
        file=f'NMME.prate.{stamp}.ENSMEAN.anom.nc'
        url=f'https://ftp.cpc.ncep.noaa.gov/NMME/realtime_anom/ENSMEAN/{stamp}0800/{file}'
        folder=f'https://ftp.cpc.ncep.noaa.gov/NMME/realtime_anom/ENSMEAN/{stamp}0800/'
        path=R/'NMME/ANOMALIAS'/file
        if path.exists():result=download(file,url,R/'NMME/ANOMALIAS')
        else:
            cat=download(stamp+'.html',folder,R/'NMME/CATALOGOS')
            if not cat['ok']:return cat,None,None,None
            parser=Links();parser.feed((R/'NMME/CATALOGOS'/(stamp+'.html')).read_text(errors='replace'))
            grib=f'prate.{stamp}0800.ENSMEAN.ensmean.anom.1x1.grb'
            links=[urljoin(folder,link) for link in parser.links]
            if url not in links and folder+grib in links:file=grib;url=folder+grib;path=R/'NMME/ANOMALIAS'/file
            if url not in links:return {'ok':False,'inicio_temporada':str(target),'error':'sin anomalía NMME en catálogo'},None,None,None
            result=download(file,url,R/'NMME/ANOMALIAS')
        result['inicio_temporada']=str(target)
        if result['ok']:
            try:
                rain,near,info=(parse_grib(path,target,units) if path.suffix=='.grb' else parse_anomaly(path,target,units))
                return result,rain,near,info
            except Exception as exc:result['ok']=False;result['error']=type(exc).__name__+': '+str(exc)
        return result,None,None,None
    with ThreadPoolExecutor(max_workers=3) as pool:raw=list(pool.map(fetch,targets))
    manifest=[a[0] for a in raw];(F/'fuentes_NMME_emitido.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
    info=[x[3] for x in raw if x[3] is not None];pd.DataFrame(info).to_csv(F/'tiempos_unidades_NMME.csv',index=False)
    pred=np.full_like(d['z'],np.nan,dtype=float);near=np.full_like(pred,np.nan);strict={};future=None;future_near=None
    for target,item in zip(targets,raw):
        _,value,n,meta=item
        if meta is None:continue
        strict[str(target)]=meta['disponible_corte9']
        # Corte de emisión estricto solo para test/proyección. Archivos del ajuste
        # se usan como históricos archivados; GRIB no demuestra fecha de publicación.
        if target>=pd.Period('2020-01','M') and not meta['disponible_corte15']:continue
        if target==pd.Period('2026-11','M'):future=value;future_near=n;continue
        t=dates.get_loc(target);pred[:,t]=value;near[:,t]=n
    baseline=np.column_stack([d['y'][:,d['train']&(month==mo)].mean(axis=1) for mo in range(1,13)])
    raw_mm=np.maximum(baseline[:,month-1]+pred,0);point=(np.log1p(raw_mm)-d['mu'][:,month-1])/d['sd'][:,month-1]
    raw_near=np.maximum(baseline[:,month-1]+near,0)
    np.savez_compressed(D/'NMME_puntos_locales.npz',months=d['months'],unit=d['unit'],
                        anomaly_mm=pred,point_z=point,raw_mm=raw_mm,raw_nearest_mm=raw_near,
                        future_anomaly_mm=future if future is not None else np.full(len(units),np.nan))
    residuals=[];pits=[]
    for u in range(len(units)):
        bi=bank&d['valid'][u]&np.isfinite(point[u]);ci=cal&d['valid'][u]&np.isfinite(point[u])
        r=d['z'][u,bi]-point[u,bi]
        if len(r)<24 or ci.sum()<24:raise ValueError('NMME banco/cal insuficiente: '+str(u))
        residuals.append(r);pits.append(pit(r,d['z'][u,ci]-point[u,ci]))
    ab={};pars=[]
    for group in sorted(set(domain)):
        us=np.flatnonzero(domain==group);a,b=fit_beta(np.concatenate([pits[u] for u in us]));ab[group]=(a,b)
        pars.append({'dominio':group,'a':a,'b':b,'fechas_cal_min':min(len(pits[u]) for u in us),'modelo':'NMME_local'})
    pd.DataFrame(pars).to_csv(F/'parametros_NMME_local.csv',index=False)
    rows=[];fs=[];qs=(np.arange(256)+.5)/256
    for u,meta in units.iterrows():
        ids=np.flatnonzero(test&d['valid'][u]&np.isfinite(point[u]));a,b=ab[domain[u]]
        for label,q in [('identidad',qs),('beta_PIT',beta_distribution.ppf(qs,a,b))]:
            offsets=np.quantile(residuals[u],q)
            samples=np.maximum(np.expm1(d['mu'][u,month[ids]-1,None]+d['sd'][u,month[ids]-1,None]*(point[u,ids,None]+offsets)),0)
            result=scores(samples,d['y'][u,ids],d['q20'][u,month[ids]-1],d['q80'][u,month[ids]-1])
            for j,t in enumerate(ids):
                rows.append({'unit':meta.unit,'dominio':domain[u],'modelo':'NMME_local__'+label,'inicio_temporada':str(dates[t]),'anio':dates[t].year,
                             'corte9':strict[str(dates[t])],'anomalía_dinamica_mm':float(pred[u,t]),
                             'prediccion_puntual_sin_cal_mm':float(raw_mm[u,t]),'sin_cal_vecino_cercano_mm':float(raw_near[u,t]),
                             'lluvia_observada_mm':float(d['y'][u,t]),**{k:float(v[j]) for k,v in result.items()}})
            if future is not None:
                zf=(np.log1p(max(baseline[u,10]+future[u],0))-d['mu'][u,10])/d['sd'][u,10]
                samples=np.maximum(np.expm1(d['mu'][u,10]+d['sd'][u,10]*(zf+offsets)),0);lo,med,hi=np.quantile(samples,[.1,.5,.9])
                fs.append({'unit':meta.unit,'nombre':meta['name'],'dominio':domain[u],'modelo':'NMME_local__'+label,'inicio_temporada':'2026-11','fin_temporada':'2027-01',
                           'inicializacion':'2026-10','anomalía_dinamica_mm':float(future[u]),'mediana_mm':med,'intervalo80_inf_mm':lo,'intervalo80_sup_mm':hi,
                           'p_seco':float((samples<d['q20'][u,10]).mean()),'p_humedo':float((samples>d['q80'][u,10]).mean()),
                           'fuente_dispersion':'residuos locales, no miembros del ensamble'})
    df=pd.DataFrame(rows);df.to_parquet(D/'test_NMME_local.parquet',index=False)
    pd.DataFrame(fs).to_csv(F/'pronostico_NMME_local_nov2026_ene2027.csv',index=False)
    v7=pd.read_parquet(D/'test_calibracion_v07.parquet')
    orig=pd.read_parquet(P6/'2_DATOS/PROCESADOS/evaluacion_test_detalle.parquet');from calibracion_v07 import groups_for_records
    orig['dominio']=groups_for_records(orig);orig['modelo']+='__V06'
    keys=df[['unit','inicio_temporada','corte9']].drop_duplicates()
    combo=pd.concat([df,v7.merge(keys,on=['unit','inicio_temporada'],validate='many_to_one'),orig.merge(keys,on=['unit','inicio_temporada'],validate='many_to_one')],ignore_index=True)
    combo.to_parquet(D/'comparacion_NMME_muestra_comun.parquet',index=False)
    summary=[]
    for corte,h in [('dia15',combo),('dia9',combo[combo.corte9.fillna(False)])]:
        for (group,model),g in h.groupby(['dominio','modelo']):
            summary.append({'corte_disponibilidad':corte,'dominio':group,'modelo':model,'n':len(g),'temporadas':g.inicio_temporada.nunique(),**g[METRICS].mean().to_dict()})
    s=pd.DataFrame(summary);s.to_csv(F/'comparacion_NMME_misma_muestra.csv',index=False)
    print('NMME archivos recuperados',sum(v['ok'] for v in manifest),'/',len(manifest),flush=True)
    print(s[(s.dominio=='Quito canton')&(s.corte_disponibilidad=='dia15')].to_string(index=False),flush=True)


if __name__=='__main__':main()
