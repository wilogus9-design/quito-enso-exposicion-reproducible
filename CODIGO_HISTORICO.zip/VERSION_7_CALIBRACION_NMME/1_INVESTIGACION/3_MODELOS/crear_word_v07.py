"""Anexo Word con tablas nativas, notas reales, citas legibles y OMML editable."""
from pathlib import Path
import importlib.util
import sys
import json
import re
import zipfile
from lxml import etree
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_ALIGN_VERTICAL
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

P=Path(__file__).resolve().parents[1];F=P/'6_FINAL';P6=P.parents[1]/'VERSION_6_ENSO_PREDICTIBILIDAD/1_INVESTIGACION'
SKILL=Path('<USUARIO_LOCAL>/.codex/plugins/cache/openai-primary-runtime/documents/26.1007.11041/skills/documents')


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);obj=importlib.util.module_from_spec(spec);sys.modules[name]=obj;spec.loader.exec_module(obj);return obj


math=module('v07_wordmath',P.parents[1]/'VERSION_5_QUITO_10M/1_INVESTIGACION/3_MODELOS/componentes_word.py')


def bib_records():
    text=(F/'referencias_v07.bib').read_text(encoding='utf-8');records={}
    for match in re.finditer(r'(?ms)^@(\w+)\{([^,]+),\s*\n(.*?)\n\}',text):
        fields={k:v.strip('{}') for k,v in re.findall(r'(\w+)\s*=\s*\{((?:\{[^{}]*\}|[^{}])*)\}',match[3])}
        records[match[2]]=fields
    return records


def authors_short(record):
    names=record.get('author','').split(' and ')
    families=[name.split(',')[0].strip('{}') for name in names]
    return families[0]+' et al.' if len(families)>2 else ' y '.join(families)


def initials(name):
    return ' '.join(p[0]+'.' for p in re.split(r'[\s-]+',name.strip()) if p)


def citation_text(key,records):
    record=records[key];return authors_short(record)+', '+record.get('year','s. f.')


def process_text(text,records):
    def cite(match):
        keys=re.findall(r'@(\w+)',match[0]);return '('+'; '.join(citation_text(k,records) for k in keys)+')'
    text=re.sub(r'\[[^\]\n]*@[^\]\n]*\]',cite,text).replace('**','').replace('`','')
    text=text.replace('Misra et al. (Misra et al., 2025)','Misra et al. (2025)')
    text=text.replace('Las predicciones observacionales no equivalen a atribución de causas ni a una función de daño.','Las puntuaciones de lluvia no son una función de daño.')
    text=text.replace(' El ranking Q1 de una revista y la decisión editorial no se garantizan mediante estos controles.','')
    text=text.replace(' No se envió ninguna solicitud a organismos ni se accedió a bases privadas.','')
    return text


def math_nodes(latex):
    def pieces(items):return [math.sub(*x) if isinstance(x,tuple) else math.run_math(x) for x in items]
    if latex.startswith('Y_'):return pieces([('Y','u,t'),' = ',('P','u,t'),' + ',('P','u,t+1'),' + ',('P','u,t+2')])
    if latex.startswith('Z_'):return pieces([('Z','u,t'),' = [log(1 + ',('Y','u,t'),') − ',('μ','u,m'),'] / ',('σ','u,m')])
    if latex=='m':return pieces(['m'])
    if latex==r'\hat Z':
        acc=OxmlElement('m:acc');pr=OxmlElement('m:accPr');ch=OxmlElement('m:chr');ch.set(qn('m:val'),'̂');pr.append(ch);e=OxmlElement('m:e');e.append(math.run_math('Z'));acc.extend([pr,e]);return [acc]
    if latex=='F_0':return pieces([('F','0')])
    if latex.startswith('F(y)='):return pieces(['F(y) = ',('B','a,b'),'(',('F','0'),'(y))'])
    if latex=='B_{a,b}':return pieces([('B','a,b')])
    if latex.startswith('E|'):
        fraction=OxmlElement('m:f');n=OxmlElement('m:num');n.append(math.run_math('1'));d=OxmlElement('m:den');d.append(math.run_math('2'));fraction.extend([n,d])
        return [*pieces(['E|X − y| − ']),fraction,*pieces([' E|X − X′|'])]
    raise ValueError('Ecuación no convertida: '+latex)


def paragraph(doc,text,records,style=None):
    p=doc.add_paragraph(style=style);text=process_text(text,records)
    for token in re.split(r'(\$[^$]+\$)',text):
        if token.startswith('$') and token.endswith('$'):
            eq=OxmlElement('m:oMath')
            for node in math_nodes(token[1:-1]):eq.append(node)
            p._p.append(eq)
        else:p.add_run(token)
    return p


def native_table(doc,lines,number):
    rows=[[v.strip() for v in line.strip().strip('|').split('|')] for line in lines if not re.fullmatch(r'[\s|:-]+',line)]
    headers=rows[0];data=rows[1:];n=len(headers)
    # Shorten headers without removing variables; abbreviation explained below.
    replacements={'CRPS observado (mm)':'CRPS original (mm)','CRPS subcaptación (mm)':'CRPS corregido (mm)',
                  'Cobertura observada (%)':'Cobertura original (%)','Cobertura subcaptación (%)':'Cobertura corregida (%)',
                  'Intervalo inferior (mm)':'Límite inferior (mm)','Intervalo superior (mm)':'Límite superior (mm)'}
    headers=[replacements.get(h,h) for h in headers]
    widths={1:[1.8,.72,.72,1.85,1.41],2:[.7,1.55,1.,.8,1.2,1.25],3:[2.,1.,1.,1.3,1.2],
            4:[.8,1.0,.9,.95,.95,.95,.95],5:[1.3,1.15,1.35,1.35,1.35]}[number]
    table=doc.add_table(rows=1,cols=n);table.autofit=False;table.alignment=WD_TABLE_ALIGNMENT.CENTER
    borders=OxmlElement('w:tblBorders')
    for key in ['top','left','bottom','right','insideH','insideV']:
        node=OxmlElement('w:'+key);node.set(qn('w:val'),'single');node.set(qn('w:sz'),'4');node.set(qn('w:color'),'D9D9D9');borders.append(node)
    table._tbl.tblPr.append(borders)
    for i,col in enumerate(table.columns):col.width=Inches(widths[i])
    for ri,values in enumerate([headers,*data]):
        row=table.rows[0] if ri==0 else table.add_row();pr=row._tr.get_or_add_trPr();pr.append(OxmlElement('w:cantSplit'))
        if ri==0:pr.append(OxmlElement('w:tblHeader'))
        for i,(cell,value) in enumerate(zip(row.cells,values)):
            if value.startswith('red_ENSO__'):value='Red ENSO'
            elif value.startswith('NMME_local__'):value='NMME local'
            elif value=='climatologia__V06':value='Climatología'
            cell.width=Inches(widths[i]);cell.text=value;cell.vertical_alignment=WD_ALIGN_VERTICAL.CENTER
            pad=OxmlElement('w:tcMar')
            for edge in ['top','bottom','left','right']:
                node=OxmlElement('w:'+edge);node.set(qn('w:w'),'80');node.set(qn('w:type'),'dxa');pad.append(node)
            cell._tc.get_or_add_tcPr().append(pad)
            if ri==0:
                shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'E8ECF0');cell._tc.get_or_add_tcPr().append(shade)
            for p in cell.paragraphs:
                p.alignment=WD_ALIGN_PARAGRAPH.LEFT if number==1 or i<2 else WD_ALIGN_PARAGRAPH.CENTER
                p.paragraph_format.space_after=Pt(0);p.paragraph_format.line_spacing=1.05
                p.paragraph_format.keep_with_next=(ri==0 or len(data)<=3)
                for run in p.runs:run.font.name='Arial';run.font.size=Pt(9)
    return table


def references(records,cited):
    prior={r['key']:r for r in json.loads((P6/'6_FINAL/referencias_verificadas.json').read_text(encoding='utf-8'))}
    new={r['clave']:r['registro'] for r in json.loads((F/'referencias_nuevas_verificadas.json').read_text(encoding='utf-8'))}
    titles={'barnston2014':'Predictability of December–April rainfall in coastal and Andean Ecuador',
            'paliz2026':'Modulation of rainfall variability and potential predictability in Ecuador: ENSO’s evolving influence (1981-2018)',
            'gneiting2007':'Strictly proper scoring rules, prediction, and estimation',
            'becker2016':'Probabilistic seasonal forecasts in the North American Multimodel Ensemble: A baseline skill assessment',
            'kirtman2014':'The North American Multimodel Ensemble: Phase-1 seasonal-to-interannual prediction; Phase-2 toward developing intraseasonal prediction'}
    out=[]
    for key in cited:
        rec=records[key]
        if key in prior:
            entry=prior[key];value=entry['text']
            if key in titles:value=value.replace(rec['title'],titles[key])
            out.append({'text':value,'journal':entry.get('revista',''),'volume':entry.get('volumen','')});continue
        if key in new:
            raw=new[key];names=[a.get('family','')+', '+initials(a.get('given','')) for a in raw.get('author',[])]
            long_list=len(names)>20
            authors=', '.join(names[:19])+', … '+names[-1] if long_list else ', '.join(names[:-1])+', & '+names[-1] if len(names)>1 else names[0]
            journal=raw.get('container-title',[''])[0];volume=raw.get('volume','');issue=raw.get('issue','');pages=raw.get('page',raw.get('article-number',''))
            if str(issue).casefold()=='none':issue=''
            title=titles.get(key,rec['title']).replace('\\&','&');text=f"{authors} ({rec['year']}). {title}. {journal}, {volume}"
            if issue:text+='('+issue+')'
            if pages:text+=', '+pages
            text+='. https://doi.org/'+raw['DOI'];out.append({'text':text,'journal':journal,'volume':volume});continue
        author=rec['author'].strip('{}');out.append({'text':f"{author}. ({rec['year']}). {rec['title']}. {rec['url']}",'journal':'','volume':''})
    return sorted(out,key=lambda r:r['text'].casefold())


def main():
    records=bib_records();text=(F/'RESULTADOS_V07.md').read_text(encoding='utf-8')
    cited=set()
    for group in re.findall(r'\[[^\]\n]*@[^\]\n]*\]',text):cited.update(re.findall(r'@(\w+)',group))
    doc=Document();section=doc.sections[0];section.page_width=Inches(8.5);section.page_height=Inches(11)
    section.left_margin=section.right_margin=Inches(1);section.top_margin=section.bottom_margin=Inches(.8)
    for name,size in [('Normal',11),('Title',16),('Heading 1',12),('Heading 2',11)]:
        style=doc.styles[name];style.font.name='Arial';style.font.size=Pt(size);style.font.color.rgb=RGBColor(0,0,0)
        style.paragraph_format.space_after=Pt(6);style.paragraph_format.line_spacing=1.08
        style.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY if name=='Normal' else WD_ALIGN_PARAGRAPH.LEFT
    doc.add_paragraph('ENSO y lluvia estacional en Ecuador',style='Title')
    p=doc.add_paragraph('Wilson Gustavo Morales Lastra[[FN]]');p.alignment=WD_ALIGN_PARAGRAPH.LEFT
    doc.add_paragraph('Códigos JEL: C53; Q54; R14').alignment=WD_ALIGN_PARAGRAPH.LEFT
    lines=text.splitlines();i=0;table_number=0;skip_bibliography=False
    while i<len(lines):
        line=lines[i].strip();i+=1
        if not line or line.startswith('# ') or line.startswith('Wilson Gustavo') or line.startswith('*Investigador') or line.startswith('Códigos JEL:'):continue
        if line.startswith('## Bibliografía'):
            skip_bibliography=True;doc.add_heading('Bibliografía',level=1)
            for entry in references(records,cited):
                p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.LEFT;p.paragraph_format.left_indent=Inches(.25);p.paragraph_format.first_line_indent=Inches(-.25)
                if entry['journal'] and entry['volume']:
                    before,after=entry['text'].split(entry['journal'],1);p.add_run(before);p.add_run(entry['journal']+', '+entry['volume']).italic=True;p.add_run(after[len(', '+entry['volume']):])
                else:p.add_run(entry['text'])
                for run in p.runs:run.font.size=Pt(10)
            continue
        if skip_bibliography:
            if line.startswith('## Disponibilidad'):skip_bibliography=False
            else:continue
        if line.startswith('### '):doc.add_heading(re.sub(r'^\d+\.\d+\.\s*','',line[4:]),level=2);continue
        if line.startswith('## '):doc.add_heading(re.sub(r'^\d+\.\s*','',line[3:]),level=1);continue
        if line.startswith('|'):
            block=[line]
            while i<len(lines) and lines[i].strip().startswith('|'):block.append(lines[i].strip());i+=1
            native_table(doc,block,table_number);continue
        if line.startswith('![]('):
            path=F/re.search(r'\((.*?)\)',line)[1];path=path.with_suffix('.png')
            p=doc.add_paragraph();p.paragraph_format.keep_with_next=True;p.add_run().add_picture(str(path),width=Inches(6.3))
            pr=p._p.find('.//'+qn('wp:docPr'))
            if pr is not None:pr.set('descr',path.stem.replace('_',' ')+'. Gráfico científico de lluvia estacional, no inundación.')
            continue
        p=paragraph(doc,line,records)
        if line.startswith('Tabla '):table_number=int(re.match(r'Tabla (\d+)',line)[1]);p.paragraph_format.keep_with_next=True
        if line.startswith('Figura '):p.paragraph_format.keep_with_next=True
        if line.startswith(('Tabla ','Figura ','Fuente:')):
            for run in p.runs:run.font.size=Pt(9)
        if line.startswith('Fuente:'):p.paragraph_format.keep_together=True;p.paragraph_format.space_before=Pt(5)
    doc.core_properties.author='Wilson Gustavo Morales Lastra';doc.core_properties.title='ENSO y lluvia estacional en Ecuador'
    fmt=OxmlElement('w:footnotePr');code=OxmlElement('w:numFmt');code.set(qn('w:val'),'chicago');fmt.append(code);section._sectPr.append(fmt)
    base=P/'2_DATOS/PROCESADOS/anexo_word_base.docx';doc.save(base)
    output=F/'ANEXO_VALIDACION_V07.docx'
    helper=module('v07_notes',SKILL/'scripts/insert_note.py')
    helper.insert_note(str(base),str(output),'footnote','[[FN]]','Investigador independiente. Correo: wilson.morales@epn.edu.ec. ORCID: https://orcid.org/0009-0008-3413-3705.')
    with zipfile.ZipFile(output) as z:parts={i.filename:z.read(i.filename) for i in z.infolist()}
    root=etree.fromstring(parts['word/document.xml']);W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
    for ref in root.findall('.//{'+W+'}footnoteReference'):
        run=ref.getparent();pr=etree.Element('{'+W+'}rPr');sup=etree.SubElement(pr,'{'+W+'}vertAlign');sup.set('{'+W+'}val','superscript');run.insert(0,pr)
    parts['word/document.xml']=etree.tostring(root,xml_declaration=True,encoding='UTF-8',standalone=True)
    sanitizer=module('v07_title_sanitize',SKILL/'scripts/google_docs_title_sanitize.py')
    styles=etree.fromstring(parts['word/styles.xml']);sanitizer.sanitize_styles(styles);sanitizer.sanitize_document_part(root,leading_nonempty_paragraphs=6)
    parts['word/styles.xml']=etree.tostring(styles,xml_declaration=True,encoding='UTF-8',standalone=True)
    parts['word/document.xml']=etree.tostring(root,xml_declaration=True,encoding='UTF-8',standalone=True)
    notes=etree.fromstring(parts['word/footnotes.xml'])
    for p in notes.findall('.//{'+W+'}p'):
        pr=etree.Element('{'+W+'}pPr');align=etree.SubElement(pr,'{'+W+'}jc');align.set('{'+W+'}val','left');p.insert(0,pr)
    parts['word/footnotes.xml']=etree.tostring(notes,xml_declaration=True,encoding='UTF-8',standalone=True)
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
        for name,value in parts.items():z.writestr(name,value)
    control=json.loads((F/'control_redaccion.json').read_text(encoding='utf-8'));control['formato_editable_entregado']=['docx','qmd']
    control['tablas_Word_nativas']=5;control['ecuaciones_Word_OMML']=8;control['figuras_Word']=3
    (F/'control_redaccion.json').write_text(json.dumps(control,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Word creado:',output,flush=True)


if __name__=='__main__':main()
