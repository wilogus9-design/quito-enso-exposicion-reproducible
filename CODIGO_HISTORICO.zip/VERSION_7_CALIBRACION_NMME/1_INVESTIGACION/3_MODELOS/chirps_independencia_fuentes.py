"""Fuentes de estaciones realmente incorporadas a CHIRPS: inspección pública."""
from fuentes_v07 import *


def main():
    truststore.inject_into_ssl()
    urls={
      'chirps3_readme':'https://data.chc.ucsb.edu/products/CHIRPS/v3.0/README-CHIRPSv3.0.txt',
      'chirps_estaciones_2020_03':'https://data.chc.ucsb.edu/products/CHIRPS/v3.0/diagnostics/list_of_stations_used/monthly/global.stationsUsed.v3.2020.03.csv',
      'chirps_estaciones_2026_03':'https://data.chc.ucsb.edu/products/CHIRPS/v3.0/diagnostics/list_of_stations_used/monthly/global.stationsUsed.v3.2026.03.csv',
      'chirps_legates_catalogo':'https://data.chc.ucsb.edu/products/CHIRPS/v3.0/diagnostics/legates-willmott/'
    }
    result=[]
    for name,url in urls.items():
        result.append(download(name+('.csv' if url.endswith('.csv') else '.txt'),url,R/'CHC'))
        if url.endswith('.csv') and result[-1]['ok']:
            # La fuente contiene nombres de estación con comas sin entrecomillar.
            # Inspección inicial textual; el normalizador conservará esas comas.
            print(name,(R/'CHC'/(name+'.csv')).read_text(errors='replace').splitlines()[:3],flush=True)
    (F/'fuentes_independencia_CHIRPS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    file=R/'CHC/chirps_legates_catalogo.txt'
    if file.exists():
        parser=Links();parser.feed(file.read_text(errors='replace'))
        print('Legates',parser.links[:25],flush=True)


if __name__=='__main__':main()
