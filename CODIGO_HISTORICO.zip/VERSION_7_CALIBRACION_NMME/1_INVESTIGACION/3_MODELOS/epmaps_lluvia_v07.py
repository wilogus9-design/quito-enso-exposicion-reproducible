"""Series de precipitación publicadas por EPMAPS. POST solo consulta, no modifica."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
import json
import re
import pandas as pd
from fuentes_v07 import P,R,F,download
import requests
import truststore
import numpy as np

URL='https://paramh2o.aguaquito.gob.ec'
D=P/'2_DATOS/PROCESADOS'


def main():
    truststore.inject_into_ssl();folder=R/'EPMAPS';folder.mkdir(parents=True,exist_ok=True)
    metadata=download('catalogo_lluvia.json',URL+'/ajax/estacion_consulta/?variable_id=1&sistema_id=&cuenca_id=&estacion_tipo_id=',folder)
    geo=download('estaciones_geojson.json',URL+'/estacion/getjson',folder)
    if not metadata['ok']:raise RuntimeError(metadata)
    stations=json.loads((folder/'catalogo_lluvia.json').read_text())['estaciones']
    print('Estaciones de lluvia',len(stations),flush=True)
    geo=json.loads((folder/'estaciones_geojson.json').read_text())
    coords={ft['properties']['codigo']:ft['geometry']['coordinates'] for ft in geo['features'] if ft.get('geometry',{}).get('type')=='Point'}
    def get(station,frequency='5'):
        code=station['est_codigo'];path=folder/('SERIES_MENSUALES' if frequency=='5' else 'SERIES_DIARIAS')/(code+'.json');path.parent.mkdir(parents=True,exist_ok=True)
        try:
            if not path.exists():
                session=requests.Session();html=session.get(URL+'/reportes/consultas/',timeout=(10,35));html.raise_for_status()
                token=re.search(r'name="csrfmiddlewaretoken" value="([^"]+)"',html.text).group(1)
                form={'csrfmiddlewaretoken':token,'filtro':'todas_estaciones','sistema':'','cuenca':'','frecuencia':frequency,
                      'variable':'1','inicio':'','fin':'','accion':'grafico','estacion_id':str(station['est_id'])}
                response=session.post(URL+'/reportes/consultas/',data=form,headers={'Referer':URL+'/reportes/consultas/','X-Requested-With':'XMLHttpRequest'},timeout=(15,60))
                response.raise_for_status();obj=response.json();path.write_text(json.dumps(obj,ensure_ascii=False),encoding='utf-8')
                path.with_suffix('.fuente.json').write_text(json.dumps({'url':URL+'/reportes/consultas/','metodo':'POST de consulta pública',
                    'station':station,'variable':'1 Precipitación','frecuencia':frequency,'consulta':'todo el periodo publicado',
                    'fecha_recuperacion_UTC':datetime.now(timezone.utc).isoformat()},ensure_ascii=False,indent=2),encoding='utf-8')
            obj=json.loads(path.read_text(encoding='utf-8')); graph=obj.get('grafico',obj)
            traces=graph.get('data',[]);layout=graph.get('layout',{})
            print(code,[(tr.get('name'),len(tr.get('x',[]))) for tr in traces],flush=True)
            return {'codigo':code,'estacion':station,'archivo':str(path.relative_to(P)),'respuesta':obj.get('response'),
                    'layout':layout,'series':[{'name':v.get('name'),'n':len(v.get('x',[]))} for v in traces]}
        except Exception as exc:return {'codigo':code,'estacion':station,'error':type(exc).__name__+': '+str(exc)[:130]}
    # Descargar todos los puntos públicos, sin escoger por correlación.
    with ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(get,stations))
    (F/'estado_lluvia_EPMAPS.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Series con respuesta',sum('archivo' in r for r in results),'/',len(results),flush=True)
    # Selección por geografía y disponibilidad previa, no por habilidad de test.
    # Todos los puntos dentro de la máscara Quito usada en V05.
    import rasterio
    from pyproj import Transformer
    P5=P.parents[1]/'VERSION_5_QUITO_10M/1_INVESTIGACION'
    maskpath=P5/'2_DATOS/PROCESADOS/mascara_quito_10m.tif'
    keep=[]
    with rasterio.open(maskpath) as mask:
        transform=Transformer.from_crs(4326,mask.crs,always_xy=True)
        for station in stations:
            code=station['est_codigo']
            if code not in coords:continue
            lon,lat=coords[code];x,y=transform.transform(lon,lat);row,col=mask.index(x,y)
            if not (0<=row<mask.height and 0<=col<mask.width):continue
            pixel=mask.read(1,window=rasterio.windows.Window(col,row,1,1))[0,0]
            if pixel!=1:continue
            obj=json.loads((folder/'SERIES_MENSUALES'/(code+'.json')).read_text(encoding='utf-8'))
            trace=next((t for t in obj.get('grafico',obj).get('data',[]) if t.get('name')=='Valor'),None)
            if trace is None:continue
            frame=pd.DataFrame({'date':pd.to_datetime(trace['x']),'rain':pd.to_numeric(pd.Series(trace['y']),errors='coerce')})
            before=(frame.date<'2014-01-01')&frame.rain.notna()
            if before.sum()<60:continue
            keep.append(station)
    print('Estaciones Quito con >=60 meses anteriores a 2014:',len(keep),flush=True)
    with ThreadPoolExecutor(max_workers=3) as pool:daily=list(pool.map(lambda s:get(s,'4'),keep))
    (F/'estado_lluvia_diaria_EPMAPS.json').write_text(json.dumps(daily,ensure_ascii=False,indent=2),encoding='utf-8')


if __name__=='__main__':main()
