"""Transferencia a pluviómetros, con y sin posprocesamiento local histórico.

No utiliza 2020–2025 para ajustar residuos, transformaciones o escoger estaciones.
Las estaciones son instrumentos externos al ajuste de nuestra red, pero su
independencia de CHIRPS no se demuestra sin el registro de incorporación de CHC.
"""
import json
import numpy as np
import pandas as pd
from affine import Affine
from scipy.stats import beta as beta_distribution
from calibracion_v07 import P,P6,D,F,fit_beta,pit
from evaluar_v06 import scores


def main(corrected=False):
    output=F/'SUBCAPTACION' if corrected else F
    dest=D/'SUBCAPTACION' if corrected else D
    output.mkdir(parents=True,exist_ok=True);dest.mkdir(parents=True,exist_ok=True)
    with np.load(P6/'2_DATOS/PROCESADOS/panel_v06.npz') as f:d={k:f[k] for k in f.files}
    with np.load(P6/'2_DATOS/PROCESADOS/predicciones_ridge.npz') as f:lin={k:f[k] for k in f.files}
    with np.load(P6/'2_DATOS/PROCESADOS/predicciones_redes.npz') as f:nets={k:f[k] for k in f.files}
    with np.load(D/'NMME_puntos_locales.npz') as f:nmme={k:f[k] for k in f.files}
    point={model:(lin[model] if model.startswith('ridge') else nets[model]) for model in ['ridge_ENSO','ridge_sin_ENSO','red_ENSO','red_sin_ENSO']}
    point['NMME_local']=nmme['point_z']
    units=pd.read_csv(P6/'2_DATOS/PROCESADOS/unidades.csv',dtype={'unit':str})
    grid=json.loads((P6/'2_DATOS/PROCESADOS/grilla_lluvia.json').read_text());transform=Affine(*grid['transform'][:6])
    codes={(c['row'],c['col']):c['id'] for c in grid['cells']}
    date=pd.PeriodIndex(d['months'],freq='M');end=date+2;mo=date.month.to_numpy()
    bank=(date.year>=2014)&(end.year<=2016);cal=(date.year>=2017)&(end.year<=2019);test=d['test']
    monthly=pd.read_parquet(D/'EPMAPS_meses_controlados.parquet')
    if corrected:
        factors=pd.read_csv(F/'factores_subcaptacion_Legates.csv');monthly['mes_calendario']=monthly.month.str[5:].astype(int)
        monthly=monthly.merge(factors,on=['codigo','mes_calendario'],validate='many_to_one')
        monthly['lluvia_mes_admitido_mm']*=monthly.factor
    v7pars=pd.read_csv(F/'parametros_beta_PIT.csv');npd=pd.read_csv(F/'parametros_NMME_local.csv')
    qs=(np.arange(256)+.5)/256;results=[];selection=[];pairs=[];parameters=[]
    for code,g in monthly.groupby('codigo'):
        meta=g.iloc[0];col,row=(~transform)*(meta.lon,meta.lat);native=codes.get((int(np.floor(row)),int(np.floor(col))))
        if native is None:
            selection.append({'codigo':code,'admitido':False,'motivo':'punto sin celda contenedora nativa Quito'});continue
        u=int(np.flatnonzero(units.unit==native)[0])
        m=g.set_index('month').lluvia_mes_admitido_mm.reindex(d['months']).to_numpy()
        target=np.full(len(m),np.nan);target[:-2]=m[:-2]+m[1:-1]+m[2:]
        available=np.isfinite(target)&d['valid'][u]&np.isfinite(point['NMME_local'][u])
        bi=bank&available;ci=cal&available;ti=test&available
        ok=bi.sum()>=24 and ci.sum()>=24 and ti.sum()>=36
        selection.append({'codigo':code,'nombre':meta.nombre,'celda_nativa':native,'temporadas_banco':int(bi.sum()),
                          'temporadas_calibrador':int(ci.sum()),'temporadas_test_comunes':int(ti.sum()),
                          'admitido':bool(ok),'motivo':'cumple reglas previas' if ok else 'cobertura inferior a 24/24/36'})
        # Concordancia todos los meses admitidos, sin selección por habilidad.
        nativepath=P6/'2_DATOS/PROCESADOS/lluvia_nativa_quito.npz'
        # Los totales de tres meses ya están en el panel: no reconstruir a partir de log-z.
        for t in np.flatnonzero(np.isfinite(target)&d['valid'][u]):
            pairs.append({'codigo':code,'celda_nativa':native,'inicio_temporada':str(date[t]),
                          'instrumental_mm':float(target[t]),'CHIRPS_mm':float(d['y'][u,t]),
                          'fase':'test' if test[t] else 'banco' if bank[t] else 'cal' if cal[t] else 'otra'})
        if not ok:continue
        ids=np.flatnonzero(ti);truth=target[ids]
        # Una distribución meteorológica común, sin adaptar la climatología al test.
        for j,t in enumerate(ids):
            draws=d['y'][u,d['train']&(mo==mo[t])&d['valid'][u]]
            out=scores(draws[None],truth[j:j+1],np.array([0.]),np.array([1e20]))
            results.append(record(code,meta,native,date[t],'climatologia_CHIRPS','directa',truth[j],out,0))
        z=(np.log1p(target)-d['mu'][u,mo-1])/d['sd'][u,mo-1]
        for model,pred in point.items():
            local_residual=z[bi]-pred[u,bi];a,b=fit_beta(pit(local_residual,z[ci]-pred[u,ci]))
            parameters.append({'codigo':code,'modelo':model,'a':a,'b':b,'n_banco':int(bi.sum()),'n_cal':int(ci.sum()),
                               'banco_hasta':'2016-12','cal_hasta':'2019-12'})
            if model=='NMME_local':
                direct=d['z'][u,bank&np.isfinite(pred[u])]-pred[u,bank&np.isfinite(pred[u])]
                prior=npd[npd.dominio=='Quito grilla'].iloc[0]
            else:
                direct=d['z'][u,bank]-pred[u,bank]
                prior=v7pars[(v7pars.dominio=='Quito grilla')&(v7pars.modelo==model)].iloc[0]
            choices=[('directa',direct,beta_distribution.ppf(qs,prior.a,prior.b)),
                     ('local_identidad',local_residual,qs),('local_beta_PIT',local_residual,beta_distribution.ppf(qs,a,b))]
            for label,residual,q in choices:
                offsets=np.quantile(residual,q)
                draws=np.maximum(np.expm1(d['mu'][u,mo[ids]-1,None]+d['sd'][u,mo[ids]-1,None]*(pred[u,ids,None]+offsets)),0)
                out=scores(draws,truth,np.zeros(len(ids)),np.full(len(ids),1e20))
                for j,t in enumerate(ids):results.append(record(code,meta,native,date[t],model,label,truth[j],out,j))
    sel=pd.DataFrame(selection);sel.to_csv(output/'estaciones_admitidas_evaluacion.csv',index=False)
    if not results:raise RuntimeError('Ninguna estación supera cobertura instrumental predefinida')
    df=pd.DataFrame(results);df.to_parquet(dest/'test_instrumental_EPMAPS.parquet',index=False)
    pd.DataFrame(parameters).to_csv(output/'parametros_calibracion_instrumental.csv',index=False)
    metrics=['mae','crps','cobertura80','amplitud80','sesgo_mediana_mm']
    per=df.groupby(['codigo','nombre','modelo','calibracion'])[metrics].mean().reset_index()
    per.to_csv(output/'evaluacion_instrumental_por_estacion.csv',index=False)
    summary=per.groupby(['modelo','calibracion'])[metrics].mean().reset_index();summary['ponderacion']='estaciones con igual peso'
    summary.to_csv(output/'evaluacion_instrumental_promedio_estaciones.csv',index=False)
    pd.DataFrame(pairs).to_parquet(dest/'concordancia_instrumental_CHIRPS.parquet',index=False)
    agreement=[]
    for code,g in pd.DataFrame(pairs).groupby('codigo'):
        h=g[g.fase=='test'];delta=h.CHIRPS_mm-h.instrumental_mm
        agreement.append({'codigo':code,'temporadas_test':len(h),'sesgo_CHIRPS_menos_estacion_mm':delta.mean(),
                          'mae_mm':delta.abs().mean(),'correlacion':h.CHIRPS_mm.corr(h.instrumental_mm)})
    pd.DataFrame(agreement).to_csv(output/'concordancia_CHIRPS_instrumental_temporadas.csv',index=False)
    print(sel.to_string(index=False),flush=True);print(summary.to_string(index=False),flush=True)


def record(code,meta,native,date,model,calibration,truth,out,j):
    return {'codigo':code,'nombre':meta.nombre,'celda_nativa':native,'inicio_temporada':str(date),'anio':date.year,
            'modelo':model,'calibracion':calibration,'instrumental_observado_mm':float(truth),
            'mediana_mm':float(out['mediana_mm'][j]),'sesgo_mediana_mm':float(out['mediana_mm'][j]-truth),
            **{k:float(out[k][j]) for k in ['mae','crps','cobertura80','amplitud80','intervalo80_inf_mm','intervalo80_sup_mm']}}


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--corregir-subcaptacion',action='store_true');args=parser.parse_args()
    main(args.corregir_subcaptacion)
