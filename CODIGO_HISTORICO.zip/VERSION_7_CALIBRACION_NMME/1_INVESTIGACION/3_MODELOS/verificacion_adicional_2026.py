"""Reserva temporal adicional 2026; ninguna puntuación elige modelos o umbrales.

Datos recuperados retrospectivamente. No son pronósticos registrados en vivo.
Todo ajuste probabilístico es anterior a las temporadas de 2026 verificadas.
"""
from concurrent.futures import ThreadPoolExecutor
import json
import numpy as np
import pandas as pd
from scipy.stats import beta as beta_distribution
import truststore
from fuentes_v07 import P,R,F,download
from calibracion_v07 import P6,D
from nmme_v07 import parse_anomaly
from evaluar_v06 import scores


def main(corrected=False):
    output=F/'SUBCAPTACION' if corrected else F
    dest=D/'SUBCAPTACION' if corrected else D
    output.mkdir(parents=True,exist_ok=True);dest.mkdir(parents=True,exist_ok=True)
    truststore.inject_into_ssl()
    with np.load(P6/'2_DATOS/PROCESADOS/panel_v06.npz') as f:d={k:f[k] for k in f.files}
    with np.load(P6/'2_DATOS/PROCESADOS/predicciones_ridge.npz') as f:lin={k:f[k] for k in f.files}
    with np.load(P6/'2_DATOS/PROCESADOS/predicciones_redes.npz') as f:nets={k:f[k] for k in f.files}
    with np.load(D/'NMME_puntos_locales.npz') as f:nmme={k:f[k] for k in f.files}
    units=pd.read_csv(P6/'2_DATOS/PROCESADOS/unidades.csv',dtype={'unit':str})
    date=pd.PeriodIndex(d['months'],freq='M');end=date+2;mo=date.month.to_numpy()
    ids2026=np.flatnonzero((date.year==2026)&(end<=pd.Period('2026-08','M'))&d['valid'].all(axis=0))
    manifest=[];npred=nmme['point_z'].copy()
    baseline=np.column_stack([d['y'][:,d['train']&(mo==m)].mean(1) for m in range(1,13)])
    def get(t):
        target=date[t];init=target-1;stamp=f'{init.year}{init.month:02d}';file=f'NMME.prate.{stamp}.ENSMEAN.anom.nc'
        url=f'https://ftp.cpc.ncep.noaa.gov/NMME/realtime_anom/ENSMEAN/{stamp}0800/{file}'
        result=download(file,url,R/'NMME/RESERVA2026');result['inicio_temporada']=str(target)
        if not result['ok']:return t,result,None
        try:
            value,_,info=parse_anomaly(R/'NMME/RESERVA2026'/file,target,units);result['tiempos']=info
            return t,result,value if info['disponible_corte15'] else None
        except Exception as e:result['ok']=False;result['error']=type(e).__name__+': '+str(e);return t,result,None
    with ThreadPoolExecutor(max_workers=2) as pool:
        for t,result,value in pool.map(get,ids2026):
            manifest.append(result)
            if value is not None:npred[:,t]=(np.log1p(np.maximum(baseline[:,mo[t]-1]+value,0))-d['mu'][:,mo[t]-1])/d['sd'][:,mo[t]-1]
    (F/'fuentes_reserva_2026.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    point={m:lin[m] if m.startswith('ridge') else nets[m] for m in ['ridge_ENSO','ridge_sin_ENSO','red_ENSO','red_sin_ENSO']}
    point['NMME_local']=npred
    bank=(date.year>=2014)&(end.year<=2016);cal=(date.year>=2017)&(end.year<=2019);recent=(date.year>=2023)&(end.year<=2025)
    fixed_params=pd.read_csv(output/'parametros_calibracion_instrumental.csv')
    weather=pd.read_csv(F/'parametros_beta_PIT.csv');weather_nmme=pd.read_csv(F/'parametros_NMME_local.csv')
    sel=pd.read_csv(F/'estaciones_admitidas_evaluacion.csv');sel=sel[sel.admitido]
    monthly=pd.read_parquet(D/'EPMAPS_meses_controlados.parquet');qs=(np.arange(256)+.5)/256
    if corrected:
        factors=pd.read_csv(F/'factores_subcaptacion_Legates.csv');monthly['mes_calendario']=monthly.month.str[5:].astype(int)
        monthly=monthly.merge(factors,on=['codigo','mes_calendario'],validate='many_to_one')
        monthly['lluvia_mes_admitido_mm']*=monthly.factor
    records=[];controls=[]
    for row in sel.itertuples():
        code=row.codigo;u=int(np.flatnonzero(units.unit==row.celda_nativa)[0]);g=monthly[monthly.codigo==code]
        m=g.set_index('month').lluvia_mes_admitido_mm.reindex(d['months']).to_numpy();target=np.full(len(m),np.nan)
        target[:-2]=m[:-2]+m[1:-1]+m[2:]
        available=np.isfinite(target)&d['valid'][u]&np.isfinite(npred[u]);ids=ids2026[available[ids2026]]
        controls.append({'codigo':code,'temporadas_2026':len(ids),'primera':str(date[ids[0]]) if len(ids) else None,
                         'ultima':str(date[ids[-1]]) if len(ids) else None,'ajuste_usa_2026':False})
        if not len(ids):continue
        z=(np.log1p(target)-d['mu'][u,mo-1])/d['sd'][u,mo-1]
        for j,t in enumerate(ids):
            draws=d['y'][u,d['train']&(mo==mo[t])]
            out=scores(draws[None],target[t:t+1],np.array([0.]),np.array([1e20]))
            records.append(rec(code,row.nombre,date[t],'climatologia_CHIRPS','directa',target[t],out,0))
        for model,pred in point.items():
            par=fixed_params[(fixed_params.codigo==code)&(fixed_params.modelo==model)].iloc[0]
            bi=bank&available;ci=cal&available
            if model=='NMME_local':
                direct=d['z'][u,bank&np.isfinite(pred[u])]-pred[u,bank&np.isfinite(pred[u])];w=weather_nmme[weather_nmme.dominio=='Quito grilla'].iloc[0]
            else:
                direct=d['z'][u,bank]-pred[u,bank];w=weather[(weather.modelo==model)&(weather.dominio=='Quito grilla')].iloc[0]
            choices=[('directa',direct,beta_distribution.ppf(qs,w.a,w.b)),
                     ('local_identidad',z[bi]-pred[u,bi],qs),('local_beta_PIT',z[bi]-pred[u,bi],beta_distribution.ppf(qs,par.a,par.b)),
                     ('congelada_2017_2019',z[ci]-pred[u,ci],qs)]
            ri=recent&available
            if ri.sum()>=18:choices.append(('actualizada_3_anios',z[ri]-pred[u,ri],qs))
            for label,residual,q in choices:
                offsets=np.quantile(residual,q);samples=np.maximum(np.expm1(d['mu'][u,mo[ids]-1,None]+d['sd'][u,mo[ids]-1,None]*(pred[u,ids,None]+offsets)),0)
                out=scores(samples,target[ids],np.zeros(len(ids)),np.full(len(ids),1e20))
                for j,t in enumerate(ids):records.append(rec(code,row.nombre,date[t],model,label,target[t],out,j))
    df=pd.DataFrame(records);df.to_parquet(dest/'test_instrumental_reserva_2026.parquet',index=False)
    pd.DataFrame(controls).to_csv(output/'cobertura_reserva_instrumental_2026.csv',index=False)
    metrics=['mae','crps','cobertura80','amplitud80','sesgo_mediana_mm']
    per=df.groupby(['codigo','nombre','modelo','calibracion'])[metrics].mean().reset_index()
    per.to_csv(output/'reserva_2026_por_estacion.csv',index=False)
    avg=per.groupby(['modelo','calibracion'])[metrics].mean().reset_index();avg['n_estaciones']=per.groupby(['modelo','calibracion']).size().to_numpy()
    avg.to_csv(output/'reserva_2026_promedio_estaciones.csv',index=False)
    print(pd.DataFrame(controls).to_string(index=False),flush=True);print(avg.to_string(index=False),flush=True)


def rec(code,name,date,model,label,truth,out,j):
    return {'codigo':code,'nombre':name,'inicio_temporada':str(date),'anio':2026,'modelo':model,'calibracion':label,
            'instrumental_observado_mm':truth,'sesgo_mediana_mm':out['mediana_mm'][j]-truth,
            **{k:float(out[k][j]) for k in ['mediana_mm','mae','crps','cobertura80','amplitud80','intervalo80_inf_mm','intervalo80_sup_mm']}}


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--corregir-subcaptacion',action='store_true');args=parser.parse_args()
    main(args.corregir_subcaptacion)
