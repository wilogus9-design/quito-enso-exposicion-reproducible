"""Audita coincidencias directas de estaciones en CHIRPS; no prueba no-asimilación absoluta."""
from concurrent.futures import ThreadPoolExecutor
import json
import unicodedata
import re
import numpy as np
import pandas as pd
from pyproj import Geod
import rasterio
import truststore
from fuentes_v07 import P,R,F,download
D=P/'2_DATOS/PROCESADOS'


def normalize(name):
    return re.sub(r'[^A-Z0-9 ]','',unicodedata.normalize('NFKD',str(name).upper()).encode('ascii','ignore').decode()).strip()


def parse_station_file(path):
    lines=path.read_text(encoding='utf-8',errors='replace').splitlines()
    if lines[0].strip()!='latitude,longitude,country_seqnum,country_name,station_name':raise ValueError('Esquema CHC cambiado')
    a=pd.DataFrame([row.split(',',4) for row in lines[1:] if row.strip()],columns=['lat','lon','seq','country','name'])
    a['lat']=pd.to_numeric(a.lat,errors='raise');a['lon']=pd.to_numeric(a.lon,errors='raise')
    return a[a.lat.between(-1.,.7)&a.lon.between(-79.3,-77.9)].copy()


def main():
    truststore.inject_into_ssl();base='https://data.chc.ucsb.edu/products/CHIRPS/v3.0/diagnostics/list_of_stations_used/monthly/'
    dates=pd.period_range('2020-01','2026-07',freq='M')
    def get(period):
        file=f'global.stationsUsed.v3.{period.year}.{period.month:02d}.csv'
        info=download(file,base+file,R/'CHC/ESTACIONES_MENSUALES');info['mes']=str(period)
        if not info['ok']:return info,None
        local=parse_station_file(R/'CHC/ESTACIONES_MENSUALES'/file);local['month']=str(period)
        return info,local
    with ThreadPoolExecutor(max_workers=3) as pool:result=list(pool.map(get,dates))
    manifest=[v[0] for v in result];(F/'fuentes_estaciones_incorporadas_CHIRPS.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    local=pd.concat([v[1] for v in result if v[1] is not None],ignore_index=True);local.to_parquet(D/'estaciones_CHIRPS_entorno_Quito.parquet',index=False)
    ep=pd.read_csv(F/'control_totales_instrumentales_EPMAPS.csv');geod=Geod(ellps='WGS84');rows=[]
    for station in ep.itertuples():
        for month in dates:
            period=str(month);group=local[local.month==period]
            if group.empty:
                rows.append({'codigo':station.codigo,'nombre':station.nombre,'mes':period,'distancia_estacion_CHC_m':np.nan,
                             'nombre_CHC_mas_cercano':None,'coincidencia_nombre_candidata':False,'coincidencia_100_m':False,
                             'coincidencia_250_m':False,'coincidencia_1000_m':False,'candidata_incorporacion_directa':False,
                             'sin_estaciones_listadas_en_entorno':True})
                continue
            _,_,distance=geod.inv(np.full(len(group),station.lon),np.full(len(group),station.lat),group.lon.to_numpy(),group.lat.to_numpy())
            best=int(np.argmin(distance));near=group.iloc[best]
            name=normalize(station.nombre);names=group.name.map(normalize)
            matches=names.apply(lambda x:(name in x or x in name) and min(len(name),len(x))>=5)
            rows.append({'codigo':station.codigo,'nombre':station.nombre,'mes':period,'distancia_estacion_CHC_m':float(distance[best]),
                         'nombre_CHC_mas_cercano':near['name'],'coincidencia_nombre_candidata':bool(matches.any()),
                         'coincidencia_100_m':bool(distance[best]<=100),'coincidencia_250_m':bool(distance[best]<=250),
                         'coincidencia_1000_m':bool(distance[best]<=1000),
                         'candidata_incorporacion_directa':bool(distance[best]<=1000 or matches.any()),'sin_estaciones_listadas_en_entorno':False})
    audit=pd.DataFrame(rows);audit.to_csv(F/'auditoria_incorporacion_estaciones_CHIRPS.csv',index=False)
    summary=audit.groupby(['codigo','nombre']).agg(meses_registro_CHC=('mes','nunique'),
                                                  meses_candidata_directa=('candidata_incorporacion_directa','sum'),
                                                  distancia_minima_m=('distancia_estacion_CHC_m','min')).reset_index()
    summary['no_certifica_independencia_absoluta']=True
    summary.to_csv(F/'resumen_incorporacion_CHIRPS.csv',index=False)
    # Factores oficiales, a su resolución nativa 0.5°: no crear falsa precisión.
    legates=[];factors=[];folder='https://data.chc.ucsb.edu/products/CHIRPS/v3.0/diagnostics/legates-willmott_corrections/'
    for month in range(1,13):
        file=f'legates_corrfactor_0.5Deg.90N90S.{month:02d}.tif';info=download(file,folder+file,R/'CHC/LEGATES');legates.append(info)
        if not info['ok']:continue
        with rasterio.open(R/'CHC/LEGATES'/file) as raster:
            if raster.crs is None or not raster.crs.is_geographic:raise ValueError('Geometría Legates inesperada')
            sampled=list(raster.sample([(s.lon,s.lat) for s in ep.itertuples()],masked=True))
            for station,value in zip(ep.itertuples(),sampled):
                v=float(value[0]) if not value.mask.any() else np.nan
                if not np.isfinite(v) or not (1<=v<=3):raise ValueError('Factor Legates inválido')
                factors.append({'codigo':station.codigo,'mes_calendario':month,'factor':v,'resolucion_grados':float(raster.res[0])})
    pd.DataFrame(factors).to_csv(F/'factores_subcaptacion_Legates.csv',index=False)
    (F/'fuentes_Legates.json').write_text(json.dumps(legates,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Listas mensuales',sum(x['ok'] for x in manifest),'/',len(manifest),flush=True)
    selected=pd.read_csv(F/'estaciones_admitidas_evaluacion.csv');selected=selected[selected.admitido].codigo
    print(summary[summary.codigo.isin(selected)].to_string(index=False),flush=True)
    print('Factores min/max',pd.DataFrame(factors).factor.min(),pd.DataFrame(factors).factor.max(),flush=True)


if __name__=='__main__':main()
