"""Sensibilidad secundaria prequential, agregada tras observar la falla fija.

No se presenta como confirmación ciega. Modelos puntuales siguen congelados.
Cada año actualiza únicamente la distribución del error con tres años previos.
Competidor: el mismo banco 2017–2019 congelado. Sin búsqueda de ventanas.
"""
import json
import numpy as np
import pandas as pd
from affine import Affine
from calibracion_v07 import P,P6,D,F
from evaluar_v06 import scores


def main():
    with np.load(P6/'2_DATOS/PROCESADOS/panel_v06.npz') as f:d={k:f[k] for k in f.files}
    with np.load(P6/'2_DATOS/PROCESADOS/predicciones_ridge.npz') as f:lin={k:f[k] for k in f.files}
    with np.load(P6/'2_DATOS/PROCESADOS/predicciones_redes.npz') as f:nets={k:f[k] for k in f.files}
    with np.load(D/'NMME_puntos_locales.npz') as f:nmme={k:f[k] for k in f.files}
    point={m:lin[m] if m.startswith('ridge') else nets[m] for m in ['ridge_ENSO','ridge_sin_ENSO','red_ENSO','red_sin_ENSO']}
    point['NMME_local']=nmme['point_z']
    date=pd.PeriodIndex(d['months'],freq='M');end=date+2;mo=date.month.to_numpy()
    units=pd.read_csv(P6/'2_DATOS/PROCESADOS/unidades.csv',dtype={'unit':str})
    monthly=pd.read_parquet(D/'EPMAPS_meses_controlados.parquet')
    selection=pd.read_csv(F/'estaciones_admitidas_evaluacion.csv');keep=selection[selection.admitido].set_index('codigo')
    direct=pd.read_parquet(D/'test_instrumental_EPMAPS.parquet');qs=(np.arange(256)+.5)/256
    records=[];control=[];future=[]
    for code,item in keep.iterrows():
        u=int(np.flatnonzero(units.unit==item.celda_nativa)[0]);g=monthly[monthly.codigo==code]
        m=g.set_index('month').lluvia_mes_admitido_mm.reindex(d['months']).to_numpy()
        target=np.full(len(m),np.nan);target[:-2]=m[:-2]+m[1:-1]+m[2:]
        valid=np.isfinite(target)&d['valid'][u]&np.isfinite(point['NMME_local'][u])
        z=(np.log1p(target)-d['mu'][u,mo-1])/d['sd'][u,mo-1]
        fixed=(date.year>=2017)&(end.year<=2019)&valid
        for year in range(2020,2027):
            cal=(date.year>=year-3)&(end.year<=year-1)&valid
            ids=np.flatnonzero((date.year==year)&d['test']&valid)
            admitted=cal.sum()>=18
            control.append({'codigo':code,'anio_objetivo':year,'temporadas_pasadas':int(cal.sum()),'admitido':bool(admitted),
                            'ultimo_final_cal':str(end[cal].max()) if cal.any() else None,'ventana_anios':3,
                            'objetivos_del_anio_en_cal':False})
            if not admitted:continue
            for model,pred in point.items():
                for label,bank in [('actualizada_3_anios',cal),('congelada_2017_2019',fixed)]:
                    offsets=np.quantile(z[bank]-pred[u,bank],qs)
                    if len(ids):
                        samples=np.maximum(np.expm1(d['mu'][u,mo[ids]-1,None]+d['sd'][u,mo[ids]-1,None]*(pred[u,ids,None]+offsets)),0)
                        result=scores(samples,target[ids],np.zeros(len(ids)),np.full(len(ids),1e20))
                        for j,t in enumerate(ids):
                            records.append({'codigo':code,'nombre':item.nombre,'modelo':model,'calibracion':label,'inicio_temporada':str(date[t]),'anio':year,
                                            'instrumental_observado_mm':target[t],'mediana_mm':result['mediana_mm'][j],
                                            'sesgo_mediana_mm':result['mediana_mm'][j]-target[t],
                                            **{k:float(result[k][j]) for k in ['mae','crps','cobertura80','amplitud80','intervalo80_inf_mm','intervalo80_sup_mm']}})
                    if year==2026:
                        if model=='NMME_local':
                            baseline=d['y'][u,d['train']&(mo==11)].mean();raw=max(baseline+nmme['future_anomaly_mm'][u],0)
                            pointf=(np.log1p(raw)-d['mu'][u,10])/d['sd'][u,10]
                        else:pointf=(lin if model.startswith('ridge') else nets)[model+'_future'][u]
                        samples=np.maximum(np.expm1(d['mu'][u,10]+d['sd'][u,10]*(pointf+offsets)),0);lo,med,hi=np.quantile(samples,[.1,.5,.9])
                        future.append({'codigo':code,'nombre':item.nombre,'celda_nativa':item.celda_nativa,'modelo':model,'calibracion':label,
                                       'inicio_temporada':'2026-11','fin_temporada':'2027-01','fecha_decision':'2026-10-09',
                                       'lluvia_estacion_mediana_mm':med,'intervalo80_inf_mm':lo,'intervalo80_sup_mm':hi,
                                       'n_residuos_pasados':int(bank.sum()),'estado':'sensibilidad prequential secundaria; no profundidad/inundación'})
    df=pd.DataFrame(records);df.to_parquet(D/'test_instrumental_actualizacion_anual.parquet',index=False)
    # Toda comparación restringe fechas de la referencia a las evaluadas por ambos.
    keys=df[['codigo','inicio_temporada']].drop_duplicates();direct=direct.merge(keys,on=['codigo','inicio_temporada'],validate='many_to_one')
    combo=pd.concat([df,direct],ignore_index=True);combo.to_parquet(D/'test_instrumental_muestra_comun.parquet',index=False)
    metrics=['mae','crps','cobertura80','amplitud80','sesgo_mediana_mm']
    per=combo.groupby(['codigo','modelo','calibracion'])[metrics].mean().reset_index()
    per.to_csv(F/'instrumental_anual_por_estacion.csv',index=False)
    avg=per.groupby(['modelo','calibracion'])[metrics].mean().reset_index()
    avg['n_estaciones']=per.groupby(['modelo','calibracion']).size().to_numpy()
    avg.to_csv(F/'instrumental_anual_muestra_comun.csv',index=False)
    pd.DataFrame(control).to_csv(F/'control_origenes_instrumentales.csv',index=False)
    pd.DataFrame(future).to_csv(F/'pronostico_instrumental_nov2026_ene2027.csv',index=False)
    # Año completo como bloque. No se trata cada estación-temporada como réplica independiente.
    rng=np.random.default_rng(7113);pairs=[]
    reference=combo[(combo.modelo=='climatologia_CHIRPS')&(combo.calibracion=='directa')].set_index(['codigo','inicio_temporada'])
    for (model,calibration),g in combo.groupby(['modelo','calibracion']):
        if model=='climatologia_CHIRPS':continue
        joined=g.set_index(['codigo','inicio_temporada']).join(reference[metrics].add_suffix('_ref'),how='inner')
        for metric in metrics:
            joined['delta']=joined[metric]-joined[metric+'_ref']
            # Cada año tiene igual peso de estaciones; el promedio principal preserva
            # igual peso de estaciones en toda la muestra. Estos estimandos son distintos.
            annual=joined.groupby(['anio','codigo']).delta.mean().groupby('anio').mean()
            draw=rng.integers(0,len(annual),(2000,len(annual)));vals=annual.to_numpy()[draw].mean(axis=1);lo,hi=np.quantile(vals,[.025,.975])
            pairs.append({'modelo':model,'calibracion':calibration,'metrica':metric,'delta_menos_climatologia':annual.mean(),
                          'IC95_anios_inf':lo,'IC95_anios_sup':hi,'n_anios':len(annual),
                          'estimando':'media anual de medias por estación; distinto del promedio principal'})
    pd.DataFrame(pairs).to_csv(F/'instrumental_diferencias_IC_anios.csv',index=False)
    print(avg.to_string(index=False),flush=True)


if __name__=='__main__':main()
