"""Informe y anexo editables, generados desde resultados, sin números simulados."""
import json
import re
import numpy as np
import pandas as pd
from calibracion_v07 import P,P6,D,F


def table(frame):
    def cell(value):
        if pd.isna(value):return 'No disponible'
        if isinstance(value,(int,float,np.number)) and not isinstance(value,(bool,np.bool_)):
            return f'{value:.3f}' if not float(value).is_integer() else str(int(value))
        return str(value).replace('|','/').replace('\n',' ')
    headers=list(frame.columns)
    return '| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+''.join('| '+' | '.join(cell(v) for v in row)+' |\n' for row in frame.itertuples(index=False,name=None))


def main():
    calibration=pd.read_csv(F/'evaluacion_calibracion_v07.csv');nmme=pd.read_csv(F/'comparacion_NMME_misma_muestra.csv')
    raw=pd.read_csv(F/'evaluacion_instrumental_promedio_estaciones.csv');corrected=pd.read_csv(F/'SUBCAPTACION/evaluacion_instrumental_promedio_estaciones.csv')
    reserve=pd.read_csv(F/'reserva_2026_promedio_estaciones.csv');reserve_corrected=pd.read_csv(F/'SUBCAPTACION/reserva_2026_promedio_estaciones.csv')
    sel=pd.read_csv(F/'estaciones_admitidas_evaluacion.csv');stations=sel[sel.admitido]
    coverage=json.loads((F/'control_instrumental_EPMAPS.json').read_text(encoding='utf-8'))
    instrument=pd.read_parquet(D/'test_instrumental_EPMAPS.parquet');cases=len(instrument[['codigo','inicio_temporada']].drop_duplicates())
    temporal=pd.read_csv(F/'cobertura_reserva_instrumental_2026.csv');newcases=int(temporal.temporadas_2026.sum())
    def get(df,model,cal='directa'):return df[(df.modelo==model)&(df.calibracion==cal)].iloc[0]
    rn=get(raw,'red_ENSO');rc=get(raw,'climatologia_CHIRPS');nn=get(reserve,'red_ENSO');nc=get(reserve,'climatologia_CHIRPS')
    gain2026=(1-nn.crps/nc.crps)*100;gaincorrect=(1-get(reserve_corrected,'red_ENSO').crps/get(reserve_corrected,'climatologia_CHIRPS').crps)*100
    c=calibration[(calibration.dominio=='Quito canton')&calibration.modelo.isin(['red_ENSO__identidad','red_ENSO__beta_PIT','climatologia__V06_banco70_o_clima'])]
    calraw=c[c.modelo=='red_ENSO__identidad'].iloc[0];calnew=c[c.modelo=='red_ENSO__beta_PIT'].iloc[0]
    close_nmme=nmme[(nmme.corte_disponibilidad=='dia15')&(nmme.dominio=='Quito canton')&nmme.modelo.isin(['red_ENSO__beta_PIT','NMME_local__beta_PIT','climatologia__V06'])]
    # Extrapolación dinámica: comparar el mismo mes de inicio y todo el banco/cal.
    with np.load(D/'NMME_puntos_locales.npz') as file:dyn={k:file[k] for k in file.files}
    units=pd.read_csv(P6/'2_DATOS/PROCESADOS/unidades.csv',dtype={'unit':str});dates=pd.PeriodIndex(dyn['months'],freq='M')
    past=(dates.year>=2014)&(dates.year<=2019)&np.isfinite(dyn['anomaly_mm']).all(axis=0)
    rows=[]
    for u,unit in units.iterrows():
        subset=dyn['anomaly_mm'][u,past&(dates.month==11)];forecast=dyn['future_anomaly_mm'][u]
        rows.append({'unit':unit.unit,'nombre':unit['name'],'anomalía_NMME_futura_mm':forecast,
                     'min_NDJ_banco_cal_mm':subset.min(),'max_NDJ_banco_cal_mm':subset.max(),'n_NDJ_hist':len(subset),
                     'fuera_rango_NDJ_banco_cal':bool(forecast<subset.min() or forecast>subset.max())})
    pd.DataFrame(rows).to_csv(F/'extrapolacion_NMME_NDJ.csv',index=False)
    future_nn=pd.read_csv(F/'pronostico_calibracion_fija_nov2026_ene2027.csv',dtype={'unit':str})
    future_dyn=pd.read_csv(F/'pronostico_NMME_local_nov2026_ene2027.csv',dtype={'unit':str})
    fut=[]
    for frame,model,label in [(future_nn,'red_ENSO__beta_PIT','Red ENSO'),(future_dyn,'NMME_local__beta_PIT','NMME local')]:
        r=frame[(frame.unit=='1701')&(frame.modelo==model)].iloc[0]
        fut.append({'Modelo':label,'Mediana (mm)':r.get('lluvia_mediana_mm',r.get('mediana_mm')),
                    'Intervalo inferior (mm)':r.intervalo80_inf_mm,'Intervalo superior (mm)':r.intervalo80_sup_mm,
                    'Probabilidad > P80':r.p_humedo})
    # Una tabla breve de transferencias directas con referencia comparable.
    comparison=[]
    for period,frame,corr,n in [('2020–2025',raw,corrected,5),('Reserva 2026',reserve,reserve_corrected,4)]:
        for model,label in [('climatologia_CHIRPS','Climatología'),('red_ENSO','Red ENSO'),('NMME_local','NMME local')]:
            row=get(frame,model);co=get(corr,model)
            comparison.append({'Periodo':period,'Modelo':label,'Estaciones':n,'CRPS observado (mm)':row.crps,
                               'CRPS subcaptación (mm)':co.crps,'Cobertura observada (%)':row.cobertura80*100,
                               'Cobertura subcaptación (%)':co.cobertura80*100})
    headline=pd.DataFrame(comparison);headline.to_csv(F/'tabla_principal_verificacion.csv',index=False)
    summary=f'''Evaluamos si los antecedentes de El Niño–Oscilación del Sur mejoran los pronósticos de lluvia estacional para orientar la planificación territorial en Ecuador. Integramos lluvia CHIRPS3, redes neuronales y regresiones regularizadas, pronósticos dinámicos NMME archivados y pluviómetros de Quito. Separamos ajuste, banco de errores, recalibración y evaluación, y distinguimos la escala meteorológica de la exposición urbana. En Quito, la recalibración de la red con ENSO elevó la cobertura de su intervalo de 80 % de {calraw.cobertura80*100:.1f} % a {calnew.cobertura80*100:.1f} %. Cinco estaciones superaron controles de cobertura y conciliación diaria–mensual. En 2020–2025, la climatología conservó el menor error promedio instrumental. En una reserva adicional de 2026 de {newcases} casos en cuatro estaciones, la red con ENSO redujo el error probabilístico {gain2026:.1f} % frente a la climatología; la reducción fue {gaincorrect:.1f} % al corregir subcaptación. Los intervalos permanecieron insuficientes en esa reserva. La contribución es una evaluación reproducible entre modelos y soportes espaciales, con controles instrumentales y límites explícitos para usar las proyecciones en la planificación de exposición.'''
    abstract=f'''We evaluate whether antecedents of El Niño–Southern Oscillation improve seasonal rainfall forecasts to guide territorial planning in Ecuador. We integrate CHIRPS3 rainfall, neural networks and regularized regressions, archived NMME dynamical forecasts, and Quito rain gauges. We separate fitting, the error bank, recalibration, and evaluation, and distinguish the meteorological scale from urban exposure. In Quito, recalibration of the network with ENSO increased coverage of its 80 % interval from {calraw.cobertura80*100:.1f} % to {calnew.cobertura80*100:.1f} %. Five stations passed coverage and daily–monthly reconciliation checks. In 2020–2025, climatology retained the lowest average instrumental error. In an additional 2026 reserve of {newcases} cases at four stations, the network with ENSO reduced probabilistic error by {gain2026:.1f} % relative to climatology; the reduction was {gaincorrect:.1f} % after correcting undercatch. Intervals remained insufficient in that reserve. The contribution is a reproducible evaluation across models and spatial supports, with instrumental checks and explicit limits for using projections in exposure planning.'''
    summary=summary.replace('El Niño–Oscilación del Sur mejoran','El Niño–Oscilación del Sur (ENSO) mejoran').replace('lluvia CHIRPS3,','lluvia Climate Hazards Center Infrared Precipitation with Stations version 3 (CHIRPS3),').replace('pronósticos dinámicos NMME archivados','pronósticos dinámicos North American Multimodel Ensemble (NMME) archivados')
    abstract=abstract.replace('El Niño–Southern Oscillation improve','El Niño–Southern Oscillation (ENSO) improve').replace('CHIRPS3 rainfall,','Climate Hazards Center Infrared Precipitation with Stations version 3 (CHIRPS3) rainfall,').replace('archived NMME dynamical forecasts','archived North American Multimodel Ensemble (NMME) dynamical forecasts')
    if len(summary.split())>200:raise ValueError('Resumen supera 200 palabras')
    text=fr'''# ENSO y lluvia estacional en Ecuador: verificación multifuente

Wilson Gustavo Morales Lastra*  
*Investigador independiente. wilson.morales@epn.edu.ec. ORCID: https://orcid.org/0009-0008-3413-3705.

Códigos JEL: C53; Q54; R14

## Resumen

{summary}

## Abstract

{abstract}

## 1. Motivación y contribución

La anticipación de lluvia estacional puede apoyar la planificación de exposición y la preparación de servicios. La relación ENSO–lluvia en Ecuador está establecida en antecedentes científicos, con diferencias entre la Costa y los Andes; no constituye por sí misma la novedad de este trabajo [@barnston2014; @paliz2026]. La extensión propone evaluar calibración, transferencia a instrumentos locales y comparación dinámica conservando una separación explícita de soportes. Un mapa fino de exposición construida no convierte una variable meteorológica de 0.05° en lluvia o inundación validada a 10 m.

La V06 se conserva como referencia. La V07 es una extensión retrospectiva: sus métodos se diseñaron después de conocer resultados generales de la V06. No se presenta como prueba ciega anterior a esos datos. La reserva adicional de 2026 no intervino en el ajuste ni en la selección de modelos. Sus datos se recuperaron retrospectivamente, no son un registro de emisión en vivo. Se publican todas las variantes, incluidas las que empeoran.

## 2. Datos, periodos y controles de medición

Tabla 1. Series y soportes utilizados.

| Serie | Desde | Hasta | Frecuencia y soporte | Papel |
| --- | --- | --- | --- | --- |
| CHIRPS3 RNL | 1981-01 | 2026-08 | Mensual, 0.05°; 218 cantones y 186 celdas Quito | Objetivo y antecedentes de lluvia |
| Índices OISST Niño 1+2, 3.4 y 4 | 1982-01 | 2026-08 | Mensual, °C | Antecedentes ENSO con rezago conservador |
| NMME archivado recuperado | 2013-12 | 2026-10 | Medias mensuales y anomalías, 1° | Banco histórico y proyección con posprocesamiento local |
| GSOD, seis códigos próximos a Quito | 2011-01 | 2025-12 | Diario, pluviómetros | Flags y concordancia diaria |
| EPMAPS, series seleccionadas de Quito | 2000-05 | 2026-07 | Diario y mensual, punto instrumental | Transferencia y verificación estacional |
| Registros CHIRPS de estaciones incorporadas | 2020-01 | 2026-07 | Mensual, coordenadas y nombres | Auditoría de coincidencias directas |
| Factores Legates–Willmott | No aplica | No aplica | Doce factores mensuales climatológicos a 0.5° | Sensibilidad por subcaptación |

Fuente: elaboración propia con archivos de Climate Hazards Center, Climate Prediction Center, National Centers for Environmental Information y Empresa Pública Metropolitana de Agua Potable y Saneamiento (EPMAPS). NOAA corresponde a National Oceanic and Atmospheric Administration. Para NMME se indican meses de inicialización; para las otras series, meses observacionales. Cada estación conserva su fecha inicial y final específica en los archivos de control. Se usan índices hasta agosto 2026 y no se retroextienden antes de enero 1982.

CHIRPS3 combina observaciones de estaciones con información satelital. Su variante diaria RNL desagrega pentadas usando ERA5: el valor diario no representa una ventana observacional uniforme de todos los pluviómetros [@funk2026; @chc2026diagnosticos]. Por ello el cotejo GSOD diario es concordancia, no certificación de ventanas idénticas; se incluye sensibilidad de ±1 día. Se aceptan únicamente flags D, F y G, se rechazan H e I incluso cuando indican 0, y 99.99 no se interpreta como ausencia de lluvia. Se recuperaron 5367 días admisibles y solo dos meses completos entre 1080 meses-código del calendario evaluado [@noaa2020gsod].

De 132 estaciones EPMAPS se preseleccionaron 28 por ubicación dentro de Quito y al menos 60 meses anteriores a 2014. Sus {coverage['meses_controlados']} meses se conciliaron con días publicados: {coverage['meses_admitidos']} pasaron el control. Cada mes admitido tiene todos sus días informados, precipitación no negativa y diferencia diaria–mensual dentro de 0.5 mm + 0.5 % del total. Los meses incompletos no se imputan. El portal no expone flags metrológicos originales; la coincidencia de sumas es un control interno de consistencia, no una calibración del sensor [@epmaps2026lluvia].

Tabla 2. Estaciones que superan la cobertura predefinida.

{table(stations[['codigo','nombre','celda_nativa','temporadas_banco','temporadas_calibrador','temporadas_test_comunes']].rename(columns={'codigo':'Código','nombre':'Estación','celda_nativa':'Celda nativa','temporadas_banco':'Banco','temporadas_calibrador':'Calibración','temporadas_test_comunes':'Test'}))}
Fuente: elaboración propia con series públicas EPMAPS y controles diarios. Los {cases} casos estación–temporada de test no son réplicas independientes.

Se contrastaron 79 registros mensuales de estaciones incorporadas a CHIRPS. Para las cinco estaciones admitidas no se encontraron coincidencias candidatas por nombre o proximidad de hasta 1000 m; se conservan también umbrales de 100 y 250 m. Las distancias mínimas observadas van de 2919 m a 15974 m. Esto respalda ausencia de coincidencia directa identificada en el registro público, pero no demuestra ausencia absoluta de reutilización mediante alias, coordenadas erróneas o fuentes indirectas. No se confunde independencia del ajuste de nuestra red con independencia perfecta del producto CHIRPS.

CHIRPS3 corrige subcaptación. Para evitar comparar inadvertidamente referencias físicas diferentes se conserva el pluviómetro original y se añade una sensibilidad multiplicando cada mes por el factor oficial Legates–Willmott en su soporte nativo de 0.5°. Los factores extraídos en las estaciones de Quito están entre 1.03 y 1.07. Esa corrección climatológica no sustituye información local sobre viento, exposición, tipo de instrumento o mantenimiento [@funk2026; @chc2026diagnosticos].

## 3. Especificación y validación

Sea $Y_{{u,t}}=P_{{u,t}}+P_{{u,t+1}}+P_{{u,t+2}}$ la acumulación de lluvia en mm. El objetivo transformado es $Z_{{u,t}}=[\log(1+Y_{{u,t}})-\mu_{{u,m}}]/\sigma_{{u,m}}$, con referencia estacional de entrenamiento y mes de inicio $m$. Las redes de V06 tienen dos capas ocultas SiLU de 64 y 32 unidades, tres semillas por variante y salida escalar; sus pesos entrenados con RTX 5070 se reutilizan sin cambiar por los resultados V07. Las regresiones ridge usan el mismo conjunto informacional pertinente. La selección de regularización y época se realiza en 2011–2013, no en test. Los modelos con y sin ENSO permanecen disponibles. La climatología es un competidor principal.

Las temporadas de entrenamiento terminan hasta 2010, la selección hasta 2013, el banco de residuos está contenido en 2014–2016 y la recalibración en 2017–2019. El test está contenido en 2020–2025. Las ventanas que atraviesan estas fronteras se excluyen. Para una predicción puntual $\hat Z$ se obtiene una distribución empírica $F_0$ de residuos del banco. La transformación es $F(y)=B_{{a,b}}(F_0(y))$, donde $B_{{a,b}}$ es la función acumulada beta [@gneiting_ranjan2013]. Se ajustan dos parámetros a rangos PIT suavizados del bloque de calibración, acotados a [0.2, 8], con penalización fija 0.01 hacia identidad. Para las comparaciones en CHIRPS se agrupa por dominio, separando Quito cantón y Quito grilla de Sierra, y se utiliza el mismo número de 256 cuantiles para identidad y transformación.

La puntuación probabilística principal es CRPS, calculada como $E|X-y|-\tfrac{{1}}{{2}}E|X-X'|$. También se publican MAE, Brier para los extremos P20/P80, cobertura y amplitud del intervalo central de 80 % [@gneiting2007]. La cobertura puntual cercana a 80 % no prueba por sí sola calibración condicional. Se remuestrean años completos para mantener conjuntamente sitios y temporadas del mismo año; seis años de test limitan la precisión de la inferencia. No hay garantías conformales bajo dependencia ni se escoge un modelo por p-valores.

El competidor **NMME local** integra las tres anomalías mensuales archivadas multiplicando cada tasa por los días correspondientes y su factor de unidad. A esa anomalía se suma la media observada de la temporada de entrenamiento; se trunca a 0. Se interpola bilinealmente la grilla 1° al objetivo local. La dispersión se estima mediante errores históricos locales, con los mismos bloques temporales; **no es la dispersión de miembros del ensamble original NMME** [@kirtman2014; @becker2016; @noaa2026nmme]. En test se exige creación del archivo antes del día 15 del mes previo; el corte del día 9 se publica como sensibilidad. La comparación principal comprende 69 temporadas comunes: una emisión tardía no pasa el corte. NetCDF y GRIB1 se leen con su semántica temporal explícita. Para el archivo GRIB antiguo no se certifica la fecha original de publicación, y se utiliza solo como histórico del ajuste, no como evidencia de emisión en tiempo real.

En los instrumentos se evalúan transferencias directas sin modificar la distribución por el test. También se estima posprocesamiento local fijo y una sensibilidad de actualización anual con errores de los tres años previos, ventana fijada sin selección de resultados. Esta última se añadió tras observar el deterioro del ajuste fijo y se identifica como secundaria. Comparar referencias o ventanas diferentes requiere restringir la muestra; todas las tablas incluyen sus denominadores. Las predicciones observacionales no equivalen a atribución de causas ni a una función de daño.

## 4. Resultados

### 4.1. Recalibración y comparación dinámica

En las 70 temporadas Quito del test CHIRPS, la red ENSO pasó de cobertura {calraw.cobertura80*100:.2f} % a {calnew.cobertura80*100:.2f} %, y de CRPS {calraw.crps:.3f} mm a {calnew.crps:.3f} mm. El intervalo se amplió; la mejora de CRPS frente a identidad fue {(1-calnew.crps/calraw.crps)*100:.2f} %. El resumen de todas las regiones y los competidores se conserva: no se generaliza el resultado Quito a la Costa o la Amazonía.

Tabla 3. Quito cantón, 69 temporadas comunes con NMME y corte del día 15.

{table(close_nmme[['modelo','mae','crps','cobertura80','amplitud80']].rename(columns={'modelo':'Modelo','mae':'MAE (mm)','crps':'CRPS (mm)','cobertura80':'Cobertura (fracción)','amplitud80':'Amplitud (mm)'}))}
Fuente: elaboración propia con CHIRPS3 y NMME archivado. Comparar dentro del mismo dominio y muestra. La escala del objetivo y el volumen habitual de lluvia impiden interpretar diferencias brutas entre regiones como diferencias de habilidad.

Figura 1. Error probabilístico y cobertura por dominio.

![](GRAFICOS/figura_1_comparacion_dinamica.svg)

Fuente: elaboración propia. Red ENSO y NMME local usan transformación beta; la climatología mantiene su distribución de entrenamiento. Todos se puntúan en las mismas fechas de cada dominio.

### 4.2. Transferencia instrumental y reserva 2026

Tabla 4. Transferencias directas a instrumentos, con y sin subcaptación.

{table(headline)}
Fuente: elaboración propia con EPMAPS, CHIRPS3 y NMME. Estaciones con igual peso. La corrección modifica la referencia instrumental, no los pronósticos directos. La reserva 2026 comprende cuatro estaciones y {newcases} casos, con diferentes fechas según cobertura; no se equipara a seis años nuevos de evaluación.

En 2020–2025 la red con ENSO redujo CRPS frente a la red sin ENSO, pero no superó la climatología en promedio instrumental. La corrección local de 2014–2016 y la actualización anual no produjeron mejoras uniformes: los resultados desfavorables se conservan. El banco congelado 2017–2019 consiguió una cobertura de 79.5 % para la red ENSO en el test instrumental original, mientras las alternativas tuvieron coberturas inferiores o mayores errores. Ese valor es una sensibilidad secundaria, no motivo para seleccionar retrospectivamente un ganador.

En la reserva 2026, la transferencia directa de la red ENSO obtuvo CRPS {nn.crps:.3f} mm frente a {nc.crps:.3f} mm de la climatología, una reducción de {gain2026:.2f} %. Con factores de subcaptación la reducción fue {gaincorrect:.2f} %. La mejora central no resuelve la cobertura: solo {nn.cobertura80*100:.2f} % de casos quedó dentro de su intervalo de 80 % sin corrección, y {get(reserve_corrected,'red_ENSO').cobertura80*100:.2f} % con corrección. Son solo {newcases} ventanas solapadas de un año parcial; no sustentan una precisión anual general ni una prueba concluyente de superioridad.

Figura 2. Error instrumental antes y después de corregir subcaptación.

![](GRAFICOS/figura_2_verificacion_instrumental.svg)

Fuente: elaboración propia. No se comparan el promedio de tres estaciones actualizado y el de cuatro estaciones directo como si tuvieran la misma muestra.

### 4.3. Proyección condicionada para noviembre 2026–enero 2027

Tabla 5. Proyecciones alternativas de lluvia para Quito cantón.

{table(pd.DataFrame(fut))}
Fuente: elaboración propia. Fecha de decisión 2026-10-09. La red utiliza antecedentes hasta agosto; el competidor dinámico usa inicialización octubre. Los modelos difieren en información y estructura. Intervalos empíricos condicionados, sin incertidumbre completa de parámetros o medición.

La discrepancia entre modelos es información pertinente para la preparación. La anomalía NMME futura de Quito queda fuera del rango de las temporadas NDJ disponibles en el banco/calibrador; se adjunta el diagnóstico de extrapolación y su reducido número de referencias estacionales. Las probabilidades cercanas a 1 no deben interpretarse como certidumbre física: proceden de un modelo y un banco empírico limitado, y la reserva instrumental muestra cobertura insuficiente. No se transforma esta proyección en hectáreas inundadas, viviendas dañadas o pérdidas monetarias.

Figura 3. Soportes meteorológicos y estaciones de verificación en Quito.

![](GRAFICOS/figura_3_soportes_y_estaciones.svg)

Fuente: elaboración propia. Los cuadrados son celdas meteorológicas que intersectan Quito, no píxeles de inundación. En el panel NMME la variación local resulta de interpolación y referencia estacional local, no de una resolución dinámica nueva de 0.05°. Las estaciones verificadas se concentran en parte del territorio: no se declara verificada toda la zona rural norte. Los mapas muestran probabilidades de lluvia > P80, no de inundación.

## 5. Alcance, uso y límites

Se dispone de verificación temporal, contraste instrumental controlado y comparación dinámica ejecutada. La ausencia de coincidencias directas en el registro CHIRPS fortalece la transferencia, con la salvedad de aliases y posibles fuentes indirectas. La pequeña reserva 2026 apoya el aporte de ENSO a errores centrales en esa muestra, mientras expone intervalos insuficientes. La recalibración debe describirse por dominio y periodo, sin declararla universalmente resuelta.

La detección SAR de agua observada aborda otra variable. Los trabajos de inundación con Sentinel-1, incluido el de Misra et al. [@misra2025], no constituyen una referencia de lluvia futura ni sustituyen inundaciones pre/post observadas en Quito. Los reportes de incidentes de V05 sostienen análisis de prioridad relativa condicionados a la observación, no probabilidades físicas calibradas por cada píxel urbano.

Los mapas a 10 m disponibles son inventarios/prioridades del enfoque previo. Para convertirlos en un pronóstico físico se necesitan forzantes de lluvia de corto plazo, hidráulica y drenaje, un terreno compatible y referencias de agua observada con exclusiones explícitas. La lluvia de tres meses por sí sola no identifica una calle inundada, duración, profundidad o pérdida de activos. La evaluación de lluvia seca relativa tampoco identifica por sí sola sequía hidrológica.

La comparación oficial de terciles NMME es distinta de los extremos P20/P80 y no se mezcla en estas tablas. La comparación ejecutada corresponde a anomalías dinámicas y posprocesamiento local; no compara las arquitecturas con un modelo SAR de Microsoft ni proclama vencerlo. El ranking Q1 de una revista y la decisión editorial no se garantizan mediante estos controles.

## 6. Conclusiones

La extensión permite comprobar, con datos reales, cuándo ENSO y la recalibración aportan información de lluvia y cuándo no. El resultado más favorable de transferencia directa aparece en la reserva 2026; la climatología mantiene la ventaja promedio en 2020–2025. NMME local es un competidor exigente que explica parte de la mejora regional y muestra diferencias importantes en la proyección futura. Los intervalos aún no tienen cobertura estable en la reserva instrumental.

La contribución defendible es una evaluación probabilística multifuente y multisoporte para planificación de exposición climática, con un caso instrumental Quito y diagnóstico explícito de transferencia. No se sostiene un pronóstico validado de inundación futura a 10 m. Un envío editorial debe mantener este alcance, publicar el protocolo retrospectivo y someter a revisión externa el diseño, las métricas y la interpretación de las probabilidades.

## Bibliografía

Las citas están en `referencias_v07.bib`, con metadatos Crossref de las referencias nuevas. Se adjunta el estilo `apa.csl` del repositorio Citation Style Language para compilación APA 7. La entrega de BibTeX y del estilo no equivale a revisión editorial de cada cita.

## Disponibilidad y reproducibilidad

La ejecución tiene un único punto de entrada Python y conserva cachés y bitácoras. Se entregan tablas CSV editables, código y gráficos SVG/PNG de 300 dpi. Las series originales se descargan desde sus fuentes; antes de redistribuir registros instrumentales debe verificarse la licencia, especialmente las restricciones WMO indicadas en GSOD para datos no estadounidenses. No se envió ninguna solicitud a organismos ni se accedió a bases privadas. El reconocimiento de NMME incluye el apoyo de NOAA, NSF, NASA y DOE y el mantenimiento del archivo por equipos de NCEP, IRI y NCAR, según las condiciones de uso de CPC.
'''
    (F/'RESULTADOS_V07.md').write_text(text,encoding='utf-8')
    qmd='''---
title: "ENSO y lluvia estacional en Ecuador: verificación multifuente"
author: "Wilson Gustavo Morales Lastra"
lang: es
bibliography: referencias_v07.bib
csl: apa.csl
format:
  docx:
    toc: false
execute:
  enabled: false
---

'''+text.split('\n',1)[1].replace('Wilson Gustavo Morales Lastra*','Wilson Gustavo Morales Lastra^*^').replace('*Investigador independiente.','\\*Investigador independiente.').replace('.svg)', '.png)')
    (F/'ANEXO_VALIDACION_V07.qmd').write_text(qmd,encoding='utf-8')
    (F/'control_redaccion.json').write_text(json.dumps({'palabras_resumen':len(summary.split()),'palabras_abstract':len(abstract.split()),
            'palabras_documento_aproximadas':len(text.split()),'casos_instrumentales_test':cases,'casos_2026':newcases,
            'Word_V06_no_modificado':True,'formato_editable_entregado':'qmd','figuras_nuevas_verificadas':3},ensure_ascii=False,indent=2),encoding='utf-8')
    print('Anexo guardado',len(text.split()),'palabras aproximadas; resumen',len(summary.split()),flush=True)


if __name__=='__main__':main()
