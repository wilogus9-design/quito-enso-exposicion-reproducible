"""Flags GSOD, denominador calendario y cotejo CHIRPS en puntos instrumentales.

Se rechazan H/I incluso cuando PRCP dice 0. No imputa meses incompletos.
El cotejo no certifica independencia de estaciones respecto a CHIRPS.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import pandas as pd
import numpy as np
import requests
import truststore
import ee
import re
from fuentes_v07 import P,R,F,STATIONS
D=P/'2_DATOS/PROCESADOS'


def valid_rain(amount, flag):
    return (amount.notna() & amount.ge(0) & amount.lt(99.99) & flag.isin(['D','F','G']))


def main():
    truststore.inject_into_ssl();D.mkdir(parents=True,exist_ok=True);F.mkdir(parents=True,exist_ok=True)
    raw=pd.concat([pd.read_csv(file,dtype={'STATION':str}) for file in sorted((R/'GSOD').glob('*.csv'))],ignore_index=True)
    raw['DATE']=pd.to_datetime(raw.DATE);raw['PRCP_ATTRIBUTES']=raw.PRCP_ATTRIBUTES.astype(str).str.strip()
    if raw.duplicated(['STATION','DATE']).any():raise ValueError('Días duplicados')
    raw['precipitacion_24h_valida']=valid_rain(raw.PRCP,raw.PRCP_ATTRIBUTES)
    raw['lluvia_24h_mm']=np.where(raw.precipitacion_24h_valida,raw.PRCP*25.4,np.nan)
    dates=pd.date_range('2011-01-01','2025-12-31',freq='D')
    idx=pd.MultiIndex.from_product([STATIONS,dates],names=['STATION','DATE'])
    full=raw.set_index(['STATION','DATE']).reindex(idx).reset_index()
    full['month']=full.DATE.dt.to_period('M').astype(str)
    monthly=full.groupby(['STATION','month']).agg(dias_calendario=('DATE','size'),dias_24h_validos=('lluvia_24h_mm','count'),
                                                suma_parcial_mm=('lluvia_24h_mm',lambda x:x.sum(min_count=1))).reset_index()
    monthly['mes_completo']=monthly.dias_24h_validos==monthly.dias_calendario
    monthly['lluvia_mes_mm']=monthly.suma_parcial_mm.where(monthly.mes_completo)
    monthly.to_csv(F/'cobertura_instrumental_GSOD.csv',index=False)
    raw.groupby(['STATION','PRCP_ATTRIBUTES']).size().rename('dias').reset_index().to_csv(F/'flags_instrumentales_GSOD.csv',index=False)
    stations=raw.groupby('STATION')[['LATITUDE','LONGITUDE','ELEVATION']].median().reset_index()
    stations=stations.merge(raw.groupby('STATION').NAME.first().reset_index(),on='STATION')
    stations.to_csv(F/'estaciones_verificacion.csv',index=False)
    raw[['STATION','DATE','PRCP','PRCP_ATTRIBUTES','lluvia_24h_mm','precipitacion_24h_valida']].to_parquet(D/'gsod_diario_controlado.parquet',index=False)
    # CHIRPS revisado: esta extracción comprueba concordancia, no disponibilidad histórica.
    ee.Initialize(project='verdant-art-479615-c4')
    points=ee.FeatureCollection([ee.Feature(ee.Geometry.Point([float(row.LONGITUDE),float(row.LATITUDE)]),{'station':row.STATION})
                                 for row in stations.itertuples()])
    folder=R/'CHIRPS_ESTACIONES_BANDAS';folder.mkdir(parents=True,exist_ok=True)
    collection=ee.ImageCollection('UCSB-CHC/CHIRPS/V3/DAILY_RNL').select('precipitation')
    projection=collection.first().projection()
    def get_year(year):
        path=folder/f'{year}.csv'
        if not path.exists():
            images=collection.filterDate(f'{year}-01-01',f'{year+1}-01-01')
            # Una sola operación espacial por año: evitar 365 agregaciones paralelas.
            bands=images.map(lambda img:img.rename('rain').set('system:index',img.date().format('YYYYMMdd'))).toBands()
            fc=bands.sampleRegions(collection=points,properties=['station'],projection=projection,scale=projection.nominalScale(),geometries=False)
            url=fc.getDownloadURL(filetype='CSV')
            response=requests.get(url,timeout=(15,120));response.raise_for_status();path.write_bytes(response.content)
        print('CHIRPS estaciones',year,flush=True)
        wide=pd.read_csv(path,dtype={'station':str});cols=[c for c in wide if re.fullmatch(r'\d{8}_rain',c)]
        if len(cols) not in [365,366]:raise ValueError('Bandas diarias incompletas o mal identificadas')
        long=wide.melt(id_vars=['station'],value_vars=cols,var_name='band',value_name='first')
        long['date']=pd.to_datetime(long.band.str[:8],format='%Y%m%d')
        return long[['station','date','first']]
    rain=pd.concat([get_year(year) for year in range(2011,2026)],ignore_index=True)
    rain['date']=pd.to_datetime(rain.date)
    if rain.duplicated(['station','date']).any():raise ValueError('Extracción duplicada')
    paired=raw.merge(rain,left_on=['STATION','DATE'],right_on=['station','date'],validate='one_to_one')
    paired=paired[paired.precipitacion_24h_valida].copy();paired['chirps_mm']=paired['first']
    # El día de acumulación GSOD puede incluir el anterior: sensibilidad prefijada ±1 día.
    for shift in [-1,1]:
        a=rain.rename(columns={'first':'chirps_shift'+str(shift)}).copy();a['date']-=pd.Timedelta(days=shift)
        paired=paired.merge(a[['station','date','chirps_shift'+str(shift)]],on=['station','date'],how='left',validate='one_to_one')
    paired.to_parquet(D/'cotejo_gsod_chirps_diario.parquet',index=False)
    result=[]
    for station,g in paired.groupby('STATION'):
        for offset,col in [(0,'chirps_mm'),(-1,'chirps_shift-1'),(1,'chirps_shift1')]:
            h=g.dropna(subset=[col,'lluvia_24h_mm']);delta=h[col]-h.lluvia_24h_mm
            result.append({'station':station,'desfase_dias':offset,'dias_pareados':len(h),'primer_dia':str(h.DATE.min().date()),
                           'ultimo_dia':str(h.DATE.max().date()),'media_instrumental_mm':h.lluvia_24h_mm.mean(),
                           'media_CHIRPS_mm':h[col].mean(),'sesgo_CHIRPS_menos_estacion_mm':delta.mean(),
                           'mae_mm':delta.abs().mean(),'rmse_mm':np.sqrt((delta**2).mean()),
                           'correlacion':h[col].corr(h.lluvia_24h_mm),
                           'muestra':'solo acumulaciones completas informadas; no todos los días, potencial selección por lluvia'})
    pd.DataFrame(result).to_csv(F/'verificacion_instrumental_diaria.csv',index=False)
    status={'dias_archivo':len(raw),'dias_24h_validos':int(raw.precipitacion_24h_valida.sum()),
            'meses_calendario':len(monthly),'meses_completos':int(monthly.mes_completo.sum()),
            'independencia_de_CHIRPS_demostrada':False,'no_se_imputan_99_99_H_I':True,
            'no_es_verificacion_de_inundacion':True,
            'licencia':'GSOD documentación WMO: comprobar autorización de redistribución antes de publicar registros no estadounidenses; descargar con código y no redistribuir archivos crudos sin revisión.',
            'CHIRPS_coleccion':'UCSB-CHC/CHIRPS/V3/DAILY_RNL','CHIRPS_hashes':{path.name:hashlib.sha256(path.read_bytes()).hexdigest() for path in folder.glob('*.csv')}}
    (F/'control_verificacion_instrumental.json').write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(status,ensure_ascii=False)[:1300],flush=True)


if __name__=='__main__':main()
