"""Inspección de metadatos públicos; no asume formato ni unidades."""
from pathlib import Path
from urllib.parse import urljoin
import json
from scipy.io import netcdf_file
from fuentes_v07 import P,R,F,download,Links
import truststore


def main():
    truststore.inject_into_ssl()
    urls={
        'nmme_enero2014':'https://ftp.cpc.ncep.noaa.gov/NMME/realtime_anom/ENSMEAN/2014010800/',
        'nmme_enero2016':'https://ftp.cpc.ncep.noaa.gov/NMME/realtime_anom/ENSMEAN/2016010800/',
        'nmme_enero2020':'https://ftp.cpc.ncep.noaa.gov/NMME/realtime_anom/ENSMEAN/2020010800/',
        'nmme_oct2026':'https://ftp.cpc.ncep.noaa.gov/NMME/realtime_anom/ENSMEAN/2026100800/',
        'nmme_prob_historico':'https://ftp.cpc.ncep.noaa.gov/NMME/prob/historical/',
        'nmme_prob_netcdf':'https://ftp.cpc.ncep.noaa.gov/NMME/prob/netcdf/',
        'nmme_guia':'https://www.cpc.ncep.noaa.gov/products/NMME/users_guide.html',
    }
    for name,url in urls.items():
        result=download(name+'.txt',url,R/'CATALOGOS'); print(result,flush=True)
        if result['ok']:
            parser=Links();parser.feed((R/'CATALOGOS'/(name+'.txt')).read_text(errors='replace'))
            links=[urljoin(url,x) for x in parser.links]
            (R/'CATALOGOS'/(name+'_links.json')).write_text(json.dumps(links,indent=2),encoding='utf-8')
            print('Enlaces:',len(links),[v for v in links if ('prate' in v or 'prec' in v)][:10],flush=True)
    for name,folder in [('NMME.prate.202001.ENSMEAN.anom.nc',urls['nmme_enero2020']),
                        ('CFSv2.prate.202001.ENSMEAN.fcst.nc',urls['nmme_enero2020']),
                        ('prate.202001.prob.seas.nc','https://ftp.cpc.ncep.noaa.gov/NMME/prob/netcdf/')]:
        result=download(name,folder+name,R/'NMME');print(result,flush=True)
        if result['ok']:
            with netcdf_file(R/'NMME'/name,'r',mmap=False) as nc:
                print('GLOBAL',nc._attributes,'DIMS',nc.dimensions,flush=True)
                for key,v in nc.variables.items():
                    print(key,v.dimensions,v.shape,v._attributes,flush=True)
                    if v.data.size<30:print(v.data,flush=True)
    import rasterio
    name='prate.2014010800.ENSMEAN.ensmean.anom.1x1.grb'
    result=download(name,urls['nmme_enero2014']+name,R/'NMME');print(result,flush=True)
    if result['ok']:
        with rasterio.open(R/'NMME'/name) as raster:
            print('GRIB',raster.count,raster.shape,raster.transform,raster.crs,flush=True)
            print([raster.tags(i) for i in [1,2,3,4]],flush=True)
    cpt=json.loads((R/'CATALOGOS/nmme_cpt_links.json').read_text())
    pick=[x for x in cpt if '_precip_' in x and 'Octic_11-1_2026-2027' in x]
    print('CPT relevantes',pick,flush=True)
    for url in pick:
        result=download(url.split('/')[-1],url,R/'NMME/CPT'); print(result,flush=True)
        if result['ok']:print((R/'NMME/CPT'/url.split('/')[-1]).read_text()[:230],flush=True)


if __name__=='__main__':main()
