"""Descargas públicas pequeñas y trazables. Sin credenciales ni bases privadas."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urljoin
from html.parser import HTMLParser
import hashlib
import json
import requests
import truststore
import pandas as pd

P = Path(__file__).resolve().parents[1]
R = P / '2_DATOS/ORIGINALES'
F = P / '6_FINAL'
BASE = P.parents[2]
SOURCES = {
 'gsod_documentacion': 'https://www.ncei.noaa.gov/data/global-summary-of-the-day/doc/readme.txt',
 'gsod_muestra': 'https://www.ncei.noaa.gov/data/global-summary-of-the-day/doc/sample.csv',
 'nmme_datos': 'https://www.cpc.ncep.noaa.gov/products/NMME/data.html',
 'nmme_realtime_anom': 'https://ftp.cpc.ncep.noaa.gov/NMME/realtime_anom/',
 'nmme_realtime_prob': 'https://ftp.cpc.ncep.noaa.gov/NMME/realtime_prob/',
 'nmme_cpt': 'https://www.ftp.cpc.ncep.noaa.gov/International/nmme/seasonal_nmme_forecast_in_cpt_format/',
 'nmme_cpt_hindcast': 'https://www.ftp.cpc.ncep.noaa.gov/International/nmme/seasonal_nmme_hindcast_in_cpt_format/',
 'nmme_netcdf': 'https://www.ftp.cpc.ncep.noaa.gov/International/nmme/netcdf/',
 'inamhi_lluvia_quito': 'https://www.inamhi.gob.ec/PronosCuanti/prec_acumulada_uio.html',
}
STATIONS = ['84071099999','84072099999','84072599999','84076099999','84088099999','84056099999']


class Links(HTMLParser):
    def __init__(self): super().__init__(); self.links=[]
    def handle_starttag(self, tag, attrs):
        if tag == 'a':
            href=dict(attrs).get('href')
            if href: self.links.append(href)


def download(name, url, folder=R):
    folder.mkdir(parents=True, exist_ok=True)
    path=folder/name
    try:
        if not path.exists():
            res=requests.get(url,timeout=(10,35));res.raise_for_status()
            if '/auth/login' in res.url: raise ValueError('Requiere cuenta: no se descarga como datos')
            path.write_bytes(res.content)
        content=path.read_bytes()
        return {'archivo':str(path.relative_to(P)), 'url':url,'ok':True,'bytes':len(content),
                'sha256':hashlib.sha256(content).hexdigest()}
    except Exception as exc:
        return {'archivo':str(path.relative_to(P)), 'url':url,'ok':False,'error':str(exc)[:180]}


def main():
    truststore.inject_into_ssl(); F.mkdir(parents=True,exist_ok=True)
    jobs=[(key+'.txt',url,R/'CATALOGOS') for key,url in SOURCES.items()]
    jobs += [(f'{station}_{year}.csv',f'https://www.ncei.noaa.gov/data/global-summary-of-the-day/access/{year}/{station}.csv',R/'GSOD')
             for station in STATIONS for year in range(2011,2026)]
    with ThreadPoolExecutor(max_workers=3) as pool:
        result=list(pool.map(lambda job:download(*job), jobs))
    (F/'fuentes_publicas_v07.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    for key in SOURCES:
        path=R/'CATALOGOS'/(key+'.txt')
        if not path.exists(): continue
        parser=Links();parser.feed(path.read_text(encoding='utf-8',errors='replace'))
        (R/'CATALOGOS'/(key+'_links.json')).write_text(json.dumps([urljoin(SOURCES[key],v) for v in parser.links],indent=2),encoding='utf-8')
    print('Fuentes:',sum(x['ok'] for x in result),'/',len(result),flush=True)
    print((R/'CATALOGOS/gsod_documentacion.txt').read_text(errors='replace')[-11000:],flush=True)
    for key in ['nmme_realtime_anom','nmme_realtime_prob','nmme_netcdf']:
        path=R/'CATALOGOS'/(key+'_links.json')
        if path.exists(): print(key,path.read_text()[:6000],flush=True)


if __name__=='__main__': main()
