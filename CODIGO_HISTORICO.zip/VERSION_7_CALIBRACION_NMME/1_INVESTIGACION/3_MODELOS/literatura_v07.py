"""Metadatos bibliográficos verificados en Crossref, fuentes primarias y BibTeX."""
import json
import requests
import truststore
from fuentes_v07 import P,R,F,download
from calibracion_v07 import P6

DOIS={'gneiting_ranjan2013':'10.1214/13-EJS823','kirtman2014':'10.1175/BAMS-D-12-00050.1',
      'becker2016':'10.1175/JCLI-D-14-00862.1','funk2026':'10.1038/s41597-026-07096-4'}


def main():
    truststore.inject_into_ssl();result=[];bib=(P6/'6_FINAL/referencias.bib').read_text(encoding='utf-8')
    for key,doi in DOIS.items():
        file=R/'BIBLIOGRAFIA'/(key+'.json');info=download(file.name,'https://api.crossref.org/works/'+doi,file.parent)
        if not info['ok']:raise RuntimeError(info)
        raw=json.loads(file.read_text(encoding='utf-8'))['message'];result.append({'clave':key,'doi_solicitado':doi,'registro':raw})
        authors=' and '.join(a.get('family','')+', '+a.get('given','') for a in raw.get('author',[]))
        year=raw.get('published',raw.get('issued'))['date-parts'][0][0]
        fields={'author':authors,'title':raw['title'][0],'year':str(year),'journal':raw.get('container-title',[''])[0],
                'volume':raw.get('volume',''),'pages':raw.get('page',raw.get('article-number','')),'doi':raw['DOI']}
        bib+='\n@article{'+key+',\n'+',\n'.join(' '+k+' = {'+str(v).replace('&','\\&')+'}' for k,v in fields.items() if v)+'\n}\n'
    bib+='''
@misc{epmaps2026lluvia,
 author = {{Empresa Pública Metropolitana de Agua Potable y Saneamiento}},
 title = {Climática: series de precipitación diarias y mensuales},
 year = {2026}, url = {https://paramh2o.aguaquito.gob.ec/reportes/consultas/},
 note = {Consulta de datos públicos el 9 de octubre de 2026. No equivale a licencia de redistribución}
}
@misc{chc2026diagnosticos,
 author = {{Climate Hazards Center}}, title = {CHIRPS3 diagnostics: stations used and Legates-Willmott corrections},
 year = {2026}, url = {https://www.chc.ucsb.edu/data/chirps3/diagnostics}
}
@misc{noaa2020gsod,
 author = {{National Centers for Environmental Information}}, title = {Global Surface Summary of Day: data documentation},
 year = {2020}, url = {https://www.ncei.noaa.gov/data/global-summary-of-the-day/doc/readme.txt}
}
@misc{noaa2026nmme,
 author = {{Climate Prediction Center}}, title = {NMME data access and user's guide},
 year = {2026}, url = {https://www.cpc.ncep.noaa.gov/products/NMME/data.html}
}
'''
    (F/'referencias_v07.bib').write_text(bib,encoding='utf-8')
    (F/'referencias_nuevas_verificadas.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    style=download('apa.csl','https://raw.githubusercontent.com/citation-style-language/styles/master/apa.csl',F)
    if not style['ok']:raise RuntimeError(style)
    (F/'fuente_estilo_APA.json').write_text(json.dumps(style,ensure_ascii=False,indent=2),encoding='utf-8')
    print([(r['clave'],r['registro']['title'][0]) for r in result],flush=True)


if __name__=='__main__':main()
