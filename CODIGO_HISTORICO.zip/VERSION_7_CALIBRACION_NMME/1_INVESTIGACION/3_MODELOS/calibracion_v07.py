"""Recalibración beta-PIT con bloques temporales separados y modelos V06 fijos.

1. Residuos 2014–2016. 2. PIT 2017–2019. 3. Verificación 2020–2025.
No elige un método por los resultados de test. Conserva resultados desfavorables.
"""
from pathlib import Path
import sys
import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import betaln
from scipy.stats import beta as beta_distribution

P=Path(__file__).resolve().parents[1]
P6=P.parents[1]/'VERSION_6_ENSO_PREDICTIBILIDAD/1_INVESTIGACION'
D=P/'2_DATOS/PROCESADOS'; F=P/'6_FINAL'
sys.path.insert(0,str(P6/'3_MODELOS'))
from evaluar_v06 import scores

MODELS=['climatologia_calibrada','ridge_sin_ENSO','ridge_ENSO','red_sin_ENSO','red_ENSO','red_ENSO_reciente']
METRICS=['mae','crps','brier_seco','brier_humedo','cobertura80','amplitud80']


def pit(residual, target):
    """Rango suavizado, sin ceros/unos artificiales en PIT finito."""
    residual=np.asarray(residual); target=np.asarray(target)
    return ((target[:,None]>residual).sum(axis=1)+.5*(target[:,None]==residual).sum(axis=1)+.5)/(len(residual)+1)


def fit_beta(p):
    p=np.asarray(p); assert np.all((p>0)&(p<1))
    def objective(theta):
        a,b=np.exp(theta)
        return float(betaln(a,b)-(a-1)*np.log(p).mean()-(b-1)*np.log1p(-p).mean()+.01*np.sum(theta**2))
    result=minimize(objective,np.zeros(2),method='L-BFGS-B',bounds=[(np.log(.2),np.log(8))]*2)
    if not result.success: raise RuntimeError(result.message)
    return np.exp(result.x)


def groups(units):
    result=units.region.astype(str).to_numpy(copy=True)
    result[units.type=='QUITO_CELDA']='Quito grilla'
    result[units.unit=='1701']='Quito canton'
    return result


def main():
    D.mkdir(parents=True,exist_ok=True);F.mkdir(parents=True,exist_ok=True)
    with np.load(P6/'2_DATOS/PROCESADOS/panel_v06.npz') as f:d={k:f[k] for k in f.files}
    units=pd.read_csv(P6/'2_DATOS/PROCESADOS/unidades.csv',dtype={'unit':str}); domain=groups(units)
    with np.load(P6/'2_DATOS/PROCESADOS/predicciones_ridge.npz') as f:linear={k:f[k] for k in f.files}
    with np.load(P6/'2_DATOS/PROCESADOS/predicciones_redes.npz') as f:nets={k:f[k] for k in f.files}
    with np.load(P6/'2_DATOS/PROCESADOS/entrada_futura_nov2026.npz') as f:future={k:f[k] for k in f.files}
    date=pd.PeriodIndex(d['months'],freq='M'); end=date+2; months=date.month.to_numpy()
    bank=(date.year>=2014)&(end.year<=2016); cal=(date.year>=2017)&(end.year<=2019); test=d['test']
    assert not np.any(bank&cal) and not np.any(cal&test)
    assert end[bank].max()<date[cal].min() and end[cal].max()<date[test].min()
    qs=(np.arange(256)+.5)/256; records=[]; parameters=[]; future_rows=[]; diagnostics=[]
    for model in MODELS:
        pred=np.zeros_like(d['z']) if model=='climatologia_calibrada' else linear[model] if model.startswith('ridge') else nets[model]
        new=np.zeros(len(units)) if model=='climatologia_calibrada' else linear[model+'_future'] if model.startswith('ridge') else nets[model+'_future']
        residuals=[]; pits=[]
        for u in range(len(units)):
            bi=bank&d['valid'][u]; ci=cal&d['valid'][u]
            residual=d['z'][u,bi]-pred[u,bi]; assert len(residual)>=30
            residuals.append(residual); pits.append(pit(residual,d['z'][u,ci]-pred[u,ci]))
        ab={}
        for group in sorted(set(domain)):
            us=np.flatnonzero(domain==group)
            if len({len(pits[u]) for u in us})!=1:raise ValueError('El peso temporal no es uniforme')
            values=np.concatenate([pits[u] for u in us]); a,b=fit_beta(values);ab[group]=(a,b)
            parameters.append({'modelo':model,'dominio':group,'a':a,'b':b,'unidades':len(us),
                               'fechas_cal':len(pits[us[0]]),'n_pit_no_independientes':len(values),
                               'banco_hasta':'2016-12','cal_hasta':'2019-12','penalizacion':.01})
        for u,meta in units.iterrows():
            ids=np.flatnonzero(test&d['valid'][u]); q20=d['q20'][u,months[ids]-1];q80=d['q80'][u,months[ids]-1]
            a,b=ab[domain[u]]; residual=residuals[u]
            for label,q in [('identidad',qs),('beta_PIT',beta_distribution.ppf(qs,a,b))]:
                offsets=np.quantile(residual,q)
                samples=np.maximum(np.expm1(d['mu'][u,months[ids]-1,None]+d['sd'][u,months[ids]-1,None]*(pred[u,ids,None]+offsets[None])),0)
                result=scores(samples,d['y'][u,ids],q20,q80)
                vals=pit(residual,d['z'][u,ids]-pred[u,ids])
                if label=='beta_PIT': vals=beta_distribution.cdf(vals,a,b)
                for j,t in enumerate(ids):
                    records.append({'unit':meta.unit,'tipo_unidad':meta.type,'region':meta.region,'dominio':domain[u],
                                    'nombre':meta['name'],'modelo_base':model,'calibracion':label,
                                    'modelo':model+'__'+label,'inicio_temporada':str(date[t]),'anio':date[t].year,
                                    'lluvia_observada_mm':float(d['y'][u,t]),'seco':int(d['y'][u,t]<q20[j]),'humedo':int(d['y'][u,t]>q80[j]),
                                    'pit':float(vals[j]),**{k:float(v[j]) for k,v in result.items()}})
                draws=np.maximum(np.expm1(future['mu'][u]+future['sd'][u]*(new[u]+offsets)),0)
                lo,med,hi=np.quantile(draws,[.1,.5,.9])
                future_rows.append({'unit':meta.unit,'tipo_unidad':meta.type,'nombre':meta['name'],'modelo':model+'__'+label,
                                    'inicio_temporada':'2026-11','fin_temporada':'2027-01','fecha_decision':'2026-10-09',
                                    'ultimo_predictor':'2026-08','lluvia_mediana_mm':med,'intervalo80_inf_mm':lo,'intervalo80_sup_mm':hi,
                                    'p_seco':float((draws<future['q20'][u]).mean()),'p_humedo':float((draws>future['q80'][u]).mean()),
                                    'cal_hasta':'2019-12','estado':'sensibilidad retrospectiva con calibración fija; no mapa de inundación'})
        print('Calibrado',model,flush=True)
    df=pd.DataFrame(records);df.to_parquet(D/'test_calibracion_v07.parquet',index=False)
    pd.DataFrame(parameters).to_csv(F/'parametros_beta_PIT.csv',index=False)
    pd.DataFrame(future_rows).to_csv(F/'pronostico_calibracion_fija_nov2026_ene2027.csv',index=False)
    original=pd.read_parquet(P6/'2_DATOS/PROCESADOS/evaluacion_test_detalle.parquet');original['dominio']=groups_for_records(original)
    summary=df.groupby(['dominio','modelo'])[METRICS].mean().reset_index()
    reference=original.groupby(['dominio','modelo'])[METRICS].mean().reset_index();reference['modelo']+='__V06_banco70_o_clima'
    summary=pd.concat([summary,reference],ignore_index=True);summary.to_csv(F/'evaluacion_calibracion_v07.csv',index=False)
    rng=np.random.default_rng(7109);comparisons=[]
    for (group,model),g in df.groupby(['dominio','modelo_base']):
        annual=g.groupby(['anio','calibracion'])[METRICS].mean().unstack('calibracion')
        count=g[g.calibracion=='identidad'].groupby('anio').size().reindex(annual.index).to_numpy()
        for metric in METRICS:
            delta=(annual[(metric,'beta_PIT')]-annual[(metric,'identidad')]).to_numpy()
            draw=rng.integers(0,len(delta),(2000,len(delta)));sample=(delta[draw]*count[draw]).sum(1)/count[draw].sum(1)
            low,high=np.quantile(sample,[.025,.975])
            comparisons.append({'dominio':group,'modelo_base':model,'metrica':metric,'diferencia_beta_menos_identidad':float(np.average(delta,weights=count)),
                                'IC95_anios_inf':low,'IC95_anios_sup':high,'anios':len(delta)})
        for event in ['seco','humedo']:
            for calibration,h in g.groupby('calibracion'):
                bins=np.minimum((h['p_'+event].to_numpy()*10).astype(int),9)
                for bin_id in range(10):
                    v=h[bins==bin_id]
                    diagnostics.append({'dominio':group,'modelo_base':model,'calibracion':calibration,'evento':event,
                                        'bin':bin_id,'n':len(v),'anios':v.anio.nunique(),
                                        'prob_media':v['p_'+event].mean(),'frecuencia_observada':v[event].mean()})
    pd.DataFrame(comparisons).to_csv(F/'diferencias_calibracion_IC_anios.csv',index=False)
    pd.DataFrame(diagnostics).to_csv(F/'fiabilidad_probabilidades.csv',index=False)
    (F/'control_particiones_calibracion.json').write_text(json.dumps({
        'banco':d['months'][bank].tolist(),'calibrador':d['months'][cal].tolist(),'test':d['months'][test].tolist(),
        '256_cuantiles_en_ambos_metodos':True,'seleccion_por_test':False,'protocolo_retrospectivo':True},indent=2),encoding='utf-8')
    print(summary[summary.dominio=='Quito canton'].to_string(index=False),flush=True)


def groups_for_records(df):
    result=df.region.astype(str).to_numpy(copy=True)
    result[df.tipo_unidad=='QUITO_CELDA']='Quito grilla';result[df.unit=='1701']='Quito canton'
    return result


if __name__=='__main__':main()
