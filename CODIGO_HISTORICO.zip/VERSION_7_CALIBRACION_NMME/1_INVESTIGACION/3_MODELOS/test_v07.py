"""Pruebas de unidades, tiempos, faltantes y resultados; no certificado científico."""
import json
import unittest
import re
import zipfile
import xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
from calibracion_v07 import P,P6,D,F,pit,fit_beta
from nmme_v07 import interpolate,grib_pds
from verificar_estaciones_v07 import valid_rain
from evaluar_v06 import scores


class Controls(unittest.TestCase):
    def test_flags_dont_make_false_zeros(self):
        amount=pd.Series([0.,99.99,0.,1.,-1.,2.,2.]);flag=pd.Series(['G','G','I','A','G','D','F'])
        self.assertEqual(valid_rain(amount,flag).tolist(),[True,False,False,False,False,True,True])

    def test_temporal_partitions(self):
        p=json.loads((F/'control_particiones_calibracion.json').read_text(encoding='utf-8'))
        blocks=[pd.PeriodIndex(p[key],freq='M') for key in ['banco','calibrador','test']]
        for a,b in zip(blocks,blocks[1:]):self.assertLess((a+2).max(),b.min())
        self.assertFalse(p['seleccion_por_test']);self.assertEqual([len(x) for x in blocks],[34,34,70])

    def test_crps_direct(self):
        x=np.array([[0.,2.,4.]]);y=np.array([1.]);expected=np.abs(x-y[:,None]).mean()-.5*np.abs(x[:,:,None]-x[:,None,:]).mean()
        self.assertAlmostEqual(scores(x,y,np.array([.5]),np.array([3.]))['crps'][0],expected)

    def test_beta_near_identity(self):
        a,b=fit_beta((np.arange(1000)+.5)/1000);self.assertAlmostEqual(a,1.,delta=.03);self.assertAlmostEqual(b,1.,delta=.03)
        p=pit(np.arange(5),np.array([-1.,0.,8.]));self.assertTrue(np.all((p>0)&(p<1)))

    def test_descending_latitude(self):
        units=pd.DataFrame({'lat':[.25],'lon':[.5]});field=np.array([[[0.,1.],[1.,2.]]]);lat=np.array([0.,1.]);lon=np.array([0.,1.])
        a=interpolate(field,lat,lon,units);b=interpolate(field[:,::-1],lat[::-1],lon,units)
        self.assertAlmostEqual(a[0,0],.75);np.testing.assert_allclose(a,b)

    def test_grib_months_from_pds(self):
        path=P/'2_DATOS/ORIGINALES/NMME/ANOMALIAS/prate.2014010800.ENSMEAN.ensmean.anom.1x1.grb'
        if not path.exists():self.skipTest('GRIB de ejemplo no descargado')
        p=grib_pds(path);self.assertEqual(str(p[0]['init']),'2014-01');self.assertEqual(str(p[0]['target']),'2014-02')
        self.assertEqual([x['P1'] for x in p],list(range(1,8)))

    def test_instrument_months_complete_and_reconciled(self):
        a=pd.read_parquet(D/'EPMAPS_meses_controlados.parquet');good=a[a.mes_admitido]
        self.assertTrue((good.dias_validos==good.dias_esperados).all())
        self.assertTrue((good.diferencia_mm.abs()<=good.tolerancia_mm).all())
        self.assertTrue(a.loc[~a.mes_admitido,'lluvia_mes_admitido_mm'].isna().all())

    def test_station_selection_and_common_cases(self):
        sel=pd.read_csv(F/'estaciones_admitidas_evaluacion.csv');good=sel[sel.admitido]
        self.assertEqual(set(good.codigo),{'C02','C05','C06','C19','P45'})
        self.assertTrue((good.temporadas_banco>=24).all() and (good.temporadas_calibrador>=24).all() and (good.temporadas_test_comunes>=36).all())
        a=pd.read_parquet(D/'test_instrumental_EPMAPS.parquet')
        counts=a.groupby(['modelo','calibracion']).size();self.assertEqual(counts.nunique(),1);self.assertEqual(int(counts.iloc[0]),272)

    def test_yearly_update_is_only_past(self):
        a=pd.read_csv(F/'control_origenes_instrumentales.csv');a=a[a.admitido]
        years=a.ultimo_final_cal.str[:4].astype(int);self.assertTrue((years<a.anio_objetivo).all());self.assertFalse(a.objetivos_del_anio_en_cal.any())

    def test_probability_and_intervals(self):
        for filename in ['test_calibracion_v07.parquet','test_NMME_local.parquet']:
            a=pd.read_parquet(D/filename)
            for name in ['p_seco','p_humedo','cobertura80']:self.assertTrue(a[name].between(0,1).all())
            self.assertTrue((a.intervalo80_sup_mm>=a.intervalo80_inf_mm).all());self.assertTrue(a.crps.ge(-1e-7).all())

    def test_2026_common_direct_sample(self):
        a=pd.read_parquet(D/'test_instrumental_reserva_2026.parquet');a=a[a.calibracion=='directa']
        counts=a.groupby('modelo').size();self.assertEqual(counts.nunique(),1);self.assertEqual(int(counts.iloc[0]),13)
        self.assertEqual(a.codigo.nunique(),4);self.assertTrue(a.anio.eq(2026).all())

    def test_chc_catalog_coverage(self):
        a=pd.read_csv(F/'auditoria_incorporacion_estaciones_CHIRPS.csv');sel=pd.read_csv(F/'estaciones_admitidas_evaluacion.csv')
        a=a[a.codigo.isin(sel[sel.admitido].codigo)]
        self.assertTrue(a.groupby('codigo').mes.nunique().eq(79).all());self.assertFalse(a.candidata_incorporacion_directa.any())

    def test_raw_data_preserved_in_correction(self):
        a=pd.read_parquet(D/'test_instrumental_EPMAPS.parquet');b=pd.read_parquet(D/'SUBCAPTACION/test_instrumental_EPMAPS.parquet')
        key=['codigo','modelo','calibracion','inicio_temporada'];j=a.merge(b,on=key,suffixes=('_raw','_corr'),validate='one_to_one')
        self.assertTrue((j.instrumental_observado_mm_corr>=j.instrumental_observado_mm_raw).all())
        direct=j[j.calibracion=='directa'];np.testing.assert_allclose(direct.mediana_mm_raw,direct.mediana_mm_corr)

    def test_summary_and_citations(self):
        info=json.loads((F/'control_redaccion.json').read_text(encoding='utf-8'));self.assertLessEqual(info['palabras_resumen'],200)
        text=(F/'RESULTADOS_V07.md').read_text(encoding='utf-8');bib=(F/'referencias_v07.bib').read_text(encoding='utf-8')
        keys=set(re.findall(r'@\w+\{([^,]+),',bib));citations=set()
        for group in re.findall(r'\[[^\]\n]*@[^\]\n]*\]',text):citations.update(re.findall(r'@(\w+)',group))
        self.assertTrue(citations.issubset(keys));self.assertNotIn('\tfrac',text);self.assertIn('\\tfrac',text)

    def test_final_file_limit(self):
        self.assertFalse([str(p) for p in F.rglob('*') if p.is_file() and p.stat().st_size>10_000_000])

    def test_word_native_content(self):
        with zipfile.ZipFile(F/'ANEXO_VALIDACION_V07.docx') as z:
            root=ET.fromstring(z.read('word/document.xml'));styles=ET.fromstring(z.read('word/styles.xml'))
            self.assertIn('word/footnotes.xml',z.namelist())
        ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
        self.assertEqual(len(root.findall('.//w:tbl',ns)),5);self.assertEqual(len(root.findall('.//m:oMath',ns)),8)
        self.assertEqual(len(root.findall('.//w:footnoteReference',ns)),1)
        title=next(node for node in styles.findall('w:style',ns) if node.get('{'+ns['w']+'}styleId')=='Title')
        self.assertIsNone(title.find('.//w:pBdr',ns))
        text=' '.join(n.text or '' for n in root.findall('.//w:t',ns));self.assertNotIn('[@',text);self.assertNotIn('[[FN]]',text)


if __name__=='__main__':unittest.main(verbosity=2)
