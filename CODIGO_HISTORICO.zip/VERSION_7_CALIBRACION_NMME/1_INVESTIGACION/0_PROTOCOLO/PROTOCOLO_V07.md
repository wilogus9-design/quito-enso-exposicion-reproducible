# Verificación y recalibración de lluvia estacional

Fecha de diseño: 2026-10-09. Se conserva la V06. Esta extensión es retrospectiva: los resultados generales de 2020–2025 ya eran conocidos; no se presenta como prueba ciega ni prerregistro anterior a los datos.

## Pregunta y escala

¿Mejora una recalibración probabilística, aprendida en un bloque anterior al test, la cobertura y las puntuaciones de pronósticos de acumulación de lluvia de tres meses? Se contrastan observaciones instrumentales y pronósticos dinámicos emitidos. La escala meteorológica nativa no es 10 m. Exposición construida de 10 m no equivale a pronóstico de inundación de 10 m.

## Reglas antes de ejecutar la extensión

- Modelos puntuales fijos de V06: ajuste hasta 2010 y selección hasta 2013. No reentrenar para perseguir un resultado favorable.
- Banco de residuos: temporadas contenidas en 2014–2016. Recalibración: temporadas contenidas en 2017–2019. Test: temporadas contenidas en 2020–2025. Ninguna temporada cruza una frontera.
- Recalibrador beta del PIT por dominio (Costa, Sierra, Amazonia, Quito cantón, Quito grilla), dos parámetros limitados a [0.2, 8], penalización fija 0.01 hacia identidad. Quito cantón no entra simultáneamente al ajuste Sierra; las celdas nativas tampoco. Todas las unidades de un dominio tienen igual peso. No hay búsqueda de parámetros por resultados del test.
- Comparar identidad y recalibración con 256 cuantiles en ambos casos; publicar CRPS, MAE, Brier seco/húmedo, cobertura y amplitud del intervalo central de 80 %. Mantener climatología V06 y distribución original como referencias, con sus diferencias numéricas explícitas.
- Incertidumbre de diferencias por remuestreo de años completos, no por píxeles independientes. Publicar todas las regiones y ambos extremos. Solo seis años de test: no prometer cobertura universal ni garantía conformal bajo dependencia.
- Estaciones: conservar códigos de aeropuerto antiguo/nuevo separados. No transformar ausencia de precipitación informada en cero. Aceptar como referencia principal solo acumulaciones de 24 h documentadas y meses completos; publicar denominador y flags. Una estación que participó en CHIRPS no constituye validación independiente del producto. Estación puntual y promedio de celda tienen distinto soporte.
- NMME: conservar modelo/versión, inicialización, fecha de archivo, horizonte, unidades y periodo objetivo. Comparaciones solo con las mismas temporadas y anticipos. No reemplazar pronósticos emitidos por hindcasts reconstruidos, ni usar media de ensamble como distribución de miembros. Terciles no equivalen a percentiles 20/80. Conversión mm/día a acumulación exige conocer ponderación temporal del producto.
- Si no hay archivo histórico comparable, publicar contraste prospectivo por separado y declarar qué evaluación no pudo ejecutarse. No llamar NMME al CFSv2 aislado ni viceversa.
- Verificación de inundación física requiere referencias observadas pre/post, exclusiones y áreas observadas, independientes del ajuste. Boletines de lluvia, amenaza municipal y simulaciones no son etiquetas de agua observada.

## Ejecución

Un único punto de entrada ejecutará descargas públicas con caché, controles de flags, calibración, comparación compatible y reporte. Los datos originales se preservan con hash y URL. No se accede a bases privadas ni se envían solicitudes a organismos.

## Ampliación de comparación dinámica, antes de calcular sus puntuaciones

El archivo CPC de anomalías NMME contiene pronósticos mensuales emitidos desde 2011. Se utilizará la inicialización del mes anterior al inicio de la temporada y la suma de sus tres meses objetivo, ponderados por días, no una media estacional multiplicada arbitrariamente. Corte de disponibilidad retrospectivo: día 15 del mes anterior; archivos creados después quedan excluidos de esa comparación. El día 9 se publica como sensibilidad estricta. La fecha de creación no prueba por sí sola disponibilidad de cada vintage. La predicción prospectiva de V06 conserva su corte original 2026-10-09.

Se evaluará un competidor **NMME con referencia y posprocesamiento local**: anomalía dinámica integrada más media observada por temporada en el entrenamiento V06, truncada a 0; residuos 2014–2016 y transformación beta 2017–2019 idénticos al protocolo anterior. Esta distribución no es el ensamble original de miembros NMME. Se incluirán identidad y beta sin elegir entre ellas por el test. La comparación usa interpolación bilineal de la grilla de 1° al mismo objetivo local; no certifica resolución de 0.05° ni 10 m. Mantener además anomalías y fecha/versión originales. La composición del ensamble operativo cambia con el tiempo.

Los terciles oficiales NMME serán un análisis separado solo tras verificar la semántica temporal de sus coordenadas. No se compararán sus Brier directamente con los extremos P20/P80.

### Compatibilidad del archivo antiguo

Los archivos anteriores a 2018 usan GRIB1. Sus meses se extraen de la sección PDS según NCEP ON388: parámetro 59, unidad temporal 3 (mes), indicador 3 (promedio), P2 = P1 + 1. No se usa el `GRIB_VALID_TIME` que GDAL devuelve idéntico para esas bandas porque advierte que no interpreta esa unidad temporal. Se conservan los diagnósticos. El GRIB no informa fecha de publicación: se admite para el banco/calibrador histórico archivado, nunca como prueba de disponibilidad en la emisión original. El corte de fecha de creación de NetCDF se exige en test 2020–2025 y en la proyección. Esto es una verificación retrospectiva del archivo, no reconstrucción certificada de vintages inmutables.

### Contraste instrumental local, antes de calcular sus puntuaciones

Se recuperaron 132 estaciones públicas EPMAPS. Para solicitar comprobación diaria se seleccionan todas las estaciones dentro de la máscara Quito V05 con al menos 60 meses informados antes de 2014, sin utilizar habilidad 2020–2025. Una estación pasa a evaluación estacional si tiene al menos 24 temporadas admisibles para banco 2014–2016, 24 para calibrador 2017–2019 y 36 para test 2020–2025. Cada temporada necesita tres meses completos en días, totales diarios no negativos y concordancia con el mensual publicado dentro de 0.5 mm + 0.5 % del total. No se reconstruyen meses incompletos.

Se cotejará la distribución V07 aprendida sobre CHIRPS contra el pluviómetro sin cambiarla (**transferencia directa**) y un posprocesamiento local de pluviómetro (**residuos 2014–2016, beta 2017–2019**) como análisis separado. No elegir entre ellos por el test. El punto se asigna a su celda CHIRPS nativa contenedora, no a un píxel de lluvia de 10 m. Comparadores: red ENSO, red sin ENSO, ridge ENSO, ridge sin ENSO y NMME local, con temporadas comunes; climatología instrumental entrenada hasta 2010 solo si hay al menos ocho valores para cada mes de inicio evaluado. Puntuaciones principales CRPS, MAE, cobertura y amplitud de 80 %, no nuevos extremos con referencia inventada. Reportar sesgo CHIRPS–estación y falta de flags metrológicos originales/independencia de CHIRPS. La preselección instrumental se añadió después de los resultados CHIRPS y se declara secundaria.
