# Terreno público de Quito

## Recuperado y utilizado

- Copernicus GLO-30 edición 2024_1, DSM y HEM, 15 teselas junto con WorldCover.
- NASA GEDI L2A V002: 259 segmentos recuperados; 132165 huellas elegibles en
  rectángulo, 70600 únicas dentro del DMQ y 76 órbitas. Fechas 2019-04-25 a
  2025-07-06; 2479 huellas sobre clase construida ESA 2021. Es LiDAR espacial
  discontinuo de aproximadamente 25 m, no un barrido urbano continuo.
- Geoide EGM2008 NGA/PROJ, necesario para compatibilizar alturas. La conversión
  manual fue contrastada con una implementación PROJ independiente.
- Superficie ajustada experimental en grilla de 10 m y dominio restringido de
  2017.02 km², evaluada por órbitas y bloques. No es un DTM medido de 10 m.

## Comprobado sin obtener DEM continuo fino

- Geoportal Quito: catálogo, capas municipales, cuencas, redes y catastro.
  El servicio accidente geográfico describe rasgos, no cotas/curvas ni DEM.
  No se descargaron atributos de propietarios.
- IGM: visor raster y páginas temáticas accesibles; conexiones a WCS/WMS y
  configuración MapStore agotaron tiempo. Un timeout no demuestra inexistencia.
- SIGTIERRAS: conexiones a páginas/geoportal agotaron tiempo; no se obtuvo
  el archivo numérico de Quito ni se asumió que una ortofoto RGB sea elevación.
- Watson et al. (2022): paquete Zenodo descargado e inventariado. Tiene
  cobertura, puntos de validación de cobertura y espacios verdes; no contiene
  el DTM/DSM Pleiades utilizado por autores. No se accedió a imágenes restringidas.
- Repositorio UPS: tesis LiDAR de una franja de Mariana de Jesús; la ficha
  consultada adjunta PDF, no una nube LAS o DTM descargable. No se extrajo altura
  desde ilustraciones de esa tesis.
- ArcGIS World Terrain3D: metadatos públicos, servicio multifuente con capacidad
  de visualización. Su pixelSize global no acredita precisión de Quito ni
  autoriza convertirlo en un DEM medido local a esa resolución.
- Mapas antiguos del municipio: sus identificadores publicados actualmente
  devuelven inexistente o inaccesible; no se eludieron permisos.

Las rutas, respuestas, fallos, inventarios y hashes se conservan en
`2_DATOS/ORIGINALES/BUSQUEDA_TERRENO`. No se obtuvo todavía un levantamiento
continuo de terreno desnudo <=10 m que cubra Quito y permita acreditar
microtopografía urbana. Esta carencia no impidió entrenar/evaluar prioridades
o desarrollar el experimento altimétrico, pero sí limita hidrodinámica urbana.
