# Modelo espacial de presencias para Quito

Fijado el 8 de octubre de 2026, antes de entrenar. El mapa municipal de inundación sólo publica niveles Medio y Alto; fuera de ellos no se conoce un negativo físico. Por tanto no entrenaremos una inundación/no inundación inventando ceros fuera de sus polígonos.

El modelo principal será un proceso puntual condicionado al número de reportes SNGR: una regresión log-lineal y una red neuronal aprenden la intensidad espacial relativa de localizaciones reportadas. Los puntos de fondo aproximan la integral del territorio, no son observaciones de ausencia. Se separan inundación y deslizamiento. Los aluviones, menos numerosos, se presentan como referencia separada y no se mezclan con agua.

Datos: reportes 2010–2025, depurados por fecha, duplicado exacto y pertenencia geométrica al cantón. Fecha final de evaluación: 2025-09-30, un cierre mensual conservador anterior al último registro recuperado. No se considera falta de un reporte como ausencia física de evento.

Entrenamiento temporal: 2010–2021; calibración: 2022–2023; test: 2024–2025-09. Evaluación espacial adicional en bloques de 5 km con partición fija por hash y separación de bordes de 250 m; los reportes anteriores a 2024 se reservan por dominio, no por pixeles aleatorios. No incluir coordenadas, parroquia ni ID como predictores.

Variables: altitud, pendiente, posición topográfica y relieve local derivados de DSM Copernicus 30 m; distancias a red hídrica, quebradas y colectores municipales; cobertura ESA WorldCover 2021 a 10 m y densidad de suelo construido a 100/500 m. La red de colectores no proporciona capacidad ni condición hidráulica. Las capas municipales de amenaza se usan para contraste y exposición, no como predictores de la red de reportes.

Referencia espacial de covariables fija: cobertura 2021 y geografía recuperada en 2026. Por ello la evaluación temporal es retrospectiva con estado territorial fijo, no reconstrucción operacional de toda la información disponible en cada fecha. La urbanización municipal 2020/2025 se incorpora por separado para medir cambios de exposición, sin cambiar retrospectivamente las etiquetas del modelo.

Se marginaliza la posición desconocida mediante 25 localizaciones posibles en un radio de 100 m alrededor de cada reporte. No se convierten esas posiciones en 25 positivos ni en una huella observada. La grilla de salida es 10 m; terreno a 30 m y soporte posicional asumido de 100 m. La evaluación conserva estas escalas distintas.

Comparadores: intensidad uniforme; densidad construida con piso positivo 0.01; proceso log-lineal regularizado; red de dos capas 32/16, tres semillas 5101/5102/5103. Seleccionar regularización y temperado usando sólo calibración, nunca test. Métricas: log-intensidad relativa en reportes reservados y captura dentro del 10 % de área priorizada, con versión específica para suelo construido. No usar exactitud de una clasificación con negativos ficticios.

La lluvia pronosticada se entrega en su resolución nativa y se superpone al orden de prioridad. No se multiplica una intensidad de reportes por lluvia para llamarla probabilidad de inundación. El pronóstico físico por píxel, profundidad y duración sigue requiriendo hidrología/hidráulica y referencias independientes. No se predice pobreza por píxel ni se crean etiquetas de daños inexistentes.

Marco metodológico: procesos puntuales de presencias (Warton y Shepherd, 2010) y modelación MaxEnt (Phillips et al., 2006). La adaptación a reportes de riesgos exige reconocer sesgo de registro y no confundir localización de un reporte con toda la huella afectada.
