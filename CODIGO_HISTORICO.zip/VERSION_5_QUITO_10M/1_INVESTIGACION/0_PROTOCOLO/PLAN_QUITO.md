# Quito a 10 m: susceptibilidad, exposición y contexto de lluvia

Fecha: 8 de octubre de 2026. Rama independiente; las versiones anteriores y el lago de datos son entradas de sólo lectura.

## Objetivo

Desarrollar una cartografía por celda de 10 m para priorizar zonas expuestas de Quito, incorporando relieve, cobertura y ocupación del suelo, drenaje, amenazas locales y lluvia. Se separan inundación fluvial, anegamiento urbano y aluviones; no son una única clase de agua detectada por SAR.

## Secuencia

1. Recuperar catálogo municipal, cartografía y metadatos originales. Identificar resolución, fecha, escala, cobertura y definición de las clases. Las copias didácticas de terceros no sustituyen una fuente municipal verificable.
2. Construir grilla métrica EPSG:32717 de 10 m en el cantón 1701. Mantener resolución nativa de cada entrada en el diccionario. No atribuir precisión altimétrica de 10 m a un DEM de 30 m, ni convertir lluvia de kilómetros en medición a 10 m.
3. Integrar cobertura terrestre/ocupación a 10 m y derivados topográficos. Separar terreno, agua habitual y suelo ocupado. No extrapolar datos parroquiales como características individuales de cada vivienda.
4. Si las etiquetas oficiales son utilizables, comparar logística/árboles/red neuronal con bloques espaciales de 5 km separados para entrenamiento, calibración y test. No usar pixeles aleatoriamente mezclados como validación espacial. La red aprendería clases cartográficas de susceptibilidad, no ocurrencia futura de inundación.
5. Incorporar pronóstico diario de lluvia como contexto dinámico a su escala nativa. Un producto de priorización condicionado no es una probabilidad calibrada de inundación por celda ni un modelo hidráulico de profundidad.
6. Validar eventos físicos nuevos cuando existan geometrías y fechas independientes. Los puntos de reportes, por sí solos, no delimitan toda una inundación y la ausencia de reporte no es un negativo.
7. Entregar rasters y vectores georreferenciados, mapas legibles, código secuencial y un informe con incertidumbre, dominios no observados y comparadores.

## Novedad a evaluar

La hipótesis es que combinar información local, ocupación del suelo a 10 m y antecedentes de lluvia mejora la priorización frente a cartografía estática o un pronóstico cantonal. Hay que demostrarlo en validación espacial y temporal, no inferirlo por tener píxeles pequeños o una arquitectura neuronal.

## Decisiones conservadoras

Fuera de cobertura de un mapa oficial: desconocido, no riesgo cero. Datos de alerta o simulación: no observaciones de agua. Probabilidades de clasificación de una cartografía: no probabilidades de evento. La referencia original se conserva; no se presenta una red que imita sus etiquetas como validación física independiente.
