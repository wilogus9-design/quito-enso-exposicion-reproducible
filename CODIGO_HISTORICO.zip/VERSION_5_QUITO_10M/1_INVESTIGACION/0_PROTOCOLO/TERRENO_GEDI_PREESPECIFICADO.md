# Experimento independiente de alturas GEDI

No modifica los modelos de reportes ya entrenados ni sus particiones.

1. Huellas LiDAR GEDI L2A vectoriales originales; calidad 1, degradación 0,
   superficie 1, sesgo de elevación 0 y sensibilidad entre 0.95 y 1. Se eliminan
   duplicados por identificador de disparo y se comprueba el límite municipal.
2. Conversión vertical explícita: H(EGM2008) = h(elipsoidal GEDI) - N(EGM2008).
   El geoide público NGA/PROJ se interpola bilinealmente. No se compara h con H.
3. Evaluación del DSM Copernicus con todas las huellas elegibles, separando
   pendiente <=20 grados y >20 grados. No se eliminan residuos por ser grandes.
4. Experimento de corrección SOLO para pendiente <=20 grados; deja sin estimación
   otras pendientes, agua y nieve. Estos límites son de dominio, no ausencia de
   amenaza. Se usan covariables físicas y cobertura, nunca coordenadas como
   predictor de corrección. El objetivo es altura GEDI-Copernicus, no inundación.
5. Órbitas completas reservadas mediante SHA256('GEDI5100:'+orbita), mod 10:
   0-5 entrenamiento, 6-7 calibración, 8-9 test. Protocolo adicional: bloques 5 km
   con igual regla espacial que los modelos de reportes y margen de 250 m.
6. Referencias: DSM sin corregir; DSM menos la mediana del sesgo de entrenamiento.
   Competidor: HistGradientBoostingRegressor, pérdida absoluta, hojas 7 o 15,
   regularización 1 o 10, 100 iteraciones, learning_rate=.05, semilla 5100.
   Selección únicamente por MAE de calibración. Se informan MAE, RMSE y sesgo
   del test, incluso si la corrección no mejora. Ningún test entrena el modelo.
7. Raster experimental a 10 m usando covariables finas donde existen; el relieve
   original sigue siendo 30 m y las huellas GEDI aproximadamente 25 m. No es un
   levantamiento continuo de 10 m, no valida rasantes, muros ni alcantarillas.
   Su utilidad se decide por errores reservados y cobertura, no por su apariencia.
8. No se usarán por ahora estas alturas para profundidades/dólares ni para proclamar
   inundación futura por píxel. La validación GEDI tampoco es validación de agua.

Fuentes: NASA GEDI L2A; Copernicus GLO-30; NGA EGM2008 distribuido por PROJ;
ESA WorldCover. Estas alturas son otro experimento reproducible, no nuevos
resultados seleccionados retrospectivamente para el artículo de reportes.
