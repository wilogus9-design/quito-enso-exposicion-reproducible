"""Comprueba normalizadores en todos los pixeles válidos, sin usar etiquetas test."""
from pathlib import Path
import json
import hashlib
import math
import numpy as np
import torch
import rasterio
from inferir_gpu import feature_window,logmeanexp
from red_punto_proceso import SpatialNet

P=Path(__file__).resolve().parents[1];D=P/'2_DATOS/PROCESADOS';F=P/'6_FINAL'


def main():
    device='cuda' if torch.cuda.is_available() else 'cpu'
    torch.set_num_threads(4)
    states=json.loads((D/'modelos_lineales.json').read_text(encoding='utf-8'))
    sums={};nets={};normalizers={}
    for hazard in ['INUNDACION','DESLIZAMIENTO']:
        key=hazard+'_espacial';st=states[key];inp=np.load(D/f'entrada_red_{key}.npz')
        normalizers[key]={'beta':np.array(st['beta'])*st['alpha'],'mu':np.array(st['mu'],np.float32),'sd':np.array(st['sd'],np.float32)}
        normalizers[key]['Zlin']=logmeanexp(inp['Xb'][inp['btest']]@normalizers[key]['beta'])
        nets[key]=[]
        for seed in [5101,5102,5103]:
            c=torch.load(D/f'red_{key}_{seed}.pt',map_location=device,weights_only=True)
            m=SpatialNet().to(device);m.load_state_dict(c['state_dict']);m.eval()
            fb=np.load(D/f'scores_red_{key}_{seed}.npz')['fb'][inp['btest']]
            nets[key].append((m,c['alpha'],logmeanexp(fb)))
        sums[key]={'red':0.,'lineal':0.,'construido':0.,'n':0}
    temporal_sums=json.loads((F/'normalizacion_grilla.json').read_text(encoding='utf-8'))['sumas']
    urban_temporal=0.;n_temporal=0
    wc=rasterio.open(D/'worldcover_2021_10m.tif');t=rasterio.open(D/'derivados_30m.tif');den=rasterio.open(D/'densidad_construida_10m.tif');mask=rasterio.open(D/'mascara_quito_10m.tif')
    xx=wc.transform.c+(np.arange(wc.width)+.5)*10
    cache={}
    for row in range(0,wc.height,128):
        X,v,win,nrows=feature_window(wc,t,den,mask,row)
        urban_temporal+=float((X[v,7]+.01).sum());n_temporal+=int(v.sum())
        yy=wc.transform.f-(np.arange(row,row+nrows)+.5)*10
        bx=(xx//5000).astype(int);by=(yy//5000).astype(int)
        folds=np.empty((nrows,wc.width),dtype=np.uint8)
        for yblock in np.unique(by):
          for xblock in np.unique(bx):
            pair=(int(xblock),int(yblock))
            if pair not in cache:cache[pair]=int(hashlib.sha256(('5100:'+str(pair[0])+'_'+str(pair[1])).encode()).hexdigest()[:8],16)%10
            folds[np.ix_(by==yblock,bx==xblock)]=cache[pair]
        edge_x=np.minimum(xx%5000,5000-xx%5000)>=250
        edge_y=np.minimum(yy%5000,5000-yy%5000)>=250
        valid=v&(folds.reshape(-1)>=8)&(edge_y[:,None]&edge_x[None,:]).reshape(-1)
        if valid.any():
          for key in nets:
            st=normalizers[key];XS=(X[valid]-st['mu'])/st['sd'];tensor=torch.as_tensor(XS,device=device)
            with torch.no_grad():
                log=torch.stack([m(tensor)*alpha-Z for m,alpha,Z in nets[key]])
                lr=(torch.logsumexp(log,dim=0)-math.log(3)).cpu().numpy()
            sums[key]['red']+=float(np.exp(lr.astype(float)).sum())
            sums[key]['lineal']+=float(np.exp(XS@st['beta']-st['Zlin']).sum())
            sums[key]['construido']+=float((X[valid,7]+.01).sum());sums[key]['n']+=int(valid.sum())
        if row%2048==0:print('Integración sin etiquetas',row,'/',wc.height,flush=True)
    correction={}
    for key,st in states.items():
        inp=np.load(D/f'entrada_red_{key}.npz');base=np.load(D/'muestras_inciertas.npz')
        umean=float((base['Xb'][inp['btest'],7]+.01).mean())
        if st['protocol']=='temporal':
            s=temporal_sums[st['hazard']]
            correction[key+'_red_ensamble']=math.log(s[0]/s[2]);correction[key+'_punto_loglineal']=math.log(s[1]/s[2])
            correction[key+'_construido_referencia']=math.log((urban_temporal/n_temporal)/umean)
        else:
            s=sums[key]
            correction[key+'_red_ensamble']=math.log(s['red']/s['n']);correction[key+'_punto_loglineal']=math.log(s['lineal']/s['n'])
            correction[key+'_construido_referencia']=math.log((s['construido']/s['n'])/umean)
        correction[key+'_uniforme']=0.
    (F/'integracion_exacta_normalizadores.json').write_text(json.dumps({'correcciones_log':correction,'sumas_espaciales':sums,'n_temporal':n_temporal,
        'nota':'Integración numérica sobre grilla completa; no usa etiquetas test, no selecciona modelos.'},ensure_ascii=False,indent=2),encoding='utf-8')
    print('Normalizadores exactos registrados',flush=True)


if __name__=='__main__':main()
