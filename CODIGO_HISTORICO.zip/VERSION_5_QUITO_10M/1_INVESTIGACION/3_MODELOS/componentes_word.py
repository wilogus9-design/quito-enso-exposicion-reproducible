"""Componentes editables de Word compartidos por el manuscrito Quito."""
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches,Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_ALIGN_VERTICAL


def run_math(text):
    r=OxmlElement('m:r');t=OxmlElement('m:t');t.text=text;r.append(t);return r


def sub(base,index):
    obj=OxmlElement('m:sSub');a=OxmlElement('m:e');b=OxmlElement('m:sub')
    a.append(run_math(base));b.append(run_math(index));obj.extend([a,b]);return obj


def math_paragraph(doc,parts):
    p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.LEFT
    outer=OxmlElement('m:oMathPara');eq=OxmlElement('m:oMath')
    for item in parts:eq.append(sub(*item) if isinstance(item,tuple) else run_math(item))
    outer.append(eq);p._p.append(outer)


def table(doc,b):
    cap=doc.add_paragraph(b['titulo']);cap.paragraph_format.keep_with_next=True
    for r in cap.runs:r.font.size=Pt(10)
    t=doc.add_table(rows=1,cols=len(b['encabezados']));t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
    if len(b['encabezados'])==6:widths=[1.1,.95,1.35,.7,1.15,1.25]
    elif b['titulo'].startswith('Tabla 1'):widths=[1.4,1.5,1.75,1.85]
    else:widths=[2.2,1.3,1.5,1.5]
    borders=OxmlElement('w:tblBorders')
    for key in ['top','left','bottom','right','insideH','insideV']:
        x=OxmlElement('w:'+key);x.set(qn('w:val'),'single');x.set(qn('w:sz'),'4');x.set(qn('w:color'),'D9D9D9');borders.append(x)
    t._tbl.tblPr.append(borders)
    for i,col in enumerate(t.columns):col.width=Inches(widths[i])
    for ri,values in enumerate([b['encabezados'],*b['filas']]):
        row=t.rows[0] if ri==0 else t.add_row();pr=row._tr.get_or_add_trPr();pr.append(OxmlElement('w:cantSplit'))
        if ri==0:pr.append(OxmlElement('w:tblHeader'))
        for i,(cell,value) in enumerate(zip(row.cells,values)):
            cell.width=Inches(widths[i]);cell.text=str(value);cell.vertical_alignment=WD_ALIGN_VERTICAL.CENTER
            cp=cell._tc.get_or_add_tcPr();pad=OxmlElement('w:tcMar')
            for key in ['top','bottom','left','right']:
                el=OxmlElement('w:'+key);el.set(qn('w:w'),'85');el.set(qn('w:type'),'dxa');pad.append(el)
            cp.append(pad)
            if ri==0:
                bg=OxmlElement('w:shd');bg.set(qn('w:fill'),'E9EEF4');cp.append(bg)
            for p in cell.paragraphs:
                p.alignment=WD_ALIGN_PARAGRAPH.LEFT if i==0 or b['titulo'].startswith('Tabla 1') else WD_ALIGN_PARAGRAPH.CENTER
                p.paragraph_format.space_after=Pt(0);p.paragraph_format.line_spacing=1
                for r in p.runs:r.font.size=Pt(9);r.font.name='Arial'
    note=doc.add_paragraph(b['nota']);note.paragraph_format.keep_together=True;note.paragraph_format.space_before=Pt(5)
    for r in note.runs:r.font.size=Pt(9)
