"""Entradas públicas: cobertura 10 m y DSM 30 m, sin falsa resolución altimétrica."""
from pathlib import Path
import json
import math
import hashlib
from concurrent.futures import ThreadPoolExecutor
import ee
import geopandas as gpd
import requests
import truststore
import rasterio

P=Path(__file__).resolve().parents[1]
ROOT=P.parents[2]
RAW=P/'2_DATOS/ORIGINALES/RASTERS'
DATA=P/'2_DATOS/PROCESADOS'


def boundary():
    municipal=P/'2_DATOS/ORIGINALES/VECTORES/limite_dmq_2024.geojson'
    if municipal.exists():q=gpd.read_file(municipal)
    else:
        q=gpd.read_file(ROOT/'EXPOSICION_FEN_NINO/VERSION_2/1_INVESTIGACION/2_DATOS/PROCESADOS/cantones.geojson')
        q=q[q.dpa_canton.astype(str).str.zfill(4)=='1701']
    q=q.to_crs(32717)
    q['geometry']=q.geometry.make_valid()
    return q


def main():
    truststore.inject_into_ssl()
    RAW.mkdir(parents=True,exist_ok=True);DATA.mkdir(parents=True,exist_ok=True)
    q=boundary();q.to_crs(4326).to_file(DATA/'quito_limite.geojson',driver='GeoJSON')
    bb=q.total_bounds
    bounds=[math.floor((bb[0]-600)/30)*30,math.floor((bb[1]-600)/30)*30,math.ceil((bb[2]+600)/30)*30,math.ceil((bb[3]+600)/30)*30]
    info={'crs':'EPSG:32717','bounds':bounds,'pixel_out_m':10,'terrain_native_m':30,'mask_area_m2':float(q.area.sum())}
    (DATA/'grilla.json').write_text(json.dumps(info,indent=2),encoding='utf-8')
    ee.Initialize(project='verdant-art-479615-c4')
    region=ee.Geometry.Rectangle(bounds,proj='EPSG:32717',geodesic=False)
    wc=ee.ImageCollection('ESA/WorldCover/v200').first().select('Map').toUint8()
    demcol=ee.ImageCollection('COPERNICUS/DEM/GLO30_2024_1').filterBounds(region)
    if demcol.size().getInfo()==0:raise RuntimeError('DSM no cubre Quito')
    dem=demcol.mosaic().select(['DEM','HEM']).toFloat()
    jobs=[]
    for name,img,res,tile in [('worldcover_2021',wc,10,4096),('dsm_copernicus_2024_1',dem,30,1536)]:
        w=int(math.ceil((bounds[2]-bounds[0])/res));h=int(math.ceil((bounds[3]-bounds[1])/res))
        for row in range(0,h,tile):
            for col in range(0,w,tile):
                width=min(tile,w-col);height=min(tile,h-row)
                x=bounds[0]+col*res;y=bounds[3]-row*res
                jobs.append((name,img,res,row,col,width,height,x,y))
    def download(job):
        name,img,res,row,col,w,h,x,y=job
        file=RAW/f'{name}_{row:05d}_{col:05d}.tif'
        if file.exists():
            with rasterio.open(file) as src:
                if src.width==w and src.height==h:return file.name+' guardado'
            raise RuntimeError('Tile existente con geometria incoherente')
        params={'crs':'EPSG:32717','crs_transform':[res,0,x,0,-res,y],'dimensions':[w,h],
                'format':'GEO_TIFF','filePerBand':False}
        url=img.getDownloadURL(params)
        response=requests.get(url,timeout=(30,240))
        if response.status_code!=200:raise RuntimeError(f'Tile {name}/{row}/{col}: HTTP {response.status_code}')
        file.with_suffix('.tif.part').write_bytes(response.content)
        file.with_suffix('.tif.part').replace(file)
        with rasterio.open(file) as src:
            if src.width!=w or src.height!=h:raise RuntimeError('Tile recibido de tamano inesperado')
        meta={'dataset':'ESA/WorldCover/v200' if name.startswith('worldcover') else 'COPERNICUS/DEM/GLO30_2024_1',
              'native_m':res,'row':row,'col':col,'width':w,'height':h,'transform':[res,0,x,0,-res,y],
              'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'bytes':file.stat().st_size}
        file.with_suffix('.fuente.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
        return file.name+' descargado'
    print('Tiles previstos',len(jobs),flush=True)
    with ThreadPoolExecutor(max_workers=2) as pool:
        for s in pool.map(download,jobs):print(s,flush=True)


if __name__=='__main__':main()
