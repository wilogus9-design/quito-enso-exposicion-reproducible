"""Descarga de capas públicas de Quito con paginación por OBJECTID y sin datos personales."""
from pathlib import Path
import argparse
import json
import hashlib
from concurrent.futures import ThreadPoolExecutor
import requests
import truststore

P=Path(__file__).resolve().parents[1]
R=P/'2_DATOS/ORIGINALES/VECTORES'
B='https://geoquito.quito.gob.ec/server/rest/services/'
LAYERS={
 'inundacion_municipal':('web_reference_dmot/plan_de_uso_y_gestion_del_suelo_2024/MapServer/19','OBJECTID,nvl_dazin,superf_ha,descripcio'),
 'movimiento_masa_municipal':('web_reference_dmot/plan_de_uso_y_gestion_del_suelo_2024/MapServer/18','OBJECTID,nvl_dazmm,superf_ha,descripcio'),
 'red_hidrica':('web_reference_dmot/plan_de_uso_y_gestion_del_suelo_2024/MapServer/11',None),
 'quebrada_viva':('web_reference_dmot/plan_de_uso_y_gestion_del_suelo_2024/MapServer/14',None),
 'colector':('web_reference_dmot/plan_de_uso_y_gestion_del_suelo_2024/MapServer/77',None),
 'microcuencas':('Hosted/cuencas_hidrograficas_dmq/FeatureServer/2',None),
 'parroquias':('Hosted/Parroquias_DMQ/FeatureServer/0',None),
 'limite_dmq_2024':('Hosted/limite_dmq_pugs_a_2024/FeatureServer/0',None),
 'mancha_urbana_2025':('Hosted/mancha_urbana_a_2025/FeatureServer/0',None),
 'cobertura_2020':('Hosted/cobertura_suelo_a_2020/FeatureServer/0',None),
 'cobertura_2025':('Hosted/cobertura_suelo_a_2025/FeatureServer/0',None),
}


def fetch(url,params):
    r=requests.get(url,params=params,timeout=(20,60))
    r.raise_for_status()
    obj=r.json()
    if obj.get('error'):raise RuntimeError(str(obj['error']))
    return obj


def download(name):
    service,fields=LAYERS[name]
    output=R/(name+'.geojson')
    if output.exists():return name+' guardado'
    base=B+service
    meta=fetch(base,{'f':'json'})
    (R/(name+'_metadatos.json')).write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
    oid=meta.get('objectIdField') or next(f['name'] for f in meta['fields'] if f['type']=='esriFieldTypeOID')
    if fields is None:
        # Sólo campos descriptivos de cartografía. Se excluyen nombres, cédulas y propietarios.
        allow={'objectid','fid','id','gridcode','class','clase','classe','dn','label','codigo','cod_par','cod_parroq','dpa_parroquia','cod_dpa','dpa_despar','nombre','nom_par','nvl_dazin','nvl_dazmm','nivel','descripcio','descripcion','cobertura','uso','area','superficie','parroquia','name','cuenca','microcuenca'}
        fields=','.join(f['name'] for f in meta['fields'] if f['name'].lower() in allow or f['name']==oid)
    ids=fetch(base+'/query',{'where':'1=1','returnIdsOnly':'true','f':'json'})['objectIds']
    ids=sorted(ids or [])
    features=[]
    batch=200
    for start in range(0,len(ids),batch):
        path=R/(name+f'_parte_{start//batch:04d}.json')
        if path.exists():obj=json.loads(path.read_text(encoding='utf-8'))
        else:
            obj=fetch(base+'/query',{'objectIds':','.join(map(str,ids[start:start+batch])), 'outFields':fields,'returnGeometry':'true',
                                    'outSR':4326,'f':'geojson','geometryPrecision':8})
            path.write_text(json.dumps(obj,ensure_ascii=False),encoding='utf-8')
        if obj.get('exceededTransferLimit'):raise RuntimeError('Lote truncado: '+name)
        features.extend(obj['features'])
        if start%2000==0:print(name,len(features),'/',len(ids),flush=True)
    if len(features)!=len(ids):raise RuntimeError('Conteo no coincide: '+name)
    output.write_text(json.dumps({'type':'FeatureCollection','features':features},ensure_ascii=False),encoding='utf-8')
    (R/(name+'_fuente.json')).write_text(json.dumps({'url':base,'n':len(ids),'outFields':fields,'outSR':4326,
        'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'interpretacion':'cartografia_publica_no_ocurrencia_futura'},ensure_ascii=False,indent=2),encoding='utf-8')
    return name+' '+str(len(ids))+' entidades'


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--completa',action='store_true',help='Añadir capas opcionales de cientos de miles de polígonos.')
    args=parser.parse_args()
    truststore.inject_into_ssl();R.mkdir(parents=True,exist_ok=True)
    failures=[]
    def task(name):
        try:return download(name)
        except Exception as error:
            failures.append({'capa':name,'tipo':type(error).__name__,'mensaje':str(error)[:500]})
            return name+' NO disponible: '+type(error).__name__
    selected=LAYERS if args.completa else [k for k in LAYERS if k not in ['movimiento_masa_municipal','mancha_urbana_2025']]
    with ThreadPoolExecutor(max_workers=3) as pool:
        for msg in pool.map(task,selected):print(msg,flush=True)
    (R/'faltantes.json').write_text(json.dumps(failures,ensure_ascii=False,indent=2),encoding='utf-8')


if __name__=='__main__':main()
