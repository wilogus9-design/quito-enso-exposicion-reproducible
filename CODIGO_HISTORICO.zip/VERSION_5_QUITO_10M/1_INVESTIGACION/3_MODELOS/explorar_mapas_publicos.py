"""Sigue servicios declarados en mapas municipales públicos; sólo metadatos."""
from pathlib import Path
import json
import re
from concurrent.futures import ThreadPoolExecutor
import requests
import truststore

P=Path(__file__).resolve().parents[1]
R=P/'2_DATOS/ORIGINALES/BUSQUEDA_TERRENO/MAPAS_PUBLICOS'


def main():
    truststore.inject_into_ssl();R.mkdir(parents=True,exist_ok=True)
    js=(R.parent/'quito_js.txt').read_text(encoding='utf-8')
    ids=sorted(set(re.findall(r'(?:id|appid)=([a-f0-9]{32})(?![a-f0-9])',js)))
    def fetch(i):
        url='https://www.arcgis.com/sharing/rest/content/items/'+i+'/data?f=json'
        try:
            file=R/(i+'.json')
            if file.exists():j=json.loads(file.read_text(encoding='utf-8'))
            else:
                j=requests.get(url,timeout=(15,35)).json()
                file.write_text(json.dumps(j,ensure_ascii=False),encoding='utf-8')
            layers=[]
            def walk(obj):
                if isinstance(obj,dict):
                    if 'url' in obj:layers.append({k:obj[k] for k in ['title','name','url','itemId','id'] if k in obj})
                    for v in obj.values():walk(v)
                elif isinstance(obj,list):
                    for v in obj:walk(v)
            walk(j);return {'id':i,'fuente':url,'capas':layers}
        except Exception as e:return {'id':i,'error':type(e).__name__}
    with ThreadPoolExecutor(max_workers=3) as pool:out=list(pool.map(fetch,ids))
    (R/'capas_encontradas.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    for a in out:print(json.dumps(a,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
