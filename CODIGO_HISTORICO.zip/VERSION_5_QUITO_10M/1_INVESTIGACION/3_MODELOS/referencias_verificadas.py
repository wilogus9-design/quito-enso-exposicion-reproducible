"""Metadatos DOI consultados en Crossref y fuentes oficiales conservadas."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json
import requests
import truststore

P=Path(__file__).resolve().parents[1]
R=P/'2_DATOS/ORIGINALES/REFERENCIAS'
F=P/'6_FINAL'
DOIS={'watson2022':'10.5194/nhess-22-1699-2022','warton2010':'10.1214/10-AOAS331',
      'phillips2006':'10.1016/j.ecolmodel.2005.03.026','harrison2022':'10.1038/s41597-022-01468-2',
      'henjones2026':'10.1007/s10346-025-02608-6'}
SOURCES={
 'gedi':('NASA','GEDI L2A Elevation and Height Metrics V002','https://developers.google.com/earth-engine/datasets/catalog/LARSE_GEDI_GEDI02_A_002'),
 'copernicus':('Copernicus','Copernicus DEM GLO-30 2024_1','https://developers.google.com/earth-engine/datasets/catalog/COPERNICUS_DEM_GLO30_2024_1'),
 'worldcover':('ESA','WorldCover 2021 v200','https://developers.google.com/earth-engine/datasets/catalog/ESA_WorldCover_v200'),
 'geoide':('National Geospatial-Intelligence Agency','EGM2008 geoid grid distributed by PROJ','https://cdn.proj.org/'),
 'municipio':('Municipio del Distrito Metropolitano de Quito','Geoportal Quito servicios geográficos públicos','https://geoquito.quito.gob.ec/server/rest/services'),
 'sngr':('Secretaría Nacional de Gestión de Riesgos','Histórico de eventos peligrosos Ecuador','https://sgrportal.gestionderiesgos.gob.ec/server/rest/services/Hosted/eventos_historicos/FeatureServer/0'),
 'chirps3':('Climate Hazards Center','CHIRPS3 daily ERA5 disaggregation','https://developers.google.com/earth-engine/datasets/catalog/UCSB-CHC_CHIRPS_V3_DAILY_RNL'),
 'gefs':('Climate Hazards Center','CHIRPS3-GEFS precipitation forecasts','https://www.chc.ucsb.edu/data/chirps-gefs'),
 'watsondatos':('Watson y colaboradores','Packaged data for Enhancing disaster risk resilience using greenspace in urbanising Quito Ecuador','https://zenodo.org/records/5881876')}


def main():
    truststore.inject_into_ssl();R.mkdir(parents=True,exist_ok=True)
    def fetch(pair):
        key,doi=pair;file=R/(key+'.json')
        if file.exists():m=json.loads(file.read_text(encoding='utf-8'))
        else:
            r=requests.get('https://api.crossref.org/works/'+doi,timeout=(15,35));r.raise_for_status();m=r.json()['message']
            file.write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8')
        if m['DOI'].lower()!=doi.lower():raise ValueError('DOI incompatible')
        return key,m
    with ThreadPoolExecutor(max_workers=3) as pool:items=list(pool.map(fetch,DOIS.items()))
    bib=[];refs=[]
    for key,m in items:
        if key=='warton2010' and not m.get('page'):
            # Author-deposited journal reference: https://arxiv.org/abs/1011.3319
            # Crossref original JSON is preserved unchanged in ORIGINALES.
            m={**m,'page':'1383-1402'}
        year=m.get('published-print',m.get('published',m.get('issued')))['date-parts'][0][0]
        authors=m.get('author',[])
        names=' and '.join(a.get('family','')+', '+a.get('given','') for a in authors)
        apa_names=[a.get('family','')+', '+' '.join(x[0]+'.' for x in a.get('given','').split() if x) for a in authors]
        apa=', '.join(apa_names[:-1])+', & '+apa_names[-1] if len(apa_names)>1 else (apa_names[0] if apa_names else '')
        title=m['title'][0];journal=m.get('container-title',[''])[0];doi=m['DOI']
        bib.append(f'@article{{{key},\n  author = {{{names}}},\n  year = {{{year}}},\n  title = {{{{{title}}}}},\n  journal = {{{journal}}},\n  doi = {{{doi}}},\n  volume = {{{m.get("volume","")}}},\n  pages = {{{m.get("page",m.get("article-number",""))}}}\n}}')
        volume=m.get('volume','');issue=m.get('issue','');pages=m.get('page',m.get('article-number',''))
        loc=volume+('('+issue+')' if issue else '')+(', '+pages if pages else '')
        refs.append({'key':key,'text':f'{apa} ({year}). {title}. {journal}, {loc}. https://doi.org/{doi}',
                     'url':'https://doi.org/'+doi,'revista':journal,'volumen':volume})
        print(key,year,title,flush=True)
    for key,(author,title,url) in SOURCES.items():
        if key=='watsondatos':
            m=dict(items)['watson2022'];aa=m['author']
            names=' and '.join(a['family']+', '+a.get('given','') for a in aa)
            apa_names=[a['family']+', '+' '.join(x[0]+'.' for x in a.get('given','').split() if x) for a in aa]
            apa=', '.join(apa_names[:-1])+', & '+apa_names[-1]
            title="Datasets supporting the paper Enhancing disaster risk resilience using greenspace in urbanising Quito Ecuador"
            bib.append(f'@misc{{{key},\n  author = {{{names}}},\n  year = {{2022}},\n  title = {{{{{title}}}}},\n  publisher = {{Zenodo}},\n  doi = {{10.5281/zenodo.5881876}},\n  url = {{{url}}}\n}}')
            refs.append({'key':key,'text':f'{apa} (2022). {title} [Conjunto de datos]. Zenodo. https://doi.org/10.5281/zenodo.5881876','url':url})
            continue
        bib.append(f'@misc{{{key},\n  author = {{{{{author}}}}},\n  title = {{{{{title}}}}},\n  url = {{{url}}},\n  note = {{Consultado 2026-10-09}}\n}}')
        refs.append({'key':key,'text':f'{author}. (s. f.). {title}. Recuperado el 9 de octubre de 2026, de {url}', 'url':url})
    (F/'referencias.bib').write_text('\n\n'.join(bib)+'\n',encoding='utf-8')
    (F/'referencias_verificadas.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2),encoding='utf-8')


if __name__=='__main__':main()
