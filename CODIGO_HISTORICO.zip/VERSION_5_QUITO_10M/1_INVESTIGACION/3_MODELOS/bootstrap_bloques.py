"""Incertidumbre exploratoria de diferencias de log-densidad entre comparadores."""
from pathlib import Path
import numpy as np
import pandas as pd
from evaluar_quito import D,F


def main():
    z=np.load(D/'muestras_inciertas.npz');vectors=np.load(D/'vectores_evaluacion.npz')
    rng=np.random.default_rng(5100);rows=[]
    for hazard in ['INUNDACION','DESLIZAMIENTO']:
      for protocol in ['temporal','espacial']:
        key=hazard+'_'+protocol
        inp=np.load(D/f'entrada_red_{key}.npz')
        ix=inp['etest']
        ids=np.array([str(int(x//5000))+'_'+str(int(y//5000)) for x,y in zip(z['event_x'][ix],z['event_y'][ix])])
        groups=np.unique(ids)
        for reference in ['punto_loglineal','construido_referencia','uniforme']:
            a=vectors[key+'_red_ensamble']-vectors[key+'_'+reference]
            replicates=[]
            for _ in range(2000):
                chosen=rng.choice(groups,size=len(groups),replace=True)
                vals=np.concatenate([a[ids==g] for g in chosen])
                replicates.append(vals.mean())
            lo,hi=np.quantile(replicates,[.025,.975])
            rows.append({'amenaza':hazard,'evaluacion':protocol,'comparacion':'red_menos_'+reference,'diferencia_media_logdensidad':a.mean(),
                         'ic95_bloques_inf':lo,'ic95_bloques_sup':hi,'bloques_test':len(groups),'replicas':2000,
                         'alcance':'exploratorio; no incluye incertidumbre de coordenadas fuente, registro ni terreno completa'})
    pd.DataFrame(rows).to_csv(F/'incertidumbre_diferencias_bloques_5km.csv',index=False)
    print('Bootstrap por bloques terminado',flush=True)


if __name__=='__main__':main()
