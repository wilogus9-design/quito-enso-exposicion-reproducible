"""Evalúa densidad de presencias reservadas, no exactitud con falsos negativos."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.special import logsumexp

P=Path(__file__).resolve().parents[1]
D=P/'2_DATOS/PROCESADOS'
F=P/'6_FINAL'


def tail_membership(values,background,fraction=.1):
    threshold=float(np.quantile(background,1-fraction))
    greater=np.mean(background>threshold)
    tied=np.mean(background==threshold)
    tie_weight=np.clip((fraction-greater)/tied,0,1) if tied>0 else 0.
    return (values>threshold).astype(float)+(values==threshold)*tie_weight,threshold


def metric(fe,fb,valid,be,bb):
    ev=logsumexp(np.where(valid,fe,-np.inf),axis=1)-np.log(valid.sum(axis=1))
    ll=float(ev.mean())
    membership,threshold=tail_membership(fe,fb)
    capture=float(((membership*valid).sum(axis=1)/valid.sum(axis=1)).mean())
    urban=bb>0
    if urban.sum()>50:
        urban_members,_=tail_membership(fe,fb[urban])
        va=valid&(be>0)
        cases=va.sum(axis=1)>0
        ucap=float(((urban_members[ cases]*va[cases]).sum(axis=1)/va[cases].sum(axis=1)).mean()) if cases.any() else np.nan
    else:ucap=np.nan
    return {'log_densidad_relativa_test':ll,'captura_soporte_top10pct_territorio':capture,'captura_soporte_top10pct_construido':ucap,'umbral_log_densidad_top10pct':threshold}


def evaluate():
    zbase=np.load(D/'muestras_inciertas.npz')
    states=json.loads((D/'modelos_lineales.json').read_text(encoding='utf-8'))
    rows=[];eval_vectors={}
    exact_file=F/'integracion_exacta_normalizadores.json'
    corrections=json.loads(exact_file.read_text(encoding='utf-8'))['correcciones_log'] if exact_file.exists() else {}
    built_index=zbase['names'].tolist().index('cobertura_50')
    for key,st in states.items():
        z=np.load(D/f'entrada_red_{key}.npz')
        valid=z['valid_e'][z['etest']]
        n=int(z['etest'].sum());nb=int(z['btest'].sum())
        be=zbase['Xe'][z['etest'],:,built_index];bb=zbase['Xb'][z['btest'],built_index]
        def append(label,fe,fb):
            correction=corrections.get(key+'_'+label,0.)
            fe=fe-correction;fb=fb-correction
            m=metric(fe,fb,valid,be,bb)
            rows.append({'amenaza':st['hazard'],'evaluacion':st['protocol'],'modelo':label,'presencias_test':n,'cuadratura_test':nb,'normalizador_grilla_completa':bool(corrections),**m})
            ev=logsumexp(np.where(valid,fe,-np.inf),axis=1)-np.log(valid.sum(axis=1))
            eval_vectors[key+'_'+label]=ev
        append('uniforme',np.zeros(valid.shape),np.zeros(nb))
        # Misma función nativa, con fondo de suelo construido, sin pretender capacidad hidráulica.
        be_density=zbase['Xe'][z['etest'],:,7]
        bb_density=zbase['Xb'][z['btest'],7]
        fb=np.log(bb_density+.01)
        normalizer=logsumexp(fb)-np.log(len(fb))
        append('construido_referencia',np.log(be_density+.01)-normalizer,fb-normalizer)
        beta=np.array(st['beta'])*st['alpha']
        fe=z['Xe'][z['etest']]@beta
        fb=z['Xb'][z['btest']]@beta
        normalizer=logsumexp(fb)-np.log(len(fb))
        append('punto_loglineal',fe-normalizer,fb-normalizer)
        lbe=[];lbb=[]
        for seed in [5101,5102,5103]:
            out=np.load(D/f'scores_red_{key}_{seed}.npz')
            fb=out['fb'][z['btest']]
            fe=out['fe'][z['etest']]
            normalizer=logsumexp(fb)-np.log(len(fb))
            lbe.append(fe-normalizer);lbb.append(fb-normalizer)
        append('red_ensamble',logsumexp(np.stack(lbe),axis=0)-np.log(3),logsumexp(np.stack(lbb),axis=0)-np.log(3))
        print(key,'evaluación de presencias reservadas',n,flush=True)
    pd.DataFrame(rows).to_csv(F/'evaluacion_presencias_reservadas.csv',index=False)
    np.savez_compressed(D/'vectores_evaluacion.npz',**eval_vectors)
    coefficients=[]
    for key,st in states.items():
        for name,value,sd in zip(st['feature_names'],st['beta'],st['sd']):
            coefficients.append({'clave':key,'variable':name,'beta_estandarizado':value,'beta_por_unidad':value/sd,'temperado':st['alpha']})
    pd.DataFrame(coefficients).to_csv(F/'coeficientes_punto_loglineal.csv',index=False)


if __name__=='__main__':evaluate()
