"""GeoTIFF por teselas (<10 MB) y VRT editable para abrir en QGIS."""
from pathlib import Path
import json
import math
import numpy as np
import rasterio
from rasterio.windows import Window
from scipy.special import logsumexp
from xml.sax.saxutils import escape
from matplotlib import colormaps

P=Path(__file__).resolve().parents[1]
D=P/'2_DATOS/PROCESADOS'
R=P/'6_FINAL/RASTERS_10M'


def linear_rank(short,hazard):
    st=json.loads((D/'modelos_lineales.json').read_text(encoding='utf-8'))[hazard+'_temporal']
    bg=np.load(D/f'entrada_red_{hazard}_temporal.npz')['Xb']
    beta=np.array(st['beta'])*st['alpha'];f=bg@beta
    normalizer=logsumexp(f)-np.log(len(f))
    sums=json.loads((P/'6_FINAL/normalizacion_grilla.json').read_text(encoding='utf-8'))['sumas'][hazard]
    correction=math.log(sums[1]/sums[2])
    q=np.quantile(f-normalizer-correction,np.arange(1,100)/100)
    with rasterio.open(D/f'log_intensidad_{short}_lineal_10m.tif') as src:
        profile=src.profile.copy();profile.update(dtype='uint8',nodata=0,predictor=2)
        out=D/f'prioridad_{short}_lineal_percentil_10m.tif'
        with rasterio.open(out,'w',**profile) as dst:
            for _,w in src.block_windows(1):
                arr=src.read(1,window=w);valid=arr!=-9999
                rank=np.zeros(arr.shape,dtype=np.uint8);rank[valid]=1+np.searchsorted(q,arr[valid],side='right')
                dst.write(rank,1,window=w)
            dst.set_band_description(1,'percentil_1_100_NO_probabilidad')
    return out


def tiles(file,label):
    folder=R/label;folder.mkdir(parents=True,exist_ok=True)
    elements=[]
    palette={0:(255,255,255,0)}
    for i in range(1,101):palette[i]=tuple(int(v*255) for v in colormaps['YlOrRd']((i-1)/99))
    with rasterio.open(file) as src:
        for row in range(0,src.height,2048):
          for col in range(0,src.width,2048):
            w=Window(col,row,min(2048,src.width-col),min(2048,src.height-row))
            a=src.read(1,window=w)
            if not (a!=src.nodata).any():continue
            path=folder/f'tesela_{row:05d}_{col:05d}.tif'
            profile=src.profile.copy();profile.update(height=a.shape[0],width=a.shape[1],transform=src.window_transform(w))
            with rasterio.open(path,'w',**profile) as out:
                out.write(a,1);out.set_band_description(1,'prioridad_relativa_no_probabilidad')
                out.write_colormap(1,palette)
                out.update_tags(source=label,grid_m=10,terrain_m=30,position_support_m=100,not_a_flood_probability='true')
            if path.stat().st_size>10_000_000:raise RuntimeError('Tesela demasiado grande: '+path.name)
            elements.append(f'''<SimpleSource><SourceFilename relativeToVRT="1">{escape(label+'/'+path.name)}</SourceFilename><SourceBand>1</SourceBand><SrcRect xOff="0" yOff="0" xSize="{a.shape[1]}" ySize="{a.shape[0]}"/><DstRect xOff="{col}" yOff="{row}" xSize="{a.shape[1]}" ySize="{a.shape[0]}"/><NODATA>0</NODATA></SimpleSource>''')
        gt=src.transform.to_gdal()
        colors=''.join(f'<Entry c1="{a}" c2="{b}" c3="{c}" c4="{d}"/>' for a,b,c,d in palette.values())
        vrt=f'''<VRTDataset rasterXSize="{src.width}" rasterYSize="{src.height}"><SRS>{escape(src.crs.to_wkt())}</SRS><GeoTransform>{','.join(map(str,gt))}</GeoTransform><VRTRasterBand dataType="Byte" band="1"><Description>Percentil de prioridad, no probabilidad de evento</Description><NoDataValue>0</NoDataValue><ColorInterp>Palette</ColorInterp><ColorTable>{colors}</ColorTable>{''.join(elements)}</VRTRasterBand></VRTDataset>'''
        (R/(label+'.vrt')).write_text(vrt,encoding='utf-8')
    print(label,'teselas',len(elements),flush=True)


def main():
    R.mkdir(parents=True,exist_ok=True)
    for short,hazard in [('inundacion','INUNDACION'),('deslizamiento','DESLIZAMIENTO')]:
        raw=R/f'prioridad_{short}_percentil_10m.tif'
        preserved=D/raw.name
        if raw.exists():raw.replace(preserved) # Archivo generado propio; no borra contenido.
        tiles(preserved,'prioridad_'+short+'_red')
        tiles(linear_rank(short,hazard),'prioridad_'+short+'_lineal')
    (R/'LEEME.md').write_text('# Mapas Quito a 10 m\n\nAbrir los archivos .vrt en QGIS: referencian todas las teselas de cada modelo. Cada tesela es un GeoTIFF real a 10 m. La unidad es percentil de prioridad de localizaciones reportadas, no probabilidad de evento ni profundidad. Terreno original 30 m; incertidumbre posicional asumida 100 m.\n\nSe conservan red y modelo log-lineal sin seleccionar por resultados del test. Las imágenes completas y las log-intensidades se conservan en 2_DATOS/PROCESADOS.\n',encoding='utf-8')


if __name__=='__main__':main()
