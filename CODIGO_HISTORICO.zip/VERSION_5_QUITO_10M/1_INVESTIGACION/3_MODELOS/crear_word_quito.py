"""Word editable con tablas nativas, ecuación OMML y afiliación en nota real.

Usar el Python del entorno documental de Codex, no el entorno de GPU.
Los resultados y textos se leen de una estructura generada por documentar_quito.
La revisión del render es una fase independiente y obligatoria de entrega.
"""
from pathlib import Path
import importlib.util
import json
import sys
import zipfile
from lxml import etree
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

P=Path(__file__).resolve().parents[1]
ROOT=P.parents[2]
S=Path.home()/'.codex/plugins/cache/openai-primary-runtime/documents/26.1007.11041/skills/documents'
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec)
    sys.modules[name]=m;spec.loader.exec_module(m);return m


def main():
    data=json.loads((P/'2_DATOS/PROCESADOS/articulo_quito_estructura.json').read_text(encoding='utf-8'))
    helper=load('word_components',P/'3_MODELOS/componentes_word.py')
    doc=Document();sec=doc.sections[0]
    sec.page_width=Inches(8.5);sec.page_height=Inches(11)
    sec.left_margin=sec.right_margin=Inches(1);sec.top_margin=sec.bottom_margin=Inches(.8)
    for style in ['Normal','Title','Heading 1','Caption']:
        st=doc.styles[style];st.font.name='Arial';st.font.color.rgb=RGBColor(0,0,0)
        st.font.size=Pt(11 if style=='Normal' else 16 if style=='Title' else 12 if style.startswith('Heading') else 10)
        st.paragraph_format.space_after=Pt(7);st.paragraph_format.line_spacing=1.1
        st.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY if style=='Normal' else WD_ALIGN_PARAGRAPH.LEFT
    for b in data['bloques']:
        kind=b['tipo']
        if kind=='titulo':doc.add_paragraph(b['texto'],style='Title')
        elif kind=='autor':
            doc.add_paragraph(b['texto']+'[[FN]]').alignment=WD_ALIGN_PARAGRAPH.LEFT;note=b['nota']
        elif kind=='titulo_seccion':
            if b['texto']=='Introducción':doc.add_page_break()
            doc.add_heading(b['texto'],level=1)
        elif kind=='texto':doc.add_paragraph(b['texto'])
        elif kind=='tabla':helper.table(doc,b)
        elif kind=='ecuacion':
            # Native, searchable equation: log rho = score minus area normalizer.
            helper.math_paragraph(doc,['log ρ(s) = ',('f','θ'),'[x(s)] − log ',('E','A'),'{exp(',('f','θ'),'[x])}'])
        elif kind=='figura':
            cap=doc.add_paragraph(b['titulo']);cap.paragraph_format.keep_with_next=True
            for r in cap.runs:r.font.size=Pt(10)
            p=doc.add_paragraph();p.paragraph_format.keep_with_next=True
            p.add_run().add_picture(str(P/'6_FINAL'/b['archivo']),width=Inches(6.3))
            pic=p._p.find('.//'+qn('wp:docPr'))
            if pic is not None:pic.set('descr',b['titulo']+'. '+b['nota'])
            n=doc.add_paragraph(b['nota']);n.paragraph_format.keep_together=True
            for r in n.runs:r.font.size=Pt(9)
        elif kind=='referencia':
            p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.LEFT
            if 'revista' in b:
                before,after=b['texto'].split(b['revista'],1)
                p.add_run(before);p.add_run(b['revista']+', '+b['volumen']).italic=True
                p.add_run(after[len(', '+b['volumen']):])
            else:p.add_run(b['texto'])
            p.paragraph_format.left_indent=Inches(.25);p.paragraph_format.first_line_indent=Inches(-.25)
            for r in p.runs:r.font.size=Pt(10)
    doc.core_properties.author=data['autor'];doc.core_properties.title=data['titulo']
    doc.core_properties.subject='Cartografía de prioridad, exposición clasificada y evaluación de alturas en Quito'
    fpr=OxmlElement('w:footnotePr');fmt=OxmlElement('w:numFmt');fmt.set(qn('w:val'),'chicago');fpr.append(fmt);sec._sectPr.append(fpr)
    base=P/'2_DATOS/PROCESADOS/base_quito.docx';doc.save(base)
    output=P/'6_FINAL/MANUSCRITO_QUITO_V05.docx'
    insert=load('note_helper',S/'scripts/insert_note.py')
    insert.insert_note(str(base),str(output),'footnote','[[FN]]',note)
    with zipfile.ZipFile(output) as z:entries={i.filename:z.read(i.filename) for i in z.infolist()}
    root=etree.fromstring(entries['word/document.xml'])
    for ref in root.findall('.//{'+W+'}footnoteReference'):
        run=ref.getparent();pr=etree.Element('{'+W+'}rPr');va=etree.SubElement(pr,'{'+W+'}vertAlign');va.set('{'+W+'}val','superscript');run.insert(0,pr)
    sanitizer=load('title_sanitize',S/'scripts/google_docs_title_sanitize.py')
    styles=etree.fromstring(entries['word/styles.xml']);sanitizer.sanitize_styles(styles);sanitizer.sanitize_document_part(root,leading_nonempty_paragraphs=6)
    entries['word/styles.xml']=etree.tostring(styles,xml_declaration=True,encoding='UTF-8',standalone=True)
    entries['word/document.xml']=etree.tostring(root,xml_declaration=True,encoding='UTF-8',standalone=True)
    notes=etree.fromstring(entries['word/footnotes.xml'])
    for p in notes.findall('.//{'+W+'}p'):
        pr=etree.Element('{'+W+'}pPr');align=etree.SubElement(pr,'{'+W+'}jc');align.set('{'+W+'}val','left');p.insert(0,pr)
        for r in p.findall('{'+W+'}r'):
            rp=etree.Element('{'+W+'}rPr');sz=etree.SubElement(rp,'{'+W+'}sz');sz.set('{'+W+'}val','18');r.insert(0,rp)
    entries['word/footnotes.xml']=etree.tostring(notes,xml_declaration=True,encoding='UTF-8',standalone=True)
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
        for name,content in entries.items():z.writestr(name,content)
    print('Word Quito creado:',output,flush=True)


if __name__=='__main__':main()
