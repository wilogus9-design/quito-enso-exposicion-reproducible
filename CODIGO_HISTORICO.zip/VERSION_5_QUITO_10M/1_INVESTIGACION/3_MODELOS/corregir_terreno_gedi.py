"""Regresión experimental de diferencias verticales; no inventa un DEM medido.

Se evalúa por órbitas completas y, por separado, por bloques espaciales. Sólo
calibración escoge regularización. Persiste modelos propios para inferencia.
"""
from pathlib import Path
import json
import pickle
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor

P=Path(__file__).resolve().parents[1]
D=P/'2_DATOS/PROCESADOS'
F=P/'6_FINAL'


def errors(e):
    return {'mae_m':float(np.mean(np.abs(e))), 'rmse_m':float(np.sqrt(np.mean(e**2))),
            'sesgo_prediccion_m':float(e.mean()), 'mediana_error_m':float(np.median(e))}


def main():
    g=pd.read_parquet(D/'huellas_gedi_quito.parquet')
    X=np.load(D/'gedi_covariables.npz')['X'];y=g.residuo_gedi_m.to_numpy()
    result=[];settings={}
    for mode,fold in [('orbita',g.fold_orbita.to_numpy()),('espacial',g.fold_espacial.to_numpy())]:
        ok=g.dominio_correccion.to_numpy().copy()
        if mode=='espacial':ok &=g.margen_bloque_250m.to_numpy()
        tr=ok&(fold<=5);ca=ok&(fold>=6)&(fold<=7);te=ok&(fold>=8)
        if min(tr.sum(),ca.sum(),te.sum())<100:raise ValueError('Muestra insuficiente para '+mode)
        med=float(np.median(y[tr]));choices=[]
        for leaves in [7,15]:
            for l2 in [1.,10.]:
                m=HistGradientBoostingRegressor(loss='absolute_error',max_leaf_nodes=leaves,
                    l2_regularization=l2,max_iter=100,learning_rate=.05,random_state=5100,
                    early_stopping=False,min_samples_leaf=50)
                m.fit(X[tr],y[tr]);mae=float(np.mean(np.abs(m.predict(X[ca])-y[ca])))
                choices.append((mae,leaves,l2,m))
        score,leaves,l2,m=min(choices,key=lambda s:s[0])
        caerr=m.predict(X[ca])-y[ca]
        margin=float(np.quantile(np.abs(caerr),.90))
        settings[mode]={'entrenamiento':int(tr.sum()),'calibracion':int(ca.sum()),'test':int(te.sum()),
                        'hojas':leaves,'l2':l2,'mae_calibracion_m':score,'mediana_residuo_train_m':med,
                        'margen_empirico90_cal_m':margin,
                        'intervalo':'margen empírico; no garantía 90 % espacial ni incertidumbre completa',
                        'busqueda_calibracion':[{'mae_m':s[0],'hojas':s[1],'l2':s[2]} for s in choices]}
        with (D/('correccion_gedi_'+mode+'.pkl')).open('wb') as f:pickle.dump(m,f)
        for name,pred in [('dsm_sin_corregir',np.zeros(te.sum())),('correccion_mediana',np.full(te.sum(),med)),('boosting',m.predict(X[te]))]:
            e=pred-y[te];r={'protocolo':mode,'modelo':name,'huellas_test':int(te.sum()),**errors(e)}
            if name=='boosting':r['cobertura_margen90_cal_en_test']=float((np.abs(e)<=margin).mean())
            result.append(r)
        # Keep prediction/test vectors for independent audits; not training inputs.
        out=g.loc[te,['shot_number','orbit_number','block','altura_gedi_egm2008_m','dsm_copernicus_m','pendiente_grados','wc2021']].copy()
        out['altura_corregida_m']=out.dsm_copernicus_m+m.predict(X[te]);out['error_m']=out.altura_corregida_m-out.altura_gedi_egm2008_m
        out.to_parquet(D/('test_terreno_'+mode+'.parquet'),index=False)
    pd.DataFrame(result).to_csv(F/'evaluacion_correccion_terreno_gedi.csv',index=False)
    (F/'configuracion_correccion_gedi.json').write_text(json.dumps(settings,ensure_ascii=False,indent=2),encoding='utf-8')
    print(pd.DataFrame(result).to_string(index=False),flush=True)


if __name__=='__main__':main()
