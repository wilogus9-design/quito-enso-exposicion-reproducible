"""Verifica artefactos reales y conserva hashes; no certifica validación científica."""
from pathlib import Path
import hashlib
import json
import importlib.metadata
import platform
import sys
import subprocess
import zipfile
import numpy as np
import pandas as pd
import rasterio
from rasterio.windows import Window
from pyproj import Transformer

P=Path(__file__).resolve().parents[1]
D=P/'2_DATOS/PROCESADOS'
F=P/'6_FINAL'
V=P/'5_VERIFICACION';V.mkdir(parents=True,exist_ok=True)


def main():
    checks=[]
    def check(name,ok,detail=''):
        checks.append({'control':name,'aprobado':bool(ok),'detalle':detail})
    z=np.load(D/'muestras_inciertas.npz')
    index=json.loads((P/'2_DATOS/ORIGINALES/GEDI/indice.json').read_text(encoding='utf-8'))['features']
    check('259 segmentos GEDI completos',all((P/'2_DATOS/ORIGINALES/GEDI'/(i['properties']['table_id'].rsplit('/',1)[-1]+'.geojson')).exists() for i in index))
    rasters=list((P/'2_DATOS/ORIGINALES/RASTERS').glob('*.tif'))
    check('15 teselas de entradas completas',len(rasters)==15)
    check('fondo es cuadratura no ausencia',len(z['Xb'])==60000)
    check('25 ubicaciones posibles un registro',z['Xe'].shape[1]==25)
    check('features20',z['Xb'].shape[1]==20)
    check('muestras fondo finitas',np.isfinite(z['Xb']).all())
    check('temporal sin datos futuros en train',bool((z['year_e'][z['split_t']=='train']<=2021).all()))
    check('test temporal no antes2024',bool((z['year_e'][z['split_t']=='test']>=2024).all()))
    for model in ['inundacion_red','inundacion_lineal','deslizamiento_red','deslizamiento_lineal']:
        with rasterio.open(F/'RASTERS_10M'/('prioridad_'+model+'.vrt')) as v, rasterio.open(D/('prioridad_'+model.replace('_red','')+'_percentil_10m.tif')) as a:
            check(model+' resolucion10m',v.res==(10.,10.) and str(v.crs)=='EPSG:32717')
            check(model+' nodata no es riesgo0',v.nodata==0)
            equal=True
            for row,col in [(0,0),(v.height//2,v.width//2),(v.height-250,v.width-250)]:
                w=Window(col,row,min(250,v.width-col),min(250,v.height-row));equal &=np.array_equal(a.read(1,window=w),v.read(1,window=w))
            check(model+' VRT igual a completo',equal)
        with rasterio.open(D/('log_intensidad_'+model+'_10m.tif')) as s:
            total=0.;n=0
            for _,w in s.block_windows(1):
                a=s.read(1,window=w);valid=a!=-9999;total+=np.exp(a[valid].astype(float)).sum();n+=valid.sum()
            check(model+' densidad media1',abs(total/n-1)<1e-5,str(total/n))
    with rasterio.open(D/'altura_ajustada_gedi_estimada_10m.tif') as a, rasterio.open(F/'RASTERS_10M/altura_ajustada_GEDI_ESTIMADA.vrt') as v:
        w=Window(a.width//2,a.height//2,250,250)
        check('altura experimental VRT igual a completo',np.array_equal(a.read(1,window=w),v.read(1,window=w)))
        check('altura no llamada medida10m',a.tags().get('measured_10m_terrain')=='false')
    g=pd.read_parquet(D/'huellas_gedi_quito.parquet')
    check('GEDI sin disparos duplicados',g.shot_number.is_unique)
    check('GEDI datum explícito',np.allclose(g.altura_gedi_egm2008_m,g.elev_lowestmode-g.geoid_egm2008_m))
    # Independent implementation PROJ checks the hand-coded bilinear geoid/sign.
    grid=P/'2_DATOS/ORIGINALES/BUSQUEDA_TERRENO/egm2008.tif'
    t=Transformer.from_pipeline('+proj=pipeline +step +proj=unitconvert +xy_in=deg +xy_out=rad +step +proj=vgridshift +grids='+grid.as_posix())
    sample=g.iloc[::max(1,len(g)//20)]
    _,_,h=t.transform(sample.lon.to_numpy(),sample.lat.to_numpy(),sample.elev_lowestmode.to_numpy())
    check('conversion vertical coincide con PROJ',np.max(np.abs(h-sample.altura_gedi_egm2008_m))<.001,str(float(np.max(np.abs(h-sample.altura_gedi_egm2008_m)))))
    x=pd.read_csv(F/'exposicion_parroquias_quito.csv');a=json.loads((F/'control_exposicion.json').read_text(encoding='utf-8'))
    check('parroquias incluye desajuste limite',bool((x.id_municipal==0).any()))
    check('denominador construido cierra',abs(x.construido_2025_ha.sum()-a['totales_ha']['construido_2025'])<.001)
    check('construido municipal medio alto desconocido cierra',np.allclose(x.construido_2025_ha,x.construido_2025_ref_medio_ha+x.construido_2025_ref_alto_ha+x.construido_2025_ref_desconocido_ha))
    check('comparacion suelo solo cobertura comun',bool((x.construido_2020_comun_ha<=x.comun_2020_2025_ha).all() and (x.construido_2025_comun_ha<=x.comun_2020_2025_ha).all()))
    m=json.loads((F/'control_lluvia.json').read_text(encoding='utf-8'))
    check('horizonte empieza despues decision',m['horizonte'][0]>m['fecha_analisis'])
    with rasterio.open(F/'lluvia_7dias_nativa_005_grados.tif') as s:check('no lluvia fingida10m',s.crs.to_epsg()==4326 and abs(s.res[0]-.05)<1e-6)
    check('emision no posterior decision',m['emision']<=m['fecha_analisis'])
    cl=json.loads((F/'control_climatologia.json').read_text(encoding='utf-8'))
    check('referencia 41 semanas completas',cl['bandas']==41 and cl['conteos_diarios_min']==7 and cl['conteos_diarios_max']==7)
    e=pd.read_csv(F/'evaluacion_presencias_reservadas.csv')
    check('16 comparaciones reservadas',len(e)==16 and e.normalizador_grilla_completa.all())
    article=json.loads((D/'articulo_quito_estructura.json').read_text(encoding='utf-8'))
    check('resumen hasta200palabras',article['resumen_palabras']<=200)
    with zipfile.ZipFile(F/'MANUSCRITO_QUITO_V05.docx') as zdoc:
        xml=zdoc.read('word/document.xml').decode('utf-8')
        check('tablas Word editables',xml.count('<w:tbl>')==4)
        check('afiliacion en nota real','word/footnotes.xml' in zdoc.namelist())
        check('ecuacion nativa','<m:oMath>' in xml)
        check('sin citas internas ni placeholders','[[FN]]' not in xml and 'turn382' not in xml)
    large=[str(f.relative_to(F)) for f in F.rglob('*') if f.is_file() and f.stat().st_size>10_000_000]
    check('final cada archivo hasta10MB',not large,str(large))
    proc=subprocess.run([sys.executable,str(P/'3_MODELOS/test_quito.py')],capture_output=True,text=True,encoding='utf-8')
    (V/'test_quito.txt').write_text(proc.stdout+proc.stderr,encoding='utf-8');check('7 pruebas unitarias',proc.returncode==0)
    inputs=[]
    files=[]
    for folder in [P/'3_MODELOS',P/'0_PROTOCOLO',P/'2_DATOS/ORIGINALES',D,F]:
        for file in sorted(folder.rglob('*')):
            if not file.is_file() or '__pycache__' in str(file) or file.suffix in ['.part','.pyc']:continue
            files.append(file)
    files.extend([P/'EJECUTAR_V05.py',P/'EJECUTAR_V05.bat',P/'LEEME_V05.md',
                  P.parents[2]/'FENOMENO_NINO/1_INVESTIGACION/2_DATOS/PROCESADOS/41_sngr_historico_eventos_v06.parquet'])
    for file in files:
        h=hashlib.sha256()
        with file.open('rb') as stream:
            for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
        path=str(file.relative_to(P)) if file.is_relative_to(P) else str(file)
        inputs.append({'path':path,'bytes':file.stat().st_size,'sha256':h.hexdigest()})
    versions={'python':sys.version,'platform':platform.platform()}
    for name in ['numpy','pandas','scipy','scikit-learn','geopandas','rasterio','pyproj','earthengine-api','matplotlib']:
        versions[name]=importlib.metadata.version(name)
    (V/'manifiesto_fuentes_codigo_entrega.json').write_text(json.dumps(inputs,ensure_ascii=False,indent=2),encoding='utf-8')
    (V/'entorno_cientifico.json').write_text(json.dumps(versions,ensure_ascii=False,indent=2),encoding='utf-8')
    (V/'auditoria_tecnica.json').write_text(json.dumps({'controles':checks,'aprobados':sum(c['aprobado'] for c in checks),'total':len(checks),'no_equivale_a':'validación científica, física, hidráulica ni aceptación editorial'},ensure_ascii=False,indent=2),encoding='utf-8')
    for c in checks:
        if not c['aprobado']:print('FALLÓ',c['control'],c['detalle'],flush=True)
    print('Controles técnicos aprobados:',sum(c['aprobado'] for c in checks),'/',len(checks),flush=True)
    if not all(c['aprobado'] for c in checks):raise SystemExit(1)


if __name__=='__main__':main()
