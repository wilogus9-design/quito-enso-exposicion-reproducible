"""Pruebas pequeñas de las decisiones estadísticas y los denominadores."""
import unittest
import numpy as np
from scipy.special import logsumexp
from ajustar_lineal import valid_norm,domains
from evaluar_quito import tail_membership,metric


class PruebasQuito(unittest.TestCase):
    def test_uniforme_decil_con_empates(self):
        out,_=tail_membership(np.zeros((5,25)),np.zeros(1000))
        np.testing.assert_allclose(out,.1)

    def test_ubicacion_unica(self):
        x=np.array([[[2.,3.]],[[1.,4.]]]);b=np.array([.1,.2])
        out,_=valid_norm(x,np.ones((2,1),bool),b)
        np.testing.assert_allclose(out,x[:,0]@b)

    def test_ubicacion_invalida_no_se_inventa(self):
        x=np.array([[[2.],[999.]]]);v=np.array([[True,False]])
        out,_=valid_norm(x,v,np.ones(1));np.testing.assert_allclose(out,[2.])

    def test_marginalizacion_no_duplica_reportes(self):
        x=np.ones((3,25,1))*2;out,_=valid_norm(x,np.ones((3,25),bool),np.ones(1))
        self.assertEqual(len(out),3);np.testing.assert_allclose(out,2.)

    def test_normalizador_invariante_a_constante(self):
        x=np.array([1.,2.,3.]);z=logsumexp(x)-np.log(3)
        z2=logsumexp(x+17)-np.log(3)
        np.testing.assert_allclose(x-z,(x+17)-z2)

    def test_particiones_no_comparten_etiquetas(self):
        z={'event_type':np.array(['INUNDACION']*10),'split_t':np.array(['train']*4+['cal']*3+['test']*3),
           'Xb':np.ones((10,1)),'year_e':np.array([2020]*10),'fold_e':np.arange(10),
           'fold_b':np.arange(10),'edge_e':np.ones(10,bool),'edge_b':np.ones(10,bool)}
        for protocol in ['temporal','espacial']:
            e,b=domains(z,'INUNDACION',protocol)
            self.assertEqual(sum(int((e[i]&e[j]).sum()) for i in range(3) for j in range(i+1,3)),0)
        # Temporal backgrounds are integration area and may repeat, not labels.

    def test_metric_uniforme_no_predice_evento(self):
        m=metric(np.zeros((5,25)),np.zeros(1000),np.ones((5,25),bool),np.ones((5,25)),np.ones(1000))
        self.assertEqual(m['log_densidad_relativa_test'],0)
        self.assertAlmostEqual(m['captura_soporte_top10pct_territorio'],.1)


if __name__=='__main__':unittest.main()
