"""Figuras científicas provenientes de datos; no imágenes generadas por IA."""
from pathlib import Path
import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from rasterio.windows import from_bounds
from rasterio.enums import Resampling
from pyproj import Transformer
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

P=Path(__file__).resolve().parents[1]
D=P/'2_DATOS/PROCESADOS'
F=P/'6_FINAL'
G=F/'GRAFICOS';G.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'Arial','font.size':8,'axes.titlesize':9,'svg.fonttype':'none'})


def save(fig,name):
    fig.savefig(G/(name+'.png'),dpi=300,bbox_inches='tight')
    fig.savefig(G/(name+'.svg'),bbox_inches='tight');plt.close(fig)


def raster(ax,file,cmap,vmin=None,vmax=None,bounds=None):
    with rasterio.open(file) as s:
        w=from_bounds(*bounds,s.transform) if bounds else None
        b=rasterio.windows.bounds(w,s.transform) if w is not None else s.bounds
        if w is None:height,width=s.height,s.width
        else:height,width=int(w.height),int(w.width)
        scale=max(1,max(height,width)/1000)
        a=s.read(1,window=w,out_shape=(int(height/scale),int(width/scale)),resampling=Resampling.nearest,masked=True)
    # UTM kilometres keep axes legible; absolute northings retained, not latitudes.
    im=ax.imshow(a,extent=(b[0]/1000,b[2]/1000,b[1]/1000,b[3]/1000),cmap=cmap,vmin=vmin,vmax=vmax,interpolation='none')
    ax.set_xlabel('Este UTM 17S (km)');ax.set_ylabel('Norte UTM 17S (km)');ax.set_aspect('equal')
    return im


def main():
    q=gpd.read_file(D/'quito_limite.geojson').to_crs(32717);q.geometry=q.geometry.scale(xfact=.001,yfact=.001,origin=(0,0))
    p=gpd.read_file(F/'parroquias_prioridad.geojson').to_crs(32717);p.geometry=p.geometry.scale(xfact=.001,yfact=.001,origin=(0,0))
    rep=gpd.read_file(D/'reportes_quito.geojson').to_crs(32717)
    models=[('inundacion_lineal','Inundación modelo log lineal'),('inundacion_red','Inundación red neuronal'),
            ('deslizamiento_lineal','Deslizamiento modelo log lineal'),('deslizamiento_red','Deslizamiento red neuronal')]
    project=Transformer.from_crs(4326,32717,always_xy=True)
    x0,y0=project.transform(-78.60,-.42);x1,y1=project.transform(-78.34,.10)
    for zoom,name,constructed in [(None,'figura_1_prioridades_dmq',False),((x0,y0,x1,y1),'figura_2_prioridades_quito_urbano',False),((x0,y0,x1,y1),'figura_6_prioridades_suelo_construido',True)]:
        fig,axes=plt.subplots(2,2,figsize=(8.2,9.3),layout='constrained')
        for ax,(model,title) in zip(axes.ravel(),models):
            suffix='_construido' if constructed else ''
            im=raster(ax,F/'RASTERS_10M'/('prioridad_'+model+suffix+'.vrt'),'YlOrRd',1,100,zoom)
            q.boundary.plot(ax=ax,color='#333333',linewidth=.35)
            if zoom:p.boundary.plot(ax=ax,color='#555555',linewidth=.25,alpha=.4)
            hazard='INUNDACION' if model.startswith('inundacion') else 'DESLIZAMIENTO'
            test=rep[(rep.evento_norm==hazard)&(rep.split_t=='test')]
            ax.scatter(test.geometry.x/1000,test.geometry.y/1000,s=3,c='black',alpha=.4,label='Reportes reservados 2024 a septiembre 2025')
            if zoom:ax.set_xlim(x0/1000,x1/1000);ax.set_ylim(y0/1000,y1/1000)
            ax.set_xlabel('Este UTM 17S (km)');ax.set_ylabel('Norte UTM 17S (km)')
            ax.set_title(title);fig.colorbar(im,ax=ax,shrink=.65,label='Percentil de prioridad de localizaciones reportadas')
        title='Quito prioridad dentro del suelo construido 2025' if constructed else 'Quito prioridades espaciales de reportes'
        fig.suptitle(title+'\nSalida 10 m terreno 30 m soporte posicional asumido 100 m',fontsize=11)
        fig.supxlabel('Fuente: SNGR, Municipio de Quito, ESA y Copernicus. Elaboración propia. No es probabilidad de inundación.',fontsize=7)
        save(fig,name)
    # Error comparison, including failure to establish neural advantage.
    e=pd.read_csv(F/'incertidumbre_diferencias_bloques_5km.csv')
    e=e[e.comparacion=='red_menos_punto_loglineal'].reset_index(drop=True)
    fig,ax=plt.subplots(figsize=(7,3.2),layout='constrained')
    for i,r in e.iterrows():
        ax.plot([r.ic95_bloques_inf,r.ic95_bloques_sup],[i,i],color='#345b8c');ax.plot(r.diferencia_media_logdensidad,i,'o',color='#345b8c')
    ax.axvline(0,color='black',lw=.8);ax.set_yticks(range(len(e)),[(r.amenaza.title()+' '+r.evaluacion) for _,r in e.iterrows()]);ax.invert_yaxis()
    ax.set_xlabel('Diferencia en log densidad red menos modelo log lineal');ax.set_title('Comparación reservada por bloques de 5 km')
    fig.supxlabel('Fuente: elaboración propia. Intervalos exploratorios 2000 réplicas. No incluyen toda la incertidumbre.',fontsize=7)
    save(fig,'figura_3_evaluacion')
    # Public LiDAR sample: retain all points in data, thin only display markers.
    g=pd.read_parquet(D/'huellas_gedi_quito.parquet');thin=g.sample(min(5000,len(g)),random_state=5100)
    fig,axes=plt.subplots(1,2,figsize=(8.2,5.5),layout='constrained')
    im=axes[0].scatter(thin.x/1000,thin.y/1000,c=-thin.residuo_gedi_m,s=2,cmap='coolwarm',vmin=-20,vmax=20,rasterized=True)
    q.boundary.plot(ax=axes[0],color='black',lw=.4);axes[0].set_aspect('equal');axes[0].set_title('DSM menos LiDAR en huellas de muestra')
    axes[0].set_xlabel('Este UTM 17S (km)');axes[0].set_ylabel('Norte UTM 17S (km)')
    fig.colorbar(im,ax=axes[0],shrink=.7,label='Diferencia vertical (m) escala visual limitada a ±20')
    im=raster(axes[1],D/'altura_ajustada_gedi_estimada_10m.tif','terrain',500,5000)
    q.boundary.plot(ax=axes[1],color='black',lw=.4);axes[1].set_title('Altura ajustada estimada dominio restringido')
    axes[1].set_xlabel('Este UTM 17S (km)');axes[1].set_ylabel('Norte UTM 17S (km)')
    fig.colorbar(im,ax=axes[1],shrink=.7,label='Altura EGM2008 (m)')
    fig.suptitle('Contraste LiDAR y superficie experimental',fontsize=11)
    fig.supxlabel('Fuente: GEDI, NGA, ESA y Copernicus. Elaboración propia. Blanco sin estimación. No es DEM medido de 10 m.',fontsize=7)
    save(fig,'figura_4_alturas_lidar')
    rain=pd.read_csv(F/'contraste_pronostico_climatologia.csv')
    fig,axes=plt.subplots(1,2,figsize=(8.2,5.5),layout='constrained')
    qw=gpd.read_file(D/'quito_limite.geojson').to_crs(4326)
    with rasterio.open(F/'lluvia_7dias_nativa_005_grados.tif') as s:
        a=s.read(1,masked=True);b=s.bounds
        im=axes[0].imshow(a,extent=(b.left,b.right,b.bottom,b.top),cmap='Blues',interpolation='none')
    qw.boundary.plot(ax=axes[0],color='black',lw=.4);axes[0].set_title('Acumulado pronosticado 10 a 16 octubre 2026');axes[0].set_xlabel('Longitud');axes[0].set_ylabel('Latitud')
    fig.colorbar(im,ax=axes[0],shrink=.7,label='Lluvia acumulada prevista (mm)')
    pg=p.merge(rain[['id_municipal','rango_percentil_historico_pronostico']],on='id_municipal')
    pg.plot(column='rango_percentil_historico_pronostico',ax=axes[1],cmap='Blues',vmin=0,vmax=100,legend=True,
            legend_kwds={'shrink':.7,'label':'Percentil de referencia histórica no probabilidad'})
    q.boundary.plot(ax=axes[1],color='black',lw=.4);axes[1].set_title('Comparación con la misma semana 1981 a 2021');axes[1].set_aspect('equal')
    axes[1].set_xlabel('Este UTM 17S (km)');axes[1].set_ylabel('Norte UTM 17S (km)')
    fig.suptitle('Contexto de lluvia emisión 8 octubre 2026',fontsize=11)
    fig.supxlabel('Fuente: CHC UCSB CHIRPS3 GEFS y DAILY RNL. Elaboración propia. Escala nativa 0.05 grados no 10 m.',fontsize=7)
    save(fig,'figura_5_lluvia_futura')
    print('Figuras PNG 300 dpi y SVG generadas',flush=True)


if __name__=='__main__':main()
