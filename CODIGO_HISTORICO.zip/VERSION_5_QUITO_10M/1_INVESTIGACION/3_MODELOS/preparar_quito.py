"""Construye entradas geoespaciales y muestras de presencia, conservando escalas."""
from pathlib import Path
import json
import hashlib
import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from rasterio.merge import merge
from rasterio.features import rasterize
from rasterio.warp import reproject, Resampling
from scipy.ndimage import gaussian_filter, uniform_filter, distance_transform_edt
from pyproj import Transformer

P=Path(__file__).resolve().parents[1]
ROOT=P.parents[2]
RAW=P/'2_DATOS/ORIGINALES'
DATA=P/'2_DATOS/PROCESADOS'
F=P/'6_FINAL'
CLASSES=[10,20,30,40,50,60,70,80,90,95,100]
FEATURE_NAMES=['altitud_km','pendiente_grados','posicion_topografica_m','relieve_local_m',
 'log_dist_rio','log_dist_quebrada','log_dist_colector','construido_100m','construido_500m']+['cobertura_'+str(c) for c in CLASSES]


def save_raster(file,arr,transform,descriptions,nodata=None):
    if arr.ndim==2:arr=arr[None]
    with rasterio.open(file,'w',driver='GTiff',height=arr.shape[1],width=arr.shape[2],count=arr.shape[0],dtype=arr.dtype,
                       crs='EPSG:32717',transform=transform,nodata=nodata,tiled=True,blockxsize=256,blockysize=256,
                       compress='deflate',predictor=3 if arr.dtype.kind=='f' else 2,BIGTIFF='IF_SAFER') as out:
        out.write(arr)
        for i,label in enumerate(descriptions,1):out.set_band_description(i,label)


def mosaic(prefix,outname):
    paths=sorted((RAW/'RASTERS').glob(prefix+'*.tif'))
    sources=[rasterio.open(p) for p in paths]
    if not sources:raise FileNotFoundError(prefix)
    arr,transform=merge(sources)
    for src in sources:src.close()
    save_raster(DATA/outname,arr,transform,['WorldCover 2021; nativo 10m'] if arr.shape[0]==1 else ['DSM 30m','HEM 30m'])
    return arr,transform


def nearest_into(src,src_transform,dest_shape,dest_transform):
    out=np.empty(dest_shape,dtype=src.dtype)
    reproject(src,out,src_transform=src_transform,src_crs='EPSG:32717',dst_transform=dest_transform,dst_crs='EPSG:32717',resampling=Resampling.nearest)
    return out


class Features:
    """Lectura por vecindarios y ventanas; no materializa todo X de 80 millones de filas."""
    def __init__(self):
        self.wc=rasterio.open(DATA/'worldcover_2021_10m.tif')
        self.terrain=rasterio.open(DATA/'derivados_30m.tif')
        self.density=rasterio.open(DATA/'densidad_construida_10m.tif')
        self.mask=rasterio.open(DATA/'mascara_quito_10m.tif')
        self.tr=self.wc.transform
        self.shape=(self.wc.height,self.wc.width)

    def point_features(self,xy,radius=100):
        from rasterio.windows import Window,from_bounds
        output=[]
        for x,y in xy:
            rr,cc=self.wc.index(x,y)
            b=(x-radius,y-radius,x+radius,y+radius)
            w=self.wc.read(1,window=from_bounds(*b,self.wc.transform),boundless=True,fill_value=0)
            t=self.terrain.read(window=from_bounds(*b,self.terrain.transform),boundless=True,fill_value=np.nan)
            d=self.density.read(window=from_bounds(*b,self.density.transform),boundless=True,fill_value=np.nan)
            # Área circular explícita para el promedio de cobertura y densidad.
            c=np.array([(w==v).mean() for v in CLASSES],dtype=np.float32)
            tmean=np.nanmean(t,axis=(1,2))
            env=[tmean[0]/1000,tmean[1],tmean[2],tmean[3],np.log1p(tmean[4]/10),np.log1p(tmean[5]/10),np.log1p(tmean[6]/10),*np.nanmean(d,axis=(1,2)),*c]
            output.append(env)
        return np.array(output,dtype=np.float32)

    def window_features(self,row,rows=256):
        from rasterio.windows import Window
        width=self.wc.width;rows=min(rows,self.wc.height-row)
        window=Window(0,row,width,rows)
        wc=self.wc.read(1,window=window)
        d=self.density.read(window=window)
        r30=np.clip((np.arange(row,row+rows)//3),0,self.terrain.height-1)
        c30=np.clip(np.arange(width)//3,0,self.terrain.width-1)
        tw=Window(0,int(r30.min()),self.terrain.width,int(r30.max()-r30.min()+1))
        coarse=self.terrain.read(window=tw)
        t=coarse[:,r30-int(r30.min())][:,:,c30]
        mask=self.mask.read(1,window=window).astype(bool)&np.isin(wc,CLASSES)&np.isfinite(t).all(axis=0)
        X=np.stack([t[0]/1000,t[1],t[2],t[3],np.log1p(t[4]/10),np.log1p(t[5]/10),np.log1p(t[6]/10),d[0],d[1],*[(wc==v).astype(np.float32) for v in CLASSES]],axis=-1)
        return X.reshape(-1,len(FEATURE_NAMES)),mask.reshape(-1),wc.reshape(-1),window


def prepare():
    DATA.mkdir(parents=True,exist_ok=True);F.mkdir(parents=True,exist_ok=True)
    print('Preparando grillas y muestras de Quito',flush=True)
    wc,tr=mosaic('worldcover_2021','worldcover_2021_10m.tif');wc=wc[0]
    dsm,dt=mosaic('dsm_copernicus_2024_1','dsm_30m.tif')
    dem=dsm[0].astype(np.float32)
    if not np.isfinite(dem).all():raise ValueError('DSM con huecos: documentar antes de modelar')
    dy,dx=np.gradient(dem,30.)
    slope=np.degrees(np.arctan(np.hypot(dx,dy))).astype(np.float32)
    mu=gaussian_filter(dem,5.) # sigma150m; no simulación hidráulica.
    tpi=dem-mu
    relief=np.sqrt(np.maximum(gaussian_filter(dem**2,5.)-mu**2,0)).astype(np.float32)
    dist=[]
    for name in ['red_hidrica','quebrada_viva','colector']:
        vec=gpd.read_file(RAW/'VECTORES'/f'{name}.geojson').to_crs(32717)
        burned=rasterize([(g,1) for g in vec.geometry if g is not None and not g.is_empty],out_shape=dem.shape,transform=dt,fill=0,dtype='uint8',all_touched=True)
        if not burned.any():raise ValueError('Red vacía: '+name)
        dist.append(distance_transform_edt(burned==0,sampling=30.).astype(np.float32))
    stack=np.stack([dem,slope,tpi,relief,*dist,dsm[1]]).astype(np.float32)
    save_raster(DATA/'derivados_30m.tif',stack,dt,['DSM_m','pendiente_grados','TPI_sigma150m','relieve_sigma150m','dist_rio_m','dist_quebrada_m','dist_colector_m','HEM_m'])
    q=gpd.read_file(DATA/'quito_limite.geojson').to_crs(32717)
    mask=rasterize([(g,1) for g in q.geometry],out_shape=wc.shape,transform=tr,fill=0,dtype='uint8')
    save_raster(DATA/'mascara_quito_10m.tif',mask,tr,['mascara_canton'],nodata=0)
    built=(wc==50).astype(np.float32)
    density=np.stack([uniform_filter(built,size=11),uniform_filter(built,size=51)])
    save_raster(DATA/'densidad_construida_10m.tif',density.astype(np.float32),tr,['fraccion_construido_110m','fraccion_construido_510m'])
    # Referencia oficial: sólo las clases publicadas, sin crear Bajo fuera de cobertura.
    vec=gpd.read_file(RAW/'VECTORES/inundacion_municipal.geojson').to_crs(32717)
    mapping={'Medio':1,'Alto':2}
    shapes=sorted([(g,mapping.get(v,0)) for g,v in zip(vec.geometry,vec.nvl_dazin) if g is not None and not g.is_empty and v in mapping],key=lambda x:x[1])
    hazard=rasterize(shapes,out_shape=wc.shape,transform=tr,fill=0,dtype='uint8')
    hazard[mask==0]=255
    save_raster(DATA/'referencia_inundacion_municipal_10m.tif',hazard,tr,['0_sin_clasificar_1_medio_2_alto_255_fuera_canton'],nodata=255)
    for year in [2020,2025]:
        vec=gpd.read_file(RAW/'VECTORES'/f'cobertura_{year}.geojson').to_crs(32717)
        classes={'otros':1,'vegetacion':2,'construido':3,'agua':4}
        land=rasterize([(g,classes.get(c,0)) for g,c in zip(vec.geometry,vec.clase) if g is not None and not g.is_empty],out_shape=wc.shape,transform=tr,fill=0,dtype='uint8')
        land[mask==0]=255
        save_raster(DATA/f'cobertura_municipal_{year}_10m.tif',land,tr,['0_sin_cobertura_1_otros_2_vegetacion_3_construido_4_agua'],nodata=255)
    # Reportes: coordenadas de la base, nunca etiquetas artificiales de pixeles inundados.
    source=ROOT/'FENOMENO_NINO/1_INVESTIGACION/2_DATOS/PROCESADOS/41_sngr_historico_eventos_v06.parquet'
    h=pd.read_parquet(source)
    h=h[(h.cod_canton.astype(str).str.zfill(4)=='1701')&h.evento_norm.isin(['INUNDACION','DESLIZAMIENTO','ALUVION (FLUJOS)'])].copy()
    h['fecha']=pd.to_datetime(h.fecha)
    h=h[h.fecha.between('2010-01-01','2025-09-30')&h.coord_valida_ecuador&~h.anio_incompatible.fillna(False)]
    h=h.drop_duplicates(['fecha','evento_norm','longitud','latitud'])
    geo=gpd.GeoDataFrame(h[['fecha','evento_norm']].copy(),geometry=gpd.points_from_xy(pd.to_numeric(h.longitud),pd.to_numeric(h.latitud)),crs=4326).to_crs(32717)
    inside=geo.geometry.within(q.geometry.union_all())
    discarded=int((~inside).sum());geo=geo[inside].reset_index(drop=True)
    geo['x']=geo.geometry.x;geo['y']=geo.geometry.y
    geo['block_x']=(geo.x//5000).astype(int);geo['block_y']=(geo.y//5000).astype(int)
    geo['block']=geo.block_x.astype(str)+'_'+geo.block_y.astype(str)
    geo['fold']=geo.block.map(lambda s:int(hashlib.sha256(('5100:'+s).encode()).hexdigest()[:8],16)%10)
    geo['split_t']=np.where(geo.fecha.dt.year<=2021,'train',np.where(geo.fecha.dt.year<=2023,'cal','test'))
    geo.to_file(DATA/'reportes_quito.geojson',driver='GeoJSON')
    # Fondo uniforme: cuadratura del área, NO negativos físicos.
    rng=np.random.default_rng(5100)
    valid=np.flatnonzero((mask>0)&np.isin(wc,CLASSES))
    idx=rng.choice(valid,size=min(60000,len(valid)),replace=False)
    rr,cc=np.unravel_index(idx,wc.shape)
    x=tr.c+(cc+.5)*10;y=tr.f-(rr+.5)*10
    bg=pd.DataFrame({'x':x,'y':y,'row':rr,'col':cc})
    bg['block']=(bg.x//5000).astype(int).astype(str)+'_'+(bg.y//5000).astype(int).astype(str)
    bg['fold']=bg.block.map(lambda s:int(hashlib.sha256(('5100:'+s).encode()).hexdigest()[:8],16)%10)
    bg.to_parquet(DATA/'cuadratura_fondo.parquet',index=False)
    reader=Features()
    print('Extrayendo covariables de reportes',len(geo),flush=True)
    Xe=reader.point_features(geo[['x','y']].to_numpy(),radius=100)
    # Punto de fondo, radio5m: covariables puntuales integradas en la misma grilla.
    print('Extrayendo cuadratura',len(bg),flush=True)
    # Muestreo vectorizado por bandas: no 60000 ventanas individuales.
    t30=stack[:7,rr//3,cc//3].T
    Xb=np.column_stack([t30[:,0]/1000,t30[:,1:4],np.log1p(t30[:,4:7]/10),density[:,rr,cc].T,*[(wc[rr,cc]==v).astype(float) for v in CLASSES]]).astype(np.float32)
    np.savez_compressed(DATA/'muestras_punto_proceso.npz',Xe=Xe,Xb=Xb,names=np.array(FEATURE_NAMES),
                        event_type=geo.evento_norm.to_numpy(dtype=str),split_t=geo.split_t.to_numpy(dtype=str),
                        fold_e=geo.fold.to_numpy(),fold_b=bg.fold.to_numpy(),event_x=geo.x.to_numpy(),event_y=geo.y.to_numpy(),bg_x=x,bg_y=y)
    controls={'reportes':geo.groupby(['evento_norm','split_t']).size().unstack(fill_value=0).to_dict(),
              'descartados_fuera_geometria':discarded,'celdas_canton_10m':int(mask.sum()),'area_grilla_canton_km2':float(mask.sum()/10000),
              'clasificado_medio_celdas':int(((hazard==1)&(mask>0)).sum()),'clasificado_alto_celdas':int(((hazard==2)&(mask>0)).sum()),
              'sin_clasificacion_municipal_celdas':int(((hazard==0)&(mask>0)).sum()),'feature_shape':list(Xb.shape),
              'feature_nulos_fondo':int((~np.isfinite(Xb)).any(axis=1).sum()),'feature_nulos_reportes':int((~np.isfinite(Xe)).any(axis=1).sum()),
              'etiquetas_negativas_fisicas_creadas':0,'soporte_posicional_reportes_m':100,'resolucion_terreno_m':30}
    (F/'control_preparacion_quito.json').write_text(json.dumps(controls,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
    print(json.dumps(controls,ensure_ascii=False,default=str),flush=True)


if __name__=='__main__':prepare()
