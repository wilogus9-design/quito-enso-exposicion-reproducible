"""Une alturas reales de huellas LiDAR, corrige datum y evalúa sin recortar errores."""
from pathlib import Path
import json
import hashlib
import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from scipy.ndimage import map_coordinates
from preparar_quito import Features

P = Path(__file__).resolve().parents[1]
D = P/'2_DATOS/PROCESADOS'
F = P/'6_FINAL'


def main():
    rows=[]
    for file in sorted((P/'2_DATOS/ORIGINALES/GEDI').glob('*.geojson')):
        for f in json.loads(file.read_text(encoding='utf-8'))['features']:
            if f.get('geometry') is None:continue
            a=f['properties'];c=f['geometry']['coordinates']
            a.update({'lon':c[0],'lat':c[1]});rows.append(a)
    df=pd.DataFrame(rows)
    n_raw=len(df);df=df.drop_duplicates('shot_number').copy()
    q=gpd.read_file(D/'quito_limite.geojson').to_crs(4326)
    g=gpd.GeoDataFrame(df,geometry=gpd.points_from_xy(df.lon,df.lat),crs=4326)
    g=g[g.geometry.within(q.geometry.union_all())].copy().to_crs(32717)
    x,y=g.geometry.x.to_numpy(),g.geometry.y.to_numpy()
    with rasterio.open(P/'2_DATOS/ORIGINALES/BUSQUEDA_TERRENO/egm2008.tif') as src:
        # Rasterio affine maps pixel corners; scipy index refers to pixel centres.
        lon=g.to_crs(4326).geometry.x.to_numpy();lat=g.to_crs(4326).geometry.y.to_numpy()
        if src.bounds.left>=0:lon=np.mod(lon,360)
        cc=(lon-src.transform.c)/src.transform.a-.5
        rr=(lat-src.transform.f)/src.transform.e-.5
        # Crop rather than load the global geoid into memory.
        r0=int(np.floor(rr.min()))-2;r1=int(np.ceil(rr.max()))+3
        c0=int(np.floor(cc.min()))-2;c1=int(np.ceil(cc.max()))+3
        win=rasterio.windows.Window(c0,r0,c1-c0,r1-r0)
        arr=src.read(1,window=win)
        geoid=map_coordinates(arr,[rr-r0,cc-c0],order=1,mode='nearest')
        meta={'crs':str(src.crs),'transform':list(src.transform),'tags':src.tags(),
              'conversion':'H_EGM2008 = h_GEDI - N_EGM2008', 'N_min':float(geoid.min()),'N_max':float(geoid.max())}
    reader=Features()
    # Identical point covariates to frozen report model, not the obsolete buffer sample.
    terrain=reader.terrain.read();wc=reader.wc.read(1);density=reader.density.read()
    r,c=rasterio.transform.rowcol(reader.wc.transform,x,y)
    r=np.asarray(r);c=np.asarray(c)
    t=terrain[:,r//3,c//3].T
    from preparar_quito import CLASSES,FEATURE_NAMES
    X=np.column_stack([t[:,0]/1000,t[:,1:4],np.log1p(t[:,4:7]/10),density[:,r,c].T,
                       *[(wc[r,c]==v).astype(float) for v in CLASSES]]).astype(np.float32)
    g['geoid_egm2008_m']=geoid;g['altura_gedi_egm2008_m']=g.elev_lowestmode.to_numpy()-geoid
    g['dsm_copernicus_m']=t[:,0];g['pendiente_grados']=t[:,1];g['wc2021']=wc[r,c]
    g['residuo_gedi_m']=g.altura_gedi_egm2008_m-g.dsm_copernicus_m
    g['fecha']=pd.Timestamp('2018-01-01')+pd.to_timedelta(g.delta_time,unit='s')
    g['x']=x;g['y']=y
    g['fold_orbita']=g.orbit_number.map(lambda o:int(hashlib.sha256(('GEDI5100:'+str(int(o))).encode()).hexdigest()[:8],16)%10)
    g['block']=(x//5000).astype(int).astype(str)+'_'+(y//5000).astype(int).astype(str)
    g['fold_espacial']=g.block.map(lambda b:int(hashlib.sha256(('5100:'+b).encode()).hexdigest()[:8],16)%10)
    g['margen_bloque_250m']=(np.minimum(x%5000,5000-x%5000)>250)&(np.minimum(y%5000,5000-y%5000)>250)
    g['dominio_correccion']=(g.pendiente_grados<=20)&~g.wc2021.isin([70,80])&np.isfinite(X).all(axis=1)
    np.savez_compressed(D/'gedi_covariables.npz',X=X,names=np.array(FEATURE_NAMES))
    g.drop(columns='geometry').to_parquet(D/'huellas_gedi_quito.parquet',index=False)
    # Editable public point file; no households or cadastral owners.
    fields=['shot_number','orbit_number','fecha','geoid_egm2008_m','altura_gedi_egm2008_m',
            'dsm_copernicus_m','residuo_gedi_m','pendiente_grados','dominio_correccion','geometry']
    g[fields].to_crs(4326).to_file(D/'huellas_gedi_quito.geojson',driver='GeoJSON')
    stats=[]
    for label,m in [('todas',np.ones(len(g),dtype=bool)),('pendiente_hasta20',g.pendiente_grados<=20),('pendiente_mayor20',g.pendiente_grados>20)]:
        e=-g.loc[m,'residuo_gedi_m'].to_numpy()
        stats.append({'dominio':label,'huellas':int(m.sum()),'mae_m':float(np.mean(np.abs(e))),
                      'rmse_m':float(np.sqrt(np.mean(e**2))),'sesgo_dsm_m':float(np.mean(e)),
                      'mediana_sesgo_dsm_m':float(np.median(e))})
    pd.DataFrame(stats).to_csv(F/'contraste_dsm_gedi.csv',index=False)
    meta.update({'huellas_descargadas_rectangulo':n_raw,'huellas_unicas_dentro_quito':len(g),
                 'orbitas':int(g.orbit_number.nunique()),'fecha_inicio':str(g.fecha.min()),'fecha_fin':str(g.fecha.max()),
                 'dominio_correccion_huellas':int(g.dominio_correccion.sum()),
                 'soporte_huella_m_aprox':25,'terreno_original_m':30,'referencia_vertical':'EGM2008',
                 'limitacion':'huellas discontinuas; lowestmode no prueba por sí solo suelo desnudo; pendientes y geolocalización afectan contraste'})
    (F/'control_alturas_gedi.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
    print(json.dumps(meta,ensure_ascii=False,default=str),flush=True)
    print(pd.DataFrame(stats).to_string(index=False),flush=True)


if __name__=='__main__':main()
