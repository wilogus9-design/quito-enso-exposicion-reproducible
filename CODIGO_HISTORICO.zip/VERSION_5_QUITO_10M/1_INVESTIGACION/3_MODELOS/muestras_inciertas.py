"""Cuadratura y localización incierta: no asigna falsos positivos a un buffer.

Las 25 posiciones posibles por reporte se marginalizan en la verosimilitud.
No son 25 eventos ni 25 pixeles observados como inundados.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from preparar_quito import FEATURE_NAMES,CLASSES

P=Path(__file__).resolve().parents[1]
D=P/'2_DATOS/PROCESADOS'


def candidates():
    reports=gpd.read_file(D/'reportes_quito.geojson')
    reports['fecha']=pd.to_datetime(reports.fecha)
    bg=pd.read_parquet(D/'cuadratura_fondo.parquet')
    rng=np.random.default_rng(5100)
    n=len(reports);K=25
    radius=100*np.sqrt(rng.uniform(size=(n,K)))
    angle=rng.uniform(0,2*np.pi,size=(n,K))
    radius[:,0]=0 # Centro publicado permanece como diagnóstico.
    xx=reports.x.to_numpy()[:,None]+radius*np.cos(angle)
    yy=reports.y.to_numpy()[:,None]+radius*np.sin(angle)
    with rasterio.open(D/'worldcover_2021_10m.tif') as s:
        wc=s.read(1);tr=s.transform
    with rasterio.open(D/'derivados_30m.tif') as s:t=s.read()
    with rasterio.open(D/'densidad_construida_10m.tif') as s:den=s.read()
    with rasterio.open(D/'mascara_quito_10m.tif') as s:mask=s.read(1)
    def extract(x,y):
        rr=np.floor((tr.f-y)/10).astype(int);cc=np.floor((x-tr.c)/10).astype(int)
        within=(rr>=0)&(rr<wc.shape[0])&(cc>=0)&(cc<wc.shape[1])
        r=np.clip(rr,0,wc.shape[0]-1);c=np.clip(cc,0,wc.shape[1]-1)
        rc=np.clip(r//3,0,t.shape[1]-1);cc30=np.clip(c//3,0,t.shape[2]-1)
        tv=t[:7,rc,cc30].T
        wv=wc[r,c];dv=den[:,r,c].T
        X=np.column_stack([tv[:,0]/1000,tv[:,1:4],np.log1p(tv[:,4:7]/10),dv,*[(wv==v).astype(float) for v in CLASSES]]).astype(np.float32)
        valid=within&(mask[r,c]>0)&np.isin(wv,CLASSES)&np.isfinite(X).all(axis=1)
        X[~valid]=np.nan
        return X,valid
    Xe,ve=extract(xx.ravel(),yy.ravel());Xe=Xe.reshape(n,K,-1);ve=ve.reshape(n,K)
    Xb,vb=extract(bg.x.to_numpy(),bg.y.to_numpy())
    edge_e=np.minimum.reduce([reports.x.to_numpy()%5000,5000-reports.x.to_numpy()%5000,reports.y.to_numpy()%5000,5000-reports.y.to_numpy()%5000])>=250
    edge_b=np.minimum.reduce([bg.x.to_numpy()%5000,5000-bg.x.to_numpy()%5000,bg.y.to_numpy()%5000,5000-bg.y.to_numpy()%5000])>=250
    keep=ve.sum(axis=1)>=5
    np.savez_compressed(D/'muestras_inciertas.npz',Xe=Xe[keep],Xb=Xb[vb],valid_e=ve[keep],
         event_type=reports.evento_norm.to_numpy(dtype=str)[keep],split_t=reports.split_t.to_numpy(dtype=str)[keep],
         year_e=reports.fecha.dt.year.to_numpy()[keep],fold_e=reports.fold.to_numpy()[keep],fold_b=bg.fold.to_numpy()[vb],
         edge_e=edge_e[keep],edge_b=edge_b[vb],names=np.array(FEATURE_NAMES),
         event_x=reports.x.to_numpy()[keep],event_y=reports.y.to_numpy()[keep],bg_x=bg.x.to_numpy()[vb],bg_y=bg.y.to_numpy()[vb])
    print('Reportes con soporte',int(keep.sum()),'fondo de cuadratura',int(vb.sum()),'posiciones posibles',K,flush=True)


if __name__=='__main__':candidates()
