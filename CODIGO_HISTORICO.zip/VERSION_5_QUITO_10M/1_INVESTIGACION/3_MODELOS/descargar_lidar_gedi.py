"""Descarga alturas LiDAR GEDI públicas, no un levantamiento LiDAR continuo.

Las huellas tienen aproximadamente 25 m y están separadas a lo largo de las
órbitas. La selección de calidad está fijada antes de examinar errores locales.
Se conservan órbita/fecha para poder reservar recorridos completos al evaluar.
No imprime credenciales ni URLs firmadas de Earth Engine.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json
import hashlib
import ee
import geopandas as gpd
import truststore

P = Path(__file__).resolve().parents[1]
R = P / '2_DATOS/ORIGINALES/GEDI'
FIELDS = ['shot_number', 'beam', 'orbit_number', 'delta_time',
          'elev_lowestmode', 'elev_highestreturn', 'digital_elevation_model',
          'quality_flag', 'degrade_flag', 'sensitivity', 'surface_flag',
          'elevation_bias_flag', 'urban_proportion', 'landsat_treecover',
          'lat_highestreturn', 'lon_highestreturn', 'rh98']


def main():
    truststore.inject_into_ssl()
    ee.Initialize(project='verdant-art-479615-c4')
    R.mkdir(parents=True, exist_ok=True)
    q = gpd.read_file(P/'2_DATOS/PROCESADOS/quito_limite.geojson').to_crs(4326)
    # Bounding box for server retrieval; exact boundary is checked locally later.
    region = ee.Geometry.Rectangle(q.total_bounds.tolist(), geodesic=False)
    idx = R/'indice.json'
    if not idx.exists():
        fc = ee.FeatureCollection('LARSE/GEDI/GEDI02_A_002_INDEX').filterBounds(region)
        j = fc.select(['table_id', 'time_start', 'time_end']).getInfo()
        idx.write_text(json.dumps(j, ensure_ascii=False), encoding='utf-8')
    items = json.loads(idx.read_text(encoding='utf-8'))['features']
    print('Tablas GEDI que intersectan el rectángulo:', len(items), flush=True)

    def download(item):
        asset = item['properties']['table_id']
        name = asset.rsplit('/', 1)[-1]
        target = R/(name+'.geojson')
        if target.exists():
            return name+' cache'
        fc = (ee.FeatureCollection(asset).filterBounds(region)
              .filter(ee.Filter.eq('quality_flag', 1))
              .filter(ee.Filter.eq('degrade_flag', 0))
              .filter(ee.Filter.eq('surface_flag', 1))
              .filter(ee.Filter.eq('elevation_bias_flag', 0))
              .filter(ee.Filter.gte('sensitivity', 0.95))
              .filter(ee.Filter.lte('sensitivity', 1)).select(FIELDS))
        # Explicit pagination avoids silently accepting an incomplete collection.
        features, token = [], None
        while True:
            args = {'expression': fc, 'pageSize': 1000}
            if token:
                args['pageToken'] = token
            page = ee.data.computeFeatures(args)
            features.extend(page.get('features', []))
            token = page.get('nextPageToken')
            if not token:
                break
        output = {'type': 'FeatureCollection', 'features': features}
        target.write_text(json.dumps(output, ensure_ascii=False), encoding='utf-8')
        target.with_suffix('.fuente.json').write_text(json.dumps({
            'asset': asset, 'registros': len(features),
            'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
            'calidad': 'quality=1, degrade=0, surface=1, elevation_bias=0, .95<=sensitivity<=1',
            'altura': 'elipsoidal; requiere conversión de datum antes de comparar DSM EGM2008',
            'fuente': 'https://developers.google.com/earth-engine/datasets/catalog/LARSE_GEDI_GEDI02_A_002'
        }, ensure_ascii=False, indent=2), encoding='utf-8')
        return name+' '+str(len(features))+' huellas'

    with ThreadPoolExecutor(max_workers=3) as pool:
        for result in pool.map(download, items):
            print(result, flush=True)


if __name__ == '__main__':
    main()
