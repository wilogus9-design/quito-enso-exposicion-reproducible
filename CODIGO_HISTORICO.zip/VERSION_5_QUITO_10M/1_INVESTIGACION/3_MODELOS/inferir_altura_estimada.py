"""Altura experimental 10 m, con origen DSM 30 m y controles LiDAR 25 m.

No cambia los mapas de reportes. No se usa para hidrodinámica ni profundidad.
La muestra test de GEDI no se reintroduce en entrenamiento.
"""
from pathlib import Path
import json
import pickle
import numpy as np
import pandas as pd
import rasterio
from preparar_quito import Features

P=Path(__file__).resolve().parents[1]
D=P/'2_DATOS/PROCESADOS'
F=P/'6_FINAL'


def main():
    reader=Features()
    with (D/'correccion_gedi_orbita.pkl').open('rb') as f:model=pickle.load(f)
    g=pd.read_parquet(D/'huellas_gedi_quito.parquet')
    train=g[g.dominio_correccion & (g.fold_orbita<=5)]
    classes=sorted(train.wc2021.unique().astype(int).tolist())
    lo,hi=float(train.dsm_copernicus_m.min()),float(train.dsm_copernicus_m.max())
    profile=reader.wc.profile.copy();profile.update(count=2,dtype='float32',nodata=-9999,predictor=3)
    count=0
    with rasterio.open(D/'altura_ajustada_gedi_estimada_10m.tif','w',**profile) as out:
        for row in range(0,reader.wc.height,128):
            X,valid,wc,w=reader.window_features(row,128)
            z=X[:,0]*1000
            domain=valid&(X[:,1]<=20)&np.isin(wc,classes)&~np.isin(wc,[70,80])&(z>=lo)&(z<=hi)
            a=np.full(len(z),-9999,dtype=np.float32);cor=a.copy()
            if domain.any():
                cor[domain]=model.predict(X[domain]);a[domain]=z[domain]+cor[domain]
            out.write(np.stack([a,cor]).reshape(2,int(w.height),int(w.width)),window=w)
            count+=int(domain.sum())
        out.set_band_description(1,'altura_estimada_EGM2008_m_NO_DEM_medido10m')
        out.set_band_description(2,'correccion_regresion_GEDI_m')
        out.update_tags(source='Copernicus DSM30 + GEDI25 + WorldCover10; elaboración propia',
                        measured_10m_terrain='false',hydraulic_depth_validation='false',native_terrain_m=30,
                        lidar_footprint_m=25,pixel_m=10,domain='pendiente<=20; clases y altitud presentes en train')
    (F/'control_inferencia_altura.json').write_text(json.dumps({
        'celdas_estimadas':count,'area_estimada_km2':count/10000,'modelo':'correccion_gedi_orbita',
        'pixel_salida_m':10,'DSM_original_m':30,'huella_lidar_aprox_m':25,
        'altitud_soporte_train_m':[lo,hi],'clases_cobertura_soporte_train':classes,
        'fuera_dominio':'nodata, no terreno plano ni ausencia de amenaza',
        'limitacion':'10 m no es precisión física; lowestmode no garantiza suelo desnudo; no profundidades',
        'uso_inundacion':'No incorporado a modelos de reportes congelados; experimento separado'
    },ensure_ascii=False,indent=2),encoding='utf-8')
    print('Alturas estimadas:',count,'celdas /',count/10000,'km2',flush=True)


if __name__=='__main__':main()
