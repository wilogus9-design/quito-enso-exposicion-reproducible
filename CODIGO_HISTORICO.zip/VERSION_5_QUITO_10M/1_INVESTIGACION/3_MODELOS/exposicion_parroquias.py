"""Cruza prioridades y suelo construido sin inventar viviendas ni daños.

La comparación 2020/2025 usa únicamente cobertura común de ambos productos.
El suelo construido no equivale a número de viviendas, población o valor de activos.
Se separa el decil del territorio del decil del suelo construido de todo el DMQ.
"""
from pathlib import Path
import json
from contextlib import ExitStack
import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from rasterio.features import rasterize
from rasterio.windows import Window

P = Path(__file__).resolve().parents[1]
D = P/'2_DATOS/PROCESADOS'
F = P/'6_FINAL'
HA_PER_CELL = 0.01


def main():
    q = gpd.read_file(P/'2_DATOS/ORIGINALES/VECTORES/parroquias.geojson').to_crs(32717)
    q.geometry = q.geometry.make_valid()
    q['parroquia'] = q.dpa_despar.replace({'AMAGUA�A':'AMAGUAÑA', 'I�AQUITO':'IÑAQUITO'})
    # IDs de entrega estables, diferentes de códigos INEC que no están en esta capa.
    q['id_municipal'] = q['fid'].astype(int)
    n = int(q.id_municipal.max())+1
    with rasterio.open(D/'mascara_quito_10m.tif') as mask:
        ids = rasterize([(g,i) for g,i in zip(q.geometry,q.id_municipal)],
                        out_shape=(mask.height,mask.width),transform=mask.transform,dtype='uint8',fill=0)
        profile=mask.profile.copy(); profile.update(dtype='uint8',nodata=0)
        with rasterio.open(D/'parroquia_municipal_10m.tif','w',**profile) as out:
            out.write(ids,1)
    names = ['territorio', 'con_cobertura_2020', 'con_cobertura_2025', 'comun_2020_2025',
             'construido_2020_comun', 'construido_2025_comun', 'construido_2025',
             'ref_municipal_medio', 'ref_municipal_alto', 'ref_municipal_desconocido',
             'construido_2025_ref_medio', 'construido_2025_ref_alto',
             'construido_2025_ref_desconocido']
    models = ['inundacion_red', 'inundacion_lineal', 'deslizamiento_red', 'deslizamiento_lineal']
    for model in models:
        names += [model+'_decil_territorio', model+'_construido_decil_territorio', model+'_construido_decil_construido']
    counts = {k: np.zeros(n,dtype=np.int64) for k in names}
    thresholds = {}
    with ExitStack() as stack:
        mask = stack.enter_context(rasterio.open(D/'mascara_quito_10m.tif'))
        c20 = stack.enter_context(rasterio.open(D/'cobertura_municipal_2020_10m.tif'))
        c25 = stack.enter_context(rasterio.open(D/'cobertura_municipal_2025_10m.tif'))
        ref = stack.enter_context(rasterio.open(D/'referencia_inundacion_municipal_10m.tif'))
        ranks = {k: stack.enter_context(rasterio.open(F/'RASTERS_10M'/('prioridad_'+k+'.vrt'))) for k in models}
        log = {k: stack.enter_context(rasterio.open(D/('log_intensidad_'+k+'_10m.tif'))) for k in models}
        vals = {k: [] for k in models}
        for row in range(0,mask.height,128):
            w=Window(0,row,mask.width,min(128,mask.height-row))
            built=(c25.read(1,window=w)==3)&(mask.read(1,window=w)==1)
            for k in models:
                vals[k].append(log[k].read(1,window=w)[built])
        for k in models:
            v=np.concatenate(vals[k]); thresholds[k]=float(np.quantile(v,.9))
        del vals
        for row in range(0,mask.height,128):
            w=Window(0,row,mask.width,min(128,mask.height-row))
            valid=mask.read(1,window=w)==1; code=ids[row:row+int(w.height)]
            a,b=c20.read(1,window=w),c25.read(1,window=w)
            r=ref.read(1,window=w); ca=(a>0)&(a<255)&valid; cb=(b>0)&(b<255)&valid
            common=ca&cb; built=(b==3)&valid
            sel={'territorio':valid,'con_cobertura_2020':ca,'con_cobertura_2025':cb,
                 'comun_2020_2025':common,'construido_2020_comun':common&(a==3),
                 'construido_2025_comun':common&(b==3),'construido_2025':built,
                 'ref_municipal_medio':valid&(r==1),'ref_municipal_alto':valid&(r==2),
                 'ref_municipal_desconocido':valid&(r==0),
                 'construido_2025_ref_medio':built&(r==1),'construido_2025_ref_alto':built&(r==2),
                 'construido_2025_ref_desconocido':built&(r==0)}
            for k in models:
                high=(ranks[k].read(1,window=w)>90)&valid
                sel[k+'_decil_territorio']=high
                sel[k+'_construido_decil_territorio']=high&built
                sel[k+'_construido_decil_construido']=built&(log[k].read(1,window=w)>=thresholds[k])
            for k,s in sel.items():
                counts[k]+=np.bincount(code[s],minlength=n)
    result=pd.concat([q[['id_municipal','parroquia']],
                      pd.DataFrame({'id_municipal':[0],'parroquia':['SIN ASIGNACIÓN PARROQUIAL']})],ignore_index=True)
    for k,c in counts.items():result[k+'_ha']=c[result.id_municipal]*HA_PER_CELL
    result['cambio_area_clasificada_construida_comun_ha']=result.construido_2025_comun_ha-result.construido_2020_comun_ha
    for k in models:
        den=result.construido_2025_ha.replace(0,np.nan)
        result[k+'_pct_construido_priorizado']=100*result[k+'_construido_decil_construido_ha']/den
    result['fuentes']='Municipio de Quito; SNGR; Copernicus; ESA; elaboración propia'
    result.to_csv(F/'exposicion_parroquias_quito.csv',index=False)
    q.merge(result.drop(columns='parroquia'),on='id_municipal').drop(columns=['fid','id','dpa_despar']).to_crs(4326).to_file(F/'parroquias_prioridad.geojson',driver='GeoJSON')
    audit={'unidad':'ha de suelo clasificado; no viviendas/personas/daños',
           'umbrales_log_intensidad_decil_construido_dmq':thresholds,
           'celdas_sin_parroquia_dentro_dmq':int(counts['territorio'][0]),
           'normalizacion_nombre_fuente':['AMAGUA�A -> AMAGUAÑA', 'I�AQUITO -> IÑAQUITO'],
           'totales_ha':{k:float(c.sum()*HA_PER_CELL) for k,c in counts.items()},
           'empates_umbral':'se incluyen >= umbral; se informa área efectiva, no se fuerza 10 % exacto',
           'modelo_construido':'ranking condicionado a suelo construido municipal 2025; no nueva evaluación externa'}
    (F/'control_exposicion.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
    print(result.sort_values('inundacion_lineal_construido_decil_construido_ha',ascending=False)[['parroquia','construido_2025_ha','inundacion_lineal_construido_decil_construido_ha']].head(10).to_string(index=False),flush=True)


if __name__=='__main__':main()
