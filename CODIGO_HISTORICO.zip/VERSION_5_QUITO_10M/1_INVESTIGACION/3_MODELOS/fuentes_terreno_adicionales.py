"""Comprueba fuentes públicas y descarga el geoide necesario para alturas GEDI.

El archivo de un estudio previo se inspecciona sin presuponer que incluya DEM.
No se ejecuta JavaScript remoto ni se consultan atributos catastrales personales.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import requests
import truststore
import hashlib
import json
import re
import zipfile

P = Path(__file__).resolve().parents[1]
R = P/'2_DATOS/ORIGINALES/BUSQUEDA_TERRENO'
URLS = {
    'egm2008': 'https://cdn.proj.org/us_nga_egm08_25.tif',
    'egm2008_licencia': 'https://raw.githubusercontent.com/OSGeo/PROJ-data/master/us_nga/us_nga_README.txt',
    'quito_js': 'https://pam.quito.gob.ec/PAM/js/geofunciones.js',
    'igm_config': 'https://www.geoportaligm.gob.ec/mapstore2/configs/localConfig.json',
    'igm_context': 'https://www.geoportaligm.gob.ec/mapstore2/rest/geostore/misc/category/name/CONTEXT/resource/name/VISOR_GEOGRAFICO_RASTER/data',
    'igm_bundle': 'https://www.geoportaligm.gob.ec/mapstore2/dist/mapstore2.js?6eababd30912839c',
    'zenodo_apoyo_quito': 'https://zenodo.org/records/5881876/files/22_Packaged_data_greenspace_paper.zip?download=1'
}


def main():
    truststore.inject_into_ssl(); R.mkdir(parents=True, exist_ok=True)
    def get(pair):
        key, url = pair
        suffix = '.tif' if key == 'egm2008' else '.zip' if key == 'zenodo_apoyo_quito' else '.txt'
        file = R/(key+suffix)
        try:
            if not file.exists():
                response = requests.get(url, timeout=(15, 180))
                status = response.status_code
                if status != 200:
                    return {'fuente': key, 'url': url, 'status': status}
                file.write_bytes(response.content)
            result = {'fuente': key, 'url': url, 'bytes': file.stat().st_size,
                      'sha256': hashlib.sha256(file.read_bytes()).hexdigest()}
            if suffix == '.zip':
                with zipfile.ZipFile(file) as z:
                    result['contenido'] = z.namelist()
            elif suffix == '.txt':
                txt = file.read_text(encoding='utf-8', errors='replace')
                urls = sorted(set(re.findall(r'https?://[^\s\"\'<>]+', txt)))
                result['urls_datos'] = [a[:350] for a in urls if re.search(r'geoserver|geostore|arcgis|wms|wcs|rest|mdt|dem', a, re.I)][:80]
            file.with_suffix('.fuente.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
            return result
        except Exception as e:
            return {'fuente': key, 'url': url, 'error': type(e).__name__}
    with ThreadPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(get, URLS.items()))
    (R/'fuentes_adicionales.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
    for result in results:
        print(json.dumps(result, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
