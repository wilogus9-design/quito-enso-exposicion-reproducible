"""Teselas de alturas experimentales de menos de 10 MB y VRT georreferenciado."""
from pathlib import Path
from xml.sax.saxutils import escape
import rasterio
from rasterio.windows import Window

P=Path(__file__).resolve().parents[1]
D=P/'2_DATOS/PROCESADOS'
F=P/'6_FINAL/RASTERS_10M'


def main():
    label='altura_ajustada_GEDI_ESTIMADA';folder=F/label;folder.mkdir(parents=True,exist_ok=True)
    sources=[]
    with rasterio.open(D/'altura_ajustada_gedi_estimada_10m.tif') as src:
        for row in range(0,src.height,1024):
            for col in range(0,src.width,1024):
                w=Window(col,row,min(1024,src.width-col),min(1024,src.height-row))
                a=src.read(window=w)
                if not (a[0]!=src.nodata).any():continue
                file=folder/f'tesela_{row:05d}_{col:05d}.tif'
                profile=src.profile.copy();profile.update(width=a.shape[2],height=a.shape[1],transform=src.window_transform(w))
                with rasterio.open(file,'w',**profile) as out:
                    out.write(a);out.descriptions=src.descriptions;out.update_tags(**src.tags())
                if file.stat().st_size>10_000_000:raise ValueError('Tesela >10 MB')
                sources.append(f'<SimpleSource><SourceFilename relativeToVRT="1">{escape(label+"/"+file.name)}</SourceFilename><SourceBand>1</SourceBand><SrcRect xOff="0" yOff="0" xSize="{a.shape[2]}" ySize="{a.shape[1]}"/><DstRect xOff="{col}" yOff="{row}" xSize="{a.shape[2]}" ySize="{a.shape[1]}"/><NODATA>-9999</NODATA></SimpleSource>')
        xml=f'<VRTDataset rasterXSize="{src.width}" rasterYSize="{src.height}"><SRS>{escape(src.crs.to_wkt())}</SRS><GeoTransform>{",".join(map(str,src.transform.to_gdal()))}</GeoTransform><VRTRasterBand dataType="Float32" band="1"><Description>Altura EGM2008 estimada NO levantamiento 10 m</Description><NoDataValue>-9999</NoDataValue>{"".join(sources)}</VRTRasterBand></VRTDataset>'
        (F/(label+'.vrt')).write_text(xml,encoding='utf-8')
    print('Teselas de altura estimada:',len(sources),flush=True)


if __name__=='__main__':main()
