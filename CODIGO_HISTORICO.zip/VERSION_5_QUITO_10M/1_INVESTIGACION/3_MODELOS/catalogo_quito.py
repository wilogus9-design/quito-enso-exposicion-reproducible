"""Descubre únicamente servicios públicos municipales relevantes para Quito."""
from pathlib import Path
import json
import re
import hashlib
import requests
import truststore
from concurrent.futures import ThreadPoolExecutor

P=Path(__file__).resolve().parents[1]
RAW=P/'2_DATOS/ORIGINALES/GEOPORTAL_QUITO'
BASE='https://geoquito.quito.gob.ec/server/rest/services'


def get(url, filename):
    path=RAW/filename
    if path.exists():return json.loads(path.read_text(encoding='utf-8'))
    r=requests.get(url,params={'f':'json'},timeout=(20,40))
    r.raise_for_status()
    obj=r.json()
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
    return obj


def main():
    truststore.inject_into_ssl()
    RAW.mkdir(parents=True,exist_ok=True)
    top=get(BASE,'catalogo_raiz.json')
    services=list(top.get('services',[]))
    folders=top.get('folders',[])
    def folder(name):
        obj=get(BASE+'/'+name,'catalogo_'+name+'.json')
        return obj.get('services',[])
    with ThreadPoolExecutor(max_workers=4) as pool:
        for s in pool.map(folder,folders):services.extend(s)
    targets=[s for s in services if re.search(r'amenaz|riesg|inund|quebrad|aluv|masa|barri|parro|hidrog|terreno|mdt|dem_|elev|orto',s['name'],re.I)]
    # Servicios generales contienen subcapas; se consideran como catálogo, sin datos privados.
    for s in services:
        if s['name'].startswith('web_service/') and s not in targets:targets.append(s)
    records=[]
    def metadata(s):
        name=s['name'].replace('/','__')+'_'+s['type']
        try:
            obj=get(BASE+'/'+s['name']+'/'+s['type'],name+'.json')
            layers=[{'id':a['id'],'name':a['name']} for a in obj.get('layers',[]) if re.search(r'amenaz|riesg|inund|quebrad|aluv|masa|barri|parro|hidrog|terreno|mdt|dem|elev|orto',a['name'],re.I)]
            return {'service':s,'url':BASE+'/'+s['name']+'/'+s['type'],'relevant_layers':layers,'description':obj.get('description','')[:1500], 'error':obj.get('error')}
        except Exception as e:return {'service':s,'error':str(e)}
    with ThreadPoolExecutor(max_workers=4) as pool:
        for item in pool.map(metadata,targets):
            records.append(item)
            if item.get('relevant_layers') or not item['service']['name'].startswith('web_service/'):
                print(item['service']['name'],item.get('relevant_layers',[]),item.get('error'),flush=True)
    (RAW/'servicios_relevantes.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
    (RAW/'manifest.json').write_text(json.dumps([{'archivo':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in RAW.glob('*.json') if p.name!='manifest.json'],indent=2),encoding='utf-8')
    print('Servicios totales:',len(services),'seleccionados:',len(records),flush=True)


if __name__=='__main__':main()
