"""Reexpresa el ranking dentro del suelo construido para distinguir sectores urbanos.

Transformación cartográfica de modelos congelados; no reentrena ni añade etiquetas.
No afirma vulnerabilidad de cada hogar. Fuera de construido 2025 es nodata.
"""
from pathlib import Path
from contextlib import ExitStack
import json
import numpy as np
import rasterio
from rasterio.windows import Window
from entrega_rasters import tiles

P=Path(__file__).resolve().parents[1]
D=P/'2_DATOS/PROCESADOS'
F=P/'6_FINAL'


def main():
    meta={}
    with rasterio.open(D/'cobertura_municipal_2025_10m.tif') as land, rasterio.open(D/'mascara_quito_10m.tif') as mask:
        for model in ['inundacion_lineal','inundacion_red','deslizamiento_lineal','deslizamiento_red']:
            with rasterio.open(D/('log_intensidad_'+model+'_10m.tif')) as src:
                vals=[]
                for row in range(0,src.height,128):
                    w=Window(0,row,src.width,min(128,src.height-row))
                    b=(land.read(1,window=w)==3)&(mask.read(1,window=w)==1)
                    vals.append(src.read(1,window=w)[b])
                v=np.concatenate(vals);thresholds=np.quantile(v,np.arange(1,100)/100)
                profile=land.profile.copy();profile.update(nodata=0)
                file=D/('prioridad_'+model+'_construido_10m.tif')
                high=0;count=0
                with rasterio.open(file,'w',**profile) as dst:
                    for row in range(0,src.height,128):
                        w=Window(0,row,src.width,min(128,src.height-row))
                        b=(land.read(1,window=w)==3)&(mask.read(1,window=w)==1)
                        value=src.read(1,window=w);out=np.zeros(b.shape,dtype=np.uint8)
                        out[b]=1+np.searchsorted(thresholds,value[b],side='right');dst.write(out,1,window=w)
                        count+=int(b.sum());high+=int((out>90).sum())
                    dst.set_band_description(1,'prioridad_condicionada_construido_NO_probabilidad')
                    dst.update_tags(pixel_m=10,terrain_native_m=30,not_a_flood_probability='true',landcover='Municipio Quito 2025')
                meta[model]={'n_celdas_construidas':count,'n_decil_superior':high,'area_decil_ha':high*.01,'umbrales_log':thresholds.tolist()}
                tiles(file,'prioridad_'+model+'_construido')
    (F/'control_prioridad_construido.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')


if __name__=='__main__':main()
