"""Inferencia por ventanas en RTX y mapas 10 m, sin confundir intensidad con probabilidad."""
from pathlib import Path
import json
import math
import numpy as np
import torch
import rasterio
from rasterio.windows import Window
from red_punto_proceso import SpatialNet

P=Path(__file__).resolve().parents[1]
D=P/'2_DATOS/PROCESADOS'
F=P/'6_FINAL'
R=F/'RASTERS_10M'
CLASSES=[10,20,30,40,50,60,70,80,90,95,100]


def logmeanexp(a,axis=None):
    m=np.max(a,axis=axis,keepdims=True)
    v=m+np.log(np.mean(np.exp(a-m),axis=axis,keepdims=True))
    return np.squeeze(v,axis=axis) if axis is not None else float(v.item())


def feature_window(wc,t,density,mask,row,nrows=128):
    width=wc.width;rows=min(nrows,wc.height-row)
    window=Window(0,row,width,rows)
    w=wc.read(1,window=window);de=density.read(window=window)
    rr=np.clip(np.arange(row,row+rows)//3,0,t.height-1)
    cc=np.clip(np.arange(width)//3,0,t.width-1)
    tw=Window(0,int(rr.min()),t.width,int(rr.max()-rr.min()+1))
    a=t.read(window=tw)
    tv=a[:7,rr-int(rr.min())][:,:,cc]
    valid=mask.read(1,window=window).astype(bool)&np.isin(w,CLASSES)&np.isfinite(tv).all(axis=0)
    X=np.stack([tv[0]/1000,tv[1],tv[2],tv[3],np.log1p(tv[4]/10),np.log1p(tv[5]/10),np.log1p(tv[6]/10),de[0],de[1],*[(w==v).astype(np.float32) for v in CLASSES]],axis=-1)
    return X.reshape(-1,20),valid.reshape(-1),window,rows


def main():
    R.mkdir(parents=True,exist_ok=True)
    device='cuda' if torch.cuda.is_available() else 'cpu'
    torch.set_num_threads(4)
    print('Inferencia por ventanas:',device,flush=True)
    states=json.loads((D/'modelos_lineales.json').read_text(encoding='utf-8'))
    models={};background={};quantiles={}
    for hazard in ['INUNDACION','DESLIZAMIENTO']:
        key=hazard+'_temporal';st=states[key];models[hazard]=[]
        z=np.load(D/f'entrada_red_{key}.npz');Xb=z['Xb']
        logs=[]
        for seed in [5101,5102,5103]:
            checkpoint=torch.load(D/f'red_{key}_{seed}.pt',map_location=device,weights_only=True)
            model=SpatialNet().to(device);model.load_state_dict(checkpoint['state_dict']);model.eval()
            fb=np.load(D/f'scores_red_{key}_{seed}.npz')['fb']
            Z=logmeanexp(fb);logs.append(fb-Z)
            models[hazard].append((model,checkpoint['alpha'],Z))
        bg=logmeanexp(np.stack(logs),axis=0)
        quantiles[hazard]=np.quantile(bg,np.arange(1,100)/100)
        b=np.array(st['beta'])*st['alpha']
        background[hazard]={'beta':b,'Z':logmeanexp(Xb@b),'mu':np.array(st['mu'],dtype=np.float32),'sd':np.array(st['sd'],dtype=np.float32)}
    wc=rasterio.open(D/'worldcover_2021_10m.tif');t=rasterio.open(D/'derivados_30m.tif');den=rasterio.open(D/'densidad_construida_10m.tif');mask=rasterio.open(D/'mascara_quito_10m.tif')
    profile=wc.profile.copy();profile.update(driver='GTiff',count=1,dtype='float32',nodata=-9999,compress='deflate',predictor=3,tiled=True,blockxsize=256,blockysize=256,BIGTIFF='IF_SAFER')
    outs={};ranks={};sums={h:[0.,0.,0] for h in models}
    for hazard in models:
        short='inundacion' if hazard=='INUNDACION' else 'deslizamiento'
        for kind in ['red','lineal','desacuerdo']:
            path=D/f'log_intensidad_{short}_{kind}_10m.tif' if kind!='desacuerdo' else D/f'desacuerdo_{short}_10m.tif'
            outs[(hazard,kind)]=rasterio.open(path,'w',**profile)
            outs[(hazard,kind)].set_band_description(1,'log_densidad_relativa_de_reportes' if kind!='desacuerdo' else 'dispersion_entre_redes_no_IC_total')
        pr=profile.copy();pr.update(dtype='uint8',nodata=0,predictor=2)
        ranks[hazard]=rasterio.open(R/f'prioridad_{short}_percentil_10m.tif','w',**pr)
        ranks[hazard].set_band_description(1,'1_100_percentil_de_prioridad_NO_probabilidad_0_sin_datos')
    try:
      for row in range(0,wc.height,128):
        X,valid,win,nrows=feature_window(wc,t,den,mask,row)
        for hazard in models:
            bg=background[hazard];XX=(X[valid]-bg['mu'])/bg['sd']
            tensor=torch.as_tensor(XX,device=device)
            if len(XX)==0:
                lr=np.empty(0,dtype=np.float32);disagreement=lr.copy()
            else:
                with torch.no_grad():
                    logseeds=torch.stack([net(tensor)*alpha-Z for net,alpha,Z in models[hazard]])
                    lr=(torch.logsumexp(logseeds,dim=0)-math.log(3)).cpu().numpy()
                    disagreement=torch.std(logseeds,dim=0,unbiased=False).cpu().numpy()
            linear=XX@bg['beta']-bg['Z']
            for kind,values in [('red',lr),('lineal',linear),('desacuerdo',disagreement)]:
                out=np.full(len(valid),-9999,dtype=np.float32);out[valid]=values
                outs[(hazard,kind)].write(out.reshape(nrows,wc.width),1,window=win)
            rank=np.zeros(len(valid),dtype=np.uint8)
            rank[valid]=1+np.searchsorted(quantiles[hazard],lr,side='right')
            ranks[hazard].write(rank.reshape(nrows,wc.width),1,window=win)
            sums[hazard][0]+=float(np.exp(lr.astype(float)).sum());sums[hazard][1]+=float(np.exp(linear).sum());sums[hazard][2]+=int(valid.sum())
        if row%1024==0:print('Fila',row,'/',wc.height,flush=True)
    finally:
      for output in [*outs.values(),*ranks.values()]:output.close()
    # Corrección exacta del normalizador de área en la grilla final, no en las etiquetas.
    for hazard in models:
        short='inundacion' if hazard=='INUNDACION' else 'deslizamiento'
        for j,kind in enumerate(['red','lineal']):
            correction=math.log(sums[hazard][j]/sums[hazard][2])
            with rasterio.open(D/f'log_intensidad_{short}_{kind}_10m.tif','r+') as src:
                for _,win in src.block_windows(1):
                    a=src.read(1,window=win);v=a!=-9999;a[v]-=correction;src.write(a,1,window=win)
        with rasterio.open(R/f'prioridad_{short}_percentil_10m.tif','r+') as src:
            src.build_overviews([2,4,8,16],rasterio.enums.Resampling.nearest)
            src.update_tags(interpreta='Prioridad relativa de localizaciones reportadas, no probabilidad de inundacion física',pixel_m=10,terreno_m=30,soporte_reportes_m=100)
    (F/'normalizacion_grilla.json').write_text(json.dumps({'sumas':sums,'interpretacion':'densidad_media_grilla=1; no probabilidad_de_evento',
       'ensemblado':'media de densidades de tres redes; parametros congelados tras calibracion','device':device},ensure_ascii=False,indent=2),encoding='utf-8')
    print('Mapas a 10 m generados; clasificacion de prioridad, no inundacion futura validada.',flush=True)


if __name__=='__main__':main()
