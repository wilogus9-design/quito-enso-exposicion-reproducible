"""Lluvia futura nativa ~5 km: cruce por área, nunca lluvia ficticia a 10 m.

La fecha de análisis fija reproduce el informe. Puede elegirse otra fecha y
actualizar el archivo público, conservando issue y fechas válidas separados.
Se usa el producto medio del ensamble: no contiene incertidumbre GEFS completa.
"""
from pathlib import Path
import argparse
import datetime as dt
import hashlib
import json
import requests
import truststore
import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from rasterio.windows import from_bounds,Window
from shapely.geometry import box
from shapely.ops import transform
from pyproj import Transformer

P=Path(__file__).resolve().parents[1]
ROOT=P.parents[2]
R=P/'2_DATOS/ORIGINALES/LLUVIA_PRONOSTICO'
F=P/'6_FINAL'


def main():
    global F
    ap=argparse.ArgumentParser();ap.add_argument('--fecha',default='2026-10-09')
    ap.add_argument('--actualizar',action='store_true');ap.add_argument('--salida',type=Path);args=ap.parse_args()
    if args.salida:
        destination=args.salida.resolve()
        if not destination.is_relative_to(P.resolve()):raise ValueError('Salida debe quedar dentro de V05')
        F=destination;F.mkdir(parents=True,exist_ok=True)
    date=dt.date.fromisoformat(args.fecha)
    issue=dt.date(2026,10,8) if not args.actualizar else date
    days=[date+dt.timedelta(days=i) for i in range(1,8)]
    truststore.inject_into_ssl();R.mkdir(parents=True,exist_ok=True)
    inputfiles=[];urls=[]
    if args.actualizar:
        # Check current/previous issue availability once, do not fabricate success.
        for candidate in [date,date-dt.timedelta(days=1),date-dt.timedelta(days=2)]:
            base=f'https://data.chc.ucsb.edu/products/CHIRPS-GEFS/v3/daily/global/{candidate:%Y/%m/%d}/'
            url=base+f'c3g_{days[0]:%Y.%m.%d}.tif'
            if requests.head(url,timeout=(15,40)).status_code==200:issue=candidate;break
        else:raise RuntimeError('No hay emisión accesible para esta fecha')
    for day in days:
        name=f'c3g_{day:%Y.%m.%d}.tif'
        old=ROOT/f'EXPOSICION_FEN_NINO/VERSION_3/1_INVESTIGACION/2_DATOS/ORIGINALES/CHIRPS3_GEFS/{issue:%Y%m%d}'/name
        own=R/f'{issue:%Y%m%d}'/name
        url=f'https://data.chc.ucsb.edu/products/CHIRPS-GEFS/v3/daily/global/{issue:%Y/%m/%d}/'+name
        if old.exists():file=old
        elif own.exists():file=own
        elif args.actualizar:
            response=requests.get(url,timeout=(20,240));response.raise_for_status()
            own.parent.mkdir(parents=True,exist_ok=True);own.write_bytes(response.content);file=own
        else:raise FileNotFoundError('Falta la emisión fija de '+str(day)+'; use --actualizar para otro análisis')
        inputfiles.append(file);urls.append(url)
    q=gpd.read_file(P/'2_DATOS/PROCESADOS/quito_limite.geojson').to_crs(4326)
    bb=q.total_bounds
    with rasterio.open(inputfiles[0]) as src:
        w=from_bounds(bb[0]-.1,bb[1]-.1,bb[2]+.1,bb[3]+.1,src.transform)
        r0,c0=int(np.floor(w.row_off)),int(np.floor(w.col_off))
        r1,c1=int(np.ceil(w.row_off+w.height)),int(np.ceil(w.col_off+w.width))
        w=Window(c0,r0,c1-c0,r1-r0);tr=src.window_transform(w)
        profile=src.profile.copy();profile.update(height=r1-r0,width=c1-c0,transform=tr,nodata=-9999)
    rain=[]
    for file in inputfiles:
        with rasterio.open(file) as src:
            a=src.read(1,window=w).astype(np.float32)
        # Product -9999, NaN or negative are missing, not zero rainfall.
        a[(~np.isfinite(a))|(a<0)]=-9999;rain.append(a)
    stack=np.stack(rain);proj=Transformer.from_crs(4326,32717,always_xy=True).transform
    cells=[]
    for row in range(stack.shape[1]):
        for col in range(stack.shape[2]):
            left,top=tr*(col,row);right,bottom=tr*(col+1,row+1)
            cells.append(transform(proj,box(left,bottom,right,top)))
    records=[]
    for layer in ['parroquias','microcuencas']:
        geo=gpd.read_file(P/f'2_DATOS/ORIGINALES/VECTORES/{layer}.geojson').to_crs(32717)
        boundary=q.to_crs(32717).geometry.union_all()
        for i,rec in geo.iterrows():
            geom=rec.geometry.intersection(boundary)
            if geom.is_empty:continue
            weight=np.array([geom.intersection(c).area if geom.intersects(c) else 0 for c in cells])
            if weight.sum()==0:continue
            ident=rec.get('fid',rec.get('objectid',rec.get('OBJECTID',i+1)))
            name=rec.get('dpa_despar','microcuenca_'+str(ident))
            name=str(name).replace('AMAGUA�A','AMAGUAÑA').replace('I�AQUITO','IÑAQUITO')
            for day,a in zip(days,stack):
                v=a.ravel();ok=v!=-9999;den=weight[ok].sum()
                records.append({'unidad_espacial':layer,'id_municipal':ident,'nombre':name,
                                'fecha_analisis':str(date),'emision':str(issue),'fecha_valida':str(day),
                                'lluvia_media_area_mm':float(np.dot(v[ok],weight[ok])/den) if den>0 else np.nan,
                                'cobertura_area_fraccion':float(den/geom.area),'n_celdas_nativas_intersectadas':int((weight>0).sum()),
                                'resolucion_grados':float(tr.a),'fuente':'CHIRPS3-GEFS; CHC UCSB; elaboración propia'})
    df=pd.DataFrame(records);df.to_csv(F/'lluvia_futura_parroquia_microcuenca.csv',index=False)
    # No extrapolation into incomplete horizons.
    agg=df.groupby(['unidad_espacial','id_municipal','nombre','emision'],as_index=False).agg(
        lluvia_7dias_mm=('lluvia_media_area_mm',lambda x:x.sum(min_count=7)),
        dias_con_datos=('lluvia_media_area_mm','count'),cobertura_area_min=('cobertura_area_fraccion','min'))
    agg['inicio_horizonte']=str(days[0]);agg['fin_horizonte']=str(days[-1]);agg.to_csv(F/'lluvia_7dias_quito.csv',index=False)
    total=np.where((stack!=-9999).all(axis=0),np.where(stack==-9999,0,stack).sum(axis=0),-9999).astype(np.float32)
    with rasterio.open(F/'lluvia_7dias_nativa_005_grados.tif','w',**profile) as dst:
        dst.write(total,1);dst.set_band_description(1,'lluvia_futura_7dias_mm_NO_10m')
        dst.update_tags(issue=str(issue),start=str(days[0]),end=str(days[-1]),source='CHC UCSB CHIRPS3-GEFS')
    meta={'fecha_analisis':str(date),'emision':str(issue),'horizonte':[str(days[0]),str(days[-1])],
          'resolucion_grados':float(tr.a),'inputs':[{'path':str(f),'url':u,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f,u in zip(inputfiles,urls)],
          'limitacion':'media del ensamble; lluvia regional, no precipitación 10 m; no profundidad inundación ni probabilidad',
          'relacion_con_prioridad':'contexto separado; no se multiplicó para inventar una probabilidad de inundación'}
    (F/'control_lluvia.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
    print(agg[agg.unidad_espacial=='parroquias'].sort_values('lluvia_7dias_mm',ascending=False).head(10).to_string(index=False),flush=True)


if __name__=='__main__':main()
