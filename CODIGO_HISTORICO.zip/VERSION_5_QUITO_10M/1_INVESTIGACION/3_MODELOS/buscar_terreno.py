"""Busca metadatos públicos de terreno sin interpretar una imagen RGB como elevación."""
from pathlib import Path
import requests
import truststore
import json
import re
from concurrent.futures import ThreadPoolExecutor

P=Path(__file__).resolve().parents[1]
R=P/'2_DATOS/ORIGINALES/BUSQUEDA_TERRENO'
TARGETS={
 'igm_visor':'https://www.geoportaligm.gob.ec/visor_raster/index.html',
 'igm_wcs':'https://www.geoportaligm.gob.ec/geoserver/igm/wcs?service=WCS&request=GetCapabilities',
 'igm_wms':'https://www.geoportaligm.gob.ec/geoserver/igm/wms?service=WMS&request=GetCapabilities',
 'sigtierras_descargas':'https://www.sigtierras.gob.ec/descargas/',
 'sigtierras_geoportal':'https://geoportal.sigtierras.gob.ec/',
 'municipio_coberturas':'https://geoquito.quito.gob.ec/server/rest/services/Vector_Tile/coberturas_catastrales/MapServer?f=json',
 'municipio_catastro_metas':'https://geoquito.quito.gob.ec/server/rest/services/web_reference_dmc/catastro_dmc_view/MapServer?f=json',
 'igm_quito_tematica':'https://www.geoportaligm.gob.ec/descargas_prueba/quito.html',
 'quito_visor':'https://pam.quito.gob.ec/PAM/Geoportales/GeoInternet.aspx',
 'ups_lidar':'https://dspace.ups.edu.ec/handle/123456789/30736',
 'igm_mapstore':'https://www.geoportaligm.gob.ec/mapstore/',
 'igm_mapstore2':'https://www.geoportaligm.gob.ec/mapstore2/',
 'quito_accidente_meta':'https://geoquito.quito.gob.ec/server/rest/services/Vector_Tile/coberturas_catastrales/MapServer/0?f=json',
 'world_elevation_meta':'https://elevation3d.arcgis.com/arcgis/rest/services/WorldElevation3D/Terrain3D/ImageServer?f=json',
}


def main():
    truststore.inject_into_ssl();R.mkdir(parents=True,exist_ok=True)
    def get(pair):
        name,url=pair
        try:
            response=requests.get(url,timeout=(15,40))
            (R/(name+'.txt')).write_text(response.text,encoding='utf-8')
            links=re.findall(r'(?:src|href)=[\"\']([^\"\']+)',response.text)
            obj={'fuente':name,'url':url,'status':response.status_code,'bytes':len(response.content),
                 'links_relevantes':[a for a in links if re.search(r'\.js|\.tif|\.zip|wms|wcs|mapserver|dem|mdt|lidar|\.las|mapstore|geonode|visor|raster',a,re.I)]}
            try:
                j=response.json()
                obj['layers']=[{'id':l['id'],'name':l['name']} for l in j.get('layers',[])]
            except Exception:pass
            return obj
        except Exception as e:return {'fuente':name,'url':url,'error':type(e).__name__}
    with ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(get,TARGETS.items()))
    (R/'estado_busqueda.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
    for item in results:print(json.dumps(item,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
