"""Red espacial de presencias, RTX opcional. Sin etiquetas de ausencia física.

Se ejecuta con el entorno Torch existente, distinto del entorno geoespacial.
"""
from pathlib import Path
import json
import copy
import math
import numpy as np
import torch
from torch import nn

P=Path(__file__).resolve().parents[1]
D=P/'2_DATOS/PROCESADOS'
F=P/'6_FINAL'


class SpatialNet(nn.Module):
    def __init__(self,p=20):
        super().__init__()
        self.layers=nn.Sequential(nn.Linear(p,32),nn.SiLU(),nn.Linear(32,16),nn.SiLU(),nn.Linear(16,1))
    def forward(self,x):return self.layers(x).squeeze(-1)


def raw(network,X,batch=262144):
    return np.concatenate([network(torch.as_tensor(X[i:i+batch],device=next(network.parameters()).device)).detach().cpu().numpy() for i in range(0,len(X),batch)])


def tensor_eval(network,Xe,Xb,valid,alpha=1):
    with torch.no_grad():
        fb=network(Xb)*alpha
        fe=network(Xe)*alpha
        fe=fe.masked_fill(~valid,-torch.inf)
        ev=torch.logsumexp(fe,dim=1)-torch.log(valid.sum(dim=1))
        return float(ev.mean()-torch.logsumexp(fb,dim=0)+math.log(len(fb)))


def main():
    device='cuda' if torch.cuda.is_available() else 'cpu'
    torch.set_num_threads(4)
    print('Entrenamiento de punto-proceso en',torch.cuda.get_device_name(0) if device=='cuda' else device,flush=True)
    states=json.loads((D/'modelos_lineales.json').read_text(encoding='utf-8'))
    results=[];audit=[]
    for key,st in states.items():
      z=np.load(D/f'entrada_red_{key}.npz')
      Xb=torch.as_tensor(z['Xb'],device=device)
      Xe=torch.as_tensor(z['Xe'],device=device)
      ve=torch.as_tensor(z['valid_e'],device=device)
      etr=torch.as_tensor(z['etrain'],device=device);ecal=torch.as_tensor(z['ecal'],device=device)
      btr=torch.as_tensor(z['btrain'],device=device);bcal=torch.as_tensor(z['bcal'],device=device)
      btrain=Xb[btr];etrain=Xe[etr];vtrain=ve[etr]
      evalid=Xe[ecal];vvalid=ve[ecal];bvalid=Xb[bcal]
      for seed in [5101,5102,5103]:
        torch.manual_seed(seed);rng=np.random.default_rng(seed)
        model=SpatialNet(Xb.shape[1]).to(device)
        optimizer=torch.optim.AdamW(model.parameters(),lr=.003,weight_decay=.01)
        best=-float('inf');best_epoch=None;best_state=None
        for epoch in range(201):
            model.train()
            ii=torch.as_tensor(rng.choice(len(btrain),size=min(16384,len(btrain)),replace=False),device=device)
            fe=model(etrain).masked_fill(~vtrain,-torch.inf)
            marginal=torch.logsumexp(fe,dim=1)-torch.log(vtrain.sum(dim=1))
            fb=model(btrain[ii])
            loss=torch.logsumexp(fb,dim=0)-math.log(len(fb))-marginal.mean()
            optimizer.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5.);optimizer.step()
            if epoch%10==0:
                model.eval();value=tensor_eval(model,evalid,bvalid,vvalid)
                if value>best:
                    best=value;best_epoch=epoch;best_state={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
        model.load_state_dict(best_state);model.eval()
        alphas=[(tensor_eval(model,evalid,bvalid,vvalid,a),a) for a in [.25,.5,.75,1.,1.25]]
        alpha=max(alphas)[1]
        path=D/f'red_{key}_{seed}.pt'
        torch.save({'state_dict':best_state,'n_features':Xb.shape[1],'seed':seed,'alpha':alpha,'epoch':best_epoch,'model_type':'spatial_presence_only_conditional_density'},path)
        with torch.no_grad():
            scores_b=raw(model,z['Xb'])*alpha
            scores_e=raw(model,z['Xe'].reshape(-1,Xb.shape[1]))*alpha
        np.savez_compressed(D/f'scores_red_{key}_{seed}.npz',fb=scores_b,fe=scores_e.reshape(z['Xe'].shape[:2]))
        audit.append({'key':key,'seed':seed,'device':device,'epoch_por_calibracion':best_epoch,'temperado':alpha,'log_densidad_cal':max(alphas)[0]})
        print(key,seed,'epoch',best_epoch,'cal',round(max(alphas)[0],4),'alpha',alpha,flush=True)
    (F/'entrenamiento_red_rtx.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')


if __name__=='__main__':main()
