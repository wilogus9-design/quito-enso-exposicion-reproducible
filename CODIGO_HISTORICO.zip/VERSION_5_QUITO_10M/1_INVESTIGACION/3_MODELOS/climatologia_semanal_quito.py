"""Referencia de la misma semana calendario 1981-2021, sin usar años test.

No calibra el pronóstico GEFS ni le asigna una probabilidad. CHIRPS3 DAILY_RNL
reparte totales pentadales mediante ERA5: no es pluviómetro urbano ni IMERG Early.
"""
from pathlib import Path
import json
import datetime as dt
import hashlib
import ee
import requests
import truststore
import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from shapely.geometry import box
from shapely.ops import transform
from pyproj import Transformer

P=Path(__file__).resolve().parents[1]
R=P/'2_DATOS/ORIGINALES/CLIMATOLOGIA'
F=P/'6_FINAL'


def main():
    meta=json.loads((F/'control_lluvia.json').read_text(encoding='utf-8'))
    start=dt.date.fromisoformat(meta['horizonte'][0]);end=dt.date.fromisoformat(meta['horizonte'][1])
    # For this frozen run the week does not span a calendar year.
    if start.year!=end.year:raise ValueError('Implementar ventana que cruza año antes de actualizar')
    R.mkdir(parents=True,exist_ok=True)
    file=R/f'chirps3_rnl_semana_{start:%m%d}_{end:%m%d}_1981_2021.tif'
    countfile=R/f'conteos_semana_{start:%m%d}_{end:%m%d}_1981_2021.tif'
    with rasterio.open(F/'lluvia_7dias_nativa_005_grados.tif') as s:
        tr=s.transform;shape=(s.height,s.width);forecast=s.read(1);crs=s.crs
    truststore.inject_into_ssl()
    if not file.exists() or not countfile.exists():
        ee.Initialize(project='verdant-art-479615-c4')
        col=ee.ImageCollection('UCSB-CHC/CHIRPS/V3/DAILY_RNL')
        images=[];counts=[]
        for year in range(1981,2022):
            a=dt.date(year,start.month,start.day);b=dt.date(year,end.month,end.day)+dt.timedelta(days=1)
            part=col.filterDate(str(a),str(b)).select('precipitation')
            # Count mask prevents missing days being counted as a complete week.
            image=part.sum().updateMask(part.count().eq(7)).rename('y'+str(year))
            images.append(image)
            counts.append(part.count().rename('n'+str(year)))
        for target,bands in [(file,images),(countfile,counts)]:
            if target.exists():continue
            image=ee.Image.cat(*bands).toFloat()
            url=image.getDownloadURL({'crs':str(crs),'crs_transform':[tr.a,0,tr.c,0,tr.e,tr.f],
                                      'dimensions':[shape[1],shape[0]],'format':'GEO_TIFF','filePerBand':False})
            response=requests.get(url,timeout=(20,180));response.raise_for_status();target.write_bytes(response.content)
    with rasterio.open(file) as s:past=s.read()
    with rasterio.open(countfile) as s:counts=s.read()
    if past.shape!=(41,*shape):raise ValueError('Grilla climatológica incompatible')
    q=gpd.read_file(P/'2_DATOS/PROCESADOS/quito_limite.geojson').to_crs(32717).geometry.union_all()
    geo=gpd.read_file(P/'2_DATOS/ORIGINALES/VECTORES/parroquias.geojson').to_crs(32717)
    proj=Transformer.from_crs(4326,32717,always_xy=True).transform
    cells=[]
    for row in range(shape[0]):
        for col in range(shape[1]):
            left,top=tr*(col,row);right,bottom=tr*(col+1,row+1)
            cells.append(transform(proj,box(left,bottom,right,top)))
    records=[];years=[]
    for _,p in geo.iterrows():
        geom=p.geometry.intersection(q)
        weight=np.array([geom.intersection(c).area if geom.intersects(c) else 0 for c in cells]);weight/=weight.sum()
        historical=past.reshape(41,-1)@weight
        complete=(counts.reshape(41,-1)[:,weight>0]==7).all(axis=1)
        historical[~complete]=np.nan
        pred=float(forecast.ravel()@weight)
        name=p.dpa_despar.replace('AMAGUA�A','AMAGUAÑA').replace('I�AQUITO','IÑAQUITO')
        if not np.isfinite(historical).all():raise ValueError('Climatología incompleta, no sustituir por ceros')
        p90=float(np.quantile(historical,.90))
        records.append({'id_municipal':int(p.fid),'parroquia':name,'lluvia_pronosticada_7dias_mm':pred,
                        'referencia_1981_2021_misma_semana_media_mm':float(historical.mean()),
                        'referencia_p90_mm':p90,'rango_percentil_historico_pronostico':float(100*np.mean(historical<=pred)),
                        'supera_p90_historico':bool(pred>p90),'inicio_horizonte':str(start),'fin_horizonte':str(end),
                        'fuente':'CHIRPS3 DAILY_RNL y CHIRPS3-GEFS; elaboración propia'})
        for year,v in zip(range(1981,2022),historical):years.append({'id_municipal':int(p.fid),'anio':year,'lluvia_semana_mm':float(v)})
    pd.DataFrame(years).to_csv(F/'referencia_lluvia_semanal_1981_2021.csv',index=False)
    df=pd.DataFrame(records);df.to_csv(F/'contraste_pronostico_climatologia.csv',index=False)
    (F/'control_climatologia.json').write_text(json.dumps({'dataset':'UCSB-CHC/CHIRPS/V3/DAILY_RNL',
        'anios':[1981,2021],'semana':[str(start),str(end)],'bandas':41,
        'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'parroquias_superan_p90':int(df.supera_p90_historico.sum()),
        'conteos_diarios_min':float(counts.min()),'conteos_diarios_max':float(counts.max()),
        'sha256_conteos':hashlib.sha256(countfile.read_bytes()).hexdigest(),
        'interpretacion':'comparación con climatología revisada de la misma semana, no validación predictiva GEFS ni probabilidad de inundación',
        'no_es':'no usa lluvia revisada del evento futuro, no lluvia a 10 m'},ensure_ascii=False,indent=2),encoding='utf-8')
    print(df.sort_values('lluvia_pronosticada_7dias_mm',ascending=False).head(8).to_string(index=False),flush=True)


if __name__=='__main__':main()
