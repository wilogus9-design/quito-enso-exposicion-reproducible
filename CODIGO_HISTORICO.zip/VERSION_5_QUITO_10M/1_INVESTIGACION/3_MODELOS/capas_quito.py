"""Metadatos de capas municipales concretas; no descarga atributos catastrales personales."""
from catalogo_quito import BASE, RAW, get
from concurrent.futures import ThreadPoolExecutor
import truststore
import json
import re

SERVICES=[
 'web_reference_dmot/plan_de_uso_y_gestion_del_suelo_2024/MapServer',
 'web_reference_dmot/plan_de_uso_y_gestion_del_suelo_2021/MapServer',
 'web_reference_dmot/plan_de_uso_y_ocupacion_del_suelo/MapServer',
 'web_reference_dmc/accidente_geografico/MapServer',
 'web_reference_dmot/division_politica_administrativa/MapServer',
 'Hosted/cobertura_suelo_a_2025/FeatureServer',
 'Hosted/cobertura_suelo_a_2020/FeatureServer',
 'Hosted/mancha_urbana_a_2025/FeatureServer',
 'Hosted/cuencas_hidrograficas_dmq/FeatureServer',
 'Hosted/Eventos_2024/FeatureServer',
 'web_image_dmot/pugs_003_2024/MapServer',
 'web_image_dmot/Franjas_de_afectación_Río_Monjas/MapServer',
]


def main():
 truststore.inject_into_ssl()
 RAW.mkdir(parents=True,exist_ok=True)
 candidates=[]
 for service in SERVICES:
    try: obj=get(BASE+'/'+service,service.replace('/','__')+'.json')
    except Exception as error:
        print('No disponible',service,type(error).__name__,flush=True)
        continue
    print('SERVICE',service,flush=True)
    for layer in obj.get('layers',[]):
        print('  ',layer['id'],layer['name'],flush=True)
        if re.search('riesg|amenaz|inund|aneg|aluv|masa|parro|barr|rio|río|queb|cobert|cuenca|urbana|evento',layer['name'],re.I) or service.endswith('FeatureServer'):
            candidates.append((service,layer))
 def detail(pair):
    service,layer=pair
    url=BASE+'/'+service+'/'+str(layer['id'])
    try: obj=get(url,service.replace('/','__')+'__'+str(layer['id'])+'.json')
    except Exception as error:return {'url':url,'name':layer['name'],'id':layer['id'],'error':type(error).__name__}
    return {'url':url,'name':layer['name'],'id':layer['id'],'type':obj.get('type'),'fields':[{'name':x['name'],'alias':x.get('alias'),'domain':x.get('domain')} for x in (obj.get('fields') or [])],
            'extent':obj.get('extent'),'description':obj.get('description'),'capabilities':obj.get('capabilities'),'error':obj.get('error')}
 with ThreadPoolExecutor(max_workers=4) as pool: details=list(pool.map(detail,candidates))
 (RAW/'capas_detalle.json').write_text(json.dumps(details,ensure_ascii=False,indent=2),encoding='utf-8')
 print('Capas detalladas',len(details),flush=True)


if __name__=='__main__':main()
