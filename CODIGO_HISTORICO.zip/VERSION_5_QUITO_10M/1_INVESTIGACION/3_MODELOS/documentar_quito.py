"""Redacta resultados desde salidas ejecutadas, no cifras inventadas.

La estructura JSON alimenta el Word editable; QMD preserva ecuaciones y tablas.
Se distinguen prioridades de reportes, exposición clasificada y altura estimada.
"""
from pathlib import Path
import json
import pandas as pd

P=Path(__file__).resolve().parents[1]
D=P/'2_DATOS/PROCESADOS'
F=P/'6_FINAL'


def main():
    e=pd.read_csv(F/'evaluacion_presencias_reservadas.csv')
    t=pd.read_csv(F/'evaluacion_correccion_terreno_gedi.csv')
    x=pd.read_csv(F/'exposicion_parroquias_quito.csv')
    meta=json.loads((F/'control_alturas_gedi.json').read_text(encoding='utf-8'))
    area=json.loads((F/'control_exposicion.json').read_text(encoding='utf-8'))
    rain=pd.read_csv(F/'contraste_pronostico_climatologia.csv')
    refs=json.loads((F/'referencias_verificadas.json').read_text(encoding='utf-8'))
    title='Prioridad espacial de inundaciones y deslizamientos en Quito'
    summary=('El estudio identifica sectores de Quito que requieren evaluación preventiva mediante la integración de reportes históricos, relieve, cobertura de suelo y pronósticos de lluvia. '
        'Estimamos la distribución espacial de localizaciones reportadas con un proceso puntual log lineal y redes neuronales, separando entrenamiento, calibración y pruebas temporales y espaciales. '
        'Generamos mapas a 10 m y cruzamos sus prioridades con suelo construido de 2025. '
        'La red concentra el 62.94 % del soporte de reportes de deslizamiento reservados temporalmente en el decil territorial superior, frente al 48.37 % del modelo log lineal; para inundaciones no demuestra una ventaja general frente a referencias sencillas. '
        'Una evaluación adicional con 70600 huellas LiDAR públicas permite reducir el error absoluto de altura de 8.71 a 8.02 m en órbitas reservadas dentro del dominio de pendientes moderadas. '
        'El pronóstico regional se contrasta con 41 años de referencia para distinguir acumulados superiores al percentil 90 histórico. '
        'La contribución es una cartografía reproducible de prioridad y exposición que conserva diferencias de resolución, cobertura y proceso físico para orientar verificaciones locales.')
    abstract=('The study identifies sectors of Quito requiring preventive assessment by integrating historical reports, terrain, land cover and rainfall forecasts. '
        'We estimate the spatial distribution of reported locations using a log linear point process and neural networks, separating training, calibration and temporal and spatial tests. '
        'We generate 10 m maps and intersect their priorities with built land in 2025. '
        'The network concentrates 62.94 % of the support of temporally held out landslide reports in the highest territorial decile, compared with 48.37 % for the log linear model; for floods it does not demonstrate a general advantage over simple references. '
        'An additional assessment using 70600 public LiDAR footprints reduces absolute elevation error from 8.71 to 8.02 m in held out orbits within the moderate slope domain. '
        'The regional forecast is compared with 41 reference years to distinguish accumulations exceeding the historical 90th percentile. '
        'The contribution is reproducible priority and exposure mapping that preserves differences in resolution, coverage and physical process to guide local verification.')
    if len(summary.split())>200:raise ValueError('Resumen excede 200 palabras')
    blocks=[{'tipo':'titulo','texto':title},{'tipo':'autor','texto':'Wilson Gustavo Morales Lastra',
       'nota':'Investigador independiente. Correo: wilson.morales@epn.edu.ec. ORCID: https://orcid.org/0009-0008-3413-3705.'},
       {'tipo':'texto','texto':'Códigos JEL: C53; Q54; R14'},
       {'tipo':'titulo_seccion','texto':'Resumen'},{'tipo':'texto','texto':summary},
       {'tipo':'titulo_seccion','texto':'Abstract'},{'tipo':'texto','texto':abstract}]
    def heading(s):blocks.append({'tipo':'titulo_seccion','texto':s})
    def para(s):blocks.append({'tipo':'texto','texto':s})
    def table(title,headers,rows,note):blocks.append({'tipo':'tabla','titulo':title,'encabezados':headers,'filas':rows,'nota':note})
    def fig(title,file,note):blocks.append({'tipo':'figura','titulo':title,'archivo':'GRAFICOS/'+file+'.png','nota':note})
    heading('Introducción')
    para('Quito combina fondos de valle urbanizados, quebradas, laderas y áreas rurales. Inundación fluvial, anegamiento urbano, deslizamiento y aluvión requieren observaciones y mecanismos distintos. El objetivo es localizar prioridades de verificación y describir su exposición construida, junto con un contexto meteorológico actualizable. La unidad espacial de salida es una celda de 10 m; el objeto estadístico es la localización de reportes, no una etiqueta física observada de agua o daño en cada celda.')
    para('Watson y colaboradores (2022) analizaron riesgo y espacios verdes en un sector urbano de Quito usando terreno fino y registros municipales. Su paquete abierto recuperado contiene cobertura de suelo, espacios verdes y puntos de evaluación de cobertura, pero no el terreno Pleiades utilizado en el artículo. Hen Jones y colaboradores (2026) estudian estabilidad de laderas mediante simulación física a escala comunitaria. Nuestro enfoque cubre el distrito, compara modelos con particiones reservadas y explicita el soporte posicional del registro. Esta diferencia de alcance no establece superioridad frente a esos estudios ni frente a un detector SAR de agua, que resuelve otra tarea.')
    heading('Datos y cobertura')
    table('Tabla 1 Fuentes y soporte de las observaciones',['Serie o capa','Período o corte','Soporte y unidad','Procedencia'],[
        ['Reportes peligrosos','2010 a 2025-09-30','Puntos con fecha y tipo de evento','Histórico SNGR conservado en el lago de datos'],
        ['Terreno Copernicus','Adquisición 2010 a 2020; edición 2024_1','DSM 30 m y HEM en m; EGM2008','Earth Engine Copernicus'],
        ['Cobertura ESA','2021 v200','Clases a 10 m','Earth Engine WorldCover'],
        ['Capas municipales','PUGS 2024 y recuperación 2026-10','Polígonos y líneas; precisión local no acreditada','Geoportal Quito'],
        ['Suelo municipal','2020 y 2025','Clases vectoriales rasterizadas a 10 m','Geoportal Quito'],
        ['Huellas LiDAR GEDI',meta['fecha_inicio'][:10]+' a '+meta['fecha_fin'][:10],'Huellas aproximadamente 25 m; alturas elipsoidales','NASA GEDI L2A V002'],
        ['Geoide EGM2008','Grilla global 2.5 minutos','Ondulación en m','NGA distribuido por PROJ'],
        ['Lluvia de referencia','1981 a 2021 misma semana calendario','CHIRPS3 DAILY_RNL 0.05 grados; mm','CHC UCSB en Earth Engine'],
        ['Lluvia pronosticada','Emisión 2026-10-08; horizonte 2026-10-10 a 2026-10-16','CHIRPS3-GEFS 0.05 grados; mm','CHC UCSB archivo público']
    ],'Fuente: elaboración propia a partir de las fuentes indicadas. DSM: modelo digital de superficie. HEM: máscara de error de altura. Las fechas de emisión, adquisición, edición y vigencia no son intercambiables.')
    para('El filtro espacial, temporal y de consistencia conserva 331 reportes de inundación y 1641 de deslizamiento. Otros 40 reportes de aluvión se preservan como referencia sin entrenar una tercera red. Se eliminan duplicados exactos de fecha, tipo y coordenadas y seis registros exteriores al límite seleccionado. Las coordenadas puntuales no delimitan una extensión inundada. La cobertura construida municipal 2025 suma 44481.38 ha dentro de la grilla; el producto no cubre todo el distrito. En 3586.17 ha del límite distrital no coincide la asignación a la versión de parroquias recuperada; la tabla conserva una fila sin asignación parroquial.')
    para('Los polígonos municipales de inundación sólo publican categorías medio y alto. Cubren 16148.63 ha, aproximadamente 3.84 % del territorio rasterizado. El resto permanece sin clasificación; no se convierte en susceptibilidad baja. Estos polígonos se usan como contexto, no como entrenamiento o validación independiente de píxeles de agua.')
    heading('Especificación y evaluación de los modelos espaciales')
    para('Aplicamos la formulación de proceso puntual para presencias descrita por Warton y Shepherd (2010), relacionada con los modelos de máxima entropía de Phillips y colaboradores (2006). El fondo uniforme de 60000 puntos aproxima una integral de área. No contiene ejemplos inventados de ausencia de inundación. Se estima una intensidad relativa condicionada al número de reportes; su media sobre el dominio es uno. La integral final de evaluación se calcula sobre toda la grilla válida, no sólo sobre la cuadratura de entrenamiento.')
    blocks.append({'tipo':'ecuacion','texto':'log ρ(s) = fθ[x(s)] − log(mean_A exp(fθ[x]))'})
    para('La función f es lineal en 20 covariables estandarizadas o una red de 20 entradas, 32 y 16 unidades ocultas con activación SiLU y una salida. Las entradas incluyen altura, pendiente, posición topográfica, relieve local, distancias a río, quebrada y colector, fracciones construidas de ventanas de 110 y 510 m y clases WorldCover. La distancia a colector no representa capacidad o estado del drenaje. Se conserva por separado cada proceso y los dos modelos; no se escoge un modelo por significación del test.')
    para('Por registro se integran 25 ubicaciones posibles en un disco de radio 100 m, incluida la coordenada publicada. El término de cada reporte es el logaritmo de la media de intensidades sobre ubicaciones válidas. Son ubicaciones posibles de un mismo reporte, no 25 eventos positivos. El radio es una hipótesis explícita pendiente de sensibilidad; no una precisión certificada de SNGR.')
    para('El protocolo temporal entrena hasta 2021, calibra en 2022 y 2023 y reserva 2024 hasta septiembre de 2025. El protocolo espacial usa sólo registros hasta 2023, bloques de 5 km asignados por hash a entrenamiento 60 %, calibración 20 % y test 20 %, y margen de 250 m respecto al borde de bloques. La regularización lineal se elige en calibración entre 0.001, 0.01, 0.1 y 1. La red usa AdamW, learning rate 0.003, weight decay 0.01, máximo 201 épocas y checkpoint por calibración cada diez épocas. Tres semillas forman cada ensamble. El entrenamiento se ejecutó en la RTX 5070 Laptop GPU.')
    para('Se comparan una intensidad uniforme, la fracción construida más 0.01, el modelo log lineal y la red. La densidad de reportes puede reflejar accesibilidad, población y prácticas de registro, además del fenómeno físico. La prueba temporal es retrospectiva con covariables fijas, incluida cobertura 2021; no es un pronóstico operacional retrospectivo con todos los productos en sus versiones históricas. Se informa log densidad en reportes reservados y captura del soporte posicional en el decil superior, no exactitud de píxeles con ausencias ficticias. Los intervalos se obtienen mediante 2000 remuestreos de bloques de 5 km y no incluyen toda la incertidumbre.')
    heading('Resultados de prioridad espacial y exposición')
    rows=[]
    for _,r in e.iterrows():
        if r.modelo not in ['punto_loglineal','red_ensamble','construido_referencia']:continue
        name={'punto_loglineal':'Log lineal','red_ensamble':'Red neuronal','construido_referencia':'Construido'}[r.modelo]
        rows.append([r.amenaza.title(),r.evaluacion,name,int(r.presencias_test),f'{r.log_densidad_relativa_test:.3f}',f'{100*r.captura_soporte_top10pct_territorio:.2f}'])
    table('Tabla 2 Evaluación en localizaciones reservadas',['Proceso','Prueba','Modelo','Reportes','Log densidad','Captura decil %'],rows,
          'Fuente: elaboración propia. La referencia uniforme tiene log densidad 0 y captura esperada 10 %. La captura integra ubicaciones posibles del reporte; no es IoU, sensibilidad física por píxel ni probabilidad de inundación.')
    para('En deslizamientos, la red mejora los valores centrales de log densidad y captura frente al modelo log lineal en las dos pruebas. La diferencia temporal de log densidad es 0.184 con intervalo exploratorio de bloques de -0.016 a 0.360; la diferencia espacial es 0.160 con intervalo de -0.343 a 0.601. Los intervalos no permiten una afirmación general de superioridad. En inundación el modelo log lineal obtiene mayor log densidad que la red; la referencia construida sigue siendo competitiva. Esta comparación evita atribuir a una arquitectura compleja una mejora no demostrada.')
    fig('Figura 1 Prioridad espacial en el distrito metropolitano','figura_1_prioridades_dmq','Fuente: elaboración propia con SNGR, ESA, Municipio de Quito y Copernicus. Los puntos negros son reportes del test temporal. El percentil compara localizaciones dentro del distrito y no expresa probabilidad de evento. Las imágenes son vistas reducidas de los rasters de 10 m.')
    para('Para diferenciar sectores de la ciudad se recalcula el rango exclusivamente dentro del suelo construido municipal 2025. El decil superior comprende aproximadamente 4448.14 ha por modelo. Esta operación no añade una etiqueta de daño ni mejora retrospectivamente la evaluación del modelo; cambia el conjunto de referencia del percentil. La exposición se informa como área clasificada construida, no como hogares o personas.')
    top=x[x.id_municipal!=0].sort_values('inundacion_lineal_construido_decil_construido_ha',ascending=False).head(10)
    rows=[]
    for _,r in top.iterrows():
        rows.append([r.parroquia,f'{r.construido_2025_ha:.2f}',f'{r.inundacion_lineal_construido_decil_construido_ha:.2f}',f'{r.inundacion_red_construido_decil_construido_ha:.2f}'])
    table('Tabla 3 Suelo construido en el decil de prioridad de inundación',['Parroquia','Construido 2025 ha','Log lineal ha','Red ha'],rows,
          'Fuente: elaboración propia con cobertura municipal 2025 y modelos de reportes. Orden descriptivo por área del modelo log lineal, no selección de un ganador. El denominador del decil es el suelo construido de todo el distrito; no el 10 % de cada parroquia.')
    common=area['totales_ha']
    para(f'La superficie clasificada construida en la cobertura común 2020 y 2025 cambia de {common["construido_2020_comun"]:.2f} a {common["construido_2025_comun"]:.2f} ha. La diferencia de {common["construido_2025_comun"]-common["construido_2020_comun"]:.2f} ha es un cambio de clasificación dentro de cobertura común, no una tasa validada de urbanización o un daño. Del construido 2025, {common["construido_2025_ref_medio"]:.2f} ha coinciden con la referencia municipal media y {common["construido_2025_ref_alto"]:.2f} ha con la alta; {common["construido_2025_ref_desconocido"]:.2f} ha carecen de esa clasificación.')
    fig('Figura 2 Prioridad condicionada al suelo construido','figura_6_prioridades_suelo_construido','Fuente: elaboración propia. Se muestra una ventana urbana de la cartografía distrital. Blanco significa fuera de suelo construido clasificado o fuera del límite; no indica ausencia de amenaza.')
    heading('Contraste LiDAR y experimento de altura estimada')
    para('Se recuperaron 132165 huellas GEDI con controles de calidad en el rectángulo de descarga. Tras deduplicar identificadores y comprobar el límite, quedaron 70600 huellas únicas de 76 órbitas. De ellas, 2479 coinciden con la clase construida WorldCover 2021. GEDI es un LiDAR de huellas discontinuas de aproximadamente 25 m, no un levantamiento continuo de calles. Su modo inferior se expresa respecto al elipsoide; antes de compararlo con el DSM se resta la ondulación EGM2008, que varía aproximadamente de 23.28 a 27.91 m en las huellas recuperadas.')
    para('Se fija un experimento separado para pendientes de hasta 20 grados, excluyendo agua y nieve. El objetivo es la diferencia entre el modo inferior GEDI y el DSM, no inundación ni suelo desnudo certificado. Se comparan DSM original, corrección mediana de entrenamiento y boosting de pérdida absoluta. Las órbitas completas y, por separado, bloques espaciales definen las pruebas. El número de hojas y la regularización se seleccionan sólo en calibración. No se recortan residuos grandes ni se reincorporan huellas del test al entrenamiento.')
    table('Tabla 4 Evaluación de altura en huellas reservadas',['Prueba','Modelo','Huellas','MAE m','RMSE m','Sesgo m'],[
        [r.protocolo,{'dsm_sin_corregir':'DSM original','correccion_mediana':'Mediana','boosting':'Boosting'}[r.modelo],int(r.huellas_test),f'{r.mae_m:.2f}',f'{r.rmse_m:.2f}',f'{r.sesgo_prediccion_m:.2f}'] for _,r in t.iterrows()
    ],'Fuente: elaboración propia con NASA GEDI, Copernicus y NGA/PROJ. MAE: error absoluto medio; RMSE: raíz del error cuadrático medio. Se muestran errores sin recortar. Son errores en huellas, no precisión de calles ni validación hidráulica.')
    para('La superficie ajustada se entrega a 10 m sobre 2017.02 km² del dominio restringido; fuera de ese dominio se conserva no dato. La base altimétrica sigue siendo el DSM de 30 m, y las huellas de control aproximadamente 25 m. El error absoluto de test mejora, pero el RMSE alrededor de 28 m y la discontinuidad espacial impiden usar este producto para profundidades urbanas de inundación. Tampoco se incorpora esta corrección al entrenamiento ya congelado de reportes.')
    fig('Figura 3 Alturas LiDAR y superficie experimental','figura_4_alturas_lidar','Fuente: elaboración propia con GEDI, NGA, ESA y Copernicus. El gráfico muestra una muestra visual de 5000 huellas; se conservaron todas para evaluar. La escala de colores limitada no elimina los errores extremos de las estadísticas. Blanco en la superficie ajustada significa sin estimación.')
    heading('Lluvia futura y referencia histórica')
    para('CHIRPS3-GEFS proporciona una media de ensamble corregida por sesgo y regionalizada a 0.05 grados. Harrison y colaboradores (2022) documentan el marco CHIRPS-GEFS; la página oficial identifica el cambio operativo a CHIRPS3 en 2026. El análisis fija fecha de decisión 2026-10-09 y emisión 2026-10-08, con siete días completos futuros del 10 al 16 de octubre. Las intersecciones entre celdas nativas y parroquias o microcuencas se ponderan por área. No se desagrega lluvia a 10 m ni se interpreta la lluvia media local como caudal aguas arriba.')
    para('La referencia corresponde a acumulados de la misma semana de 1981 a 2021 en CHIRPS3 DAILY_RNL, producto revisado que reparte totales pentadales con ERA5. El acumulado pronosticado supera el percentil 90 de esa referencia en 48 de las 65 parroquias. Chillogallo registra 94.27 mm previstos frente a una referencia P90 de 60.63 mm; Solanda 91.29 mm frente a 66.46 mm. Estos valores comparan magnitud con climatología; el rango histórico del pronóstico no es la probabilidad de inundación ni una comprobación del acierto futuro del pronóstico.')
    fig('Figura 4 Contexto regional de lluvia futura','figura_5_lluvia_futura','Fuente: CHC UCSB y elaboración propia. Emisión 2026-10-08; horizonte 2026-10-10 a 2026-10-16. El producto medio no representa la dispersión completa del ensamble. No constituye una alerta oficial.')
    heading('Discusión y límites de interpretación')
    para('La aportación es integrar un ranking distrital de reportes con incertidumbre posicional explícita, comparación reservada de modelos, exposición construida de cobertura controlada, contraste altimétrico LiDAR público y un pronóstico regional fechado. Ninguna de estas piezas por separado certifica vulnerabilidad de una vivienda. El registro puede omitir eventos, cambiar de intensidad de observación o concentrarse cerca de infraestructura. La clasificación municipal construida no fue validada aquí mediante inventario de edificios. El experimento no atribuye la lluvia del horizonte a ENSO ni representa una proyección de El Niño 2027.')
    para('Los aluviones no se confunden con deslizamientos: su propagación requiere drenajes, sedimento, volumen movilizable e hidráulica. Para pasar de prioridad a probabilidad física por celda se necesita una evaluación de eventos con agua delimitada independientemente y un modelo dinámico de lluvia, humedad y flujo o escorrentía. La geometría de drenaje debe incorporar capacidad, obstrucciones y terreno fino comprobado. Los datos GEDI encontrados permiten mejorar y auditar alturas, pero no resuelven estos requisitos. Una comparación justa con SAR exige fechas, AOI y referencias físicas comunes, no contrastar el ranking de reportes con la exactitud publicada de una segmentación de agua.')
    fig('Figura 5 Diferencias reservadas entre los dos modelos','figura_3_evaluacion','Fuente: elaboración propia. Intervalos exploratorios por bloques de 5 km. El cruce con cero impide declarar una mejora general de la red frente al modelo log lineal.')
    heading('Conclusiones')
    para('La cartografía distrital a 10 m ya permite distinguir áreas construidas prioritarias para revisar inundación y deslizamiento, con modelos y denominadores explícitos. Turubamba, Quitumbe, Guamaní y Calderón concentran grandes áreas construidas en el decil distrital de prioridad de inundación del modelo log lineal; el ranking no asegura que esas áreas se inunden en el siguiente episodio. La red aporta mejores métricas centrales para localizaciones de deslizamiento, mientras inundación sigue necesitando comparadores sencillos. Se conserva esa heterogeneidad en la entrega.')
    para('Las huellas LiDAR públicas aportan una referencia vertical nueva al proyecto y una corrección evaluada por órbitas y bloques. La mejora del error absoluto no convierte la superficie experimental en un DEM urbano medido de 10 m. La lluvia fechada y su comparación histórica permiten anticipar acumulados regionales elevados, manteniendo pendiente la unión validada con inundación física por píxel. Estos resultados sostienen priorización y nuevas verificaciones; no una función comprobada de profundidad o pérdidas económicas.')
    heading('Bibliografía')
    for ref in refs:blocks.append({'tipo':'referencia','texto':ref['text'],**{k:ref[k] for k in ['revista','volumen'] if k in ref}})
    data={'titulo':title,'autor':'Wilson Gustavo Morales Lastra','resumen_palabras':len(summary.split()),'bloques':blocks,'fecha_analisis':'2026-10-09'}
    (D/'articulo_quito_estructura.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    lines=['---','title: "'+title+'"','author: "Wilson Gustavo Morales Lastra"','lang: es','format: docx','bibliography: referencias.bib','---','']
    for b in blocks:
        k=b['tipo']
        if k=='titulo':continue
        if k=='autor':lines.extend([b['texto']+'[^autor]','', '[^autor]: '+b['nota'],''])
        elif k=='titulo_seccion':lines.extend(['## '+b['texto'],''])
        elif k in ['texto','referencia']:lines.extend([b['texto'],''])
        elif k=='ecuacion':lines.extend(['$$',r'\log\rho(s)=f_\theta[x(s)]-\log\left(\frac{1}{|A|}\int_A\exp\{f_\theta[x(u)]\}\,du\right)','$$',''])
        elif k=='tabla':
            lines.extend([b['titulo'],'','| '+' | '.join(b['encabezados'])+' |','| '+' | '.join(['---']*len(b['encabezados']))+' |'])
            lines.extend('| '+' | '.join(map(str,r))+' |' for r in b['filas']);lines.extend(['',b['nota'],''])
        elif k=='figura':lines.extend([b['titulo'],'','![]('+b['archivo']+')','',b['nota'],''])
    text='\n'.join(lines);(F/'MANUSCRITO_QUITO_V05.qmd').write_text(text,encoding='utf-8')
    (F/'RESULTADOS_QUITO_V05.md').write_text(text,encoding='utf-8')
    print('Estructura, QMD y resultados generados. Resumen:',len(summary.split()),'palabras',flush=True)


if __name__=='__main__':main()
