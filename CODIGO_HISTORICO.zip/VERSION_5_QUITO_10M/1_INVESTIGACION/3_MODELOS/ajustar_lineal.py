"""Proceso puntual log-lineal con marginalización posicional y cuadratura uniforme."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.special import logsumexp
from scipy.optimize import minimize

P=Path(__file__).resolve().parents[1]
D=P/'2_DATOS/PROCESADOS'
F=P/'6_FINAL'


def domains(z,hazard,protocol):
    positive=z['event_type']==hazard
    if protocol=='temporal':
        return [positive&(z['split_t']==p) for p in ['train','cal','test']],[np.ones(len(z['Xb']),bool)]*3
    early=z['year_e']<=2023
    ge,zbg=z['fold_e'],z['fold_b']
    return ([positive&early&z['edge_e']&(ge<6),positive&early&z['edge_e']&np.isin(ge,[6,7]),positive&early&z['edge_e']&(ge>=8)],
            [z['edge_b']&(zbg<6),z['edge_b']&np.isin(zbg,[6,7]),z['edge_b']&(zbg>=8)])


def valid_norm(Xe,valid,beta):
    f=Xe@beta
    f=np.where(valid,f,-np.inf)
    l=logsumexp(f,axis=1)-np.log(valid.sum(axis=1))
    return l,f


def fit(Xe,Xb,valid,lam):
    def objective(beta):
        ev,fe=valid_norm(Xe,valid,beta)
        fb=Xb@beta
        ze=logsumexp(np.where(valid,fe,-np.inf),axis=1)
        wb=np.exp(fb-logsumexp(fb))
        we=np.exp(fe-ze[:,None])
        gradient=wb@Xb-(we[:,:,None]*Xe).sum(axis=1).mean(axis=0)+lam*beta
        loss=logsumexp(fb)-np.log(len(fb))-ev.mean()+.5*lam*(beta@beta)
        return float(loss),gradient
    r=minimize(objective,np.zeros(Xb.shape[1]),jac=True,method='L-BFGS-B',options={'maxiter':300,'ftol':1e-10})
    if not r.success:raise RuntimeError('No convergió log-lineal: '+r.message)
    return r.x


def main():
    D.mkdir(parents=True,exist_ok=True);F.mkdir(parents=True,exist_ok=True)
    z=np.load(D/'muestras_inciertas.npz')
    summary=[];states={}
    for hazard in ['INUNDACION','DESLIZAMIENTO']:
      for protocol in ['temporal','espacial']:
        e,b=domains(z,hazard,protocol)
        counts=[int(v.sum()) for v in e]
        if min(counts)<10:raise RuntimeError('Pocas presencias en partición '+hazard+'/'+protocol+': '+str(counts))
        mu=z['Xb'][b[0]].mean(axis=0);sd=z['Xb'][b[0]].std(axis=0);sd=np.where(sd>1e-6,sd,1)
        Xb=(z['Xb']-mu)/sd
        Xe=np.nan_to_num((z['Xe']-mu)/sd,nan=0)
        candidates=[]
        for lam in [.001,.01,.1,1.]:
            beta=fit(Xe[e[0]],Xb[b[0]],z['valid_e'][e[0]],lam)
            val,_=valid_norm(Xe[e[1]],z['valid_e'][e[1]],beta)
            LL=float(val.mean()-(logsumexp(Xb[b[1]]@beta)-np.log(b[1].sum())))
            candidates.append((LL,lam,beta))
            summary.append({'amenaza':hazard,'evaluacion':protocol,'lambda':lam,'log_densidad_cal':LL,'n_train':counts[0],'n_cal':counts[1],'n_test':counts[2]})
        best=max(candidates,key=lambda x:x[0])
        beta=best[2]
        # Temperado aprendido en calibración, no en test. No es probabilidad de evento.
        options=[]
        for alpha in [.25,.5,.75,1.,1.25]:
            val,_=valid_norm(Xe[e[1]],z['valid_e'][e[1]],beta*alpha)
            ll=float(val.mean()-(logsumexp(Xb[b[1]]@(beta*alpha))-np.log(b[1].sum())))
            options.append((ll,alpha))
        alpha=max(options)[1]
        key=hazard+'_'+protocol
        states[key]={'hazard':hazard,'protocol':protocol,'beta':beta.tolist(),'mu':mu.tolist(),'sd':sd.tolist(),
                     'lambda':best[1],'alpha':alpha,'feature_names':z['names'].tolist(),'counts':counts}
        np.savez_compressed(D/f'entrada_red_{key}.npz',Xe=Xe,Xb=Xb,valid_e=z['valid_e'],etrain=e[0],ecal=e[1],etest=e[2],
                           btrain=b[0],bcal=b[1],btest=b[2],mu=mu,sd=sd)
        print(key,'presencias',counts,'lambda',best[1],'temperado',alpha,flush=True)
    (D/'modelos_lineales.json').write_text(json.dumps(states,ensure_ascii=False,indent=2),encoding='utf-8')
    pd.DataFrame(summary).to_csv(F/'seleccion_regularizacion_calibracion.csv',index=False)


if __name__=='__main__':main()
