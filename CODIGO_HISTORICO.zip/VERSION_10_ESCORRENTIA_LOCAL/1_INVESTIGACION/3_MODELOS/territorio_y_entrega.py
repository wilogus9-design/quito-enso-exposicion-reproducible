"""Agregación parroquial y figuras: soporte nativo, fuentes y alcance explícitos."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from rasterio.features import rasterize
from rasterio.windows import Window
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.ndimage import maximum_filter

P = Path(__file__).resolve().parents[1]
ROOT = P.parents[2]
D = P/'2_DATOS/PROCESADOS'
R = P/'2_DATOS/ORIGINALES'
F = P/'6_FINAL'
P9 = ROOT/'EXPOSICION_FEN_NINO/VERSION_9_INTEGRACION_SOCIAL/1_INVESTIGACION'


def table(df):
    def fmt(x):
        if isinstance(x,(float,np.floating)):
            return f'{x:.3f}' if np.isfinite(x) else 'No disponible'
        return str(x).replace('|','/')
    text = '| '+' | '.join(map(str,df.columns))+' |\n'
    text += '| '+' | '.join(['---']*len(df.columns))+' |\n'
    for row in df.to_numpy().tolist():
        text += '| '+' | '.join(map(fmt,row))+' |\n'
    return text


def main():
    g = gpd.read_file(P9/'2_DATOS/PROCESADOS/geometria_censal.geojson').to_crs(32717)
    g['parroquia'] = g.parroquia.astype(str).str.zfill(6)
    g = g.sort_values('parroquia').reset_index(drop=True)
    g['id_aux'] = np.arange(1,66)
    with np.load(D/'contexto_vial_30m.npz') as z:
        mask,roads,built = z['mask'],z['roads'],z['built']
    with rasterio.open(D/'escorrentia_fabdem_30m.tif') as src:
        tr = src.transform
        profile = src.profile
    ids = rasterize([(geom,int(i))for geom,i in zip(g.geometry,g.id_aux)],out_shape=mask.shape,transform=tr,dtype='uint8')
    rows = []
    terrain = {}
    for source in ['copernicus','fabdem']:
        with rasterio.open(D/f'escorrentia_{source}_30m.tif') as src:
            arr = src.read([1,2,3,5])
        terrain[source] = arr
        candidate = (arr[0]>=.5)&(np.expm1(arr[1])>=1)&(roads>0)&mask
        for _,p in g.iterrows():
            inside = (ids==p.id_aux)&mask
            validroad = inside&(roads>0)
            rows.append({'parroquia':p.parroquia,'nombre':p.nom_par,'fuente_relieve':source,
                'celdas_viales_30m':int(validroad.sum()),
                'celdas_viales_candidatas_digitales':int((candidate&inside).sum()),
                'area_soporte_candidato_ha':float((candidate&inside).sum()*.09),
                'construido_WC2021_agregado_ha':float(built[inside].astype(float).sum()*.09),
                'area_contribuyente_mediana_vial_ha':float(np.median(np.expm1(arr[1][validroad]))) if validroad.any() else np.nan,
                'pct_vial_influencia_borde':float(100*arr[3][validroad].mean()) if validroad.any() else np.nan,
                'interpretacion':'área de soporte de proxy digital; no superficie inundada ni pavimento medido'})
    data = pd.DataFrame(rows)
    social = pd.read_csv(P9/'6_FINAL/territorio_vulnerabilidad_parroquias.csv',dtype={'parroquia':str})
    data = data.merge(social[['parroquia','pc_pnbi','pc_SH','pc_FSA','pc_HAC']],on='parroquia',validate='many_to_one')
    data.to_csv(F/'escorrentia_y_contexto_social_parroquias.csv',index=False)
    pts = gpd.read_file(F/'candidatos_depresion_vial.geojson').to_crs(32717)
    pts = gpd.sjoin(pts,g[['parroquia','nom_par','geometry']],how='left',predicate='within').drop(columns='index_right')
    pts.to_crs(4326).to_file(F/'candidatos_con_parroquia.geojson',driver='GeoJSON')
    # Confirmed names from a primary municipal report. No invented coordinates,
    # flood labels, maintenance dates, capacities or water depth.
    url = 'https://www.quitoinforma.gob.ec/2021/03/10/epmaps-intensifica-limpieza-de-sumideros-y-quebradas-para-evitar-inundaciones/'
    refs = [{'sitio':name,'fecha_publicacion':'2021-03-10','fuente':url,
             'evidencia':'sitio mencionado por EPMAPS como paso a desnivel/deprimido con mantenimiento',
             'coordenada_confirmada':None,'altura_calado_confirmado_m':None,
             'no_usado_como_etiqueta_pixel':True} for name in
            ['El Labrador','La Y','6 de Diciembre y Patria','América y Pérez Guerrero',
             'Eloy Alfaro y 10 de Agosto','Naciones Unidas y 10 de Agosto','Antiguo Aeropuerto','La Villaflora']]
    (F/'referencias_estructurales_municipales.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2),encoding='utf-8')
    G = F/'GRAFICOS'
    G.mkdir(exist_ok=True)
    plt.rcParams.update({'font.family':'Arial','font.size':8,'svg.fonttype':'none','axes.titlesize':8})
    # Plotting decimation is not a change of analytical support.
    outline = g.copy()
    outline.geometry = outline.geometry.simplify(20,preserve_topology=True)
    fig,axes = plt.subplots(1,2,figsize=(8,5.2))
    for ax,source in zip(axes,['copernicus','fabdem']):
        # Preserve narrow drainage corridors in the overview instead of dropping
        # them by simple pixel decimation; this is a visualization-only operation.
        value = maximum_filter(terrain[source][1],size=6)[::6,::6]
        valid = mask[::6,::6]
        value = np.ma.array(value,mask=~valid)
        h,w = mask.shape
        extent = [tr.c,tr.c+30*w,tr.f-30*h,tr.f]
        im = ax.imshow(value,extent=extent,cmap='YlGnBu',vmin=0,vmax=7,interpolation='nearest')
        outline.boundary.plot(ax=ax,linewidth=.2,color='#666666')
        subset = pts[pts.source==source]
        subset.plot(ax=ax,color='#b63129',markersize=3)
        ax.set_title(('DSM Copernicus' if source=='copernicus' else 'FABDEM corregido')+'\nPuntos: candidatos digitales viales',loc='left')
        ax.set_axis_off()
    cb = fig.colorbar(im,ax=axes,shrink=.65,pad=.02)
    cb.set_label('log(1 + área contribuyente en ha)')
    fig.subplots_adjust(left=.01,right=.83,top=.89,bottom=.16,wspace=.08)
    cb.ax.set_position([.87,.25,.02,.55])
    fig.text(.02,.025,'Fuente: Copernicus DEM, FABDEM, WorldCover y Municipio de Quito. Elaboración propia.\nCálculos: 30 m. Generalización visual por máximo local. Puntos: no agua ni pasos inferiores confirmados.\nDerivados FABDEM: CC BY-NC-SA 4.0. Mapa de contexto, no pronóstico de inundación.',fontsize=8)
    fig.savefig(G/'figura_1_conectividad_y_candidatos.svg')
    fig.savefig(G/'figura_1_conectividad_y_candidatos.png',dpi=300)
    plt.close(fig)
    metrics = pd.read_csv(F/'comparacion_vias_escorrentia.csv')
    diff = pd.read_csv(F/'diferencias_emparejadas_por_bloques.csv')
    fig,axes = plt.subplots(1,2,figsize=(8.3,3.8))
    for ax,protocol in zip(axes,['temporal','espacial']):
        x = diff[(diff.protocolo==protocol)&(diff.modelo=='red_ensamble')]
        ys = np.arange(len(x))
        delta = x.diferencia_log_densidad_vs_base.to_numpy()
        ax.errorbar(delta,ys,xerr=np.stack([delta-x.rango95_bloques_inf.to_numpy(),x.rango95_bloques_sup.to_numpy()-delta]),fmt='o',color='#205375',capsize=3)
        ax.set_yticks(ys,labels=['Vías','Vías + DSM','Vías + FABDEM'])
        ax.axvline(0,color='#888888',linewidth=.8)
        ax.set_title('Evaluación '+protocol,loc='left')
        ax.set_xlabel('Diferencia de log densidad frente a red base')
        ax.spines[['top','right']].set_visible(False)
    fig.text(.02,.015,'Fuente: SNGR y experimento V10. Elaboración propia. Rangos exploratorios por bloques de 5 km, no precisión física.',fontsize=8)
    fig.tight_layout(rect=(0,.07,1,1))
    fig.savefig(G/'figura_2_aporte_variables.svg')
    fig.savefig(G/'figura_2_aporte_variables.png',dpi=300)
    plt.close(fig)
    ctrl = json.loads((F/'control_hidrologia.json').read_text(encoding='utf-8'))
    verification = json.loads((R/'verificacion_exportacion_fabdem.json').read_text(encoding='utf-8'))
    netaudit = json.loads((F/'entrenamiento_redes_RTX.json').read_text(encoding='utf-8'))
    bibliography = ''
    bibliographic_lines = []
    for name in ['hawker2022','floodcast2025']:
        item = json.loads((R/(name+'_crossref.json')).read_text(encoding='utf-8'))
        authors = ' and '.join(x['family']+', '+x.get('given','') for x in item['author'])
        year = item.get('published',item.get('issued'))['date-parts'][0][0]
        bibliography += '@article{'+name+',\n  author={'+authors+'},\n  title={'+item['title'][0]+'},\n  journal={'+item['container-title'][0]+'},\n  year={'+str(year)+'},\n  volume={'+item.get('volume','')+'},\n  pages={'+item.get('page',item.get('article-number',''))+'},\n  doi={'+item['DOI']+'}\n}\n'
        formatted_authors = []
        for a in item['author']:
            initials = ''.join(word[0]+'. ' for word in a.get('given','').replace('-',' ').split()).strip()
            formatted_authors.append(a['family']+', '+initials)
        names = ', '.join(formatted_authors[:-1])+', & '+formatted_authors[-1] if len(formatted_authors)>1 else formatted_authors[0]
        vol = item.get('volume','')
        if item.get('issue'):
            vol += '('+item['issue']+')'
        pages = item.get('page',item.get('article-number',''))
        bibliographic_lines.append(names+' ('+str(year)+'). '+item['title'][0]+'. *'+item['container-title'][0]+', '+vol+'*, '+pages+'. https://doi.org/'+item['DOI'])
    (F/'referencias_v10.bib').write_text(bibliography,encoding='utf-8')
    comparative = metrics[metrics.muestra=='completo'][['protocolo','variante','modelo','n_reportes_test','log_densidad_relativa','captura_soporte_top10pct_territorio']]
    specific_results = []
    for protocol in ['temporal','espacial']:
        ll = diff[(diff.protocolo==protocol)&(diff.variante=='vias')&(diff.modelo=='loglineal')].iloc[0]
        specific_results.append(f"El modelo loglineal con vías, frente al base, tiene diferencia de log densidad {ll.diferencia_log_densidad_vs_base:.4f} en test {protocol}, con rango exploratorio [{ll.rango95_bloques_inf:.4f}, {ll.rango95_bloques_sup:.4f}].")
    sources = pd.DataFrame(ctrl['sources'])[['source','digital_depression_cells_gt_05m_canton','road_candidate_cells']]
    summary = ('Este estudio incorpora información local de vías y relieve satelital para mejorar la representación de acumulación superficial en Quito. '
        'Se combinan cartografía vial municipal, construido WorldCover y dos fuentes de elevación, Copernicus y FABDEM, para calcular depresiones digitales, área contribuyente y construido aguas arriba. '
        'Se entrenan 24 redes neuronales con la RTX 5070 y se comparan con modelos loglineales en muestras idénticas de reportes geocodificados. '
        'La evaluación temporal utiliza 100 presencias y la espacial 58. Añadir vías mejora puntualmente la log densidad del modelo loglineal en ambos contrastes, pero sus rangos exploratorios incluyen cero. Las redes presentan ganancias y pérdidas de transferencia según la fuente de relieve. '
        'Se entregan 388 componentes candidatos para revisión, corredores potenciales de escorrentía y agregados sociales de 65 parroquias. '
        'La contribución es una extracción multifuente reproducible con evaluación incremental, que evita confundir depresiones digitales con agua observada. El soporte altimétrico es de 30 m; la simulación de drenaje subterráneo y la validación física de inundación permanecen como etapas adicionales.')
    abstract = ('This study incorporates local road and satellite-derived terrain information to improve the representation of surface accumulation in Quito. '
        'Municipal road mapping, WorldCover built-up land, and two elevation sources, Copernicus and FABDEM, are combined to calculate digital depressions, contributing area, and upstream built-up land. '
        'Twenty-four neural networks are trained with the RTX 5070 and compared with log-linear models on identical samples of geocoded reports. '
        'Temporal evaluation uses 100 presences and spatial evaluation 58. Adding roads improves the log-linear model’s point log-density estimate in both comparisons, but its exploratory ranges include zero. Neural networks show transfer gains and losses depending on the terrain source. '
        'The outputs include 388 candidate components for review, potential runoff corridors, and social aggregates for 65 parishes. '
        'The contribution is reproducible multi-source extraction with incremental evaluation, avoiding confusion between digital depressions and observed water. Elevation support is 30 m; underground drainage simulation and physical flood validation remain additional stages.')
    if len(summary.split())>200 or len(abstract.split())>200:
        raise ValueError('Resumen supera el límite de 200 palabras')
    report = rf'''# Calles, relieve satelital y escorrentía potencial en Quito

Wilson Gustavo Morales Lastra[^autor]

[^autor]: Investigador independiente. Correo: wilson.morales@epn.edu.ec. ORCID: https://orcid.org/0009-0008-3413-3705.

Códigos JEL: C45; C53; Q54; R14.

Versión 10. Fecha de corte: 2026-10-09. Borrador metodológico, no certificación editorial.

## Resumen

{summary}

## Abstract

{abstract}

## Resultado de la incorporación

Se incorporaron vías municipales existentes, relieve FABDEM y cuatro variables de conectividad superficial al experimento V05. Se entrenaron {len(netaudit)} redes pequeñas nuevas con la RTX y se conservaron modelos loglineales, sin reemplazar ni modificar versiones previas. Las nuevas variables representan depresiones digitales, área contribuyente, construido aguas arriba y su fracción, además de distancia a vías. No se crearon etiquetas ficticias de agua, pasos inferiores o daño.

## Datos y extracción

La cartografía PUGS 2024 devuelve 3464 registros de vías principales existentes y 60127 de vías locales. Son registros de trazado, no calles únicas ni un inventario hidráulico. Se excluyeron vías proyectadas. El sistema local SIRES-DMQ se transformó mediante el servicio a WGS84 y luego EPSG:32717; no se interpretaron sus coordenadas locales como UTM estándar.

El relieve satelital Copernicus representa superficie con edificios y vegetación. FABDEM V1-2 utiliza aprendizaje automático para reducir esos artefactos a aproximadamente 30 m. Los activos utilizados fueron N00W079 y S01W079 del catálogo comunitario de Earth Engine, con fuente original de la University of Bristol. WorldCover 2021 de 10 m se agregó por área a 30 m para aproximar construido. Construido no equivale a impermeabilidad medida.

Se calculó priority-flood sobre el rectángulo completo de 9557121 celdas, sin cortar por parroquia. La elevación rellenada menos la original define una **depresión digital**, no una profundidad futura de inundación. D8 conecta cada celda con una salida superficial descendente; en planos se conserva un árbol de salida acíclico. Se acumuló área y construido y se comprobó conservación de ambos en las salidas. La influencia de una franja exterior de 300 m se propaga aguas abajo para advertir posible truncamiento. No se rebajaron carreteras para inventar puentes o alcantarillas.

La primera exportación FABDEM mostró suavizado incorrecto por la proyección predeterminada de un mosaico Earth Engine. Se apartaron de manera recuperable nueve archivos propios bajo `2_DATOS/ORIGINALES/RECHAZADO_REPROYECCION_20261009`; no se entrenó la red con esa versión. Se fijó la proyección nativa antes del remuestreo y se comprobaron nueve puntos contra activos individuales. La diferencia máxima fue {verification['max_abs_difference_m']:.2f} m entre vecino nativo y exportación bilineal: es un control de exportación, no una evaluación de precisión contra terreno medido. Fuente técnica: https://developers.google.com/earth-engine/apidocs/ee-image-resample.

Tabla 1. Señales digitales por fuente de relieve.

{table(sources)}
Fuente: cálculo sobre Copernicus/FABDEM y vías municipales. Elaboración propia.

Se conservaron {ctrl['n_candidates']} componentes candidatos entre las dos fuentes, sin deduplicarlos como si fueran estructuras reales. Se exige relleno digital >= 0.5 m, área contribuyente >= 1 ha, intersección vial y al menos dos celdas conectadas de 30 m. Estas reglas predefinidas identifican sitios para revisión; el error vertical puede superar el umbral y pequeños pasos inferiores pueden no resolverse. No son criterios de pérdida ni extensión de agua.

Se intentaron dos instancias públicas de OpenStreetMap para túneles/niveles inferiores. Las respuestas 406/429 impidieron recuperar esa capa. Se excluyó su variable de todas las variantes, no se sustituyó por una etiqueta de ausencia. Hay ocho referencias nominales municipales de estructuras en `referencias_estructurales_municipales.json`; sus coordenadas no se inventaron y no se usaron como etiquetas de píxel. EPMAPS menciona La Y, El Labrador y varios cruces viales como puntos de mantenimiento: {url}.

Figura 1. Conectividad superficial y candidatos de acumulación vial.

![Conectividad y candidatos](GRAFICOS/figura_1_conectividad_y_candidatos.png)

Fuente: Copernicus DEM, FABDEM, WorldCover y Municipio de Quito. Elaboración propia. El mapa presenta soporte nativo de 30 m, no un pronóstico de agua de 10 m.

Los archivos `rutas_potenciales_fabdem_30m.geojson` y su alternativa Copernicus entregan corredores D8 como líneas editables GIS. Se unen aristas con área contribuyente >= 20 ha únicamente para representación cartográfica; ese corte no interviene en el aprendizaje ni es un umbral de caudal o daño. No son cauces confirmados y no se deducen conexiones hidráulicas subterráneas de sus cruces.

## Experimento de aprendizaje

Se conservaron las 25 posiciones posibles por reporte, el fondo de cuadratura uniforme de 60000 puntos y las particiones V05. No se crearon negativos de inundación a partir del fondo. El contraste temporal tiene 143/88/100 presencias en entrenamiento/calibración/test; el espacial, con bloques 5 km y separación 250 m, tiene 85/48/58.

Las cuatro variantes tienen 20 variables base, 21 con vías y 25 con vías más cada relieve. Los modelos loglineales usan la misma lista lambda y temperado V05. Las redes tienen capas de 32/16 neuronas SiLU, AdamW y tres semillas; se entrena hasta 201 epochs y se elige el punto de parada y temperado por calibración. No se selecciona la variante por resultados de test.

La pérdida del modelo es la diferencia entre log normalizador de fondo y log intensidad marginalizada del reporte. Para la posición incierta se usa la media de intensidades de sus posiciones válidas, no 25 eventos independientes:

$$\ell(\theta)=\log\left(\frac1{{n_B}}\sum_b e^{{f_\theta(X_b)}}\right)-\frac1{{n_E}}\sum_e\log\left(\frac1{{K_e}}\sum_{{k\in V_e}}e^{{f_\theta(X_{{ek}})}}\right).$$

Se compara log densidad relativa y captura del soporte en el 10 % del territorio, normalizando cada modelo sobre el mismo subconjunto de fondo. El bootstrap emparejado por bloques de 5 km es exploratorio; no resuelve por completo dependencia entre reportes de un mismo episodio. Los tests anteriores ya eran conocidos: esta es una extensión retrospectiva secundaria, no una reserva prospectiva ciega.

Tabla 2. Comparación completa, sin eliminar casos desfavorables.

{table(comparative)}
Fuente: SNGR y experimento V10. Elaboración propia. Mayor log densidad es mejor; captura se refiere a localización incierta de reportes, no a exactitud de agua.

{chr(10).join(specific_results)}

Las redes muestran transferencia desigual. Con FABDEM, la diferencia temporal frente a la red base es positiva, pero la espacial es fuertemente negativa. Con escorrentía Copernicus, la diferencia espacial es positiva, pero la temporal no mejora. Por ello, añadir indicadores físicos no demuestra superioridad general de una red ni valida inundación futura. Se conserva el loglineal como competidor y los rangos por bloques como exploratorios, no como prueba causal o validación física.

Figura 2. Aporte incremental de variables en las redes.

![Aporte incremental](GRAFICOS/figura_2_aporte_variables.png)

Fuente: experimento V10. Elaboración propia. Rangos exploratorios de diferencias emparejadas por bloques. Los resultados sin influencia del borde se conservan como sensibilidad separada.

## Incorporación al enfoque social y predictivo

`escorrentia_y_contexto_social_parroquias.csv` une estos proxies con NBI, saneamiento, agua y hacinamiento de V09 para las 65 parroquias. El soporte vial representa celdas gruesas tocadas por una línea, no el ancho real de la vía ni personas afectadas. Los porcentajes censales conservan la advertencia de discrepancias de cantidades V09.

La capa ya está disponible para construir la siguiente relación física: lluvia intensa de corta duración → escorrentía desde cuencas contribuyentes → captación y evacuación por drenaje → acumulación superficial. Esta versión ejecuta la extracción y el aprendizaje de localización, no ese balance hidráulico completo. Faltan capacidad y conexiones subterráneas, obstrucciones, lluvia local subhoraria y referencias de inundación física. Una red no convierte esa falta de información en profundidad observada.

FABDEM y WorldCover son aplicaciones reales de modelos sobre imágenes; las redes V10 son modelos nuevos propios que incorporan sus señales derivadas. No se afirma haber entrenado un detector óptico de pasos deprimidos sin etiquetas independientes. Para pasos pequeños, la opción es observar imágenes ópticas adecuadas y contrastar un inventario local, en lugar de interpretar interpolación del relieve como un levantamiento fino.

## Fuentes, licencia y ejecución

FABDEM: https://data.bris.ac.uk/data/dataset/s5hqmjcdj8yo2ibzi9b4ew3sn. Acceso usado: https://gee-community-catalog.org/projects/fabdem/. Los derivados FABDEM están sujetos a CC BY-NC-SA 4.0 y conservan atribución. Los demás insumos mantienen sus términos originales; no se declara una licencia única para toda la información municipal.

Produced using Copernicus WorldDEM-30 © DLR e.V. 2010-2014 and © Airbus Defence and Space GmbH 2014-2018 provided under COPERNICUS by the European Union and ESA; all rights reserved.

Los siguientes trabajos orientan la extracción y el alcance. Los metadatos de los dos artículos se verificaron con Crossref:

{chr(10).join(bibliographic_lines)}

Poppenga et al. (2014), *Hydrologic enforcement of lidar DEMs*, U.S. Geological Survey: https://doi.org/10.3133/fs20143051. La conectividad a través de una carretera requiere información real de puente/alcantarilla, no un ajuste geométrico arbitrario. FloodCastBench muestra una ruta de combinación de relieve, cobertura y lluvia; remuestrear un insumo grueso no produce observación fina independiente.

`EJECUTAR_V10.py` es el punto único de entrada. Los scripts ejecutan fuentes, hidrología, preparación, entrenamiento RTX, evaluación, agregación/informe y pruebas, con cachés y fallos explícitos. No se modifica V05–V09 ni el lago de datos. Esta versión incorpora las señales pedidas y las evalúa; no certifica inundaciones futuras ni aceptación Q1.
'''
    (F/'RESULTADOS_ESCORRENTIA_V10.md').write_text(report,encoding='utf-8')
    (F/'MANUSCRITO_ESCORRENTIA_V10.qmd').write_text('---\ntitle: "Calles, relieve satelital y escorrentía potencial en Quito"\nlang: es\nformat: docx\n---\n\n'+report,encoding='utf-8')
    (F/'control_redaccion.json').write_text(json.dumps({'palabras_resumen':len(summary.split()),
        'palabras_abstract':len(abstract.split()),'palabras_documento_aproximadas':len(report.split()),
        'n_figuras':2,'sources_in_tables_and_figures':True,'not_final_docx':True},indent=2),encoding='utf-8')
    print('Agregación, mapas e informe V10 preparados.',flush=True)


if __name__ == '__main__':
    main()
