"""Fuentes públicas para vías, pasos candidatos y terreno corregido.

La descarga EE usa las credenciales ya configuradas, sin imprimir tokens o URLs
firmadas. Cada mosaico se alinea exactamente con la malla Copernicus V05.
"""
from pathlib import Path
import json
import hashlib
import datetime as dt
from concurrent.futures import ThreadPoolExecutor
import requests
import truststore
import ee
import numpy as np
import geopandas as gpd
import rasterio
from rasterio.windows import Window, transform as window_transform
from shapely.geometry import LineString, mapping

P = Path(__file__).resolve().parents[1]
ROOT = P.parents[2]
P5 = ROOT/'EXPOSICION_FEN_NINO/VERSION_5_QUITO_10M/1_INVESTIGACION'
R = P/'2_DATOS/ORIGINALES'
D = P/'2_DATOS/PROCESADOS'
F = P/'6_FINAL'
BASE = 'https://geoquito.quito.gob.ec/server/rest/services/web_reference_dmot/plan_de_uso_y_gestion_del_suelo_2024/MapServer/'


def cache_json(file, url, params):
    if not file.exists():
        response = requests.get(url, params=params, timeout=(15,50))
        response.raise_for_status()
        data = response.json()
        if data.get('error'):
            raise RuntimeError(str(data['error']))
        file.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    return json.loads(file.read_text(encoding='utf-8'))


def roads(layer):
    metadata = cache_json(R/f'vias_{layer}_metadatos.json', BASE+str(layer), {'f':'json'})
    ids = cache_json(R/f'vias_{layer}_ids.json', BASE+str(layer)+'/query', {
        'f':'json','where':'1=1','returnIdsOnly':'true'})
    allids = sorted(ids['objectIds'])
    features = []
    for j in range(0,len(allids),500):
        data = cache_json(R/f'vias_{layer}_parte_{j:05}.json', BASE+str(layer)+'/query', {
            'f':'geojson','objectIds':','.join(map(str,allids[j:j+500])),
            'outFields':'OBJECTID,descripcio,nam,tipo,catg_via,clasifica,fuente',
            'outSR':4326,'returnGeometry':'true','geometryPrecision':7})
        if data.get('exceededTransferLimit'):
            raise ValueError('Vías truncadas')
        features.extend(data['features'])
    if len(features) != len(allids):
        raise ValueError('Conteo de vías distinto del inventario')
    result = {'type':'FeatureCollection','features':features}
    (R/f'vias_{layer}.geojson').write_text(json.dumps(result,ensure_ascii=False),encoding='utf-8')
    print('Vías',layer,len(features),flush=True)


def osm_candidates():
    target = R/'osm_estructuras_candidatas.json'
    query = ('[out:json][timeout:35];('+
        'way["highway"]["tunnel"](-0.60,-78.96,0.29,-78.16);'+
        'way["highway"]["layer"~"^-"](-0.60,-78.96,0.29,-78.16);'+
        ');out tags geom;')
    if not target.exists():
        response = requests.post('https://overpass.private.coffee/api/interpreter',data={'data':query},timeout=(15,50),
            headers={'User-Agent':'QuitoHydrologyResearch/1.0 (noncommercial research; limited geospatial queries)'})
        response.raise_for_status()
        target.write_text(json.dumps(response.json(),ensure_ascii=False,indent=2),encoding='utf-8')
    data = json.loads(target.read_text(encoding='utf-8'))
    if data.get('remark'):
        raise ValueError('Respuesta OSM posiblemente incompleta: '+data['remark'])
    features = []
    seen = set()
    for x in data['elements']:
        if x['id'] in seen:
            continue
        seen.add(x['id'])
        points = [(p['lon'],p['lat']) for p in x.get('geometry',[])]
        if len(points) < 2:
            continue
        tags = x.get('tags',{})
        features.append({'type':'Feature','geometry':mapping(LineString(points)),
            'properties':{'osm_id':str(x['id']), 'highway':tags.get('highway'),
            'name':tags.get('name'), 'tunnel':tags.get('tunnel'), 'layer':tags.get('layer'),
            'bridge':tags.get('bridge'), 'evidencia':'etiqueta OSM; no profundidad ni paso deprimido confirmado'}})
    (R/'osm_estructuras_candidatas.geojson').write_text(json.dumps({'type':'FeatureCollection','features':features},ensure_ascii=False),encoding='utf-8')
    print('Estructuras OSM candidatas',len(features),flush=True)


def fabdem():
    target = D/'fabdem_30m_alineado.tif'
    if target.exists():
        print('FABDEM: reutilizando mosaico',flush=True)
        return
    ee.Initialize(project='verdant-art-479615-c4')
    with rasterio.open(P5/'2_DATOS/PROCESADOS/dsm_30m.tif') as src:
        profile = src.profile.copy()
        profile.update(count=1,dtype='float32',nodata=-9999.,compress='deflate',predictor=3)
        h,w,tr = src.height,src.width,src.transform
    tiles = [(r,c,min(1536,h-r),min(1536,w-c)) for r in range(0,h,1536) for c in range(0,w,1536)]
    boundary = gpd.read_file(P5/'2_DATOS/PROCESADOS/quito_limite.geojson').to_crs(4326)
    region = ee.Geometry.Rectangle(boundary.total_bounds.tolist(),proj='EPSG:4326',geodesic=False)
    collection = ee.ImageCollection('projects/sat-io/open-datasets/FABDEM').filterBounds(region)
    identifiers = collection.aggregate_array('system:index').getInfo()
    (R/'fabdem_activos.json').write_text(json.dumps({'assets':identifiers,'collection':'projects/sat-io/open-datasets/FABDEM',
        'license':'CC BY-NC-SA 4.0','source_native_arcseconds':1,'output_grid_m':30},indent=2),encoding='utf-8')
    # Earth Engine composites have a default 1-degree projection unless explicitly
    # set. Resampling that default creates a falsely smooth terrain surface.
    image = collection.mosaic().select('b1').setDefaultProjection(collection.first().projection()).resample('bilinear').unmask(-9999).toFloat()
    def tile(args):
        r,c,hh,ww = args
        path = R/f'fabdem_{r:05}_{c:05}.tif'
        if not path.exists():
            t = window_transform(Window(c,r,ww,hh),tr)
            url = image.getDownloadURL({'crs':'EPSG:32717','crs_transform':list(t)[:6],
                'dimensions':[ww,hh],'format':'GEO_TIFF','filePerBand':False})
            try:
                response = requests.get(url,timeout=(15,50))
            except requests.RequestException as error:
                raise RuntimeError('Descarga de tesela FABDEM falló: '+type(error).__name__) from None
            if response.status_code != 200:
                raise RuntimeError('Descarga de tesela FABDEM: HTTP '+str(response.status_code))
            path.write_bytes(response.content)
        with rasterio.open(path) as data:
            arr = data.read(1)
            if arr.shape != (hh,ww) or not np.allclose(data.transform,tr*tr.translation(c,r),atol=1e-6):
                raise ValueError('FABDEM: grilla desalineada')
        return args,path
    with ThreadPoolExecutor(max_workers=2) as pool:
        downloaded = list(pool.map(tile,tiles))
    with rasterio.open(target,'w',**profile) as out:
        for (r,c,hh,ww),path in downloaded:
            with rasterio.open(path) as data:
                out.write(data.read(1),1,window=Window(c,r,ww,hh))
        out.update_tags(source='FABDEM V1-2 community EE assets',license='CC BY-NC-SA 4.0',
            not_measured_10m_terrain='true',sampling='bilinear to 30 m existing grid')
    print('FABDEM alineado:',h,w,flush=True)
    validate_fabdem()


def validate_fabdem():
    """Contrasta alturas exportadas con píxeles de activos nativos individuales."""
    from pyproj import Transformer
    ee.Initialize(project='verdant-art-479615-c4')
    with rasterio.open(D/'fabdem_30m_alineado.tif') as src:
        arr = src.read(1)
        tr = src.transform
        points = [(r,c) for r in [500,1500,2500] for c in [500,1400,2400]]
    transform = Transformer.from_crs(32717,4326,always_xy=True)
    features = []
    for r,c in points:
        x,y = rasterio.transform.xy(tr,r,c)
        lon,lat = transform.transform(x,y)
        point = ee.Geometry.Point([lon,lat])
        native = ee.Image(ee.ImageCollection('projects/sat-io/open-datasets/FABDEM').filterBounds(point).first())
        value = native.reduceRegion(ee.Reducer.first(),point,crs=native.projection(),maxPixels=10)
        features.append(ee.Feature(point,value).set({'row':r,'col':c,'exported_m':float(arr[r,c])}))
    values = ee.FeatureCollection(features).getInfo()
    checks = []
    for f in values['features']:
        p = f['properties']
        checks.append({**p,'difference_m':p['exported_m']-p['b1']})
    # Nearest native vs bilinear exports differ, especially on steep slopes.
    # Broad guard rejects kilometer-scale reprojection errors, not claims of accuracy.
    maximum = max(abs(x['difference_m']) for x in checks)
    if maximum > 150 or np.std(arr) < 400:
        raise ValueError('FABDEM no concuerda con activos nativos; no usar para hidrología')
    (R/'verificacion_exportacion_fabdem.json').write_text(json.dumps({'checks':checks,
        'max_abs_difference_m':maximum,'guard_not_scientific_accuracy_threshold':True,
        'setDefaultProjection_before_resample':True},indent=2),encoding='utf-8')


def main():
    truststore.inject_into_ssl()
    for path in [R,D,F]:
        path.mkdir(parents=True,exist_ok=True)
    for layer in [68,71]:
        roads(layer)
    # Optional supplementary OSM is explicitly marked if public service fails;
    # a missing source must not become "no structures".
    status_file = R/'estado_consulta_OSM.json'
    if status_file.exists() and not (R/'osm_estructuras_candidatas.json').exists():
        osm_status = json.loads(status_file.read_text())['estado']
        print('OSM: incidencia documentada; no repetir consultas automáticamente.',flush=True)
    else:
        try:
            osm_candidates()
            osm_status = 'recuperado'
        except (requests.RequestException, ValueError) as e:
            osm_status = 'no_disponible_'+type(e).__name__
            print('OSM no recuperado; no se sustituye por ceros:',type(e).__name__,flush=True)
        status_file.write_text(json.dumps({'estado':osm_status,'fecha':'2026-10-09',
            'endpoints_attempted':['overpass-api.de (POST/GET, 406)','overpass.private.coffee (429)'],
            'no_zero_absence_labels':True,'new_retry_requires_removing_this_status_explicitly':True},indent=2),encoding='utf-8')
    fabdem()
    if not (R/'verificacion_exportacion_fabdem.json').exists():
        validate_fabdem()
    audit = {'ejecutado_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
        'osm_status':osm_status,'snapshot_version':'2026-10-09',
        'public_sources_only':True,'no_raw_credentials_or_signed_urls_saved':True,
        'urls':{'vialidad':BASE,'fabdem_source':'https://data.bris.ac.uk/data/dataset/s5hqmjcdj8yo2ibzi9b4ew3sn',
                'catalogo_EE':'https://gee-community-catalog.org/projects/fabdem/',
                'paper_FABDEM':'https://doi.org/10.1088/1748-9326/ac4d4f',
                'hydro_enforcement':'https://doi.org/10.3133/fs20143051',
                'FloodCastBench':'https://doi.org/10.1038/s41597-025-04725-2'},
        'raw_files':[{'name':f.name,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted(R.iterdir()) if f.is_file()]}
    (F/'fuentes_y_hashes.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')


if __name__ == '__main__':
    main()
