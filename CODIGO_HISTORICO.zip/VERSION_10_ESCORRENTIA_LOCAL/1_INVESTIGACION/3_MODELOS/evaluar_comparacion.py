"""Evaluación emparejada de señales de vías y escorrentía; conserva todos los casos."""
from pathlib import Path
import json
import sys
import numpy as np
import pandas as pd
from scipy.special import logsumexp

P = Path(__file__).resolve().parents[1]
ROOT = P.parents[2]
P5 = ROOT/'EXPOSICION_FEN_NINO/VERSION_5_QUITO_10M/1_INVESTIGACION'
sys.path.insert(0,str(P5/'3_MODELOS'))
from evaluar_quito import tail_membership
D = P/'2_DATOS/PROCESADOS'
F = P/'6_FINAL'


def evaluate(fe,fb,valid):
    normalizer = logsumexp(fb)-np.log(len(fb))
    ev = logsumexp(np.where(valid,fe,-np.inf),axis=1)-np.log(valid.sum(1))-normalizer
    members,threshold = tail_membership(fe,fb)
    capture = (members*valid).sum(1)/valid.sum(1)
    return ev,capture


def main():
    states = json.loads((D/'modelos_lineales_v10.json').read_text(encoding='utf-8'))
    records = []
    vectors = {}
    for key,st in states.items():
        with np.load(D/f'entrada_{key}.npz') as z:
            inp = {k:z[k] for k in z.files}
        e,b = inp['etest'],inp['btest']
        valid = inp['valid_e'][e]
        block = (inp['event_x'][e]//5000).astype(int).astype(str)+'_'+(inp['event_y'][e]//5000).astype(int).astype(str)
        scores = {}
        with np.load(D/f'lineal_{key}.npz') as z:
            scores['loglineal'] = (z['fe'][e],z['fb'][b])
        network_e,network_b = [],[]
        for seed in [5101,5102,5103]:
            with np.load(D/f'scores_red_{key}_{seed}.npz') as z:
                fe,fb = z['fe'][e],z['fb'][b]
            norm = logsumexp(fb)-np.log(len(fb))
            network_e.append(fe-norm)
            network_b.append(fb-norm)
        scores['red_ensamble'] = (logsumexp(np.stack(network_e),axis=0)-np.log(3),
                                  logsumexp(np.stack(network_b),axis=0)-np.log(3))
        edge = np.any((inp['edge_copernicus_e'][e] > 0)&valid,axis=1)|np.any((inp['edge_fabdem_e'][e] > 0)&valid,axis=1)
        for name,(fe,fb) in scores.items():
            ev,cap = evaluate(fe,fb,valid)
            vectors[(st['protocol'],st['variant'],name)] = (ev,cap,block,edge)
            for domain,use in [('completo',np.ones(len(ev),bool)),('sin_influencia_borde',~edge)]:
                records.append({'protocolo':st['protocol'],'variante':st['variant'],'modelo':name,'muestra':domain,
                    'n_reportes_test':int(use.sum()),'n_bloques_5km':len(np.unique(block[use])),
                    'n_cuadratura_test':int(b.sum()),
                    'log_densidad_relativa':float(ev[use].mean()) if use.any() else np.nan,
                    'captura_soporte_top10pct_territorio':float(cap[use].mean()) if use.any() else np.nan,
                    'definicion':'presencias geocodificadas; no agua física ni ausencia confirmada'})
    metrics = pd.DataFrame(records)
    metrics.to_csv(F/'comparacion_vias_escorrentia.csv',index=False)
    comparisons = []
    rng = np.random.default_rng(10109)
    for (protocol,variant,name),(ev,cap,block,edge) in vectors.items():
        if variant == 'base':
            continue
        base_ev,base_cap,base_block,base_edge = vectors[(protocol,'base',name)]
        if not np.array_equal(block,base_block):
            raise ValueError('No son muestras emparejadas')
        unique = np.unique(block)
        sums = np.array([(ev-base_ev)[block==k].sum() for k in unique])
        counts = np.array([(block==k).sum() for k in unique])
        draw = rng.integers(0,len(unique),(3000,len(unique)))
        simulated = sums[draw].sum(1)/counts[draw].sum(1)
        lo,hi = np.quantile(simulated,[.025,.975])
        comparisons.append({'protocolo':protocol,'variante':variant,'modelo':name,
            'diferencia_log_densidad_vs_base':float((ev-base_ev).mean()),
            'rango95_bloques_inf':lo,'rango95_bloques_sup':hi,
            'diferencia_captura_vs_base':float((cap-base_cap).mean()),
            'n_bloques':len(unique),'inferencia':'exploratoria; dependencia por evento no completamente resuelta'})
    pd.DataFrame(comparisons).to_csv(F/'diferencias_emparejadas_por_bloques.csv',index=False)
    (F/'control_evaluacion.json').write_text(json.dumps({
        'same_sample_in_each_variant':True,'all_variants_retained':True,
        'normalizer':'same V05 background subset for each protocol; no mixing full-grid normalizers',
        'new_neural_training_on_existing_RTX':True,'not_physical_flood_accuracy':True,
        'retrospective_secondary_validation':True,'bootstrap_seed':10109},indent=2),encoding='utf-8')
    print(metrics[metrics.muestra=='completo'].to_string(index=False),flush=True)


if __name__ == '__main__':
    main()
