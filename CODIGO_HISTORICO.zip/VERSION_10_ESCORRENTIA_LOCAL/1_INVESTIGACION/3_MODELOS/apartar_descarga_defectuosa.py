"""Aparta exclusivamente salidas V10 defectuosas; operación recuperable."""
from pathlib import Path
import json

P = Path(__file__).resolve().parents[1]
R = P/'2_DATOS/ORIGINALES'
D = P/'2_DATOS/PROCESADOS'
ARCHIVE = R/'RECHAZADO_REPROYECCION_20261009'


def main():
    # Never remove user or earlier-version files. Validate every exact target.
    targets = [R/f'fabdem_{r:05}_{c:05}.tif' for r in [0,1536,3072] for c in [0,1536]]
    targets += [D/'fabdem_30m_alineado.tif',D/'escorrentia_fabdem_30m.tif',D/'grafo_flujo_fabdem.npz']
    ARCHIVE.mkdir(exist_ok=True)
    moved = []
    for file in targets:
        if not file.resolve().is_relative_to(P.resolve()):
            raise ValueError('Ruta fuera de V10')
        dest = ARCHIVE/file.name
        if file.exists():
            if dest.exists():
                raise FileExistsError('No sobrescribir evidencia rechazada')
            file.rename(dest)
            moved.append(file.name)
    (ARCHIVE/'MOTIVO.json').write_text(json.dumps({'motivo':'mosaico EE con proyección por defecto antes de resample; relieve suavizado inválido',
        'recoverable_moved_files':moved,'not_used_in_neural_training_or_final_comparison':True},ensure_ascii=False,indent=2),encoding='utf-8')
    print('Apartados de forma recuperable:',moved,flush=True)


if __name__=='__main__':
    main()
