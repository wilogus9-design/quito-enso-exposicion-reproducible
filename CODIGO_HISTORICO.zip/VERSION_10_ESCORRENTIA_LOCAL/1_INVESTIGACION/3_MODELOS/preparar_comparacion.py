"""Agrega covariables nativas y mantiene iguales las muestras de comparación."""
from pathlib import Path
import json
import sys
import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from scipy.special import logsumexp

P = Path(__file__).resolve().parents[1]
ROOT = P.parents[2]
P5 = ROOT/'EXPOSICION_FEN_NINO/VERSION_5_QUITO_10M/1_INVESTIGACION'
D = P/'2_DATOS/PROCESADOS'
F = P/'6_FINAL'
sys.path.insert(0,str(P5/'3_MODELOS'))
from ajustar_lineal import domains, fit, valid_norm


def extract(file,x,y,bands):
    with rasterio.open(file) as src:
        data = src.read(bands)
        r = np.floor((y-src.transform.f)/src.transform.e).astype(int)
        c = np.floor((x-src.transform.c)/src.transform.a).astype(int)
        within = (r>=0)&(r<src.height)&(c>=0)&(c<src.width)
        rr = np.clip(r,0,src.height-1)
        cc = np.clip(c,0,src.width-1)
        result = np.moveaxis(data[:,rr,cc],0,-1)
        result[~within] = np.nan
        return result


def main():
    with np.load(P5/'2_DATOS/PROCESADOS/muestras_inciertas.npz') as file:
        base = {k:file[k] for k in file.files}
    reports = gpd.read_file(P5/'2_DATOS/PROCESADOS/reportes_quito.geojson')
    if len(reports) != len(base['event_x']):
        raise ValueError('No reconstruir posiciones inciertas con registros diferentes')
    np.testing.assert_allclose(reports.x,base['event_x'])
    np.testing.assert_allclose(reports.y,base['event_y'])
    rng = np.random.default_rng(5100)
    n,k = base['valid_e'].shape
    radius = 100*np.sqrt(rng.uniform(size=(n,k)))
    angle = rng.uniform(0,2*np.pi,size=(n,k))
    radius[:,0] = 0
    x = base['event_x'][:,None]+radius*np.cos(angle)
    y = base['event_y'][:,None]+radius*np.sin(angle)
    extras_e = {}
    extras_b = {}
    edge_e = {}
    osm_available = not json.loads((F/'control_hidrologia.json').read_text())['osm_missing_not_replaced_by_absence']
    for name in ['copernicus','fabdem']:
        file = D/f'escorrentia_{name}_30m.tif'
        extras_e[name] = extract(file,x,y,[1,2,3,4])
        extras_b[name] = extract(file,base['bg_x'],base['bg_y'],[1,2,3,4])
        edge_e[name] = extract(file,x,y,[5])[...,0]
    road_bands = [6,7] if osm_available else [6]
    road_e = extract(D/'escorrentia_fabdem_30m.tif',x,y,road_bands)
    road_b = extract(D/'escorrentia_fabdem_30m.tif',base['bg_x'],base['bg_y'],road_bands)
    road_e[...,0] = np.log1p(road_e[...,0]/10)
    road_b[...,0] = np.log1p(road_b[...,0]/10)
    names_road = ['log_distancia_vial']+(['proximidad_estructura_OSM_100m'] if osm_available else [])
    names_hydro = ['depresion_digital_m','log_area_contribuyente_ha','log_construido_contribuyente_ha','fraccion_construida_contribuyente']
    variants = {'base':([],[],[]),'vias':([road_e],[road_b],names_road),
        'vias_copernicus':([road_e,extras_e['copernicus']],[road_b,extras_b['copernicus']],names_road+names_hydro),
        'vias_fabdem':([road_e,extras_e['fabdem']],[road_b,extras_b['fabdem']],names_road+names_hydro)}
    states = {}
    tuning = []
    for protocol in ['temporal','espacial']:
        emasks,bmasks = domains(base,'INUNDACION',protocol)
        counts = [int(e.sum()) for e in emasks]
        for variant,(ee,bb,extra_names) in variants.items():
            Xe = np.concatenate([base['Xe'],*ee],axis=-1)
            Xb = np.concatenate([base['Xb'],*bb],axis=-1)
            if not np.isfinite(Xe[base['valid_e']]).all() or not np.isfinite(Xb).all():
                raise ValueError('La ampliación pierde soporte; no cambiar muestras silenciosamente')
            mu = Xb[bmasks[0]].mean(axis=0)
            sd = Xb[bmasks[0]].std(axis=0)
            sd = np.where(sd>1e-6,sd,1)
            Xe = np.nan_to_num((Xe-mu)/sd,nan=0).astype(np.float32)
            Xb = ((Xb-mu)/sd).astype(np.float32)
            candidates = []
            for lam in [.001,.01,.1,1.]:
                beta = fit(Xe[emasks[0]],Xb[bmasks[0]],base['valid_e'][emasks[0]],lam)
                ev,_ = valid_norm(Xe[emasks[1]],base['valid_e'][emasks[1]],beta)
                ll = float(ev.mean()-logsumexp(Xb[bmasks[1]]@beta)+np.log(bmasks[1].sum()))
                candidates.append((ll,lam,beta))
                tuning.append({'protocolo':protocol,'variante':variant,'lambda':lam,'log_densidad_cal':ll})
            best = max(candidates,key=lambda c:c[0])
            options = []
            for alpha in [.25,.5,.75,1.,1.25]:
                ev,_ = valid_norm(Xe[emasks[1]],base['valid_e'][emasks[1]],best[2]*alpha)
                ll = float(ev.mean()-logsumexp(Xb[bmasks[1]]@(best[2]*alpha))+np.log(bmasks[1].sum()))
                options.append((ll,alpha))
            alpha = max(options)[1]
            key = protocol+'__'+variant
            st = {'protocol':protocol,'variant':variant,'beta':best[2].tolist(),
                  'alpha':alpha,'lambda':best[1],'mu':mu.tolist(),'sd':sd.tolist(),
                  'names':base['names'].tolist()+extra_names,'counts':counts,
                  'osm_feature_available':osm_available}
            states[key] = st
            np.savez_compressed(D/f'entrada_{key}.npz',Xe=Xe,Xb=Xb,valid_e=base['valid_e'],
                etrain=emasks[0],ecal=emasks[1],etest=emasks[2],
                btrain=bmasks[0],bcal=bmasks[1],btest=bmasks[2],
                event_x=base['event_x'],event_y=base['event_y'],
                edge_copernicus_e=edge_e['copernicus'],edge_fabdem_e=edge_e['fabdem'])
            np.savez_compressed(D/f'lineal_{key}.npz',fe=Xe@(best[2]*alpha),fb=Xb@(best[2]*alpha))
            print(key,'variables',Xb.shape[1],'muestras',counts,'lambda',best[1],flush=True)
    (D/'modelos_lineales_v10.json').write_text(json.dumps(states,ensure_ascii=False,indent=2),encoding='utf-8')
    pd.DataFrame(tuning).to_csv(F/'seleccion_calibracion_lineal.csv',index=False)
    (F/'control_muestras.json').write_text(json.dumps({'same_25_positions_as_V05':True,
        'same_train_cal_test_masks_as_V05':True,'same_background_60000':True,
        'osm_not_imputed_as_absence':not osm_available,'osm_used':osm_available,
        'n_features_by_variant':{k:len(v['names'])for k,v in states.items()},
        'historical_vintage_of_roads_not_certified':True},indent=2),encoding='utf-8')


if __name__ == '__main__':
    main()
