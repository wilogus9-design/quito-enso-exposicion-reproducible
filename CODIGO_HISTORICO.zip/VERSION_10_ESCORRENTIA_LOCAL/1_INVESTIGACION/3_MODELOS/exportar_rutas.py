"""Entrega corredores D8 potenciales como líneas GIS, no cauces observados."""
from pathlib import Path
import json
import numpy as np
import rasterio
import shapely
from shapely.ops import transform
from pyproj import Transformer

P = Path(__file__).resolve().parents[1]
D = P/'2_DATOS/PROCESADOS'
F = P/'6_FINAL'


def main():
    with np.load(D/'contexto_vial_30m.npz') as z:
        mask = z['mask']
    project = Transformer.from_crs(32717,4326,always_xy=True)
    audit = []
    for source in ['copernicus','fabdem']:
        with rasterio.open(D/f'escorrentia_{source}_30m.tif') as src:
            loga = src.read(2)
            tr = src.transform
        with np.load(D/f'grafo_flujo_{source}.npz') as z:
            rec = z['receiver'].ravel()
        h,w = mask.shape
        selected = np.flatnonzero((mask.ravel())&(rec>=0)&(loga.ravel()>=np.log1p(20)))
        target = rec[selected]
        rr,cc = np.divmod(selected,w)
        rt,ct = np.divmod(target,w)
        coordinates = np.stack([np.stack([tr.c+(cc+.5)*30,tr.f-(rr+.5)*30],axis=-1),
                                 np.stack([tr.c+(ct+.5)*30,tr.f-(rt+.5)*30],axis=-1)],axis=1)
        lines = shapely.linestrings(coordinates)
        merged = shapely.line_merge(shapely.multilinestrings(lines))
        geoms = list(merged.geoms) if merged.geom_type=='MultiLineString' else [merged]
        features = []
        for i,geom in enumerate(geoms,1):
            geo = transform(project.transform,geom)
            xy = [[round(x,7),round(y,7)]for x,y in geo.coords]
            features.append({'type':'Feature','geometry':{'type':'LineString','coordinates':xy},
                'properties':{'id':i,'source':source,'support_m':30,'contributing_area_cutoff_ha':20,
                    'observed_channel':False,'hydraulic_flow_simulated':False}})
        file = F/f'rutas_potenciales_{source}_30m.geojson'
        file.write_text(json.dumps({'type':'FeatureCollection','features':features},ensure_ascii=False,separators=(',',':')),encoding='utf-8')
        audit.append({'source':source,'selected_D8_edges':len(selected),'merged_lines':len(features),
            'native_m':30,'threshold_for_cartographic_display_ha':20,'not_used_for_model_threshold_tuning':True,
            'file_bytes':file.stat().st_size})
        print(source,'rutas cartográficas',len(features),'aristas D8',len(selected),flush=True)
    (F/'control_rutas.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')


if __name__=='__main__':
    main()
