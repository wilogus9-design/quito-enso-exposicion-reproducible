"""Conectividad superficial y depresiones digitales en su soporte nativo de 30 m.

Priority-flood conserva profundidad de relleno como diagnóstico. El relleno es
una operación de DEM, no una lámina de agua. D8 no simula tuberías o lluvia.
"""
from pathlib import Path
from collections import deque
from heapq import heappush, heappop, heapify
import json
import numpy as np
import geopandas as gpd
import rasterio
from rasterio.features import rasterize
from rasterio.windows import Window
from scipy.ndimage import distance_transform_edt, label, find_objects
from shapely.geometry import Point

P = Path(__file__).resolve().parents[1]
ROOT = P.parents[2]
P5 = ROOT/'EXPOSICION_FEN_NINO/VERSION_5_QUITO_10M/1_INVESTIGACION'
D = P/'2_DATOS/PROCESADOS'
R = P/'2_DATOS/ORIGINALES'
F = P/'6_FINAL'
NAMES = ['depresion_digital_m','log_area_contribuyente_ha','log_construido_contribuyente_ha',
         'fraccion_construida_contribuyente','influencia_borde_externo','distancia_vial_m',
         'proximidad_estructura_OSM','construido_local_fraccion']
OFFSETS = [(-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1)]


def priority_flood(dem, progress=False):
    h,w = dem.shape
    values = dem.astype(np.float32).ravel().copy()
    filled = values.copy()
    visited = np.zeros(len(values), dtype=bool)
    parent = np.full(len(values), -1, dtype=np.int32)
    border = np.unique(np.concatenate([np.arange(w), np.arange((h-1)*w,h*w),
                            np.arange(0,h*w,w),np.arange(w-1,h*w,w)]))
    visited[border] = True
    heap = [(float(values[i]),int(i)) for i in border]
    heapify(heap)
    queue = deque()
    order = np.empty(len(values),dtype=np.int32)
    n = 0
    while heap or queue:
        if queue:
            i = queue.popleft()
            height = float(filled[i])
        else:
            height,i = heappop(heap)
        order[n] = i
        n += 1
        row,col = divmod(i,w)
        for dr,dc in OFFSETS:
            rr,cc = row+dr,col+dc
            if rr < 0 or rr >= h or cc < 0 or cc >= w:
                continue
            j = rr*w+cc
            if visited[j]:
                continue
            visited[j] = True
            parent[j] = i
            value = float(values[j])
            if value <= height:
                filled[j] = height
                queue.append(j)
            else:
                heappush(heap,(value,j))
        if progress and n%1000000 == 0:
            print('Priority-flood:',n,'de',len(values),flush=True)
    if n != len(values):
        raise RuntimeError('El rectángulo no fue recorrido completo')
    return filled.reshape(h,w),parent.reshape(h,w),order


def receiver_d8(filled,parent,order):
    h,w = filled.shape
    rec = parent.copy()
    slope = np.zeros((h,w),dtype=np.float32)
    ids = np.arange(h*w,dtype=np.int32).reshape(h,w)
    # Rectángulo exterior libre; conserva sus celdas como salidas.
    interior = np.ones((h,w),dtype=bool)
    interior[[0,-1],:] = False
    interior[:,[0,-1]] = False
    for dr,dc in OFFSETS:
        rs = slice(max(0,-dr),min(h,h-dr));cs = slice(max(0,-dc),min(w,w-dc))
        rn = slice(max(0,dr),min(h,h+dr));cn = slice(max(0,dc),min(w,w+dc))
        drop = (filled[rs,cs]-filled[rn,cn])/(30*np.hypot(dr,dc))
        use = (drop > slope[rs,cs])&interior[rs,cs]
        slope[rs,cs][use] = drop[use]
        rec[rs,cs][use] = ids[rn,cn][use]
    rank = np.empty(h*w,dtype=np.int32)
    rank[order] = np.arange(len(order),dtype=np.int32)
    flat = rec.ravel()
    source = np.flatnonzero(flat >= 0)
    if not np.all(rank[flat[source]] < rank[source]):
        raise ValueError('Ciclo de flujo o orden hidrológico incompatible')
    return rec,slope


def accumulate(receiver,order,built):
    rec = receiver.ravel()
    area = np.full(len(rec),.09,dtype=np.float64)
    upstream_built = built.ravel().astype(float)*.09
    h,w = receiver.shape
    edge = np.zeros((h,w),dtype=np.uint8)
    # Afluentes que tocan una franja exterior de 300 m pueden estar truncados.
    edge[:10,:] = 1
    edge[-10:,:] = 1
    edge[:,:10] = 1
    edge[:,-10:] = 1
    edge = edge.ravel()
    for i in order[::-1]:
        j = rec[i]
        if j >= 0:
            area[j] += area[i]
            upstream_built[j] += upstream_built[i]
            edge[j] |= edge[i]
    outlets = rec < 0
    if abs(area[outlets].sum()-.09*len(rec)) > 1e-5:
        raise ValueError('Balance de área contribuyente incorrecto')
    if abs(upstream_built[outlets].sum()-built.astype(np.float64).sum()*.09) > 1e-5:
        raise ValueError('Balance de construido incorrecto')
    return area.reshape(h,w),upstream_built.reshape(h,w),edge.reshape(h,w)


def main():
    with rasterio.open(P5/'2_DATOS/PROCESADOS/dsm_30m.tif') as src:
        profile = src.profile.copy()
        dsm = src.read(1)
        tr = src.transform
        shape = src.shape
    if not np.isfinite(dsm).all():
        raise ValueError('DSM con faltantes: no rellenar elevaciones sin fuente')
    built = np.zeros(shape,dtype=np.float32)
    mask = np.zeros(shape,dtype=bool)
    with rasterio.open(P5/'2_DATOS/PROCESADOS/worldcover_2021_10m.tif') as wc, rasterio.open(P5/'2_DATOS/PROCESADOS/mascara_quito_10m.tif') as m:
        if wc.shape != (shape[0]*3,shape[1]*3):
            raise ValueError('Las mallas 10/30 m no están alineadas')
        for r in range(0,shape[0],128):
            hh = min(128,shape[0]-r)
            win = Window(0,r*3,wc.width,hh*3)
            built[r:r+hh] = (wc.read(1,window=win)==50).reshape(hh,3,shape[1],3).mean(axis=(1,3))
            mask[r:r+hh] = (m.read(1,window=win)>0).reshape(hh,3,shape[1],3).any(axis=(1,3))
    streets = []
    for k in [68,71]:
        geo = gpd.read_file(R/f'vias_{k}.geojson').to_crs(32717)
        streets.extend([g for g in geo.geometry if g is not None and not g.is_empty])
    roadmask = rasterize([(g,1) for g in streets],out_shape=shape,transform=tr,fill=0,dtype='uint8',all_touched=True)
    if not roadmask.any():
        raise ValueError('La vialidad está fuera de la grilla: revisar CRS SIRES-DMQ')
    road_distance = distance_transform_edt(roadmask==0,sampling=30).astype(np.float32)
    osmfile = R/'osm_estructuras_candidatas.geojson'
    osm_proximity = np.full(shape,np.nan,dtype=np.float32)
    osm_count = None
    if osmfile.exists():
        osm = gpd.read_file(osmfile).to_crs(32717)
        osm_count = len(osm)
        om = rasterize([(g,1) for g in osm.geometry],out_shape=shape,transform=tr,dtype='uint8',all_touched=True)
        if om.any():
            osm_proximity = np.exp(-distance_transform_edt(om==0,sampling=30)/100).astype(np.float32)
    np.savez_compressed(D/'contexto_vial_30m.npz',built=built,mask=mask,roads=roadmask,osm_proximity=osm_proximity)
    audits = []
    candidates = []
    for key,source in [('copernicus',P5/'2_DATOS/PROCESADOS/dsm_30m.tif'),('fabdem',D/'fabdem_30m_alineado.tif')]:
        target = D/f'escorrentia_{key}_30m.tif'
        if target.exists():
            print('Reutilizando hidrología',key,flush=True)
            with rasterio.open(target) as src:
                depression,loga,logb = src.read([1,2,3])
        else:
            with rasterio.open(source) as src:
                dem = src.read(1)
                if dem.shape != shape or not np.allclose(src.transform,tr):
                    raise ValueError('Relieve no alineado')
            if not np.isfinite(dem).all() or (dem == -9999).any():
                raise ValueError('Relieve con huecos; no simular')
            print('Calculando hidrología',key,shape,flush=True)
            filled,parent,order = priority_flood(dem,progress=True)
            receiver,slope = receiver_d8(filled,parent,order)
            area,upstream,edge = accumulate(receiver,order,built)
            depression = np.maximum(filled-dem,0)
            loga = np.log1p(area).astype(np.float32)
            logb = np.log1p(upstream).astype(np.float32)
            data = np.stack([depression,loga,logb,(upstream/area).astype(np.float32),edge.astype(np.float32),road_distance,osm_proximity,built]).astype(np.float32)
            profile.update(count=len(NAMES),dtype='float32',nodata=None,compress='deflate',predictor=3)
            with rasterio.open(target,'w',**profile) as out:
                out.write(data)
                for band,name in enumerate(NAMES,1):
                    out.set_band_description(band,name)
                out.update_tags(native_support_m=30,source=key,not_water_depth='true',not_flood_probability='true',
                    license='CC BY-NC-SA 4.0' if key=='fabdem' else 'Copernicus DEM source obligations apply')
            np.savez_compressed(D/f'grafo_flujo_{key}.npz',receiver=receiver,order=order)
            del data,filled,parent,order,receiver,area,upstream,edge,slope
        selected = (depression >= .5)&(np.expm1(loga) >= 1)&(roadmask>0)&mask
        labels,n = label(selected)
        flatlabels = labels.ravel()
        counts = np.bincount(flatlabels,minlength=n+1)
        boxes = find_objects(labels)
        # Component statistics refer to digital cells, not physically inundated parcels.
        for region in np.flatnonzero(counts[1:] >= 2)+1:
            box = boxes[region-1]
            rr,cc = np.nonzero(labels[box]==region)
            rr += box[0].start
            cc += box[1].start
            depth = depression[rr,cc]
            high = int(np.argmax(depth))
            x,y = rasterio.transform.xy(tr,rr[high],cc[high])
            candidates.append({'source':key,'n_celdas_30m':len(rr),'area_soporte_m2':len(rr)*900,
                'relleno_digital_max_m':float(depth[high]),'area_contribuyente_max_ha':float(np.expm1(loga[rr,cc]).max()),
                'construido_contribuyente_max_ha':float(np.expm1(logb[rr,cc]).max()),
                'evidencia':'candidato geométrico para revisión; no paso deprimido ni agua confirmada',
                'geometry':Point(x,y)})
        audits.append({'source':key,'cells_rectangle':int(np.prod(shape)),
            'cells_canton_coarse':int(mask.sum()),'vial_cells_canton':int(((roadmask>0)&mask).sum()),
            'digital_depression_cells_gt_05m_canton':int(((depression>=.5)&mask).sum()),
            'road_candidate_cells':int(selected.sum()),'native_m':30,
            'flood_depth_measured':False,'underground_drainage_modeled':False})
    gpd.GeoDataFrame(candidates,geometry='geometry',crs=32717).to_crs(4326).to_file(F/'candidatos_depresion_vial.geojson',driver='GeoJSON')
    (F/'control_hidrologia.json').write_text(json.dumps({'sources':audits,'osm_structures':osm_count,
        'osm_missing_not_replaced_by_absence':bool(np.isnan(osm_proximity).all()),
        'priority_flood_rectangular_context':True,'native_terrain_support_m':30,
        'roads_data_version':'PUGS 2024; not historical opening dates',
        'n_candidates':len(candidates),'not_hydraulic_simulation':True},ensure_ascii=False,indent=2),encoding='utf-8')
    print('Candidatos digitales de acumulación vial:',len(candidates),flush=True)


if __name__ == '__main__':
    main()
