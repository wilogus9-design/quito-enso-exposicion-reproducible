"""Controles técnicos y numéricos; no prueba de validación física de inundación."""
from pathlib import Path
import json
import unittest
import numpy as np
import pandas as pd
import rasterio
import geopandas as gpd
from hidrologia_terreno import priority_flood,receiver_d8,accumulate

P = Path(__file__).resolve().parents[1]
D = P/'2_DATOS/PROCESADOS'
R = P/'2_DATOS/ORIGINALES'
F = P/'6_FINAL'


class Checks(unittest.TestCase):
    def test_priority_flood_closed_pit(self):
        dem = np.ones((7,7),dtype=np.float32)*10
        dem[[0,-1],:] = 0
        dem[:,[0,-1]] = 0
        dem[3,3] = 1
        filled,parent,order = priority_flood(dem)
        self.assertEqual(filled[3,3],10)
        self.assertTrue((filled>=dem).all())
        self.assertEqual(len(np.unique(order)),49)
        rec,slope = receiver_d8(filled,parent,order)
        area,built,edge = accumulate(rec,order,np.ones(dem.shape)*.4)
        outlets = rec<0
        self.assertAlmostEqual(area[outlets].sum(),49*.09,places=10)
        self.assertAlmostEqual(built[outlets].sum(),49*.09*.4,places=10)

    def test_flow_planar_and_flat(self):
        for dem in [np.zeros((8,9)),np.add.outer(np.arange(8)[::-1],np.arange(9)[::-1])]:
            filled,parent,order = priority_flood(dem)
            rec,slope = receiver_d8(filled,parent,order)
            area,built,edge = accumulate(rec,order,np.zeros(dem.shape))
            self.assertAlmostEqual(area[rec<0].sum(),72*.09,places=8)
            self.assertEqual(built.sum(),0)

    def test_source_reprojection_and_archive(self):
        check = json.loads((R/'verificacion_exportacion_fabdem.json').read_text())
        self.assertEqual(len(check['checks']),9)
        self.assertLess(check['max_abs_difference_m'],150)
        self.assertTrue(check['setDefaultProjection_before_resample'])
        self.assertTrue((R/'RECHAZADO_REPROYECCION_20261009/MOTIVO.json').exists())
        with rasterio.open(D/'fabdem_30m_alineado.tif') as src:
            a = src.read(1)
            self.assertGreater(float(a.std()),400)
            self.assertFalse((a==-9999).any())

    def test_terrain_support_and_covariates(self):
        for name in ['copernicus','fabdem']:
            with rasterio.open(D/f'escorrentia_{name}_30m.tif') as src:
                self.assertEqual(src.count,8)
                self.assertEqual(src.res,(30,30))
                x = src.read([1,2,3,4],out_shape=(4,100,100))
                self.assertTrue(np.isfinite(x).all())
                self.assertTrue((x[0]>=0).all())
                self.assertTrue((x[3]>=0).all())
                self.assertTrue((x[3]<=1+1e-6).all())
                self.assertEqual(src.tags()['not_water_depth'],'true')

    def test_samples_identical(self):
        with np.load(D/'entrada_temporal__base.npz') as z:
            base = {k:z[k] for k in ['valid_e','etrain','ecal','etest','btrain','btest']}
        for variant in ['vias','vias_copernicus','vias_fabdem']:
            with np.load(D/f'entrada_temporal__{variant}.npz') as z:
                for key,a in base.items():
                    np.testing.assert_array_equal(a,z[key])
                self.assertTrue(np.isfinite(z['Xe']).all())
                self.assertTrue(np.isfinite(z['Xb']).all())
        self.assertEqual([int(base[k].sum())for k in ['etrain','ecal','etest']],[143,88,100])

    def test_gpu_training_and_all_results(self):
        audit = json.loads((F/'entrenamiento_redes_RTX.json').read_text())
        self.assertEqual(len(audit),24)
        self.assertTrue(all(x['device']=='cuda' and '5070' in x['gpu_name'] for x in audit))
        self.assertEqual(len(list(D.glob('red_*.pt'))),24)
        metrics = pd.read_csv(F/'comparacion_vias_escorrentia.csv')
        full = metrics[metrics.muestra=='completo']
        self.assertEqual(len(full),16)
        self.assertTrue((full[full.protocolo=='temporal'].n_reportes_test==100).all())
        self.assertTrue((full[full.protocolo=='espacial'].n_reportes_test==58).all())
        # Failed transfer is retained, not removed as a supposedly invalid model.
        delta = pd.read_csv(F/'diferencias_emparejadas_por_bloques.csv')
        x = delta[(delta.protocolo=='espacial')&(delta.variante=='vias_fabdem')&(delta.modelo=='red_ensamble')]
        self.assertLess(float(x.diferencia_log_densidad_vs_base.iloc[0]),0)

    def test_parish_aggregation_and_structural_references(self):
        x = pd.read_csv(F/'escorrentia_y_contexto_social_parroquias.csv',dtype={'parroquia':str})
        self.assertEqual(len(x),130)
        self.assertEqual(x.parroquia.nunique(),65)
        self.assertFalse(x[['pc_pnbi','pc_SH','pc_FSA','pc_HAC']].isna().any().any())
        refs = json.loads((F/'referencias_estructurales_municipales.json').read_text())
        self.assertEqual(len(refs),8)
        self.assertTrue(all(x['coordenada_confirmada'] is None for x in refs))

    def test_candidate_and_route_semantics(self):
        candidates = gpd.read_file(F/'candidatos_depresion_vial.geojson')
        self.assertEqual(len(candidates),388)
        self.assertEqual(set(candidates.source),{'copernicus','fabdem'})
        self.assertTrue((candidates.n_celdas_30m>=2).all())
        for source in ['copernicus','fabdem']:
            data = json.loads((F/f'rutas_potenciales_{source}_30m.geojson').read_text())
            self.assertGreater(len(data['features']),0)
            self.assertFalse(any(x['properties']['observed_channel'] for x in data['features']))

    def test_missing_osm_not_zero_labels(self):
        ctrl = json.loads((F/'control_muestras.json').read_text())
        self.assertFalse(ctrl['osm_used'])
        self.assertTrue(ctrl['osm_not_imputed_as_absence'])
        self.assertEqual(ctrl['n_features_by_variant']['temporal__vias'],21)

    def test_document_and_delivery(self):
        text = (F/'MANUSCRITO_ESCORRENTIA_V10.qmd').read_text(encoding='utf-8')
        self.assertNotIn('\x08',text)
        self.assertNotIn('\x0c',text)
        self.assertLess(len(text.split()),10000)
        self.assertIn('fuertemente negativa',text)
        for file in F.rglob('*'):
            if file.is_file():
                self.assertLess(file.stat().st_size,10000000,file.name)


if __name__=='__main__':
    unittest.main(verbosity=2)
