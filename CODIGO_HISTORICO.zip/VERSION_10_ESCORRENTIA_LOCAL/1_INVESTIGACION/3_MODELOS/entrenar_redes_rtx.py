"""Experimento neural emparejado V10 con la RTX existente.

Las covariables vienen de relieve y cobertura; las etiquetas son presencias de
reportes con posición incierta. No se las presenta como inundación por píxel.
"""
from pathlib import Path
import sys
import json
import math
import numpy as np
import torch

P = Path(__file__).resolve().parents[1]
ROOT = P.parents[2]
P5 = ROOT/'EXPOSICION_FEN_NINO/VERSION_5_QUITO_10M/1_INVESTIGACION'
sys.path.insert(0,str(P5/'3_MODELOS'))
from red_punto_proceso import SpatialNet, tensor_eval, raw
D = P/'2_DATOS/PROCESADOS'
F = P/'6_FINAL'


def main():
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    torch.set_num_threads(4)
    print('Entrenamiento V10 en',torch.cuda.get_device_name(0) if device=='cuda' else device,flush=True)
    states = json.loads((D/'modelos_lineales_v10.json').read_text(encoding='utf-8'))
    audit = []
    for key,st in states.items():
        with np.load(D/f'entrada_{key}.npz') as z:
            data = {k:z[k] for k in z.files}
        Xb = torch.as_tensor(data['Xb'],device=device)
        Xe = torch.as_tensor(data['Xe'],device=device)
        valid = torch.as_tensor(data['valid_e'],device=device)
        btrain = Xb[torch.as_tensor(data['btrain'],device=device)]
        etrain = Xe[torch.as_tensor(data['etrain'],device=device)]
        vtrain = valid[torch.as_tensor(data['etrain'],device=device)]
        bcal = Xb[torch.as_tensor(data['bcal'],device=device)]
        ecal = Xe[torch.as_tensor(data['ecal'],device=device)]
        vcal = valid[torch.as_tensor(data['ecal'],device=device)]
        for seed in [5101,5102,5103]:
            torch.manual_seed(seed)
            rng = np.random.default_rng(seed)
            model = SpatialNet(Xb.shape[1]).to(device)
            optimizer = torch.optim.AdamW(model.parameters(),lr=.003,weight_decay=.01)
            best = -float('inf')
            best_state = None
            best_epoch = None
            for epoch in range(201):
                model.train()
                ii = torch.as_tensor(rng.choice(len(btrain),size=min(16384,len(btrain)),replace=False),device=device)
                fe = model(etrain).masked_fill(~vtrain,-torch.inf)
                marginal = torch.logsumexp(fe,dim=1)-torch.log(vtrain.sum(dim=1))
                fb = model(btrain[ii])
                loss = torch.logsumexp(fb,dim=0)-math.log(len(fb))-marginal.mean()
                optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(),5.)
                optimizer.step()
                if epoch%10 == 0:
                    model.eval()
                    value = tensor_eval(model,ecal,bcal,vcal)
                    if value > best:
                        best = value
                        best_epoch = epoch
                        best_state = {k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
            model.load_state_dict(best_state)
            model.eval()
            alphas = [(tensor_eval(model,ecal,bcal,vcal,a),a) for a in [.25,.5,.75,1.,1.25]]
            alpha = max(alphas)[1]
            torch.save({'state_dict':best_state,'n_features':Xb.shape[1],'alpha':alpha,
                        'seed':seed,'epoch':best_epoch,'type':'presence_only_spatial_intensity'},D/f'red_{key}_{seed}.pt')
            with torch.no_grad():
                fb = raw(model,data['Xb'])*alpha
                fe = raw(model,data['Xe'].reshape(-1,Xb.shape[1]))*alpha
            np.savez_compressed(D/f'scores_red_{key}_{seed}.npz',fb=fb,fe=fe.reshape(data['Xe'].shape[:2]))
            audit.append({'key':key,'seed':seed,'device':device,'gpu_name':torch.cuda.get_device_name(0) if device=='cuda' else None,
                'n_features':Xb.shape[1],'epoch_por_calibracion':best_epoch,'alpha':alpha,'log_densidad_cal':max(alphas)[0]})
            print(key,seed,'cal',round(max(alphas)[0],4),'epoch',best_epoch,flush=True)
        del model,Xb,Xe,valid,btrain,etrain,vtrain,bcal,ecal,vcal
        if device == 'cuda':
            torch.cuda.empty_cache()
    (F/'entrenamiento_redes_RTX.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')


if __name__ == '__main__':
    main()
