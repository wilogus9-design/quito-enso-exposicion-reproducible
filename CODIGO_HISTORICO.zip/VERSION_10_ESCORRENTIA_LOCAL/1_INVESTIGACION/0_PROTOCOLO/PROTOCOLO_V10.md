# Calles y escorrentía potencial de Quito

Protocolo 2026-10-09, establecido antes de calcular y evaluar variables V10.

## Objetivo

Incorporar señales físicas extraídas de modelos de elevación satelital y cobertura, junto con vías existentes. Comparar si añaden información a la intensidad relativa de reportes de inundación V05. Las depresiones digitales no son calados de agua ni pasos deprimidos confirmados.

## Insumos

1. DSM Copernicus ya descargado V05, grilla EPSG:32717, 30 m. Incluye edificios y vegetación.
2. FABDEM V1-2, aproximadamente 30 m, edificios y bosques corregidos mediante aprendizaje automático. Obtener el subconjunto de Earth Engine con identificación de activos y hashes; licencia CC BY-NC-SA 4.0 para los derivados FABDEM.
3. WorldCover 2021, construido 10 m, agregado por área a 30 m. Es una clase de suelo construido, no una fracción impermeable medida ni un coeficiente de escorrentía calibrado.
4. Vías principales existentes y vías locales municipales PUGS 2024. Se excluyen las proyectadas. La geometría de esta cartografía no certifica estado ni apertura en cada año histórico.
5. OpenStreetMap: vías etiquetadas como túnel o nivel negativo, obtenidas a la fecha. Son estructuras candidatas, no depresión hidráulica observada ni inventario completo. Se diferencia túnel, paso cubierto y nivel relativo.

## Variables predefinidas

Para cada relieve: depresión digital (elevación rellena menos original), área contribuyente D8 (ha), construido contribuyente (ha) y fracción construida aguas arriba. La malla incluye el rectángulo completo y no corta el cálculo en límites parroquiales. Registrar influencia del borde externo; no interpretar contribuciones incompletas como cuencas cerradas.

De vías: distancia a trazado existente y proximidad a estructuras OSM candidatas (escala fija 100 m). Sin codificar ausencia de estructuras cuando faltan atributos. Sin elevar resolución altimétrica interpolando a 10 m. No rebajar carreteras para fabricar alcantarillas; hidro-enforcement requiere conocer conexiones y cotas.

Candidatos cartográficos para revisión: intersección vial de depresiones digitales >= 0.5 m con área contribuyente >= 1 ha. Umbrales exploratorios geométricos, no ajustados por reportes. El error vertical puede superar estas diferencias; no son umbrales de daño.

## Modelos y comparación

Reutilizar las mismas posiciones inciertas, fondo de cuadratura, particiones temporales y espaciales V05. Mantener exactamente la misma muestra en cada comparación. No usar fondo como negativos físicos.

Especificaciones: base V05 de 20 variables; base + vías; base + vías + hidrología Copernicus; base + vías + hidrología FABDEM. Se conservan modelos loglineales y redes neuronales pequeñas. Para loglineales, lambda en 0.001, 0.01, 0.1, 1 y temperado 0.25, 0.5, 0.75, 1, 1.25 mediante calibración, como V05. Redes de 32/16 neuronas SiLU, tres semillas 5101/5102/5103, 201 epochs, calibración cada 10, AdamW, igual V05. No elegir la especificación ganadora por test.

Evaluar log densidad relativa marginalizada y captura del soporte de localización en el 10 % de territorio, con normalización de fondo idéntica. Inferencia exploratoria por bloques 5 km, no por millones de píxeles. Añadir estrés retirando puntos influidos por el borde, sin reemplazar el resultado completo. Ambos tests se conocían en versiones anteriores: extensión retrospectiva secundaria, no prospectiva ciega.

## Alcance

La red aprende localización de reportes; no se la etiqueta como detector de láminas de agua. Los raster hidráulicos son proxies de conectividad superficial estática. Son insumos nuevos para una futura combinación lluvia–escorrentía–drenaje. No simulan redes subterráneas, capacidad, taponamiento, profundidad, duración ni inundación futura calibrada. La pobreza V09 se cruza después con los territorios, no se emplea como sustituto del relieve.
