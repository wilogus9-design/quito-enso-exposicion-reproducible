# Red residual y manuscrito científico de Quito

Fecha de diseño: 2026-10-09. Se conocen los resultados V10: esta extensión no es una validación prospectiva ciega.

## Objetivo

Continuar el desarrollo neuronal limitando extrapolaciones que perjudicaron la transferencia espacial. Redactar un artículo de susceptibilidad relativa y priorización social con arquitectura, entrenamiento, fuentes y resultados exactos. El hardware no se menciona en el manuscrito, pero el registro técnico de cómputo se conserva para reproducibilidad.

## Referente SAR

Se revisa el PDF local de Misra et al. (2025), DOI 10.1038/s41467-025-60973-1, páginas 1–4 y 7–10. Es MobileNet de fusión temprana con cambios VV/VH en pares Sentinel-1, entrenamiento con máscaras de agua y validación Kuro Siwo. El modelo local de Quito usa covariables y presencias de reportes con incertidumbre posicional. No es el mismo objetivo ni una réplica de esa segmentación SAR; no se comparan F1/IoU con captura de soporte de reportes. Los experimentos SAR existentes en la rama FENOMENO_NINO se conservan separados; no se declaran entrenamiento o validación urbana de Quito.

## Experimento fijado antes de resultados V11

1. Mantener las cuatro variantes V10 y las dos particiones, sin cambiar observaciones, cuadratura, fechas, bloques ni radio posicional.
2. Acotar covariables continuas a cuantiles 0.005 y 0.995 del fondo de entrenamiento de cada partición. No acotar indicadores de cobertura categóricos. Registrar frecuencia de extrapolación, sin eliminar casos desfavorables.
3. Reajustar el loglineal acotado con la grilla de lambda y temperado V10. Mantener como comparadores los loglineales y redes libres previos, además del lineal acotado nuevo.
4. Red residual: f(x)=beta·x+B·tanh(g(x)); beta fijo, capas 16/8 con SiLU, dropout 0.10 y salida inicializada a cero. B en 0.25 y 1.0. Regularización residual: 0.10 por la media del residual al cuadrado en fondo de entrenamiento. AdamW, lr=0.002, weight_decay=0.05, clip de gradiente=5, epochs 0–300, evaluación de calibración cada 10, mismas tres semillas 5101/5102/5103. No acceder al test para parada o selección.
5. Elegir B mediante media de log densidad de calibración de las tres semillas. Conservar los resultados de ambos B. Sin temperado adicional de la red. La corrección cruda está acotada por B; el cociente de densidades normalizadas frente a su ancla está entre exp(-2B) y exp(2B).
6. Publicar log densidad relativa y captura del 10 % del territorio en 100 reportes temporales y 58 espaciales. Diferencias emparejadas, bootstrap 3000 por bloques de 5 km. No elegir la variante por p-valores ni por test.

## Manuscrito

Formato editable Word y QMD, autor proporcionado, nota de afiliación real, resumen <=200 palabras y traducción inglesa, JEL, introducción, datos, modelos, evaluación, resultados, discusión, conclusiones y referencias estructuradas verificadas. Describir el objetivo como localización de reportes e intensidad relativa; distinguirlo de agua observada, profundidad y pronóstico dinámico. Incorporar la priorización NBI V09 como análisis distributivo separado, con advertencia de cantidades censales no reconciliadas. Mantener la lluvia V07 como módulo estacional separado, sin convertir P(lluvia húmeda) en P(inundación de píxel).

No prometer aceptación Q1 ni usar esa etiqueta como resultado científico. La novedad candidata es regularización de la transferencia urbana y priorización multiescala; se reconoce la literatura que ya integra inundación y vulnerabilidad.
