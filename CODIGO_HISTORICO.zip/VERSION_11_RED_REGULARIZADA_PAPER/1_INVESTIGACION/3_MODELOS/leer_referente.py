"""Lectura técnica del referente local SAR y delimitación del modelo de Quito."""
from pathlib import Path
import hashlib
import json
from pypdf import PdfReader

P=Path(__file__).resolve().parents[1];ROOT=P.parents[2]
L=P/'1_LITERATURA';L.mkdir(parents=True,exist_ok=True)
SOURCE=ROOT/'1_INVESTIGACION/PAPERS REFERENCIA/s41467-025-60973-1.pdf'


def main():
    reader=PdfReader(SOURCE)
    pages=[1,2,3,4,7,8,9,10]
    text='\n\n'.join(f'PÁGINA {p}\n'+(reader.pages[p-1].extract_text()or'')for p in pages)
    (L/'lectura_metodologia_SAR.txt').write_text(text,encoding='utf-8')
    (L/'control_referente_SAR.json').write_text(json.dumps({'source':str(SOURCE),
        'sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'pages_read':pages,
        'doi':'10.1038/s41467-025-60973-1','architecture':'MobileNet early fusion change detection',
        'inputs':'four VV/VH binary-change and delta-amplitude features; paired pre/post SAR',
        'prediction_target':'pixel flood/no flood segmentation','operating_resolution_m':20,
        'urban_built_up_and_steep_areas_masked_unreliable':True,
        'not_same_target_as_Quito_presence_only_model':True},ensure_ascii=False,indent=2),encoding='utf-8')
    print('Referente SAR revisado; comparación de objetivos documentada.',flush=True)


if __name__=='__main__':main()
