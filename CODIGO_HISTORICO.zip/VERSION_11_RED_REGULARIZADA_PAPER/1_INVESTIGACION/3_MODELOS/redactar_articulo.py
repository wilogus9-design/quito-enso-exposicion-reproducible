"""Manuscrito científico basado en resultados reales, sin hardware como contribución."""
from pathlib import Path
import json
import re
import shutil
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from scipy.special import logsumexp
import geopandas as gpd

P=Path(__file__).resolve().parents[1];ROOT=P.parents[2]
P5=ROOT/'EXPOSICION_FEN_NINO/VERSION_5_QUITO_10M/1_INVESTIGACION'
P7=ROOT/'EXPOSICION_FEN_NINO/VERSION_7_CALIBRACION_NMME/1_INVESTIGACION'
P8=ROOT/'EXPOSICION_FEN_NINO/VERSION_8_REFERENTE_Q1/1_INVESTIGACION'
P9=ROOT/'EXPOSICION_FEN_NINO/VERSION_9_INTEGRACION_SOCIAL/1_INVESTIGACION'
P10=ROOT/'EXPOSICION_FEN_NINO/VERSION_10_ESCORRENTIA_LOCAL/1_INVESTIGACION'
D=P/'2_DATOS/PROCESADOS';F=P/'6_FINAL';G=F/'GRAFICOS'


def reference_records():
    old=json.loads((P8/'6_FINAL/articulos_metadatos_verificados.json').read_text(encoding='utf-8'))
    chosen={'misra2025','canavire2026','rentschler2022','nearing2024'}
    refs={x['clave']:x['metadatos']for x in old if x['clave']in chosen}
    extra=json.loads((P9/'6_FINAL/referencias_adicionales.json').read_text(encoding='utf-8'))
    refs['fox2024']=extra[0];refs['mester2025']=extra[1]
    refs['hawker2022']=json.loads((P10/'2_DATOS/ORIGINALES/hawker2022_crossref.json').read_text())
    return refs


def initials(name):return ' '.join(x[0]+'.'for x in re.split(r'[\s-]+',name)if x)


def apa(item):
    people=[x['family']+', '+initials(x.get('given',''))+(', '+x['suffix'] if x.get('suffix') else '') for x in item['author']]
    people=', '.join(people[:-1])+', & '+people[-1]if len(people)>1 else people[0]
    year=item.get('published',item['issued'])['date-parts'][0][0]
    journal=item['container-title'][0];volume=item.get('volume','')
    issue='('+item['issue']+')'if item.get('issue') and journal!='Nature Communications'else''
    pages=item.get('page',item.get('article-number',''))
    if pages.isdigit() and len(pages)>=5:pages='Article '+pages
    return f"{people} ({year}). {item['title'][0]}. {journal}, {volume}{issue}, {pages}. https://doi.org/{item['DOI']}"


def main():
    G.mkdir(parents=True,exist_ok=True)
    metrics=pd.read_csv(F/'comparacion_modelos_V11.csv')
    differences=pd.read_csv(F/'diferencias_residual_emparejadas.csv')
    selected=json.loads((D/'seleccion_residual.json').read_text())
    audit=json.loads((F/'entrenamiento_residual.json').read_text())
    plt.rcParams.update({'font.family':'Arial','font.size':8,'svg.fonttype':'none','axes.titlesize':8})
    fig,ax=plt.subplots(figsize=(6.3,2.4));ax.set_xlim(0,10);ax.set_ylim(0,3.7);ax.axis('off')
    def box(x,y,w,h,text):
        ax.add_patch(Rectangle((x,y),w,h,fill=False,linewidth=.7))
        ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=8)
    def arrow(x1,y1,x2,y2):ax.annotate('',xy=(x2,y2),xytext=(x1,y1),arrowprops={'arrowstyle':'->','linewidth':.7})
    box(.05,1.3,1.7,1.3,'Covariables\n20 a 25\nEntrenamiento')
    box(2.05,1.3,1.6,1.3,'Acotamiento\nq 0.005 y 0.995\ncontinuas')
    box(4.0,2.6,2.4,.9,'Ancla loglineal fija')
    box(4.0,.55,2.4,1.35,'Red 16 y 8\nSiLU y dropout 0.10\nB tanh salida')
    box(7.0,1.5,1.1,.8,'Suma f(x)')
    box(8.6,1.1,1.3,1.6,'Normalizador\nde área\nIntensidad\nrelativa')
    arrow(1.75,1.95,2.05,1.95);arrow(3.65,2.15,4,3.05);arrow(3.65,1.7,4,1.25)
    arrow(6.4,3.05,7,2.2);arrow(6.4,1.25,7,1.6);arrow(8.1,1.9,8.6,1.9)
    ax.text(.05,.12,'La salida describe localización de reportes. No es probabilidad física de inundación.',fontsize=8)
    fig.tight_layout();fig.savefig(G/'figura_1_arquitectura.svg');fig.savefig(G/'figura_1_arquitectura.png',dpi=300);plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(6.3,3.2))
    labels=['Base','Vías','Vías y DSM','Vías y FABDEM']
    variants=['base','vias','vias_copernicus','vias_fabdem']
    for ax,protocol in zip(axes,['temporal','espacial']):
        h=differences[(differences.protocolo==protocol)&(differences.comparador=='ancla_acotada')].set_index('variante').loc[variants]
        delta=h.delta_log_densidad_residual.to_numpy();lo=h.rango95_inf.to_numpy();hi=h.rango95_sup.to_numpy()
        ax.errorbar(delta,np.arange(4),xerr=np.stack([delta-lo,hi-delta]),fmt='o',color='#205375',capsize=2)
        ax.axvline(0,color='#666666',linewidth=.7);ax.set_yticks(np.arange(4),labels=labels);ax.invert_yaxis()
        ax.set_title(protocol.capitalize(),loc='left');ax.set_xlabel('Diferencia de log densidad')
        ax.spines[['top','right']].set_visible(False)
    fig.tight_layout();fig.savefig(G/'figura_2_aporte_residual.svg');fig.savefig(G/'figura_2_aporte_residual.png',dpi=300);plt.close(fig)
    # Geographic preview uses exactly the 60000 background locations; it is not
    # interpolation of them into a fictitious fine-resolution flood raster.
    with np.load(D/'entrada_temporal__vias_fabdem.npz')as z:bmask=z['btest']
    with np.load(P5/'2_DATOS/PROCESADOS/muestras_inciertas.npz')as z:bx,by=z['bg_x'],z['bg_y']
    bound=selected['temporal__vias_fabdem']['bound_selected_by_calibration'];label=str(bound).replace('.','p')
    scores=[]
    for seed in [5101,5102,5103]:
        with np.load(D/f'scores_temporal__vias_fabdem_B{label}_{seed}.npz')as z:score=z['fb']
        scores.append(score-logsumexp(score)+np.log(len(score)))
    spatial=logsumexp(np.stack(scores),axis=0)-np.log(3)
    rank=pd.Series(spatial).rank(pct=True).to_numpy()*100
    par=gpd.read_file(P9/'2_DATOS/PROCESADOS/geometria_censal.geojson').to_crs(32717)
    socio=pd.read_csv(P9/'6_FINAL/territorio_vulnerabilidad_parroquias.csv',dtype={'parroquia':str})
    par=par.merge(socio[['parroquia','pc_pnbi']],on='parroquia',validate='one_to_one')
    par.geometry=par.geometry.simplify(20,preserve_topology=True)
    fig,axes=plt.subplots(1,2,figsize=(6.3,4.5))
    s=axes[0].scatter(bx,by,c=rank,s=.22,cmap='viridis',rasterized=True,vmin=0,vmax=100)
    par.boundary.plot(ax=axes[0],linewidth=.2,color='#777777');axes[0].set_aspect('equal');axes[0].set_axis_off()
    axes[0].set_title('Ranking neuronal en puntos\nde cuadratura',loc='left')
    fig.colorbar(s,ax=axes[0],shrink=.6,label='Percentil relativo')
    par.plot(column='pc_pnbi',ax=axes[1],cmap='YlOrRd',legend=True,legend_kwds={'label':'NBI municipal (%)','shrink':.6},edgecolor='#777777',linewidth=.2)
    axes[1].set_title('Contexto social parroquial\nCenso 2022',loc='left');axes[1].set_axis_off()
    fig.subplots_adjust(left=.01,right=.98,top=.87,bottom=.04,wspace=.25)
    fig.savefig(G/'figura_3_susceptibilidad_y_NBI.svg');fig.savefig(G/'figura_3_susceptibilidad_y_NBI.png',dpi=300);plt.close(fig)
    refs=reference_records();biblio=[];bib=''
    for key,item in refs.items():
        biblio.append(apa(item));year=item.get('published',item['issued'])['date-parts'][0][0]
        authors=' and '.join(x['family']+', '+x.get('given','')for x in item['author'])
        bib+='@article{'+key+',\n title={'+item['title'][0]+'},\n author={'+authors+'},\n journal={'+item['container-title'][0]+'},\n year={'+str(year)+'},\n volume={'+item.get('volume','')+'},\n doi={'+item['DOI']+'}\n}\n'
    (F/'referencias_paper.bib').write_text(bib,encoding='utf-8')
    biblio.sort(key=str.casefold)
    values=metrics.set_index(['protocolo','variante','modelo'])
    def val(protocol,variant,model,metric='log_densidad_relativa'):return float(values.loc[(protocol,variant,model),metric])
    t=val('temporal','vias','residual_cal');s=val('espacial','vias','residual_cal')
    summary=('La preparación urbana frente a inundaciones requiere identificar territorios susceptibles y distinguir las necesidades sociales de la población. '
        'Este estudio desarrolla una red neuronal residual acotada para localizar reportes de inundación en Quito e integra señales satelitales, vías y contexto parroquial. '
        'Se utilizan 20 a 25 covariables y una arquitectura de dos capas ocultas de 16 y 8 neuronas, apoyada en un modelo loglineal fijo. '
        'La calibración selecciona parada temprana y amplitud residual; la evaluación mantiene 100 reportes temporales y 58 espaciales con posiciones inciertas. '
        f'Con vías, la log densidad relativa alcanza {t:.3f} y {s:.3f}, respectivamente. '
        'La red residual mejora las puntuaciones frente a la red libre en las cuatro variantes, pero no presenta superioridad uniforme frente a sus anclas loglineales. '
        'El análisis territorial añade depresiones digitales, escorrentía potencial y pobreza por necesidades básicas insatisfechas en 65 parroquias. '
        'La contribución es una estrategia reproducible para controlar extrapolación y examinar prioridades distributivas conservando los soportes espaciales. Los resultados describen susceptibilidad relativa de reportes y preparación condicionada, no profundidad ni extensión futura de agua.')
    abstract=('Urban flood preparedness requires identifying susceptible territories and distinguishing the population’s social needs. '
        'This study develops a bounded residual neural network to locate flood reports in Quito and integrates satellite signals, roads, and parish context. '
        'It uses 20 to 25 covariates and an architecture with two hidden layers of 16 and 8 neurons, supported by a fixed log-linear model. '
        'Calibration selects early stopping and residual amplitude; evaluation retains 100 temporal and 58 spatial reports with uncertain locations. '
        f'With roads, relative log density reaches {t:.3f} and {s:.3f}, respectively. '
        'The residual network improves scores relative to the unconstrained network across the four variants, but does not show uniform superiority over its log-linear anchors. '
        'Territorial analysis adds digital depressions, potential runoff, and poverty measured by unsatisfied basic needs in 65 parishes. '
        'The contribution is a reproducible strategy to control extrapolation and examine distributional priorities while preserving spatial supports. Results describe relative reporting susceptibility and conditional preparedness, not future water depth or extent.')
    assert len(summary.split())<=200 and len(abstract.split())<=200
    blocks=[]
    def heading(text):blocks.append({'type':'heading','text':text})
    def paragraph(text):blocks.append({'type':'paragraph','text':text})
    def equation(name,latex):blocks.append({'type':'equation','name':name,'latex':latex})
    def table(title,headers,rows,note,widths):blocks.append({'type':'table','title':title,'headers':headers,'rows':rows,'note':note,'widths':widths})
    def figure(title,file,note,width=6.3):blocks.append({'type':'figure','title':title,'file':file,'note':note,'width':width})
    heading('Resumen');paragraph(summary);heading('Abstract');paragraph(abstract)
    heading('1 Introducción')
    paragraph('Las inundaciones urbanas combinan concentración de escorrentía, impermeabilización, capacidad de captación y exposición de hogares e infraestructura. Una clasificación del terreno susceptible puede apoyar la preparación, pero su utilidad depende de la información observada y de su desempeño al trasladarse a otras zonas. Quito ofrece un caso exigente por la heterogeneidad topográfica y la coexistencia de tejidos urbanos densos, valles y parroquias rurales.')
    paragraph('La literatura satelital permite medir agua observada y construir antecedentes de exposición. Misra et al. (2025) utilizan MobileNet con pares Sentinel-1 para detectar cambios asociados a inundación; su producto señala limitaciones en superficies urbanas y terreno escarpado. El presente estudio aborda otro objetivo: intensidad relativa de reportes geocodificados, con covariables derivadas del relieve y cobertura. La segmentación SAR y la localización de reportes tienen etiquetas y métricas diferentes y no se comparan como tareas equivalentes.')
    paragraph('La relación entre precipitación y bienestar ha sido estudiada en Ecuador por Canavire-Bacarreza et al. (2026). La incorporación social a mapas de exposición también tiene antecedentes globales en Rentschler et al. (2022), Fox et al. (2024) y Mester et al. (2025). Por tanto, combinar satélites y pobreza no constituye por sí solo la novedad. Nuestra pregunta es si una corrección neuronal acotada estabiliza la transferencia espacial y cómo se distinguen prioridades por exposición y por privación cuando se conservan las escalas reales de los datos.')
    paragraph('Se evalúa una red residual apoyada en un modelo loglineal, frente a una red libre y a dos referencias lineales. La separación entre transferencia predictiva y objetivo distributivo permite examinar qué añade el componente no lineal y evita interpretar una preferencia de priorización social como una mejora física del pronóstico.')
    heading('2 Área de estudio y datos')
    paragraph('Se analiza el Distrito Metropolitano de Quito con geometría municipal y una malla de referencia EPSG:32717. Los reportes del Servicio Nacional de Gestión de Riesgos corresponden a 2010–septiembre de 2025, con coordenadas válidas dentro del cantón, fechas compatibles y eliminación de duplicados por fecha, tipo de evento y posición. El conjunto de inundación contiene 331 presencias. No se interpreta falta de reporte como ausencia física del evento.')
    table('Tabla 1. Fuentes y soportes espaciales',['Fuente','Referencia temporal','Soporte','Función'],[
        ['Reportes SNGR','2010–septiembre 2025','Puntos geocodificados','Localización de eventos reportados'],
        ['ESA WorldCover','2021','10 m','Cobertura y construido'],
        ['Copernicus DEM','Observaciones principalmente 2011–2015','Aproximadamente 30 m','Relieve de superficie'],
        ['FABDEM V1-2','Derivado de Copernicus DEM','Aproximadamente 30 m','Relieve corregido por edificios y vegetación'],
        ['Vialidad municipal','PUGS 2024','Trazados vectoriales','Distancia a vías existentes'],
        ['Capa social municipal','Censo 2022','65 parroquias','NBI, agua, saneamiento y hacinamiento']],
        'Fuente: SNGR, ESA, Copernicus, FABDEM y Municipio de Quito. Elaboración propia. Las versiones cartográficas no certifican disponibilidad ni estado en cada emisión histórica.',[1.25,1.35,1.45,2.25])
    paragraph('WorldCover proporciona cobertura a 10 m, mientras el soporte altimétrico permanece en aproximadamente 30 m. FABDEM reduce alturas de edificios y vegetación mediante aprendizaje automático (Hawker et al., 2022). Ni la reproyección ni la combinación con cobertura fina convierten el relieve en un levantamiento altimétrico de 10 m. La información vial corresponde a 3464 registros de vías principales existentes y 60127 de vías locales; se excluyen las proyectadas. Estos registros no son calles únicas ni un inventario de capacidad hidráulica.')
    paragraph('Las 20 covariables iniciales representan altitud, pendiente, posición topográfica, relieve local, distancias a ríos, quebradas y colectores, densidad construida y categorías de cobertura. La variante vial añade distancia al trazado. Las variantes de conectividad agregan depresión digital, área contribuyente, construido aguas arriba y su fracción para cada fuente de elevación, alcanzando 25 entradas. No se incluyó la capa complementaria de túneles de OpenStreetMap, que no se pudo recuperar; su información faltante no se convirtió en ausencia de estructuras.')
    heading('3 Extracción geoespacial y soporte de observación')
    paragraph('La conectividad se calcula sobre un rectángulo de 9557121 celdas de 30 m, sin cortar el flujo en límites parroquiales. El algoritmo priority-flood identifica la elevación mínima de salida y se utiliza para conectar el relieve mediante D8. La diferencia entre elevación rellenada y original se conserva como depresión digital. Se acumulan área y construido y se verifica conservación en las salidas del dominio. Una franja exterior de 300 m advierte posible truncamiento de cuencas contribuyentes. Estas operaciones describen conectividad superficial estática, no caudal, profundidad, obstrucción o conducción subterránea.')
    paragraph('Se identifican 388 componentes digitales para revisión entre Copernicus y FABDEM, sin deduplicarlos como estructuras observadas. Las reglas geométricas requieren relleno de al menos 0.5 m, contribución de al menos 1 ha, intersección vial y dos celdas conectadas. El error vertical puede superar el umbral y los pasos pequeños pueden no resolverse. La utilidad de estos componentes es organizar verificación local; no funcionan como etiquetas de inundación o daño para entrenar la red.')
    paragraph('Cada reporte se representa mediante 25 posiciones posibles dentro de un radio supuesto de 100 m, incluyendo su centro publicado. La intensidad se marginaliza sobre posiciones válidas; estas posiciones no son 25 eventos independientes. El radio representa un supuesto de localización, no una precisión instrumental verificada. Se generan 60000 puntos de cuadratura uniforme para aproximar el normalizador de área, sin etiquetarlos como sitios no inundados.')
    heading('4 Modelo neuronal residual')
    paragraph('La red estima un log score espacial f(x), que se normaliza sobre el dominio de cuadratura para producir intensidad relativa. Se combina una ancla loglineal fija con una corrección neuronal de amplitud limitada. Las covariables continuas se acotan a los cuantiles 0.005 y 0.995 del fondo de entrenamiento de cada partición; los indicadores de cobertura categóricos se conservan. Se registra la frecuencia de valores fuera del soporte sin retirar los casos de evaluación.')
    equation('residual',r'f_\theta(x)=f_{lin}(C(x))+B\tanh(g_\phi(C(x)))')
    paragraph('C(x) denota el acotamiento por soporte de entrenamiento. El componente lineal utiliza coeficientes estimados y después fijados. El componente neuronal tiene dos capas ocultas de 16 y 8 neuronas, activación SiLU, dropout 0.10 y salida escalar. La salida final se inicializa a cero, de modo que el punto de partida coincide con el ancla. Para 25 entradas hay 561 parámetros neuronales ajustables; los 25 coeficientes del ancla no se actualizan durante ese entrenamiento. La corrección utiliza tanh y B pertenece a 0.25 o 1.0.')
    equation('density',r'\rho_\theta(x)=\exp(f_\theta(x))/\operatorname{mean}_b\exp(f_\theta(X_b))')
    paragraph('La densidad relativa tiene media de cuadratura igual a uno. No es una probabilidad de inundación por píxel ni predice la frecuencia total de eventos. Dado el límite residual, el cociente de densidades normalizadas respecto a su ancla está entre exp(-2B) y exp(2B), lo que controla correcciones extremas. Esa propiedad matemática no sustituye la evaluación externa.')
    figure('Figura 1. Arquitectura de la red residual','figura_1_arquitectura.png','Fuente: especificación y código del estudio. Elaboración propia.')
    heading('5 Entrenamiento y evaluación')
    paragraph('El ancla se ajusta con penalización L2 en 0.001, 0.01, 0.1 y 1.0, y temperado en 0.25, 0.5, 0.75, 1.0 y 1.25, seleccionados por calibración. La red optimiza la diferencia entre log normalizador de fondo y log intensidad marginalizada de los reportes, más 0.10 por la media del residual al cuadrado en el fondo de entrenamiento. Se emplea AdamW con tasa 0.002, weight decay 0.05, limitación de norma de gradiente a 5 y un máximo de 301 épocas. Se muestrean hasta 16384 puntos de fondo por época; todos los reportes de entrenamiento conservan su soporte marginalizado.')
    paragraph('La calibración se evalúa cada 10 épocas para parada temprana. Se utilizan tres semillas fijas por configuración y se elige B según la media de log densidad de calibración de las tres redes. No se accede a etiquetas de test durante selección o parada. Se entrenan 48 redes, correspondientes a cuatro grupos de covariables, dos particiones, dos amplitudes y tres semillas. Se conservan ambas amplitudes y todos los resultados de variantes, sin selección por p-valores.')
    table('Tabla 2. Particiones de evaluación',['Protocolo','Entrenamiento','Calibración','Evaluación','Separación'],[
        ['Temporal','143 reportes','88 reportes','100 reportes','2010–2021 / 2022–2023 / 2024–septiembre 2025'],
        ['Espacial','85 reportes','48 reportes','58 reportes','Bloques 5 km; separación de borde 250 m; registros hasta 2023']],
        'Fuente: particiones congeladas de reportes. Elaboración propia. La extensión se diseñó después de observar resultados de modelos anteriores: es retrospectiva, no prospectiva ciega.',[.85,1.05,.9,.9,2.6])
    paragraph('Se evalúa la log densidad relativa media y la captura del soporte posicional dentro del 10 % del territorio. Para cada contraste se mantiene exactamente el mismo conjunto de presencias, posiciones y cuadratura. Los rangos de diferencias provienen de 3000 remuestreos emparejados de bloques de 5 km, con 36 bloques temporales y 13 espaciales. Son rangos exploratorios y no resuelven completamente la dependencia de reportes de un mismo episodio. No se usan millones de píxeles como réplicas independientes.')
    heading('6 Resultados predictivos')
    paragraph(f'Con información vial, la red residual alcanza log densidad {t:.3f} en la evaluación temporal y {s:.3f} en la espacial. La red libre alcanza {val("temporal","vias","red_libre"):.3f} y {val("espacial","vias","red_libre"):.3f}, respectivamente. La mejora frente a la red libre se observa en las cuatro variantes y ambos protocolos, pero esa comparación debe distinguirse del aporte incremental respecto a la referencia lineal.')
    for number,protocol in [(3,'temporal'),(4,'espacial')]:
        rows=[]
        names={'base':'Base','vias':'Vías','vias_copernicus':'Vías y DSM','vias_fabdem':'Vías y FABDEM'}
        method={'loglineal':'Loglineal','red_libre':'Red libre','ancla_acotada':'Ancla acotada','residual_cal':'Red residual'}
        for variant in variants:
            for model in ['loglineal','red_libre','ancla_acotada','residual_cal']:
                rows.append([names[variant],method[model],f'{val(protocol,variant,model):.3f}',f'{100*val(protocol,variant,model,"captura_top10pct_soporte"):.2f}'])
        table(f'Tabla {number}. Evaluación {protocol} en la misma muestra',['Covariables','Modelo','Log densidad','Captura (%)'],rows,
            'Fuente: evaluación emparejada del estudio. Elaboración propia. Mayor log densidad es mejor. Captura describe soporte de reportes en el 10 % del territorio, no exactitud de agua.',[1.5,1.5,1.25,2.05])
    paragraph('La regularización limita las pérdidas observadas al transferir la red libre. No obstante, las correcciones sobre el ancla acotada tienen efectos heterogéneos: las variantes base y vial mejoran puntualmente en la prueba espacial, mientras las variantes de conectividad pueden empeorar. En el protocolo temporal, la calibración selecciona con frecuencia puntos de parada iniciales, conservando una corrección pequeña cuando la complejidad adicional no aporta evidencia suficiente.')
    figure('Figura 2. Aporte neuronal sobre el ancla acotada','figura_2_aporte_residual.png','Fuente: bootstrap emparejado por bloques de 5 km. Elaboración propia. Rangos exploratorios de diferencias de log densidad.')
    paragraph('La diferencia entre regularización estabilizadora y ganancia informativa es central. Recuperar el desempeño de una red que extrapola mal no implica superar al modelo loglineal, ni atribuir la mejora a una sola intervención cuando se combinan acotamiento de covariables y arquitectura residual. Las referencias acotada y no acotada permiten separar parcialmente esos componentes; una ablación más extensa y episodios nuevos fortalecerían la comparación.')
    heading('7 Susceptibilidad y prioridades sociales')
    paragraph('Los scores se examinan junto con indicadores parroquiales de necesidades básicas insatisfechas, acceso a agua, saneamiento y hacinamiento. NBI es una medida de privación distinta de pobreza monetaria ENEMDU. Las tasas publicadas coinciden con sus propios numeradores y denominadores, pero sus cantidades agregadas difieren de los controles cantonales del lago de datos: 119116 personas en el universo NBI y 23375 personas NBI adicionales. Por ello, el análisis distributivo usa proporciones y no presenta conteos oficiales de futuros afectados.')
    figure('Figura 3. Ranking neuronal y contexto social de Quito','figura_3_susceptibilidad_y_NBI.png','Fuente: modelo residual con vías y FABDEM en 60000 puntos de cuadratura; capa municipal Censo 2022. Elaboración propia. Los puntos no se interpolan como una observación fina de agua; los indicadores sociales mantienen soporte parroquial.')
    paragraph('Como análisis de preparación separado, se conserva la regla de prioridad que combina área construida de mayor intensidad espacial, probabilidad regional de estación húmeda y proporción NBI. La comparación distribuye hasta 13 prioridades entre 65 parroquias. En la combinación inicial de redes, incorporar NBI modifica tres seleccionadas por área; Guamaní, Turubamba, La Ecuatoriana y Quitumbe permanecen priorizadas en seis combinaciones. Esa regla se mantuvo fija del análisis anterior y no se reoptimizó con los resultados residuales. El acuerdo entre modelos no es probabilidad de daño.')
    paragraph('El pronóstico estacional para noviembre 2026–enero 2027 es un componente meteorológico separado, con soporte nativo de 0.05 grados y calibración temporal. Considerar ENSO puede informar escenarios de preparación, pero convertir probabilidad de lluvia húmeda en inundación urbana requiere lluvia de corta duración, captación, conectividad y capacidad del drenaje. La red espacial aquí evaluada no realiza esa conversión. La existencia de modelos hidrológicos predictivos en cuencas no aforadas tampoco garantiza precisión de agua urbana por píxel (Nearing et al., 2024).')
    heading('8 Discusión')
    paragraph('El estudio aporta un experimento local reproducible de transferencia espacial, con ancla interpretable y corrección neuronal acotada, y una lectura distributiva que conserva los soportes de exposición y privación. La evidencia favorece estabilizar modelos frente a aumentar complejidad sin restricciones. Las ganancias frente a referencias lineales son pequeñas o heterogéneas, y no se presenta una arquitectura vencedora universal.')
    paragraph('La información satelital ayuda a caracterizar cobertura y relieve, mientras los reportes aportan localizaciones históricas. Persisten sesgos por visibilidad, acceso institucional y calidad de geocodificación. Un dominio con pocos reportes puede estar poco observado, no protegido. La cartografía vial de 2024 y la disponibilidad censal no están certificadas a cada fecha histórica; el contraste temporal es una evaluación retrospectiva de localización, no una reconstrucción de pronósticos emitidos en tiempo real.')
    paragraph('La validación física de inundación debe emplear referencias pre/durante/post independientes y distinguir agua habitual, exclusiones y no observación. Los corredores D8 son proxies superficiales; no representan captación por sumideros, conducción en tuberías ni taponamiento. Los componentes digitales de depresión requieren verificación de estructura y elevación. La segmentación SAR constituye una línea complementaria y no se incorpora como evidencia urbana validada de Quito en este manuscrito.')
    paragraph('La relación entre amenazas y bienestar exige además observar pérdidas, interrupciones o cambios económicos con diseños adecuados. Ni los índices NBI ni la intensidad de reportes son funciones monetarias de daño. El artículo se concentra en susceptibilidad y prioridades de preparación; la estimación económica puede añadirse cuando estén comprobados exposición y resultados de hogares. Las mediciones y escenarios mantienen incertidumbre climática y de fuentes sin interpretar ENSO como cambio climático antropogénico.')
    heading('9 Conclusiones')
    paragraph('La red residual acotada mejora las puntuaciones frente a la red libre en las cuatro variantes y en ambos contrastes, reduciendo problemas de transferencia espacial. Su superioridad sobre referencias loglineales no es uniforme. El resultado respalda una estrategia de complejidad controlada con comparadores interpretables y selección por calibración, preservando pruebas desfavorables.')
    paragraph('La integración de vías, relieve y construido genera insumos concretos de conectividad y componentes para verificación local. El cruce social identifica objetivos distributivos que no se confunden con precisión física. La siguiente evaluación debe mantener reglas congeladas ante nuevos episodios, verificar agua y drenaje de manera independiente y reconciliar las cantidades censales antes de publicar cifras de población expuesta. La utilidad final debe medirse para decisiones reales de preparación, no deducirse de la resolución del archivo o del tamaño de la red.')
    heading('Disponibilidad de datos y código')
    paragraph('Las fuentes geoespaciales e institucionales utilizadas son públicas. Se adjuntan código, particiones, parámetros, bibliografía y resultados agregados para reproducir los experimentos. No se afirma la existencia de un depósito público nuevo. Los derivados FABDEM conservan las condiciones CC BY-NC-SA 4.0 y la atribución de Copernicus; las otras fuentes mantienen sus términos originales. Los registros técnicos de ejecución se conservan separados del texto del artículo.')
    heading('Referencias')
    institutional=[
        'Copernicus. (s. f.). Copernicus DEM Global and European Digital Elevation Model. https://dataspace.copernicus.eu/explore-data/data-collections/copernicus-contributing-missions/collections-description/COP-DEM',
        'Municipio del Distrito Metropolitano de Quito. (2024). Cartografía del Plan de uso y gestión del suelo. https://geoquito.quito.gob.ec/server/rest/services/web_reference_dmot/plan_de_uso_y_gestion_del_suelo_2024/MapServer',
        'Municipio del Distrito Metropolitano de Quito. (s. f.). Personas pobres por NBI Parroquias Censo 2022. https://geoquito.quito.gob.ec/server/rest/services/web_service/s_nbi_porcentaje_personas_con_pobreza_por_nbi_2022/MapServer/2']
    for ref in sorted([*biblio,*institutional],key=str.casefold):blocks.append({'type':'reference','text':ref})
    content={'title':'Red neuronal regularizada y prioridades sociales ante inundaciones en Quito',
        'author':'Wilson Gustavo Morales Lastra','footnote':'Investigador independiente. Correo: wilson.morales@epn.edu.ec. ORCID: https://orcid.org/0009-0008-3413-3705.',
        'JEL':'C45; C53; Q54; R14','blocks':blocks}
    (D/'contenido_paper.json').write_text(json.dumps(content,ensure_ascii=False,indent=2),encoding='utf-8')
    # QMD is editable supplementary source; DOCX builder converts equations natively.
    lines=['---',f'title: "{content["title"]}"','lang: es','format: docx','---','',content['author']+'[^autor]','',
        '[^autor]: '+content['footnote'],'','Códigos JEL: '+content['JEL'],'']
    for block in blocks:
        kind=block['type']
        if kind=='heading':lines+=['## '+block['text'],'']
        elif kind in ['paragraph','reference']:lines+=[block['text'],'']
        elif kind=='equation':lines+=['$$'+block['latex']+'$$','']
        elif kind=='figure':lines+=[block['title'],'',f'![](GRAFICOS/{block["file"]})','',block['note'],'']
        elif kind=='table':
            lines+=[block['title'],'','| '+' | '.join(block['headers'])+' |','| '+' | '.join(['---']*len(block['headers']))+' |']
            lines+=['| '+' | '.join(map(str,row))+' |'for row in block['rows']];lines+=['',block['note'],'']
    text='\n'.join(lines)
    if re.search(r'RTX|5070|\bGPU\b|\bCPU\b',text):raise ValueError('El manuscrito contiene referencias al hardware')
    (F/'MANUSCRITO_QUITO_V11.qmd').write_text(text,encoding='utf-8')
    (F/'control_redaccion.json').write_text(json.dumps({'words_summary':len(summary.split()),'words_abstract':len(abstract.split()),
        'words_manuscript_approx':len(text.split()),'no_hardware_in_manuscript':True,
        'neural_target_presence_intensity_not_SAR_segmentation':True,'figures':3,'native_tables_planned':4},indent=2),encoding='utf-8')
    print('Manuscrito y tres figuras preparados; hardware excluido del texto.',flush=True)


if __name__=='__main__':main()
