"""Word científico editable: tablas nativas, ecuaciones OMML y afiliación real."""
from pathlib import Path
import json
import importlib.util
import sys
import zipfile
import re
from lxml import etree
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_ALIGN_VERTICAL
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

P=Path(__file__).resolve().parents[1];ROOT=P.parents[2];D=P/'2_DATOS/PROCESADOS';F=P/'6_FINAL'
SKILL=Path('<USUARIO_LOCAL>/.codex/plugins/cache/openai-primary-runtime/documents/26.1007.11041/skills/documents')


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);obj=importlib.util.module_from_spec(spec)
    sys.modules[name]=obj;spec.loader.exec_module(obj);return obj


math=module('v11_math',ROOT/'EXPOSICION_FEN_NINO/VERSION_5_QUITO_10M/1_INVESTIGACION/3_MODELOS/componentes_word.py')


def equation(doc,name):
    if name=='residual':
        math.math_paragraph(doc,[('f','θ'),'(x) = ',('f','lin'),'(C(x)) + B tanh(',('g','φ'),'(C(x)))'])
    elif name=='density':
        p=doc.add_paragraph();om=OxmlElement('m:oMathPara');eq=OxmlElement('m:oMath')
        eq.append(math.sub('ρ','θ'));eq.append(math.run_math('(x) = '))
        frac=OxmlElement('m:f');num=OxmlElement('m:num');den=OxmlElement('m:den')
        for node in [math.run_math('exp('),math.sub('f','θ'),math.run_math('(x))')]:num.append(node)
        for node in [math.sub('mean','b'),math.run_math(' exp('),math.sub('f','θ'),math.run_math('('),math.sub('X','b'),math.run_math('))')]:den.append(node)
        frac.extend([num,den]);eq.append(frac);om.append(eq);p._p.append(om)
    else:raise ValueError('Ecuación no implementada '+name)


def native_table(doc,block):
    p=doc.add_paragraph(block['title']);p.paragraph_format.keep_with_next=True
    for r in p.runs:r.font.size=Pt(10)
    table=doc.add_table(rows=1,cols=len(block['headers']));table.autofit=False;table.alignment=WD_TABLE_ALIGNMENT.CENTER
    border=OxmlElement('w:tblBorders')
    for edge in ['top','left','bottom','right','insideH','insideV']:
        x=OxmlElement('w:'+edge);x.set(qn('w:val'),'single');x.set(qn('w:sz'),'4');x.set(qn('w:color'),'D9D9D9');border.append(x)
    table._tbl.tblPr.append(border)
    for i,col in enumerate(table.columns):col.width=Inches(block['widths'][i])
    for ri,values in enumerate([block['headers'],*block['rows']]):
        row=table.rows[0]if ri==0 else table.add_row();pr=row._tr.get_or_add_trPr();pr.append(OxmlElement('w:cantSplit'))
        if ri==0:pr.append(OxmlElement('w:tblHeader'))
        for i,(cell,value)in enumerate(zip(row.cells,values)):
            cell.width=Inches(block['widths'][i]);cell.text=str(value);cell.vertical_alignment=WD_ALIGN_VERTICAL.CENTER
            pad=OxmlElement('w:tcMar')
            for edge in ['top','bottom','left','right']:
                e=OxmlElement('w:'+edge);e.set(qn('w:w'),'60' if len(block['rows'])>10 else '85');e.set(qn('w:type'),'dxa');pad.append(e)
            cell._tc.get_or_add_tcPr().append(pad)
            if ri==0:
                shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'E9EEF4');cell._tc.get_or_add_tcPr().append(shade)
            for paragraph in cell.paragraphs:
                paragraph.paragraph_format.space_after=Pt(1);paragraph.paragraph_format.line_spacing=1.05
                # Keep small tables together, and the last row with its source.
                paragraph.paragraph_format.keep_with_next=(len(block['rows'])<=4 or ri==len(block['rows']))
                paragraph.alignment=WD_ALIGN_PARAGRAPH.LEFT if i<2 else WD_ALIGN_PARAGRAPH.CENTER
                for run in paragraph.runs:run.font.name='Arial';run.font.size=Pt(9);run.font.bold=ri==0
    source=doc.add_paragraph(block['note']);source.paragraph_format.space_before=Pt(5)
    for r in source.runs:r.font.size=Pt(9)


def main():
    content=json.loads((D/'contenido_paper.json').read_text(encoding='utf-8'))
    doc=Document();section=doc.sections[0];section.page_width=Inches(8.5);section.page_height=Inches(11)
    section.left_margin=section.right_margin=Inches(1);section.top_margin=section.bottom_margin=Inches(.8)
    for name,size in [('Normal',11),('Title',16),('Heading 1',12),('Heading 2',11)]:
        style=doc.styles[name];style.font.name='Arial';style.font.size=Pt(size);style.font.color.rgb=RGBColor(0,0,0)
        style.paragraph_format.line_spacing=1.08;style.paragraph_format.space_after=Pt(6)
        style.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY if name=='Normal'else WD_ALIGN_PARAGRAPH.LEFT
    doc.add_paragraph(content['title'],style='Title')
    p=doc.add_paragraph(content['author']+'[[FN]]');p.alignment=WD_ALIGN_PARAGRAPH.LEFT
    doc.add_paragraph('Códigos JEL: '+content['JEL']).alignment=WD_ALIGN_PARAGRAPH.LEFT
    for b in content['blocks']:
        kind=b['type']
        if kind=='heading':doc.add_heading(b['text'],level=1)
        elif kind=='paragraph':doc.add_paragraph(b['text'])
        elif kind=='equation':equation(doc,b['name'])
        elif kind=='table':native_table(doc,b)
        elif kind=='figure':
            cap=doc.add_paragraph(b['title']);cap.paragraph_format.keep_with_next=True
            for r in cap.runs:r.font.size=Pt(10)
            p=doc.add_paragraph();p.paragraph_format.keep_with_next=True
            p.add_run().add_picture(str(F/'GRAFICOS'/b['file']),width=Inches(b['width']))
            pr=p._p.find('.//'+qn('wp:docPr'))
            if pr is not None:pr.set('descr',b['title']+'. '+b['note'])
            p=doc.add_paragraph(b['note'])
            for r in p.runs:r.font.size=Pt(9)
        elif kind=='reference':
            p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.LEFT
            found=False
            for journal in ['Nature Communications','Environmental Research Letters','World Development','Nature']:
                match=re.search(re.escape(journal)+r', (\d+)',b['text'])
                if match:
                    p.add_run(b['text'][:match.start()]);p.add_run(match[0]).italic=True;p.add_run(b['text'][match.end():]);found=True;break
            if not found:p.add_run(b['text'])
            p.paragraph_format.left_indent=Inches(.25);p.paragraph_format.first_line_indent=Inches(-.25)
            for r in p.runs:r.font.size=Pt(10)
    p=section.footer.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');p._p.append(fld)
    fmt=OxmlElement('w:footnotePr');num=OxmlElement('w:numFmt');num.set(qn('w:val'),'chicago');fmt.append(num);section._sectPr.append(fmt)
    doc.core_properties.author=content['author'];doc.core_properties.title=content['title']
    base=D/'paper_base.docx';doc.save(base)
    output=F/'MANUSCRITO_QUITO_V11.docx'
    notes=module('v11_notes',SKILL/'scripts/insert_note.py')
    notes.insert_note(str(base),str(output),'footnote','[[FN]]',' '+content['footnote'])
    with zipfile.ZipFile(output)as z:parts={i.filename:z.read(i.filename)for i in z.infolist()}
    root=etree.fromstring(parts['word/document.xml']);W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
    for ref in root.findall('.//{'+W+'}footnoteReference'):
        pr=etree.Element('{'+W+'}rPr');sup=etree.SubElement(pr,'{'+W+'}vertAlign');sup.set('{'+W+'}val','superscript');ref.getparent().insert(0,pr)
    sanitizer=module('v11_sanitize',SKILL/'scripts/google_docs_title_sanitize.py')
    styles=etree.fromstring(parts['word/styles.xml']);sanitizer.sanitize_styles(styles);sanitizer.sanitize_document_part(root,leading_nonempty_paragraphs=6)
    parts['word/styles.xml']=etree.tostring(styles,xml_declaration=True,encoding='UTF-8',standalone=True)
    parts['word/document.xml']=etree.tostring(root,xml_declaration=True,encoding='UTF-8',standalone=True)
    note_root=etree.fromstring(parts['word/footnotes.xml'])
    for p in note_root.findall('.//{'+W+'}p'):
        pr=p.find('{'+W+'}pPr')
        if pr is None:pr=etree.Element('{'+W+'}pPr');p.insert(0,pr)
        jc=etree.SubElement(pr,'{'+W+'}jc');jc.set('{'+W+'}val','left')
    for run in note_root.findall('.//{'+W+'}r'):
        pr=run.find('{'+W+'}rPr')
        if pr is None:pr=etree.Element('{'+W+'}rPr');run.insert(0,pr)
        size=etree.SubElement(pr,'{'+W+'}sz');size.set('{'+W+'}val','18')
        fonts=etree.SubElement(pr,'{'+W+'}rFonts');fonts.set('{'+W+'}ascii','Arial');fonts.set('{'+W+'}hAnsi','Arial')
    parts['word/footnotes.xml']=etree.tostring(note_root,xml_declaration=True,encoding='UTF-8',standalone=True)
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED)as z:
        for name,value in parts.items():z.writestr(name,value)
    control=json.loads((F/'control_redaccion.json').read_text());control.update({'docx':output.name,'native_tables':4,'native_equations':2,'figures':3})
    (F/'control_redaccion.json').write_text(json.dumps(control,indent=2),encoding='utf-8')
    print('Word editable creado:',output.name,flush=True)


if __name__=='__main__':main()
