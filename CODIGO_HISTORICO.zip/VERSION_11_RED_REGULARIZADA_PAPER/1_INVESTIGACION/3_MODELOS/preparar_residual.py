"""Entradas V11: mismas muestras V10, soporte de entrenamiento acotado."""
from pathlib import Path
import json
import sys
import numpy as np
import pandas as pd
from scipy.special import logsumexp

P=Path(__file__).resolve().parents[1]
ROOT=P.parents[2]
P5=ROOT/'EXPOSICION_FEN_NINO/VERSION_5_QUITO_10M/1_INVESTIGACION'
P10=ROOT/'EXPOSICION_FEN_NINO/VERSION_10_ESCORRENTIA_LOCAL/1_INVESTIGACION'
sys.path.insert(0,str(P5/'3_MODELOS'))
from ajustar_lineal import fit,valid_norm
D=P/'2_DATOS/PROCESADOS';F=P/'6_FINAL'


def main():
    D.mkdir(parents=True,exist_ok=True);F.mkdir(parents=True,exist_ok=True)
    old=json.loads((P10/'2_DATOS/PROCESADOS/modelos_lineales_v10.json').read_text(encoding='utf-8'))
    states={};audit=[]
    for key,st in old.items():
        with np.load(P10/f'2_DATOS/PROCESADOS/entrada_{key}.npz') as z:inp={k:z[k]for k in z.files}
        Xe,Xb=inp['Xe'].copy(),inp['Xb'].copy()
        lo,hi=np.quantile(Xb[inp['btrain']],[.005,.995],axis=0)
        categorical=np.array([n.startswith('cobertura_')for n in st['names']])
        lo[categorical]=-np.inf;hi[categorical]=np.inf
        outside_e=((Xe<lo)|(Xe>hi))&inp['valid_e'][...,None]
        outside_b=(Xb<lo)|(Xb>hi)
        Xe=np.clip(Xe,lo,hi).astype(np.float32);Xb=np.clip(Xb,lo,hi).astype(np.float32)
        for split in ['train','cal','test']:
            em=inp['e'+split];bm=inp['b'+split]
            vals=outside_e[em];valid=inp['valid_e'][em]
            audit.append({'key':key,'split':split,'n_reports':int(em.sum()),
                'report_support_fraction_any_clipped':float(((vals.any(-1)*valid).sum(1)/valid.sum(1)).mean()),
                'background_fraction_any_clipped':float(outside_b[bm].any(1).mean())})
        candidates=[]
        for lam in [.001,.01,.1,1.]:
            beta=fit(Xe[inp['etrain']],Xb[inp['btrain']],inp['valid_e'][inp['etrain']],lam)
            ev,_=valid_norm(Xe[inp['ecal']],inp['valid_e'][inp['ecal']],beta)
            ll=float(ev.mean()-logsumexp(Xb[inp['bcal']]@beta)+np.log(inp['bcal'].sum()))
            candidates.append((ll,lam,beta))
        best=max(candidates,key=lambda c:c[0]);options=[]
        for alpha in [.25,.5,.75,1.,1.25]:
            ev,_=valid_norm(Xe[inp['ecal']],inp['valid_e'][inp['ecal']],best[2]*alpha)
            ll=float(ev.mean()-logsumexp(Xb[inp['bcal']]@(best[2]*alpha))+np.log(inp['bcal'].sum()))
            options.append((ll,alpha))
        alpha=max(options)[1];anchor=best[2]*alpha
        inp['Xe']=Xe;inp['Xb']=Xb
        np.savez_compressed(D/f'entrada_{key}.npz',**inp,anchor=anchor.astype(np.float32),lo=lo,hi=hi,
                            clipped_e=outside_e.any(-1),clipped_b=outside_b.any(1))
        np.savez_compressed(D/f'ancla_{key}.npz',fe=Xe@anchor,fb=Xb@anchor)
        states[key]={**st,'anchor':anchor.tolist(),'lambda_clipped':best[1],
                     'alpha_clipped':alpha,'q_clip':[.005,.995],'n_features':Xb.shape[1]}
        print(key,'ancla ajustada sin acceso al test',flush=True)
    (D/'parametros_ancla.json').write_text(json.dumps(states,ensure_ascii=False,indent=2),encoding='utf-8')
    pd.DataFrame(audit).to_csv(F/'diagnostico_soporte_entrenamiento.csv',index=False)


if __name__=='__main__':main()
