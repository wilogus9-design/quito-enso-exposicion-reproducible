"""Red residual acotada con ancla lineal, regularización y selección por calibración."""
from pathlib import Path
import json
import math
import argparse
import numpy as np
import torch
from torch import nn

P=Path(__file__).resolve().parents[1];D=P/'2_DATOS/PROCESADOS';F=P/'6_FINAL'


class ResidualNet(nn.Module):
    def __init__(self,anchor,bound):
        super().__init__()
        p=len(anchor)
        self.register_buffer('anchor',torch.as_tensor(anchor,dtype=torch.float32))
        self.bound=float(bound)
        self.layers=nn.Sequential(nn.Linear(p,16),nn.SiLU(),nn.Dropout(.10),
                                  nn.Linear(16,8),nn.SiLU(),nn.Dropout(.10),nn.Linear(8,1))
        nn.init.zeros_(self.layers[-1].weight);nn.init.zeros_(self.layers[-1].bias)
    def residual(self,x):return self.bound*torch.tanh(self.layers(x).squeeze(-1))
    def forward(self,x):return (x*self.anchor).sum(dim=-1)+self.residual(x)


def ll(model,Xe,Xb,valid):
    with torch.no_grad():
        fe=model(Xe).masked_fill(~valid,-torch.inf)
        return float((torch.logsumexp(fe,dim=1)-torch.log(valid.sum(1))).mean()-torch.logsumexp(model(Xb),dim=0)+math.log(len(Xb)))


def raw(model,X,batch=262144):
    with torch.no_grad():
        return np.concatenate([model(torch.as_tensor(X[i:i+batch],device=model.anchor.device)).cpu().numpy()for i in range(0,len(X),batch)])


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--device',choices=['auto','cpu','cuda'],default='auto')
    args=parser.parse_args()
    device=('cuda'if torch.cuda.is_available()else'cpu')if args.device=='auto'else args.device
    torch.set_num_threads(4)
    states=json.loads((D/'parametros_ancla.json').read_text(encoding='utf-8'))
    audit=[];selected={}
    print('Entrenamiento de redes residuales en',device,flush=True)
    for key,st in states.items():
        with np.load(D/f'entrada_{key}.npz')as z:d={k:z[k]for k in z.files}
        Xb=torch.as_tensor(d['Xb'],device=device);Xe=torch.as_tensor(d['Xe'],device=device)
        valid=torch.as_tensor(d['valid_e'],device=device)
        def e(split):return Xe[torch.as_tensor(d['e'+split],device=device)],valid[torch.as_tensor(d['e'+split],device=device)]
        et,vt=e('train');ec,vc=e('cal')
        bt=Xb[torch.as_tensor(d['btrain'],device=device)];bc=Xb[torch.as_tensor(d['bcal'],device=device)]
        bounds=[]
        for bound in [.25,1.]:
            cal_scores=[]
            for seed in [5101,5102,5103]:
                torch.manual_seed(seed);rng=np.random.default_rng(seed)
                model=ResidualNet(d['anchor'],bound).to(device)
                optimizer=torch.optim.AdamW(model.layers.parameters(),lr=.002,weight_decay=.05)
                best=-float('inf');best_state=None;best_epoch=None
                for epoch in range(301):
                    model.train();idx=torch.as_tensor(rng.choice(len(bt),min(16384,len(bt)),replace=False),device=device)
                    fe=model(et).masked_fill(~vt,-torch.inf)
                    ev=torch.logsumexp(fe,dim=1)-torch.log(vt.sum(1))
                    fb=model(bt[idx]);res=model.residual(bt[idx])
                    loss=torch.logsumexp(fb,dim=0)-math.log(len(fb))-ev.mean()+.10*(res**2).mean()
                    optimizer.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5.);optimizer.step()
                    if epoch%10==0:
                        model.eval();score=ll(model,ec,bc,vc)
                        if score>best:
                            best=score;best_epoch=epoch;best_state={k:v.detach().cpu().clone()for k,v in model.state_dict().items()}
                model.load_state_dict(best_state);model.eval();cal_scores.append(best)
                label=str(bound).replace('.','p')
                torch.save({'state_dict':best_state,'bound':bound,'anchor':d['anchor'].tolist(),'n_features':Xb.shape[1],
                    'seed':seed,'epoch':best_epoch,'model_type':'bounded_residual_presence_intensity'},D/f'residual_{key}_B{label}_{seed}.pt')
                fb=raw(model,d['Xb']);fe=raw(model,d['Xe'].reshape(-1,Xb.shape[1])).reshape(d['Xe'].shape[:2])
                np.savez_compressed(D/f'scores_{key}_B{label}_{seed}.npz',fe=fe,fb=fb)
                audit.append({'key':key,'seed':seed,'bound':bound,'epoch':best_epoch,'cal_log_density':best,
                    'device':device,'training_architecture':[Xb.shape[1],16,8,1],'dropout':.10,
                    'residual_penalty':.10,'weight_decay':.05,'lr':.002})
                print(key,'B',bound,'semilla',seed,'epoch',best_epoch,'cal',round(best,4),flush=True)
            bounds.append((float(np.mean(cal_scores)),bound))
        bestbound=max(bounds)[1]
        selected[key]={'bound_selected_by_calibration':bestbound,'mean_calibration_scores':bounds,
                       'test_not_used_for_selection':True}
        if device=='cuda':torch.cuda.empty_cache()
    (F/'entrenamiento_residual.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
    (D/'seleccion_residual.json').write_text(json.dumps(selected,ensure_ascii=False,indent=2),encoding='utf-8')


if __name__=='__main__':main()
