"""Verificación del entrenamiento y de la redacción; no certificado editorial."""
from pathlib import Path
import json
import zipfile
import unittest
import numpy as np
import pandas as pd
import xml.etree.ElementTree as etree

P=Path(__file__).resolve().parents[1];ROOT=P.parents[2];D=P/'2_DATOS/PROCESADOS';F=P/'6_FINAL'
P10=ROOT/'EXPOSICION_FEN_NINO/VERSION_10_ESCORRENTIA_LOCAL/1_INVESTIGACION'


class Checks(unittest.TestCase):
    def test_unchanged_sample_and_partition(self):
        for key in ['temporal__base','temporal__vias_fabdem','espacial__base','espacial__vias_fabdem']:
            with np.load(D/f'entrada_{key}.npz')as new,np.load(P10/f'2_DATOS/PROCESADOS/entrada_{key}.npz')as old:
                for name in ['valid_e','etrain','ecal','etest','btrain','bcal','btest']:
                    np.testing.assert_array_equal(new[name],old[name])
                self.assertFalse(np.any(new['etrain']&new['etest']))

    def test_clipping_only_training_and_categorical_preserved(self):
        states=json.loads((D/'parametros_ancla.json').read_text())
        for key,st in states.items():
            with np.load(D/f'entrada_{key}.npz')as new,np.load(P10/f'2_DATOS/PROCESADOS/entrada_{key}.npz')as old:
                q=np.quantile(old['Xb'][old['btrain']],[.005,.995],axis=0)
                categorical=np.array([x.startswith('cobertura_')for x in st['names']])
                np.testing.assert_allclose(new['lo'][~categorical],q[0,~categorical])
                np.testing.assert_allclose(new['hi'][~categorical],q[1,~categorical])
                np.testing.assert_array_equal(new['Xb'][:,categorical],old['Xb'][:,categorical])

    def test_48_actual_models(self):
        audit=json.loads((F/'entrenamiento_residual.json').read_text())
        self.assertEqual(len(audit),48)
        self.assertEqual(len(list(D.glob('residual_*.pt'))),48)
        self.assertEqual(set(x['seed']for x in audit),{5101,5102,5103})
        self.assertTrue(all(x['training_architecture'][1:]==[16,8,1]for x in audit))
        self.assertTrue(all(0<=x['epoch']<=300 for x in audit))

    def test_bounded_output(self):
        x=pd.read_csv(F/'control_cotas_residuales.csv')
        self.assertEqual(len(x),48)
        self.assertTrue((x.max_raw_correction<=x.bound+1e-4).all())

    def test_selection_does_not_use_test(self):
        chosen=json.loads((D/'seleccion_residual.json').read_text())
        for st in chosen.values():
            winner=max(st['mean_calibration_scores'])[1]
            self.assertEqual(winner,st['bound_selected_by_calibration'])
            self.assertTrue(st['test_not_used_for_selection'])

    def test_all_variants_and_favorable_unfavorable_retained(self):
        x=pd.read_csv(F/'comparacion_modelos_V11.csv')
        self.assertEqual(len(x),48)
        self.assertEqual(x.modelo.nunique(),6)
        self.assertTrue((x[x.protocolo=='temporal'].n_test==100).all())
        self.assertTrue((x[x.protocolo=='espacial'].n_test==58).all())
        d=pd.read_csv(F/'diferencias_residual_emparejadas.csv')
        a=d[d.comparador=='ancla_acotada']
        self.assertTrue((a.delta_log_densidad_residual<0).any())
        self.assertTrue((a.delta_log_densidad_residual>0).any())

    def test_manuscript_no_hardware_or_fake_SAR(self):
        text=(F/'MANUSCRITO_QUITO_V11.qmd').read_text(encoding='utf-8')
        for term in ['RTX','5070','GPU','CPU']:
            self.assertNotIn(term,text)
        self.assertIn('no se comparan como tareas equivalentes',text)
        self.assertIn('No se interpreta falta de reporte como ausencia física',text)
        c=json.loads((F/'control_redaccion.json').read_text())
        self.assertLessEqual(c['words_summary'],200)
        self.assertLessEqual(c['words_abstract'],200)
        self.assertLess(c['words_manuscript_approx'],10000)

    def test_native_word_structure(self):
        file=F/'MANUSCRITO_QUITO_V11.docx'
        with zipfile.ZipFile(file)as z:
            doc=etree.fromstring(z.read('word/document.xml'))
            notes=etree.fromstring(z.read('word/footnotes.xml'))
        ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
        self.assertEqual(len(doc.findall('.//w:tbl',ns)),4)
        self.assertEqual(len(doc.findall('.//m:oMath',ns)),2)
        self.assertEqual(len(doc.findall('.//w:footnoteReference',ns)),1)
        text=' '.join(x.text or '' for x in doc.findall('.//w:t',ns))
        for term in ['RTX','5070','GPU','CPU']:
            self.assertNotIn(term,text)
        self.assertIn('Investigador independiente',' '.join(x.text or '' for x in notes.findall('.//w:t',ns)))

    def test_referent_review_and_delivery_sizes(self):
        x=json.loads((P/'1_LITERATURA/control_referente_SAR.json').read_text())
        self.assertEqual(x['architecture'],'MobileNet early fusion change detection')
        self.assertTrue(x['urban_built_up_and_steep_areas_masked_unreliable'])
        for f in F.rglob('*'):
            if f.is_file():self.assertLess(f.stat().st_size,10000000,f.name)


if __name__=='__main__':unittest.main(verbosity=2)
