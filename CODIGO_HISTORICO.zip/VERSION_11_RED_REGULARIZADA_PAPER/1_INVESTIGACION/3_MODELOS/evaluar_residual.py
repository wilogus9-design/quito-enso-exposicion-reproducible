"""Evaluación emparejada conservando anclas, redes libres y ambas cotas residuales."""
from pathlib import Path
import sys
import json
import numpy as np
import pandas as pd
from scipy.special import logsumexp

P=Path(__file__).resolve().parents[1];ROOT=P.parents[2]
P10=ROOT/'EXPOSICION_FEN_NINO/VERSION_10_ESCORRENTIA_LOCAL/1_INVESTIGACION'
sys.path.insert(0,str(P10/'3_MODELOS'))
from evaluar_comparacion import evaluate
D=P/'2_DATOS/PROCESADOS';F=P/'6_FINAL'


def ensemble(files,e,b):
    fes=[];fbs=[]
    for file in files:
        with np.load(file)as z:fe,fb=z['fe'][e],z['fb'][b]
        norm=logsumexp(fb)-np.log(len(fb))
        fes.append(fe-norm);fbs.append(fb-norm)
    return logsumexp(np.stack(fes),axis=0)-np.log(3),logsumexp(np.stack(fbs),axis=0)-np.log(3)


def main():
    states=json.loads((D/'parametros_ancla.json').read_text(encoding='utf-8'))
    selected=json.loads((D/'seleccion_residual.json').read_text())
    rows=[];differences=[];bounds=[];saved={};rng=np.random.default_rng(11109)
    for key,st in states.items():
        with np.load(D/f'entrada_{key}.npz')as z:d={k:z[k]for k in z.files}
        e,b=d['etest'],d['btest'];valid=d['valid_e'][e]
        block=(d['event_x'][e]//5000).astype(int).astype(str)+'_'+(d['event_y'][e]//5000).astype(int).astype(str)
        predictions={}
        for name,path in [('loglineal',P10/f'2_DATOS/PROCESADOS/lineal_{key}.npz'),('ancla_acotada',D/f'ancla_{key}.npz')]:
            with np.load(path)as z:predictions[name]=(z['fe'][e],z['fb'][b])
        predictions['red_libre']=ensemble([P10/f'2_DATOS/PROCESADOS/scores_red_{key}_{s}.npz'for s in [5101,5102,5103]],e,b)
        for bound in [.25,1.]:
            label=str(bound).replace('.','p')
            files=[D/f'scores_{key}_B{label}_{s}.npz'for s in [5101,5102,5103]]
            predictions['residual_B'+str(bound)]=ensemble(files,e,b)
            for file in files:
                with np.load(file)as z:
                    anchor_e=d['Xe']@d['anchor'];anchor_b=d['Xb']@d['anchor']
                    maximum=max(float(np.abs(z['fe']-anchor_e).max()),float(np.abs(z['fb']-anchor_b).max()))
                if maximum>bound+1e-4:raise ValueError('Corrección excede la cota fijada')
                bounds.append({'key':key,'file':file.name,'bound':bound,'max_raw_correction':maximum})
        chosen=selected[key]['bound_selected_by_calibration']
        predictions['residual_cal']=predictions['residual_B'+str(chosen)]
        vectors={}
        for name,(fe,fb)in predictions.items():
            ev,capture=evaluate(fe,fb,valid)
            vectors[name]=(ev,capture)
            saved[key+'__'+name]=ev
            rows.append({'protocolo':st['protocol'],'variante':st['variant'],'modelo':name,
                'n_test':int(e.sum()),'n_bloques':len(np.unique(block)),
                'log_densidad_relativa':float(ev.mean()),'captura_top10pct_soporte':float(capture.mean()),
                'bound_selected_by_calibration':chosen if name=='residual_cal'else None})
        unique=np.unique(block);counts=np.array([(block==k).sum()for k in unique])
        draw=rng.integers(0,len(unique),(3000,len(unique)))
        residual=vectors['residual_cal'][0]
        for comparator in ['loglineal','ancla_acotada','red_libre']:
            delta=residual-vectors[comparator][0]
            sums=np.array([delta[block==k].sum()for k in unique])
            simulated=sums[draw].sum(1)/counts[draw].sum(1)
            lo,hi=np.quantile(simulated,[.025,.975])
            differences.append({'protocolo':st['protocol'],'variante':st['variant'],'comparador':comparator,
                'delta_log_densidad_residual':float(delta.mean()),'rango95_inf':lo,'rango95_sup':hi,
                'n_bloques':len(unique),'inferencia':'exploratoria por bloques; extensión posterior a V10'})
    metrics=pd.DataFrame(rows);metrics.to_csv(F/'comparacion_modelos_V11.csv',index=False)
    pd.DataFrame(differences).to_csv(F/'diferencias_residual_emparejadas.csv',index=False)
    pd.DataFrame(bounds).to_csv(F/'control_cotas_residuales.csv',index=False)
    np.savez_compressed(D/'vectores_test_V11.npz',**saved)
    print(metrics[metrics.modelo.isin(['loglineal','red_libre','ancla_acotada','residual_cal'])].to_string(index=False),flush=True)


if __name__=='__main__':main()
