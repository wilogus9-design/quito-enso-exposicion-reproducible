# Integración multiescala de amenaza, exposición y vulnerabilidad

Fecha del protocolo: 2026-10-09. Se establece antes de estimar los modelos V09.

## Pregunta y contribución candidata

¿Cambian las prioridades territoriales de preparación cuando se combinan pronósticos estacionales de lluvia, susceptibilidad geoespacial y privaciones censales? ¿Mejora la distribución prevista de reportes de inundación al incorporar estos componentes, frente a referencias sencillas?

No se afirma que combinar satélites y pobreza sea por sí mismo nuevo: Rentschler et al. (2022), el índice VARI Flood (2024) y Mester et al. (2025) ya integran exposición y vulnerabilidad. La extensión local propuesta es la anticipación estacional evaluada, la comparación incremental y una priorización multiescala con denominadores e incertidumbre explícitos. Se contrasta con la asociación lluvia–bienestar de Canavire-Bacarreza et al. (2026), sin sustituir pobreza monetaria por NBI.

## Fuentes y soportes

- Capa municipal de Quito, Censo 2022, 65 parroquias: cantidades y porcentajes NBI, agua, saneamiento y hacinamiento; se conservan denominadores originales. `pobT` no se usa como denominador de NBI sin reconciliación, pues contiene decimales y difiere de `p_nbi + nop_nbi`.
- Mapas y modelos V05 conservados: red de intensidad de reportes y modelo loglineal, cobertura WorldCover 2021 de 10 m, coberturas municipales 2020/2025. Los modelos no producen profundidad ni probabilidad física por píxel.
- V07 conservada: pronósticos red ENSO y climatología, calibración fija beta-PIT, meteorología nativa de 0.05 grados. NMME se conserva como sensibilidad para la proyección actual.
- Reportes SNGR de V05: registros puntuales geocodificados, no parcelas físicamente observadas ni censos completos de incidentes.

## Análisis definidos

1. Reproyectar la geometría censal a EPSG:32717 y rasterizarla sobre la grilla ya existente. Auditar superposición, cobertura y cruce con las parroquias municipales V05. No unir solamente por nombres.
2. Contar suelo construido y prioridad por parroquia y celda meteorológica. Agregar probabilidades regionales por áreas exactas. No interpolar probabilidades de inundación a 10 m.
3. Publicar para NDJ 2026/2027 áreas de prioridad ponderadas por probabilidad de lluvia húmeda. Para indicadores sociales, publicar unidades separadas de ha, personas NBI y hogares privados de servicios. La asignación de habitantes al construido será una hipótesis uniforme explícita, no una localización observada. Publicar cotas de Fréchet de pobres dentro de la exposición asumida y sensibilidad red/loglineal/climatología/NMME.
4. Prueba secundaria retrospectiva de distribución espacial de **reportes** por trimestre no solapado. Ajuste 2022–2023, evaluación 2024–septiembre 2025. La red espacial original se entrenó hasta 2021, pero las versiones cartográficas y la disponibilidad del censo no están certificadas a cada emisión histórica: esta prueba no es una evaluación prospectiva ciega. Los resultados anteriores V05/V07 ya fueron vistos.
5. Modelos condicionales multinomiales sobre las mismas parroquias y fechas: construido, frecuencia histórica suavizada, lluvia, susceptibilidad de red, susceptibilidad + lluvia y fusión social. Penalización L2 = 1 por coeficiente estandarizado, fija; sin selección por p-valores o resultados de test. La fusión añade NBI, saneamiento, agua y hacinamiento, e interacción NBI × lluvia. Se conservan las variantes desfavorables.
6. La log-verosimilitud por reporte y captura del 20 % de parroquias se comparan en test; remuestreo de trimestres completos para rangos exploratorios. Ausencia de reporte no equivale a ausencia de inundación. Evaluar reportes no demuestra predecir perjuicio de hogares.

## Redacción

El resultado social principal es una prioridad de preparación, no una cifra de pérdidas. Las métricas de lluvia y de reportes conservan sus objetivos. Una mejor capacidad de anticipar cambios de pobreza requiere una evaluación ENEMDU separada; no se deriva automáticamente del índice NBI. Las referencias SAR independientes continúan siendo necesarias para declarar inundación física validada.
