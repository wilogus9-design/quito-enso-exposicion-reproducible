# Enmienda por cobertura, 2026-10-09

Después de ejecutar la primera unión geográfica se encontró que nueve parroquias rurales no tienen suelo clasificado como construido en la capa municipal 2025. Esto no significa ausencia de residentes ni de edificios. Las cantidades NBI municipales también difieren de los controles cantonales INEC Gold.

Para no excluir automáticamente a esas parroquias, la exposición principal se calcula sobre ESA WorldCover 2021, disponible en todas las parroquias y anterior al censo. Se conserva la capa municipal 2025 como contraste de cobertura, no se rellena con ceros. Se redefine el decil construido sobre WorldCover con los mismos scores espaciales congelados V05, mediante el percentil 90 del área construida de todo el DMQ, sin ajustar el umbral por los resultados de reportes.

La comparación predictiva de reportes ya empleaba WorldCover 2021 y no cambia de especificación. Sus resultados se conocían al efectuar esta enmienda; no se presenta como prueba ciega.

La priorización social principal usa hectáreas de prioridad ponderadas por la proporción NBI publicada, con unidad de índice explícita. Los proxies de personas/hogares permanecen en el archivo de sensibilidad, etiquetados como cantidades municipales no reconciliadas y asignación uniforme supuesta. No se presentan como número oficial de afectados.
