"""Prioridades de preparación, escenarios de modelo y campos de lluvia conjuntos.

No suma pobreza, agua y saneamiento: son objetivos distintos y parcialmente
superpuestos. No convierte esos objetivos en pérdidas ni individuos localizados.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import geopandas as gpd
from scipy.stats import rankdata, beta as beta_distribution

P = Path(__file__).resolve().parents[1]
ROOT = P.parents[2]
P6 = ROOT/'EXPOSICION_FEN_NINO/VERSION_6_ENSO_PREDICTIBILIDAD/1_INVESTIGACION'
P7 = ROOT/'EXPOSICION_FEN_NINO/VERSION_7_CALIBRACION_NMME/1_INVESTIGACION'
D = P/'2_DATOS/PROCESADOS'
F = P/'6_FINAL'


def main():
    data = pd.read_csv(F/'prioridad_social_NDJ2026_2027.csv', dtype={'parroquia': str})
    territory = pd.read_csv(F/'territorio_vulnerabilidad_parroquias.csv', dtype={'parroquia': str})
    data['indice_social_ha_ponderadas_NBI'] = data.area_prioritaria_bajo_estado_humedo_ponderada_ha*data.nbi_pct/100
    # No se utiliza la diferencia de cantidades censales para ocultar incertidumbre.
    data['estado_conteos_censales'] = 'No reconciliados; proxies de personas solo para sensibilidad, no cifras oficiales'
    data.to_csv(F/'prioridad_social_NDJ2026_2027.csv', index=False)
    rows = []
    comparisons = []
    for (rain, spatial), h in data.groupby(['modelo_lluvia','modelo_territorial']):
        h = h.sort_values('parroquia').copy()
        physical = h.area_prioritaria_bajo_estado_humedo_ponderada_ha.rank(method='first', ascending=False).astype(int)
        social = h.indice_social_ha_ponderadas_NBI.rank(method='first', ascending=False).astype(int)
        eligible_area = h.area_prioritaria_bajo_estado_humedo_ponderada_ha > 0
        eligible_social = h.indice_social_ha_ponderadas_NBI > 0
        a = set(h.loc[(physical <= 13)&eligible_area, 'parroquia'])
        b = set(h.loc[(social <= 13)&eligible_social, 'parroquia'])
        comparisons.append({'modelo_lluvia': rain, 'modelo_territorial': spatial,
            'presupuesto_maximo_parroquias': 13, 'seleccionadas_area': len(a),
            'seleccionadas_social': len(b), 'comunes_area_social': len(a&b),
            'cambios_por_incorporar_NBI': len(b-a),
            'jaccard_top13_area_social': len(a&b)/len(a|b),
            'interpretacion': 'diferencia de objetivos; no mejora predictiva demostrada'})
        for idx, r in h.iterrows():
            rows.append({'parroquia': r.parroquia, 'nombre': r.nombre,
                'modelo_lluvia': rain, 'modelo_territorial': spatial,
                'orden_area': int(physical.loc[idx]) if eligible_area.loc[idx] else None,
                'orden_social': int(social.loc[idx]) if eligible_social.loc[idx] else None,
                'seleccion_social_top13': int((social.loc[idx] <= 13)&eligible_social.loc[idx]),
                'estado_diferenciacion': 'positivo' if eligible_social.loc[idx] else 'sin diferenciación positiva; no ausencia de riesgo',
                'area_humeda_prioritaria_ponderada_ha': r.area_prioritaria_bajo_estado_humedo_ponderada_ha,
                'indice_social_ha_ponderadas_NBI': r.indice_social_ha_ponderadas_NBI,
                'NBI_pct': r.nbi_pct})
    ranking = pd.DataFrame(rows)
    ranking.to_csv(F/'ranking_prioridades_y_sensibilidades.csv', index=False)
    pd.DataFrame(comparisons).to_csv(F/'cambio_prioridades_al_incluir_NBI.csv', index=False)
    stability = ranking.groupby(['parroquia','nombre'], as_index=False).agg(
        selecciones_sociales_de_6=('seleccion_social_top13','sum'),
        mejor_orden_social=('orden_social','min'), peor_orden_social=('orden_social','max'),
        indice_social_min=('indice_social_ha_ponderadas_NBI','min'),
        indice_social_max=('indice_social_ha_ponderadas_NBI','max'))
    stability['tipo_medida'] = 'acuerdo entre escenarios de modelo; no probabilidad ni intervalo de confianza'
    stability.to_csv(F/'estabilidad_prioridades.csv', index=False)
    geometry = gpd.read_file(D/'geometria_censal.geojson')
    primary = ranking[(ranking.modelo_lluvia == 'red_ENSO__beta_PIT')&(ranking.modelo_territorial == 'red')]
    geo = geometry.merge(primary, on='parroquia', validate='one_to_one').merge(stability, on=['parroquia','nombre'], validate='one_to_one')
    geo['interpretacion'] = 'Parroquias prioritarias; no profundidad futura ni pobreza observada por píxel'
    geo.to_file(F/'prioridades_sociales_quito.geojson', driver='GeoJSON')
    # Empirical copula: each realization retains the spatial ordering of one
    # historical residual field, instead of assuming millions of independent pixels.
    with np.load(P6/'2_DATOS/PROCESADOS/panel_v06.npz') as z:
        panel = {k: z[k] for k in z.files}
    with np.load(P6/'2_DATOS/PROCESADOS/entrada_futura_nov2026.npz') as z:
        future = {k: z[k] for k in z.files}
    with np.load(P6/'2_DATOS/PROCESADOS/predicciones_redes.npz') as z:
        net = {k: z[k] for k in z.files if k in ['red_ENSO','red_ENSO_future']}
    units = pd.read_csv(P6/'2_DATOS/PROCESADOS/unidades.csv', dtype={'unit': str})
    with np.load(D/'intersecciones_multiescala.npz') as z:
        local = z['unit']
        counts = {k: z[k][1:].astype(float) for k in ['construido_WC2021','red_WC2021_prioritario','lineal_WC2021_prioritario']}
    selected = units.set_index('unit').reindex(local).index
    ids = units.reset_index().set_index('unit').loc[selected, 'index'].to_numpy()
    dates = pd.PeriodIndex(panel['months'], freq='M')
    bank = (dates.year >= 2014)&((dates+2).year <= 2016)
    if not panel['valid'][ids][:,bank].all():
        raise ValueError('Campos residuales incompletos: no simular independencia espacial')
    params = pd.read_csv(P7/'6_FINAL/parametros_beta_PIT.csv')
    den = counts['construido_WC2021'].sum(1)
    results = []
    for model in ['red_ENSO','climatologia_calibrada']:
        zpred = net['red_ENSO'] if model == 'red_ENSO' else np.zeros_like(panel['z'])
        current = net['red_ENSO_future'][ids] if model == 'red_ENSO' else np.zeros(len(ids))
        residual = panel['z'][ids][:,bank]-zpred[ids][:,bank]
        copula = (rankdata(residual, axis=1, method='average')-.5)/residual.shape[1]
        parameter = params[(params.modelo == model)&(params.dominio == 'Quito grilla')].iloc[0]
        offsets = np.stack([np.quantile(r, beta_distribution.ppf(q, parameter.a, parameter.b)) for r,q in zip(residual,copula)])
        draws = np.maximum(np.expm1(future['mu'][ids,None]+future['sd'][ids,None]*(current[:,None]+offsets)), 0)
        wet = draws > future['q80'][ids,None]
        for spatial in ['red','lineal']:
            hectares = counts[spatial+'_WC2021_prioritario']@wet*.01
            index = hectares*territory.pc_pnbi.to_numpy()[:,None]/100
            for i, r in territory.iterrows():
                lo, med, hi = np.quantile(hectares[i], [.1,.5,.9])
                slo, smed, shi = np.quantile(index[i], [.1,.5,.9])
                results.append({'parroquia': r.parroquia, 'nombre': r.nom_par,
                    'modelo_lluvia': model+'__beta_PIT', 'modelo_territorial': spatial,
                    'n_campos_historicos_conjuntos': residual.shape[1],
                    'area_prioritaria_estado_humedo_media_campos_ha': hectares[i].mean(),
                    'rango80_campos_area_inf_ha': lo, 'mediana_campos_area_ha': med, 'rango80_campos_area_sup_ha': hi,
                    'rango80_campos_indice_NBI_inf': slo, 'mediana_campos_indice_NBI': smed,
                    'rango80_campos_indice_NBI_sup': shi,
                    'interpretacion': 'rango experimental de campos de lluvia; no cobertura garantizada, no superficie inundada'})
    pd.DataFrame(results).to_csv(F/'incertidumbre_campos_sociales.csv', index=False)
    (F/'control_prioridades.json').write_text(json.dumps({
        'escenarios_modelo': 6, 'presupuesto_maximo_parroquias_por_escenario': 13,
        'no_prioriza_empates_cero_por_orden_alfabetico': True,
        'objetivo_social': 'ha de prioridad bajo estado húmedo ponderadas por proporción NBI',
        'no_doble_suma_NBI_servicios': True,
        'campos_copula_residual': residual.shape[1],
        'fechas_campos': panel['months'][bank].tolist(),
        'incertidumbre_parcial': 'lluvia y escenarios; no incertidumbre completa de censo, parámetros, cobertura o susceptibilidad'},
        ensure_ascii=False, indent=2), encoding='utf-8')
    print(pd.DataFrame(comparisons).to_string(index=False), flush=True)
    print(stability.sort_values(['selecciones_sociales_de_6','mejor_orden_social'], ascending=[False,True]).head(10).to_string(index=False), flush=True)


if __name__ == '__main__':
    main()
