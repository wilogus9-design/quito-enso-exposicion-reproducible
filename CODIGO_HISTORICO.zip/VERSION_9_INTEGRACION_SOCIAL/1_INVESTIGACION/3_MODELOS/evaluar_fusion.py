"""Compara la distribución de reportes, no la probabilidad física de inundación.

El modelo es multinomial condicional al total de reportes del trimestre.
La evaluación geográfica es retrospectiva y secundaria, con datos censales
cuya disponibilidad histórica no está certificada. No escoge ganadores por test.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import geopandas as gpd
from scipy.special import logsumexp
from scipy.optimize import minimize

P = Path(__file__).resolve().parents[1]
ROOT = P.parents[2]
P5 = ROOT/'EXPOSICION_FEN_NINO/VERSION_5_QUITO_10M/1_INVESTIGACION'
P7 = ROOT/'EXPOSICION_FEN_NINO/VERSION_7_CALIBRACION_NMME/1_INVESTIGACION'
D = P/'2_DATOS/PROCESADOS'
F = P/'6_FINAL'
SPECS = {
    'lluvia': ['lluvia'],
    'red_territorial': ['susceptibilidad'],
    'red_y_lluvia': ['susceptibilidad', 'lluvia'],
    'fusion_social': ['susceptibilidad', 'lluvia', 'nbi', 'saneamiento', 'agua', 'hacinamiento', 'nbi_x_lluvia']}


def fit_conditional(X, count, offset, penalty=1.):
    """L2 fijada; gradiente analítico; un normalizador por fecha."""
    def obj(beta):
        eta = offset+np.einsum('tpv,v->tp', X, beta)
        lp = eta-logsumexp(eta, axis=1, keepdims=True)
        prob = np.exp(lp)
        value = -np.sum(count*lp)+.5*penalty*np.sum(beta**2)
        grad = np.einsum('tp,tpv->v', count.sum(1)[:,None]*prob-count, X)+penalty*beta
        return value, grad
    r = minimize(obj, np.zeros(X.shape[2]), method='L-BFGS-B', jac=True,
                 options={'maxiter': 1000, 'ftol': 1e-12, 'gtol': 1e-8})
    if not r.success:
        raise RuntimeError(r.message)
    return r.x


def main():
    territory = pd.read_csv(F/'territorio_vulnerabilidad_parroquias.csv', dtype={'parroquia': str})
    geometry = gpd.read_file(D/'geometria_censal.geojson').to_crs(32717)
    events = gpd.read_file(P5/'2_DATOS/PROCESADOS/reportes_quito.geojson').to_crs(32717)
    events.fecha = pd.to_datetime(events.fecha)
    events = events[(events.evento_norm == 'INUNDACION')&events.fecha.between('2022-01-01', '2025-09-30')].copy()
    joined = gpd.sjoin(events, geometry[['parroquia','geometry']], how='left', predicate='within')
    # Un punto en borde o fuera no se asigna por cercanía. Registrar cualquier ambigüedad.
    if joined.index.duplicated().any():
        raise ValueError('Reportes en geometrías superpuestas; resolver antes de estimar')
    missing = int(joined.parroquia.isna().sum())
    joined = joined.dropna(subset=['parroquia'])
    joined['trimestre'] = joined.fecha.dt.to_period('Q').astype(str)
    quarters = pd.period_range('2022Q1', '2025Q3', freq='Q')
    labels = quarters.astype(str)
    start = quarters.asfreq('M', how='start').astype(str)
    code = territory.parroquia.to_numpy(dtype=str)
    eventcount = joined.groupby(['trimestre','parroquia']).size().unstack(fill_value=0)
    y = eventcount.reindex(index=labels, columns=code, fill_value=0).to_numpy(dtype=float)
    bank = np.array([q.year <= 2023 for q in quarters])
    test = ~bank
    with np.load(D/'intersecciones_multiescala.npz') as z:
        units = z['unit']
        assert np.array_equal(z['codigo'], code)
        counts = z['construido_WC2021'][1:].astype(float)
    den = counts.sum(1)
    if (den <= 0).any():
        raise ValueError('Parroquia sin construido 2021: no crear exposición ficticia')
    weights = counts/den[:,None]
    weather = pd.read_parquet(P7/'2_DATOS/PROCESADOS/test_calibracion_v07.parquet')
    weather = weather[(weather.tipo_unidad == 'QUITO_CELDA')&(weather.modelo == 'red_ENSO__beta_PIT')]
    wet = weather.pivot(index='inicio_temporada', columns='unit', values='p_humedo').reindex(index=start, columns=units)
    if wet.isna().any().any():
        raise ValueError('Predicciones de lluvia incompletas para trimestre/celda')
    w = wet.to_numpy()@weights.T
    features = {
        'susceptibilidad': np.broadcast_to(np.log(territory.intensidad_media_inundacion_red.to_numpy()), y.shape),
        'lluvia': w,
        'nbi': np.broadcast_to(territory.pc_pnbi.to_numpy()/100, y.shape),
        'saneamiento': np.broadcast_to(territory.pc_SH.to_numpy()/100, y.shape),
        'agua': np.broadcast_to(territory.pc_FSA.to_numpy()/100, y.shape),
        'hacinamiento': np.broadcast_to(territory.pc_HAC.to_numpy()/100, y.shape)}
    features['nbi_x_lluvia'] = features['nbi']*w
    offset = np.broadcast_to(np.log(den), y.shape)
    probs = {}
    probs['construido'] = np.broadcast_to(den/den.sum(), y.shape).copy()
    # Comparador fuerte: frecuencia histórica suavizada por la proporción construida.
    historic = y[bank].sum(0)+len(code)*den/den.sum()
    probs['frecuencia_historica'] = np.broadcast_to(historic/historic.sum(), y.shape).copy()
    params = []
    for name, fields in SPECS.items():
        X = np.stack([features[k] for k in fields], axis=-1)
        mu = X[bank].mean(axis=(0,1))
        sd = X[bank].std(axis=(0,1))
        if not np.isfinite(X).all() or (sd < 1e-10).any():
            raise ValueError('Entrada inválida: '+name)
        X = (X-mu)/sd
        beta = fit_conditional(X[bank], y[bank], offset[bank], penalty=1.)
        eta = offset+np.einsum('tpv,v->tp', X, beta)
        probs[name] = np.exp(eta-logsumexp(eta, axis=1, keepdims=True))
        for f, b, m, s in zip(fields, beta, mu, sd):
            params.append({'modelo': name, 'variable': f, 'coeficiente_estandarizado': b,
                           'media_ajuste': m, 'sd_ajuste': s, 'penalizacion_L2': 1.,
                           'coeficiente_no_es_efecto_pobreza': True})
    pd.DataFrame(params).to_csv(F/'parametros_fusion.csv', index=False)
    detail = []
    for name, prob in probs.items():
        for i, q in enumerate(labels):
            top = np.argsort(-prob[i], kind='stable')[:13]  # 20 % de 65 parroquias
            capture = float(y[i,top].sum())
            for j, c in enumerate(code):
                detail.append({'trimestre': q, 'parroquia': c, 'modelo': name,
                    'particion': 'ajuste' if bank[i] else 'evaluacion',
                    'reportes_observados': int(y[i,j]), 'total_reportes_trimestre': int(y[i].sum()),
                    'proporcion_reportes_prevista': float(prob[i,j]),
                    'log_score_contribucion': float(y[i,j]*np.log(prob[i,j])),
                    'priorizada_top20pct_parroquias': int(j in top),
                    'p_lluvia_humeda_regional': float(w[i,j])})
    pd.DataFrame(detail).to_csv(F/'evaluacion_fusion_parroquia_trimestre.csv', index=False)
    rng = np.random.default_rng(9109)
    draws = rng.integers(0, int(test.sum()), size=(3000, int(test.sum())))
    totals = y[test].sum(1)
    metrics = []
    scores_per = {}
    for name, prob in probs.items():
        ll = np.sum(y[test]*np.log(prob[test]), axis=1)
        scores_per[name] = ll
        captures = np.array([y[test][i, np.argsort(-p, kind='stable')[:13]].sum() for i, p in enumerate(prob[test])])
        metrics.append({'modelo': name, 'trimestres_evaluacion': int(test.sum()),
            'reportes_evaluacion': int(totals.sum()), 'parroquias': len(code),
            'log_score_por_reporte': float(ll.sum()/totals.sum()),
            'captura_reportes_top20pct_parroquias': float(captures.sum()/totals.sum()),
            'objetivo': 'distribución de reportes condicionada a su total; no daños'})
    pd.DataFrame(metrics).to_csv(F/'comparacion_fusion.csv', index=False)
    comparisons = []
    for name, values in scores_per.items():
        if name == 'fusion_social':
            continue
        delta = scores_per['fusion_social']-values
        estimates = delta[draws].sum(1)/totals[draws].sum(1)
        low, high = np.quantile(estimates, [.025, .975])
        comparisons.append({'comparador': name, 'diferencia_log_score_fusion_menos_comparador': float(delta.sum()/totals.sum()),
                            'rango95_bootstrap_trimestres_inf': low,
                            'rango95_bootstrap_trimestres_sup': high,
                            'n_trimestres': len(totals),
                            'inferencia': 'exploratoria; trimestres pueden depender entre sí'})
    pd.DataFrame(comparisons).to_csv(F/'incertidumbre_comparacion_fusion.csv', index=False)
    audit = {'ajuste_trimestres': labels[bank].tolist(), 'evaluacion_trimestres': labels[test].tolist(),
             'reportes_ajuste': int(y[bank].sum()), 'reportes_evaluacion': int(y[test].sum()),
             'reportes_sin_parroquia': missing, 'semilla': 9109,
             'ventanas_no_solapadas': True, 'penalizacion_predefinida': 1.,
             'calidad_datos_sociales': 'porcentajes internamente coherentes; cantidades no reconciliadas con Gold INEC',
             'no_indicador_ausencia_fisica': True, 'no_evaluacion_prospectiva_ciega': True,
             'no_seleccion_modelo_por_test': True, 'no_pronostico_total_incidentes': True}
    (F/'control_evaluacion_fusion.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
    print(pd.DataFrame(metrics).to_string(index=False), flush=True)
    print(json.dumps(audit, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
