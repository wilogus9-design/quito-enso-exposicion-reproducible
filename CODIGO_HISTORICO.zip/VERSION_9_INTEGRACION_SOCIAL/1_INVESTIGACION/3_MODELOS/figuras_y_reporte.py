"""Entrega metodología, resultados, bibliografía y figuras vectoriales editables."""
from pathlib import Path
import json
import re
import numpy as np
import pandas as pd
import geopandas as gpd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

P = Path(__file__).resolve().parents[1]
ROOT = P.parents[2]
F = P/'6_FINAL'
D = P/'2_DATOS/PROCESADOS'
G = F/'GRAFICOS'


def table(df):
    # CSV remains the exact editable table; Markdown is a rounded presentation.
    rows = [list(df.columns), *df.to_numpy().tolist()]
    def fmt(x):
        if isinstance(x, (float, np.floating)):
            return f'{x:.3f}' if np.isfinite(x) else 'No disponible'
        return str(x).replace('|', '/')
    text = '| '+' | '.join(map(str, rows[0]))+' |\n'
    text += '| '+' | '.join(['---']*len(rows[0]))+' |\n'
    for row in rows[1:]:
        text += '| '+' | '.join(fmt(x) for x in row)+' |\n'
    return text


def main():
    G.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({'font.family': 'Arial', 'font.size': 8, 'axes.titlesize': 8,
                         'svg.fonttype': 'none', 'axes.titleweight': 'normal'})
    territory = pd.read_csv(F/'territorio_vulnerabilidad_parroquias.csv', dtype={'parroquia': str})
    geo = gpd.read_file(F/'prioridades_sociales_quito.geojson').to_crs(32717)
    geo = geo.merge(territory[['parroquia','pc_pnbi','construido_WC2021_ha']], on='parroquia', validate='one_to_one')
    # Generalización exclusivamente visual: cálculos y GeoJSON mantienen la geometría original.
    mapgeo = geo.copy()
    mapgeo.geometry = mapgeo.geometry.simplify(20, preserve_topology=True)
    fig, axes = plt.subplots(1, 3, figsize=(10, 5.4))
    mapgeo.plot(column='pc_pnbi', cmap='YlOrRd', ax=axes[0], legend=True,
             legend_kwds={'label': 'Personas con NBI (%)', 'shrink': .6}, linewidth=.2, edgecolor='#777777')
    mapgeo.plot(column='orden_social', cmap='viridis_r', ax=axes[1], legend=True, missing_kwds={'color':'#eeeeee'},
             legend_kwds={'label': 'Orden (1 = mayor prioridad)', 'shrink': .6}, linewidth=.2, edgecolor='#777777')
    mapgeo.plot(column='selecciones_sociales_de_6', cmap='YlGnBu', ax=axes[2], legend=True, vmin=0, vmax=6,
             legend_kwds={'label': 'Selecciones entre 6 escenarios', 'shrink': .6}, linewidth=.2, edgecolor='#777777')
    titles = ['Pobreza NBI municipal, referencia 2022', 'Prioridad social NDJ 2026/2027\nRed ENSO y red territorial', 'Acuerdo entre modelos\nNo probabilidad de inundación']
    for ax, title in zip(axes, titles):
        ax.set_title(title, loc='left')
        ax.set_axis_off()
    fig.text(.02, .02, 'Fuente: Municipio de Quito (capa Censo 2022), ESA WorldCover, V05/V07. Elaboración propia.\nCantidades censales no reconciliadas. Lluvia nativa: 0.05 grados. Generalización visual: 20 m.\nGris: índice sin diferenciación positiva; no significa ausencia de riesgo.', fontsize=8)
    fig.subplots_adjust(left=.01, right=.99, top=.92, bottom=.12, wspace=.13)
    fig.savefig(G/'figura_1_prioridades_parroquiales.svg')
    fig.savefig(G/'figura_1_prioridades_parroquiales.png', dpi=300)
    plt.close(fig)
    models = pd.read_csv(F/'comparacion_fusion.csv')
    fig, ax = plt.subplots(figsize=(6.7, 3.2))
    names = ['Construido', 'Frecuencia histórica', 'Lluvia', 'Red territorial', 'Red y lluvia', 'Fusión social']
    ax.scatter(models.log_score_por_reporte, range(len(models)), color='#205375', s=30)
    ax.set_yticks(range(len(models)), labels=names)
    ax.invert_yaxis()
    ax.set_xlabel('Log score por reporte (mayor = mejor)')
    ax.set_title('Figura 2. Comparación en 100 reportes reservados', loc='left')
    ax.grid(axis='x', alpha=.25)
    ax.spines[['top','right']].set_visible(False)
    fig.text(.02, .015, 'Fuente: SNGR y modelos V05/V07. Elaboración propia. Prueba retrospectiva secundaria, 2024–septiembre 2025.', fontsize=8)
    fig.tight_layout(rect=(0,.07,1,1))
    fig.savefig(G/'figura_2_comparacion_predictiva.svg')
    fig.savefig(G/'figura_2_comparacion_predictiva.png', dpi=300)
    plt.close(fig)
    ctrl = json.loads((F/'control_integracion.json').read_text(encoding='utf-8'))
    evaluation = json.loads((F/'control_evaluacion_fusion.json').read_text(encoding='utf-8'))
    stability = pd.read_csv(F/'estabilidad_prioridades.csv', dtype={'parroquia':str})
    primary = geo[['nombre','orden_area','orden_social','pc_pnbi','selecciones_sociales_de_6']].sort_values('orden_social').head(13)
    primary = primary.rename(columns={'nombre':'Parroquia','orden_area':'Orden por área','orden_social':'Orden social','pc_pnbi':'NBI (%)','selecciones_sociales_de_6':'Selecciones de 6'})
    compare = models[['modelo','log_score_por_reporte','captura_reportes_top20pct_parroquias']].rename(columns={'modelo':'Modelo','log_score_por_reporte':'Log score por reporte','captura_reportes_top20pct_parroquias':'Captura en 13 parroquias'})
    reconciliation = pd.read_csv(F/'reconciliacion_censo.csv')
    robust = stability[stability.selecciones_sociales_de_6 == 6].nombre.tolist()
    additional = json.loads((F/'referencias_adicionales.json').read_text(encoding='utf-8'))
    old = json.loads((ROOT/'EXPOSICION_FEN_NINO/VERSION_8_REFERENTE_Q1/1_INVESTIGACION/6_FINAL/articulos_metadatos_verificados.json').read_text(encoding='utf-8'))
    # New references are verified Crossref records; preserve prior bibliography as read-only.
    bib = (ROOT/'EXPOSICION_FEN_NINO/VERSION_8_REFERENTE_Q1/1_INVESTIGACION/6_FINAL/referencias_estudios.bib').read_text(encoding='utf-8')
    for key, item in zip(['fox2024','mester2025'], additional):
        authors = ' and '.join(x.get('family','')+', '+x.get('given','') for x in item.get('author',[]))
        year = item.get('published',item.get('issued'))['date-parts'][0][0]
        bib += '\n@article{'+key+',\n  title={'+item['title'][0]+'},\n  author={'+authors+'},\n  year={'+str(year)+'},\n  journal={'+item['container-title'][0]+'},\n  volume={'+item.get('volume','')+'},\n  eid={'+item.get('article-number','')+'},\n  doi={'+item['DOI']+'}\n}\n'
    bib += '\n@article{fox_correccion2025,\n  author={Fox, Sean and Agyemang, Felix and Hawker, Laurence and Neal, Jeffrey},\n  title={Author Correction: Integrating social vulnerability into high-resolution global flood risk mapping},\n  journal={Nature Communications},\n  year={2025},\n  volume={16},\n  eid={1456},\n  doi={10.1038/s41467-025-56676-2}\n}\n'
    (F/'referencias_v09.bib').write_text(bib, encoding='utf-8')
    summary = ('Este estudio desarrolla una priorización territorial de preparación ante lluvias extremas en Quito mediante la integración de pronósticos estacionales, modelos geoespaciales y privaciones sociales. '
        'Se unen 65 parroquias del Censo 2022 municipal con suelo construido WorldCover de 10 m, intensidades de reportes estimadas por una red neuronal y un modelo loglineal, y probabilidades regionales de lluvia. '
        'Una comparación retrospectiva de seis modelos utiliza 88 reportes para ajuste y 100 para evaluación. La incorporación social no mejora el log score frente a la referencia de suelo construido. '
        'Sin embargo, modifica tres de las 13 prioridades en la combinación de redes; Guamaní, Turubamba, La Ecuatoriana y Quitumbe permanecen priorizadas en los seis escenarios de modelo. '
        'La contribución es separar desempeño predictivo y objetivos distributivos, conservar los soportes espaciales y mostrar sensibilidad e incertidumbre conjunta. Las prioridades orientan preparación; no representan superficie inundada futura. Las cantidades censales municipales requieren reconciliación con INEC antes de publicar cifras de población expuesta.')
    abstract = ('This study develops territorial prioritization for preparedness against extreme rainfall in Quito by integrating seasonal forecasts, geospatial models, and social deprivation. '
        'It joins 65 parishes from the municipal 2022 Census with 10 m WorldCover built-up land, reporting intensities estimated by a neural network and a log-linear model, and regional rainfall probabilities. '
        'A retrospective comparison of six models uses 88 reports for fitting and 100 for evaluation. Incorporating social indicators does not improve the log score relative to the built-up land benchmark. '
        'However, it changes three of the 13 priorities in the combination of neural networks; Guamaní, Turubamba, La Ecuatoriana, and Quitumbe remain prioritized in all six model scenarios. '
        'The contribution is to separate predictive performance and distributional objectives, preserve spatial supports, and show sensitivity and joint uncertainty. Priorities guide preparedness; they do not represent future inundated area. Municipal census counts require reconciliation with INEC before publishing exposed population figures.')
    assert len(summary.split()) <= 200 and len(abstract.split()) <= 200
    report = rf'''# Lluvia y prioridades sociales en Quito

Wilson Gustavo Morales Lastra[^autor]

[^autor]: Investigador independiente. Correo: wilson.morales@epn.edu.ec. ORCID: https://orcid.org/0009-0008-3413-3705.

Códigos JEL: C53; Q54; R14.

Versión 9, 2026-10-09. Borrador metodológico con resultados, no certificación de aceptación editorial.

## Resumen

{summary}

## Abstract

{abstract}

## 1. Pregunta, teoría y aporte

La pregunta es qué cambia al preparar territorios para una estación potencialmente húmeda cuando se incorporan carencias sociales, además de lluvia y susceptibilidad geográfica. La hipótesis distributiva es que las mismas amenazas pueden requerir respuestas diferentes cuando varía la capacidad de afrontar interrupciones de vivienda, agua y saneamiento. Esta hipótesis no implica que pobreza deba aumentar la frecuencia de inundación ni que más indicadores mejoren automáticamente los pronósticos.

El antecedente de Canavire-Bacarreza, Puerta-Cuartas y Ramos (2026), *Here comes the rain*, DOI https://doi.org/10.1016/j.worlddev.2026.107468, relaciona anomalías de precipitación con resultados económicos de Ecuador. Nuestra V08 replica su código público y presenta una extensión ENEMDU 2021–2025. Esta V09 añade una capa de preparación territorial; no convierte NBI en pobreza monetaria ni transfiere un coeficiente nacional a cada píxel.

La combinación vulnerabilidad–exposición ya existe en la literatura. Fox et al. (2024) construyen VARI Flood con amenaza fluvial, población y privación; su corrección de 2025 modifica referencias internas a figuras. Mester et al. (2025) relacionan exposición satelital y desplazamientos y consideran predictores sociales. Por ello, el aporte candidato de este proyecto debe demostrarse en la anticipación local, la validación incremental y el valor de decisión. No se reivindica inventar la unión de pobreza y satélites. Véanse https://doi.org/10.1038/s41467-024-47394-2, https://doi.org/10.1038/s41467-025-56676-2 y https://doi.org/10.1038/s41467-025-64015-8.

## 2. Datos, cronología y unidades

Tabla 1. Fuentes y soportes del análisis.

| Fuente | Periodo usado | Soporte | Función |
| --- | --- | --- | --- |
| Municipio de Quito, capa Censo 2022 | Referencia 2022, recuperada 2026-10-09 | 65 polígonos parroquiales | NBI, saneamiento, agua y hacinamiento |
| ESA WorldCover | 2021 | Clasificación nativa 10 m | Denominador construido completo |
| Municipio de Quito, cobertura | 2020 y 2025 | Polígonos rasterizados 10 m | Sensibilidad de cobertura |
| Modelos V05 y SNGR | Entrenamiento hasta 2021, calibración 2022–2023 | Scores geoespaciales y reportes puntuales | Susceptibilidad relativa de reportes |
| Pronósticos V07 | Ajuste hasta 2013, bancos 2014–2016, calibración 2017–2019 | Meteorología 0.05 grados | Estado húmedo/seco regional |
| Comparación de fusión | Ajuste 2022–2023, evaluación 2024–septiembre 2025 | Parroquia × trimestre | Distribución geográfica de reportes |
| Proyección actual | Noviembre 2026–enero 2027 | Misma unión multiescala | Prioridad condicionada |

Fuente: archivos originales y protocolos V05–V09. Elaboración propia.

La fuente municipal se conserva íntegra: https://geoquito.quito.gob.ec/server/rest/services/web_service/s_nbi_porcentaje_personas_con_pobreza_por_nbi_2022/MapServer/2. Sus nombres, códigos, cantidades, porcentajes y geometría se descargaron mediante consulta pública. La consulta pidió generalización de 0.000005 grados, aproximadamente 0.6 m, y seis decimales. Se transformó a EPSG:32717. El archivo `cruce_geometrias_versiones.csv` documenta las intersecciones con la capa parroquial V05; no se unieron nombres por aproximación.

Las capas municipales 2025 omiten suelo construido en nueve parroquias rurales. WorldCover identifica construido en todas las 65 y se eligió como exposición principal tras esta auditoría, mediante la enmienda de cobertura documentada. Clasificar suelo no observa viviendas, habitantes o valores de activos. WorldCover tampoco es un censo de edificios. Se contabilizan {ctrl['construido_WC2021_canton_ha']:.2f} ha en todo el cantón; la alternativa municipal 2025 suma {ctrl['construido2025_canton_ha']:.2f} ha. La diferencia mezcla cobertura y definición, no crecimiento comprobado.

Los universos sociales municipales presentan discrepancias con los microdatos cantonales INEC ya procesados en el lago de datos. No se corrigieron proporcionalmente ni se atribuyó una causa sin documentos.

Tabla 2. Reconciliación de cantidades municipales con Gold INEC.

{table(reconciliation)}
Fuente: Municipio de Quito y microdatos CPV 2022 del lago de datos. Elaboración propia.

Los porcentajes publicados coinciden con sus propios numeradores y denominadores, pero esa coherencia no resuelve la diferencia de versiones. El campo `pobT`, que contiene decimales, no es el universo NBI. Los proxies de personas y hogares permanecen solo como sensibilidad explícitamente no reconciliada. El resultado principal es un índice de prioridad en ha ponderadas, no un conteo oficial de afectados.

## 3. Especificación del modelo y de la decisión

Sea $A_{{pj}}$ el suelo construido de la parroquia $p$ en la celda meteorológica $j$. Sea $S^{{(m)}}_{{pj}}$ su parte por encima del percentil 90 de intensidad territorial del modelo $m$, calculado sobre todo el construido WorldCover del DMQ. Los mapas espaciales usan los scores ya congelados; el umbral es de área y no se ajustó a reportes reservados. Sea $\pi_{{jt}}$ la probabilidad de lluvia trimestral por encima de su percentil histórico 80 y $v_p$ la proporción de personas NBI publicada por parroquia.

$$H^{{(m)}}_{{pt}}=\sum_j S^{{(m)}}_{{pj}}\pi_{{jt}},\qquad I^{{(m)}}_{{pt}}=H^{{(m)}}_{{pt}}v_p.$$

$H$ tiene unidades de ha de prioridad ponderadas por estado pluviométrico. $I$ tiene unidades de ha ponderadas también por NBI. Ninguno es superficie futura inundada. El segundo incorpora una preferencia distributiva; cambiar de objetivo no demuestra mayor exactitud. Agua, saneamiento y hacinamiento se presentan por separado, pues sumarlos a NBI duplicaría privaciones relacionadas sin una función de bienestar justificada.

Para el contraste predictivo, los conteos de reportes por trimestre se modelan como una distribución multinomial condicionada a su total $N_t$:

$$q_{{pt}}=\frac{{A_p\exp(X_{{pt}}\beta)}}{{\sum_r A_r\exp(X_{{rt}}\beta)}}.$$

Se minimiza la log-verosimilitud negativa más $\frac12\sum_k\beta_k^2$, con coeficientes estandarizados usando únicamente el ajuste y penalización L2 igual a 1, fijada en el protocolo. Los comparadores son construido, frecuencia histórica suavizada, lluvia, red territorial, red más lluvia y fusión. La fusión añade NBI, saneamiento, agua, hacinamiento e interacción NBI × lluvia. Se utilizan las mismas parroquias y fechas para todos.

Esta especificación estima cómo se distribuyen los reportes dado su total; no pronostica ese total ni aprende que ausencia de reporte sea ausencia de inundación. La cartografía y el censo no tienen disponibilidad histórica certificada para cada emisión. Los resultados V05/V07 ya se conocían: la prueba adicional es retrospectiva y secundaria, no una reserva completamente ciega.

La incertidumbre climática se examina con 34 campos residuales históricos de 2014–2016, conservando sus ordenamientos espaciales mediante una cópula empírica y las marginales beta-PIT V07. Se comparan también tres fuentes de probabilidad y dos mapas territoriales. Los rangos no incluyen toda la incertidumbre censal, de parámetros, coberturas o susceptibilidad y no tienen garantía de cobertura futura. Los proxies de población requieren localización uniforme supuesta sobre construido; las cotas de Fréchet muestran que conocer los márgenes parroquiales no identifica quién vive en la parte expuesta.

## 4. Resultados

La comparación emplea {evaluation['reportes_ajuste']} reportes en ocho trimestres de ajuste y {evaluation['reportes_evaluacion']} reportes en siete trimestres no solapados de evaluación. No hubo reportes evaluados sin asignación parroquial.

Tabla 3. Comparación predictiva geográfica en la misma muestra.

{table(compare)}
Fuente: SNGR y modelos V05/V07. Elaboración propia. Mayor log score es mejor.

La fusión tiene log score {models.loc[models.modelo=='fusion_social','log_score_por_reporte'].iloc[0]:.4f}, frente a {models.loc[models.modelo=='construido','log_score_por_reporte'].iloc[0]:.4f} del construido. No mejora esta métrica. Captura 44 de los 100 reportes en 13 parroquias, frente a 42 de la referencia, pero los rangos exploratorios remuestreando trimestres no establecen superioridad. No se selecciona la fusión porque su captura puntual sea mayor. La señal ENSO de lluvia regional y la ocurrencia puntual urbana son objetivos distintos.

Figura 1. Vulnerabilidad y prioridades parroquiales.

![Vulnerabilidad y prioridades](GRAFICOS/figura_1_prioridades_parroquiales.png)

Fuente: Municipio de Quito, ESA, V05/V07. Elaboración propia.

Con red ENSO y red territorial, incorporar NBI cambia tres parroquias del grupo de 13: conserva diez seleccionadas por área. Guamaní, Turubamba, La Ecuatoriana y Quitumbe aparecen en las seis combinaciones. La estabilidad es acuerdo entre escenarios, no probabilidad de daño. Los demás órdenes pueden cambiar mucho, como indica `estabilidad_prioridades.csv`. El resultado depende del objetivo y de los modelos; no se usa un escenario único para declarar afectación cierta. El presupuesto de selección es de hasta 13 parroquias: si el pronóstico discretizado no diferencia suficientes índices positivos, no se completan puestos por orden alfabético entre ceros. En climatología más red territorial se seleccionan diez; un cero no establece ausencia de riesgo.

Tabla 4. Prioridades de la combinación de redes para NDJ 2026/2027.

{table(primary)}
Fuente: unión territorial V09. Elaboración propia. Los órdenes son relativos entre 65 parroquias.

Figura 2. Capacidad predictiva de la distribución de reportes.

![Comparación predictiva](GRAFICOS/figura_2_comparacion_predictiva.png)

Fuente: SNGR y modelos V05/V07. Elaboración propia.

## 5. Discusión y siguiente contraste científico

El aporte observado es distinguir territorios prioritarios por equidad de territorios que concentran área expuesta al estado de lluvia. No hay evidencia en esta prueba de que añadir cuatro indicadores sociales mejore la predicción de reportes. Esto orienta el desarrollo: pobreza sirve primero para evaluar necesidades y capacidad de respuesta, no necesariamente para predecir la física de la lluvia.

La actualización cotidiana necesita una etapa meteorológica de baja latencia y validación a esos horizontes. Esta entrega conserva la emisión fija del 2026-10-09 para una estación; ejecutar el código vuelve a producirla, no fabrica un pronóstico diario. El módulo SAR sigue reservado para agua observada y referencias físicas independientes. No se integra una señal SAR todavía insuficientemente validada como si fuera profundidad cierta.

Para la siguiente evaluación, las prioridades y reglas deben quedar congeladas antes de un episodio nuevo. Se debe contrastar exposición física y afectación con observaciones independientes, medir el beneficio bajo un presupuesto o capacidad de respuesta real, reconciliar los indicadores censales y evaluar cambios de bienestar en ENEMDU con su diseño. No se reentrena sobre el test para conseguir resultados favorables. Esa prueba de valor adicional y transferencia daría sustento más sólido a una contribución para revistas competitivas.

## 6. Conclusiones

Se ejecutó la unión de pronóstico, exposición geoespacial y vulnerabilidad social en las 65 parroquias de Quito, conservando ambos modelos territoriales. La comparación encontró que la fusión social no mejora el error central de distribución de reportes, mientras la incorporación de NBI modifica prioridades de preparación. Cuatro parroquias permanecen priorizadas en los seis escenarios. La exposición completa con WorldCover evita tratar vacíos municipales rurales como ausencia de edificios. Las discrepancias de cantidades censales y la validación física pendiente impiden interpretar el índice como afectados futuros. La contribución candidata es una priorización anticipatoria, multiescala y distributiva verificable, no la mayor resolución por sí sola ni una garantía de publicación Q1.

## Bibliografía y reproducibilidad

Canavire-Bacarreza, G., Puerta-Cuartas, A., & Ramos, A. (2026). Here comes the rain: Precipitation shocks and economic outcomes in Ecuador. *World Development, 206*, 107468. https://doi.org/10.1016/j.worlddev.2026.107468

Fox, S., Agyemang, F., Hawker, L., & Neal, J. (2024). Integrating social vulnerability into high-resolution global flood risk mapping. *Nature Communications, 15*, 3155. https://doi.org/10.1038/s41467-024-47394-2

Fox, S., Agyemang, F., Hawker, L., & Neal, J. (2025). Author correction: Integrating social vulnerability into high-resolution global flood risk mapping. *Nature Communications, 16*, 1456. https://doi.org/10.1038/s41467-025-56676-2

Mester, B., Frieler, K., Korup, O., Desai, B., & Schewe, J. (2025). Socioeconomic predictors of vulnerability to flood-induced displacement. *Nature Communications, 16*, 8296. https://doi.org/10.1038/s41467-025-64015-8

Las referencias estructuradas se entregan en `referencias_v09.bib`. Se mantienen las de V08 como antecedentes del proyecto y se añaden los artículos nuevos con DOI y autores verificados mediante Crossref. La corrección Fox et al. (2025) se consultó en la editorial. La consulta es dirigida, no una revisión sistemática completa ni una búsqueda autenticada nueva de Scopus. Las fuentes institucionales y sus fechas se indican en la tabla 1 y `fuentes_y_hashes.json`.

Los CSV son editables; los SVG conservan texto vectorial Arial 8 pt y se acompañan de PNG a 300 dpi. La geometría GeoJSON conserva códigos censales. `EJECUTAR_V09.py` ejecuta en orden descarga/caché, unión geográfica, estimación, prioridades, informe y pruebas. No cambia V05–V08, el lago de datos ni las redes entrenadas. Esta versión reutiliza sus inferencias; no afirma haber entrenado una nueva red GPU.
'''
    (F/'RESULTADOS_INTEGRACION_V09.md').write_text(report, encoding='utf-8')
    qmd = '---\ntitle: "Lluvia y prioridades sociales en Quito"\nlang: es\nformat: docx\n---\n\n'+report
    (F/'MANUSCRITO_INTEGRACION_V09.qmd').write_text(qmd, encoding='utf-8')
    (F/'control_redaccion.json').write_text(json.dumps({'palabras_resumen':len(summary.split()),
        'palabras_abstract':len(abstract.split()), 'palabras_documento_aproximadas':len(report.split()),
        'figuras_vectoriales': 2, 'fuentes_en_tablas_figuras': True,
        'proxies_no_reconciliados_solo_sensibilidad': True}, indent=2), encoding='utf-8')
    print('Informe, QMD, bibliografía y dos figuras vectoriales producidos.', flush=True)


if __name__ == '__main__':
    main()
