"""Pruebas técnicas de integración; no sustituyen validación científica."""
from pathlib import Path
import json
import unittest
import numpy as np
import pandas as pd
from scipy.optimize._numdiff import approx_derivative
from scipy.special import logsumexp
from integrar_territorio import frechet
from evaluar_fusion import fit_conditional

P = Path(__file__).resolve().parents[1]
F = P/'6_FINAL'
D = P/'2_DATOS/PROCESADOS'


class Checks(unittest.TestCase):
    def test_geo_coverage_and_sources(self):
        x = pd.read_csv(F/'territorio_vulnerabilidad_parroquias.csv', dtype={'parroquia':str})
        self.assertEqual(len(x), 65)
        self.assertTrue(x.parroquia.is_unique)
        self.assertTrue((x.construido_WC2021_ha > 0).all())
        # Nueve ceros municipales NO fueron convertidos en ausencia de edificios.
        self.assertEqual(int((x.construido_2025_ha == 0).sum()), 9)

    def test_integer_composite_index(self):
        ids = np.array([1,32,65], dtype=np.uint8).astype(np.int64)
        self.assertEqual((ids*186).tolist(), [186,5952,12090])
        source = (P/'3_MODELOS/integrar_territorio.py').read_text(encoding='utf-8')
        self.assertIn('ids[start:start+int(win.height)].astype(np.int64)', source)

    def test_area_conservation(self):
        x = pd.read_csv(F/'territorio_vulnerabilidad_parroquias.csv')
        with np.load(D/'intersecciones_multiescala.npz') as z:
            for key in ['construido_2025','construido_WC2021','red_WC2021_prioritario','lineal_WC2021_prioritario']:
                np.testing.assert_allclose(x[key+'_ha'], z[key][1:].sum(1)*.01, atol=1e-8)
                self.assertTrue(np.issubdtype(z[key].dtype, np.integer))
        ctrl = json.loads((F/'control_integracion.json').read_text(encoding='utf-8'))
        self.assertGreater(ctrl['construido2025_cubierto_censo_ha']/ctrl['construido2025_canton_ha'], .999)

    def test_census_mismatch_is_not_hidden(self):
        r = pd.read_csv(F/'reconciliacion_censo.csv')
        self.assertEqual(r.diferencia.tolist(), [119116.,23375.,41980.,6954.])
        report = (F/'RESULTADOS_INTEGRACION_V09.md').read_text(encoding='utf-8')
        self.assertIn('No se corrigieron proporcionalmente', report)

    def test_future_no_missing_and_direct_matrix(self):
        p = pd.read_csv(F/'prioridad_social_NDJ2026_2027.csv')
        self.assertEqual(len(p), 65*6)
        self.assertFalse(p.area_prioritaria_bajo_estado_humedo_ponderada_ha.isna().any())
        self.assertTrue((p.indice_social_ha_ponderadas_NBI >= 0).all())
        np.testing.assert_allclose(p.indice_social_ha_ponderadas_NBI,
                                   p.area_prioritaria_bajo_estado_humedo_ponderada_ha*p.nbi_pct/100)
        self.assertTrue(p.fuente_exposicion_principal.str.contains('WorldCover 2021').all())
        P7 = P.parents[1]/'VERSION_7_CALIBRACION_NMME/1_INVESTIGACION'
        weather = pd.read_csv(P7/'6_FINAL/pronostico_calibracion_fija_nov2026_ene2027.csv',dtype={'unit':str})
        weather = weather[(weather.tipo_unidad=='QUITO_CELDA')&(weather.modelo=='red_ENSO__beta_PIT')]
        with np.load(D/'intersecciones_multiescala.npz') as z:
            wet = weather.set_index('unit').reindex(z['unit']).p_humedo.to_numpy()
            independent = z['red_WC2021_prioritario'][1:]@wet*.01
        published = p[(p.modelo_lluvia=='red_ENSO__beta_PIT')&(p.modelo_territorial=='red')]
        np.testing.assert_allclose(published.area_prioritaria_bajo_estado_humedo_ponderada_ha,independent,atol=1e-8)

    def test_frechet_and_proxies(self):
        low, high = frechet(np.array([0,25,75,100]), 40, 60)
        np.testing.assert_array_equal(low, [0,0,15,40])
        np.testing.assert_array_equal(high, [0,25,40,40])
        x = pd.read_csv(F/'prioridad_social_NDJ2026_2027.csv')
        proxy = x.personas_NBI_asignadas_prioridad_humeda_proxy
        self.assertTrue((proxy >= x.personas_NBI_cota_inferior_condicional-1e-7).all())
        self.assertTrue((proxy <= x.personas_NBI_cota_superior_condicional+1e-7).all())

    def test_conditional_estimation(self):
        rng = np.random.default_rng(91)
        X = rng.normal(size=(5,7,2))
        off = rng.normal(size=(5,7))
        y = rng.integers(0,8,size=(5,7)).astype(float)
        b = fit_conditional(X,y,off)
        def loss(beta):
            eta = off+np.einsum('tpv,v->tp',X,beta)
            return -np.sum(y*(eta-logsumexp(eta,axis=1,keepdims=True)))+.5*np.sum(beta**2)
        self.assertLess(float(np.max(np.abs(approx_derivative(loss,b)))), 1e-4)

    def test_report_partitions_and_probabilities(self):
        x = pd.read_csv(F/'evaluacion_fusion_parroquia_trimestre.csv')
        sums = x.groupby(['modelo','trimestre']).proporcion_reportes_prevista.sum()
        np.testing.assert_allclose(sums, 1, atol=1e-10)
        train = set(x.loc[x.particion=='ajuste','trimestre'])
        test = set(x.loc[x.particion=='evaluacion','trimestre'])
        self.assertFalse(train&test)
        self.assertEqual(len(train),8)
        self.assertEqual(len(test),7)
        y = x[x.particion=='evaluacion'].groupby('modelo').reportes_observados.sum()
        self.assertTrue((y==100).all())

    def test_rank_sensitivity_and_zero_ties(self):
        x = pd.read_csv(F/'ranking_prioridades_y_sensibilidades.csv')
        selections = x.groupby(['modelo_lluvia','modelo_territorial']).seleccion_social_top13.sum()
        self.assertTrue((selections <= 13).all())
        self.assertTrue((selections > 0).all())
        self.assertTrue((x.loc[x.seleccion_social_top13==1,'indice_social_ha_ponderadas_NBI'] > 0).all())

    def test_weather_fields_and_document(self):
        x = pd.read_csv(F/'incertidumbre_campos_sociales.csv')
        self.assertEqual(len(x), 65*4)
        self.assertTrue((x.n_campos_historicos_conjuntos == 34).all())
        r = (F/'MANUSCRITO_INTEGRACION_V09.qmd').read_text(encoding='utf-8')
        self.assertNotIn('\x08',r)
        self.assertNotIn('\x0c',r)
        c = json.loads((F/'control_redaccion.json').read_text(encoding='utf-8'))
        self.assertLessEqual(c['palabras_resumen'],200)
        self.assertLess(c['palabras_documento_aproximadas'],10000)
        for p in F.rglob('*'):
            if p.is_file():
                self.assertLess(p.stat().st_size,10000000,p.name)


if __name__ == '__main__':
    unittest.main(verbosity=2)
