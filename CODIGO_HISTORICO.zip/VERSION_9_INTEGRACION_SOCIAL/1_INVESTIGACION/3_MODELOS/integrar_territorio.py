"""Cuenta intersecciones multiescala sin inventar pobreza por píxel.

Los indicadores censales se mantienen por parroquia. Las cifras de población
dentro de áreas prioritarias dependen de una asignación uniforme explícita.
"""
from pathlib import Path
from contextlib import ExitStack
import json
import hashlib
import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from rasterio.features import rasterize
from rasterio.windows import Window
from affine import Affine
from pyproj import Transformer

P = Path(__file__).resolve().parents[1]
ROOT = P.parents[2]
P5 = ROOT/'EXPOSICION_FEN_NINO/VERSION_5_QUITO_10M/1_INVESTIGACION'
P6 = ROOT/'EXPOSICION_FEN_NINO/VERSION_6_ENSO_PREDICTIBILIDAD/1_INVESTIGACION'
P7 = ROOT/'EXPOSICION_FEN_NINO/VERSION_7_CALIBRACION_NMME/1_INVESTIGACION'
D = P/'2_DATOS/PROCESADOS'
F = P/'6_FINAL'
MODEL_NAMES = ['inundacion_red', 'inundacion_lineal']


def frechet(exposed, poor, nonpoor):
    """Cotas de pobres expuestos, condicionado al total expuesto supuesto."""
    return np.maximum(0, exposed-nonpoor), np.minimum(poor, exposed)


def main():
    D.mkdir(parents=True, exist_ok=True)
    F.mkdir(parents=True, exist_ok=True)
    g = gpd.read_file(P/'2_DATOS/ORIGINALES/parroquias_censo2022.geojson').to_crs(32717)
    g.geometry = g.geometry.make_valid()
    g['parroquia'] = g.parroquia.astype(str).str.zfill(6)
    g = g.sort_values('parroquia').reset_index(drop=True)
    assert g.parroquia.is_unique and len(g) == 65
    g['id_censo'] = np.arange(1, len(g)+1)
    n = len(g)+1
    # El universo NBI NO es el campo pobT. Comprobar porcentajes con sus conteos.
    g['personas_universo_nbi'] = g.p_nbi+g.nop_nbi
    g['hogares_universo_nbi'] = g.h_nbi+g.noh_nbi
    validpct = (100*g.p_nbi/g.personas_universo_nbi-g.pc_pnbi).abs().max()
    validh = (100*g.h_nbi/g.hogares_universo_nbi-g.pc_hnbi).abs().max()
    if validpct > 1e-6 or validh > 1e-6:
        raise ValueError('Porcentajes NBI no reconciliados con cantidades')
    official = pd.read_parquet(ROOT/'DATA_LAKE_HOUSE/GOLD/INEC_CENSO_2022/canton/censo_2022.parquet')
    row = official[official.dpa_canton == '1701'].iloc[0]
    totals = [
        ('personas_universo_nbi', 'personas_nbi_valido'),
        ('p_nbi', 'personas_pobres_nbi'),
        ('hogares_universo_nbi', 'hogares_nbi_valido'),
        ('h_nbi', 'hogares_pobres_nbi')]
    checks = []
    for field, ref in totals:
        checks.append({'serie': field, 'suma_capa': float(g[field].sum()),
                       'censo_lago': int(row[ref]),
                       'diferencia': float(g[field].sum()-row[ref])})
    pd.DataFrame(checks).to_csv(F/'reconciliacion_censo.csv', index=False)
    # Se permite documentar divergencia de versión; nunca ajustar cantidades sin fuente.
    overlap = float(g.geometry.area.sum()-g.geometry.union_all().area)
    maskfile = P5/'2_DATOS/PROCESADOS/mascara_quito_10m.tif'
    with rasterio.open(maskfile) as ref:
        ids = rasterize([(geom, int(i)) for geom, i in zip(g.geometry, g.id_censo)],
                        out_shape=(ref.height, ref.width), transform=ref.transform,
                        fill=0, dtype='uint8')
        profile = ref.profile.copy()
        profile.update(dtype='uint8', nodata=0)
        with rasterio.open(D/'parroquias_censo_10m.tif', 'w', **profile) as out:
            out.write(ids, 1)
            out.update_tags(description='Código auxiliar de parroquia; no pobreza observada por píxel')
    gridmeta = json.loads((P6/'2_DATOS/PROCESADOS/grilla_lluvia.json').read_text(encoding='utf-8'))
    cells = gridmeta['cells']
    names = np.array([c['id'] for c in cells])
    grid = np.full((gridmeta['height'], gridmeta['width']), -1, dtype=int)
    for j, c in enumerate(cells):
        grid[c['row'], c['col']] = j
    tr = Affine(*gridmeta['transform'][:6])
    transformer = Transformer.from_crs(32717, 4326, always_xy=True)
    nc = len(cells)
    count = {x: np.zeros((n, nc), dtype=np.int64) for x in
             ['construido_2025', 'construido_WC2021', 'red_prioritario', 'lineal_prioritario',
              'red_WC2021_prioritario', 'lineal_WC2021_prioritario']}
    aggregate = {x: np.zeros(n, dtype=np.int64) for x in
                 ['territorio', 'cobertura_2025', 'construido_2020_comun', 'construido_2025_comun']}
    density = {m: np.zeros(n) for m in MODEL_NAMES}
    built_logs = {m: [] for m in MODEL_NAMES}
    cross = np.zeros((n, 66), dtype=np.int64)
    unmapped = 0
    with ExitStack() as stack:
        def src(path):
            return stack.enter_context(rasterio.open(path))
        mask = src(maskfile)
        oldid = src(P5/'2_DATOS/PROCESADOS/parroquia_municipal_10m.tif')
        c25 = src(P5/'2_DATOS/PROCESADOS/cobertura_municipal_2025_10m.tif')
        c20 = src(P5/'2_DATOS/PROCESADOS/cobertura_municipal_2020_10m.tif')
        wc = src(P5/'2_DATOS/PROCESADOS/worldcover_2021_10m.tif')
        rankings = {m: src(P5/f'6_FINAL/RASTERS_10M/prioridad_{m}_construido.vrt') for m in MODEL_NAMES}
        scores = {m: src(P5/f'2_DATOS/PROCESADOS/log_intensidad_{m}_10m.tif') for m in MODEL_NAMES}
        for start in range(0, mask.height, 128):
            win = Window(0, start, mask.width, min(128, mask.height-start))
            valid = mask.read(1, window=win) == 1
            # Expandir uint8 antes de construir índices compuestos: evita overflow.
            pid = ids[start:start+int(win.height)].astype(np.int64)
            oid = oldid.read(1, window=win).astype(int)
            cross += np.bincount((pid[valid]*66+oid[valid]), minlength=n*66).reshape(n, 66)
            a, b = c20.read(1, window=win), c25.read(1, window=win)
            built = (b == 3)&valid
            built21 = (wc.read(1, window=win) == 50)&valid
            common = (a > 0)&(a < 255)&(b > 0)&(b < 255)&valid
            selected = {'territorio': valid, 'cobertura_2025': (b > 0)&(b < 255)&valid,
                        'construido_2020_comun': common&(a == 3), 'construido_2025_comun': common&(b == 3)}
            for key, use in selected.items():
                aggregate[key] += np.bincount(pid[use], minlength=n)
            union = built|built21
            rr, cc = np.nonzero(union)
            x = mask.transform.c+(cc+.5)*10
            y = mask.transform.f-(start+rr+.5)*10
            lon, lat = transformer.transform(x, y)
            gr = np.floor((lat-tr.f)/tr.e).astype(int)
            gc = np.floor((lon-tr.c)/tr.a).astype(int)
            if (gr < 0).any() or (gc < 0).any() or (gr >= grid.shape[0]).any() or (gc >= grid.shape[1]).any():
                raise ValueError('Coordenadas fuera de grilla de lluvia')
            weatherid = grid[gr, gc]
            if (weatherid < 0).any():
                raise ValueError('Construido sin celda meteorológica')
            p = pid[rr, cc]
            unmapped += int((p == 0).sum())
            keyid = p*nc+weatherid
            selects = {'construido_2025': built[rr, cc], 'construido_WC2021': built21[rr, cc]}
            for model in MODEL_NAMES:
                label = 'red' if model.endswith('red') else 'lineal'
                selects[label+'_prioritario'] = built[rr, cc]&(rankings[model].read(1, window=win)[rr, cc] > 90)
                l = scores[model].read(1, window=win)[built21].astype(float)
                if not np.isfinite(l).all():
                    raise ValueError('Intensidad de modelo sin cobertura')
                density[model] += np.bincount(pid[built21], weights=np.exp(l), minlength=n)
                built_logs[model].append(l)
            for key, use in selects.items():
                count[key] += np.bincount(keyid[use], minlength=n*nc).reshape(n, nc)
        profile = mask.profile.copy()
        # WorldCover cubre también las parroquias rurales omitidas por la capa
        # municipal de construido. Umbral de área, nunca ajustado por reportes.
        thresholds = {m: float(np.quantile(np.concatenate(built_logs[m]), .9)) for m in MODEL_NAMES}
        del built_logs
        for start in range(0, mask.height, 128):
            win = Window(0, start, mask.width, min(128, mask.height-start))
            built21 = (wc.read(1, window=win) == 50)&(mask.read(1, window=win) == 1)
            rr, cc = np.nonzero(built21)
            pid = ids[start:start+int(win.height)].astype(np.int64)[rr,cc]
            x = mask.transform.c+(cc+.5)*10
            y = mask.transform.f-(start+rr+.5)*10
            lon, lat = transformer.transform(x, y)
            weatherid = grid[np.floor((lat-tr.f)/tr.e).astype(int), np.floor((lon-tr.c)/tr.a).astype(int)]
            keyid = pid*nc+weatherid
            for model in MODEL_NAMES:
                label = 'red' if model.endswith('red') else 'lineal'
                use = scores[model].read(1, window=win)[rr,cc] >= thresholds[model]
                count[label+'_WC2021_prioritario'] += np.bincount(keyid[use], minlength=n*nc).reshape(n,nc)
    area = {key: val.sum(1)*.01 for key, val in count.items()}
    table = pd.DataFrame(g.drop(columns='geometry'))
    for key, val in aggregate.items():
        table[key+'_ha'] = val[1:]*.01
    for key, val in area.items():
        table[key+'_ha'] = val[1:]
    for model, val in density.items():
        table['intensidad_media_'+model] = val[1:]/np.maximum(count['construido_WC2021'].sum(1)[1:], 1)
    table['diferencia_pobT_menos_universo_NBI'] = table.pobT-table.personas_universo_nbi
    table['fuente'] = 'Municipio de Quito, Censo 2022 INEC; V05; elaboración propia'
    table.to_csv(F/'territorio_vulnerabilidad_parroquias.csv', index=False)
    crossrows = []
    for pid, oid in zip(*np.nonzero(cross)):
        crossrows.append({'id_censo': pid, 'codigo_censo': g.iloc[pid-1].parroquia if pid else '',
                          'id_municipal_V05': oid, 'area_interseccion_ha': cross[pid, oid]*.01})
    pd.DataFrame(crossrows).to_csv(F/'cruce_geometrias_versiones.csv', index=False)
    np.savez_compressed(D/'intersecciones_multiescala.npz', unit=names,
                        codigo=g.parroquia.to_numpy(dtype=str), **count)
    g[['parroquia','nom_par','id_censo','geometry']].to_crs(4326).to_file(D/'geometria_censal.geojson', driver='GeoJSON')
    projection_rows = []
    neural = pd.read_csv(P7/'6_FINAL/pronostico_calibracion_fija_nov2026_ene2027.csv', dtype={'unit': str})
    neural = neural[(neural.tipo_unidad == 'QUITO_CELDA') & neural.modelo.isin(['red_ENSO__beta_PIT', 'climatologia_calibrada__beta_PIT'])]
    dynamic = pd.read_csv(P7/'6_FINAL/pronostico_NMME_local_nov2026_ene2027.csv', dtype={'unit': str})
    dynamic = dynamic[(dynamic.dominio == 'Quito grilla') & (dynamic.modelo == 'NMME_local__beta_PIT')]
    for metmodel, data in pd.concat([neural, dynamic], ignore_index=True).groupby('modelo'):
        values = data.set_index('unit').reindex(names)
        if values[['p_humedo','p_seco']].isna().any().any():
            raise ValueError('Modelo meteorológico sin soporte completo: '+metmodel)
        for spatial in ['red', 'lineal']:
            spatial_counts = count[spatial+'_WC2021_prioritario'][1:]
            den = count['construido_WC2021'].sum(1)[1:]
            h = spatial_counts@values.p_humedo.to_numpy()/np.where(den > 0, den, np.nan)
            dry = count['construido_WC2021'][1:]@values.p_seco.to_numpy()/np.where(den > 0, den, np.nan)
            p = g.personas_universo_nbi.to_numpy()
            poor = g.p_nbi.to_numpy()
            exp = p*h
            low, high = frechet(exp, poor, g.nop_nbi.to_numpy())
            for j, r in table.iterrows():
                projection_rows.append({'parroquia': r.parroquia, 'nombre': r.nom_par,
                    'modelo_lluvia': metmodel, 'modelo_territorial': spatial,
                    'temporada': '2026-11 a 2027-01', 'fecha_decision': '2026-10-09',
                    'p_humedo_sobre_prioritario': float(spatial_counts[j]@values.p_humedo.to_numpy()/spatial_counts[j].sum()) if spatial_counts[j].sum() else np.nan,
                    'p_seco_promedio_construido': dry[j],
                    'area_prioritaria_bajo_estado_humedo_ponderada_ha': h[j]*den[j]*.01,
                    'proporcion_construido_prioritario_y_humedo_ponderada': h[j],
                    'personas_universo_nbi': p[j], 'personas_NBI': poor[j], 'nbi_pct': r.pc_pnbi,
                    'personas_asignadas_prioridad_humeda_proxy': exp[j],
                    'personas_NBI_asignadas_prioridad_humeda_proxy': poor[j]*h[j],
                    'personas_NBI_cota_inferior_condicional': low[j],
                    'personas_NBI_cota_superior_condicional': high[j],
                    'hogares_saneamiento_insuficiente_asignados_proxy': r.SH*h[j],
                    'hogares_agua_limitada_asignados_proxy': r.FSA*h[j],
                    'hogares_hacinamiento_asignados_proxy': r.HAC*h[j],
                    'unidad_proyeccion': 'prioridad ponderada; no afectados o inundados previstos',
                    'hipotesis_localizacion': 'universos municipales NBI distribuidos uniformemente en construido WorldCover 2021; foto social 2022 fija',
                    'fuente_exposicion_principal': 'ESA WorldCover 2021, 10 m; no interpolación de población'})
    future = pd.DataFrame(projection_rows)
    future.to_csv(F/'prioridad_social_NDJ2026_2027.csv', index=False)
    audit = {'parroquias': len(g), 'crs': 'EPSG:32717', 'tamano_celda_exposicion_m': 10,
             'meteorologia_grados': .05, 'solapamiento_geometria_m2': overlap,
             'area_sin_parroquia_ha': float(cross[0].sum()*.01),
             'construido_sin_parroquia_celdas_union': unmapped,
             'construido2025_canton_ha': float(area['construido_2025'].sum()),
             'construido2025_cubierto_censo_ha': float(area['construido_2025'][1:].sum()),
             'personas_universo_NBI': int(g.personas_universo_nbi.sum()),
             'personas_NBI': int(g.p_nbi.sum()),
             'hogares_universo_NBI': int(g.hogares_universo_nbi.sum()),
             'hogares_NBI': int(g.h_nbi.sum()),
             'max_error_porcentaje_personas': validpct, 'max_error_porcentaje_hogares': validh,
             'nbi_no_es_pobreza_monetaria': True, 'no_crea_probabilidad_inundacion_10m': True,
             'cotas_condicionadas_a_asignacion_espacial_supuesta': True,
             'conteos_sin_geometria_no_se_reasignan': True,
             'reconciliacion': checks}
    audit['umbrales_log_intensidad_decil_construido_WC2021'] = thresholds
    audit['construido_WC2021_canton_ha'] = float(area['construido_WC2021'].sum())
    audit['parroquias_sin_construido_municipal2025'] = table.loc[table.construido_2025_ha == 0, 'nom_par'].tolist()
    audit['parroquias_sin_construido_WC2021'] = table.loc[table.construido_WC2021_ha == 0, 'nom_par'].tolist()
    (F/'control_integracion.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(audit, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
