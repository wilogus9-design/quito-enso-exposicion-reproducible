"""Descarga solo información pública; guarda contenido, metadatos y hashes.

No requiere cuentas ni contraseñas. Los datos originales de versiones previas
se leen sin modificaciones. Una caché existente se reutiliza.
"""
from pathlib import Path
import hashlib
import json
import datetime as dt
import requests
import truststore

P = Path(__file__).resolve().parents[1]
D = P / '2_DATOS/ORIGINALES'
F = P / '6_FINAL'
URL = ('https://geoquito.quito.gob.ec/server/rest/services/web_service/'
       's_nbi_porcentaje_personas_con_pobreza_por_nbi_2022/MapServer/2')
DOIS = ['10.1038/s41467-024-47394-2', '10.1038/s41467-025-64015-8']


def get_cache(file, url, params=None):
    if not file.exists():
        response = requests.get(url, params=params, timeout=50)
        response.raise_for_status()
        payload = response.json()
        if payload.get('error'):
            raise RuntimeError(str(payload['error']))
        file.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    return json.loads(file.read_text(encoding='utf-8'))


def main():
    truststore.inject_into_ssl()
    D.mkdir(parents=True, exist_ok=True)
    F.mkdir(parents=True, exist_ok=True)
    get_cache(D/'metadatos_capa_NBI.json', URL, {'f': 'pjson'})
    data = get_cache(D/'parroquias_censo2022.geojson', URL+'/query', {
        'f': 'geojson', 'where': '1=1', 'outFields': '*',
        'returnGeometry': 'true', 'outSR': '4326', 'resultRecordCount': 2000,
        'geometryPrecision': 6, 'maxAllowableOffset': .000005})
    if len(data.get('features', [])) != 65 or data.get('exceededTransferLimit'):
        raise ValueError('La fuente no devuelve las 65 parroquias completas')
    refs = []
    for doi in DOIS:
        name = doi.rsplit('/', 1)[1]
        refs.append(get_cache(D/(name+'_crossref.json'),
                              'https://api.crossref.org/works/'+doi)['message'])
    (F/'referencias_adicionales.json').write_text(
        json.dumps(refs, ensure_ascii=False, indent=2), encoding='utf-8')
    files = []
    for file in sorted(D.iterdir()):
        if file.is_file():
            files.append({'archivo': file.name, 'bytes': file.stat().st_size,
                          'sha256': hashlib.sha256(file.read_bytes()).hexdigest()})
    audit = {'ejecutado_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
             'fecha_snapshot_version': '2026-10-09',
             'cache_no_actualiza_emision': True,
             'fuente_capa': URL, 'fuente_atributos': 'Municipio de Quito; Censo 2022 INEC',
             'parroquias': len(data['features']), 'archivos': files,
             'fecha_publicacion_capa_no_certificada': True}
    audit['generalizacion_solicitada_grados'] = .000005
    audit['precision_coordenadas_decimales'] = 6
    (F/'fuentes_y_hashes.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Fuente censal recuperada:', len(data['features']), 'parroquias', flush=True)


if __name__ == '__main__':
    main()
