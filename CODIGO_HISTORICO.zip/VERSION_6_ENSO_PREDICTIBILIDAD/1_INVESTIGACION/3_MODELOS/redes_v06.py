"""Redes ENSO y controles en RTX; lectura NumPy sin pandas ni librerías GIS.

Entrenamiento balanceado por fechas/unidades completas. Épocas y semillas
fijadas, checkpoint por 2011-2013. 2014-2019 sólo calibra distribución después.
"""
from pathlib import Path
import json
import copy
import time
import numpy as np
import torch

P=Path(__file__).resolve().parents[1]
D=P/'2_DATOS/PROCESADOS'
F=P/'6_FINAL'


class Red(torch.nn.Module):
    def __init__(self,n):
        super().__init__();self.net=torch.nn.Sequential(torch.nn.Linear(n,64),torch.nn.SiLU(),torch.nn.Linear(64,32),torch.nn.SiLU(),torch.nn.Linear(32,1))
    def forward(self,x):return self.net(x).squeeze(-1)


def main():
    data=np.load(D/'panel_v06.npz');X=data['X'];y=data['z'];valid=data['valid']
    future=np.load(D/'entrada_futura_nov2026.npz')['X']
    if not torch.cuda.is_available():raise RuntimeError('No se detecta GPU CUDA, no fingir entrenamiento RTX')
    device='cuda';torch.set_num_threads(4)
    train=valid&data['train'];tune=valid&data['tune']
    dates=data['months'];years=np.array([int(s[:4]) for s in dates])
    audit=[];output={}
    for label,nf,recent in [('red_sin_ENSO',int(data['n_base']),False),('red_ENSO',X.shape[2],False),('red_ENSO_reciente',X.shape[2],True)]:
        a=X[:,:,:nf][train].astype(np.float32);mu=a.mean(axis=0);sd=a.std(axis=0);sd=np.where(sd>1e-6,sd,1)
        tx=torch.as_tensor((a-mu)/sd,device=device);ty=torch.as_tensor(y[train].astype(np.float32),device=device)
        vx=torch.as_tensor((X[:,:,:nf][tune]-mu)/sd,device=device);vy=torch.as_tensor(y[tune].astype(np.float32),device=device)
        weights=np.broadcast_to(2.**((years-2010)/10) if recent else np.ones(len(years)),y.shape)[train].astype(np.float32)
        weights/=weights.mean();tw=torch.as_tensor(weights,device=device)
        predictions=[];pf=[]
        ok=np.isfinite(X[:,:,:nf]).all(axis=2)
        for seed in [6101,6102,6103]:
            begin=time.time();torch.manual_seed(seed);np.random.seed(seed)
            model=Red(nf).to(device);opt=torch.optim.AdamW(model.parameters(),lr=.002,weight_decay=.01)
            best=float('inf');checkpoint=None;epochbest=None
            for epoch in range(160):
                model.train();indices=torch.randperm(len(tx),device=device)
                for ids in indices.split(32768):
                    opt.zero_grad();err=model(tx[ids])-ty[ids]
                    loss=(err.square()*tw[ids]).mean();loss.backward();opt.step()
                if epoch%5==0 or epoch==159:
                    model.eval()
                    with torch.no_grad():score=float((model(vx)-vy).abs().mean().item())
                    if score<best:best=score;checkpoint=copy.deepcopy(model.state_dict());epochbest=epoch
            model.load_state_dict(checkpoint);model.eval()
            pred=np.full(y.shape,np.nan,dtype=np.float32)
            with torch.no_grad():
                chunks=[]
                allx=(X[:,:,:nf][ok]-mu)/sd
                for start in range(0,len(allx),32768):chunks.append(model(torch.as_tensor(allx[start:start+32768],device=device)).cpu().numpy())
                pred[ok]=np.concatenate(chunks)
                fut=model(torch.as_tensor((future[:,:nf]-mu)/sd,dtype=torch.float32,device=device)).cpu().numpy()
            predictions.append(pred);pf.append(fut)
            torch.save({'state_dict':checkpoint,'mu':torch.as_tensor(mu),'sd':torch.as_tensor(sd),'n_features':nf,'label':label,'seed':seed},D/f'{label}_{seed}.pt')
            record={'modelo':label,'seed':seed,'best_epoch':epochbest,'mae_tune_z':best,'segundos':round(time.time()-begin,2),
                    'device':torch.cuda.get_device_name(0),'torch':torch.__version__,'test_para_seleccion':False}
            audit.append(record);print(json.dumps(record,ensure_ascii=False),flush=True)
        output[label]=np.mean(np.stack(predictions),axis=0);output[label+'_future']=np.mean(np.stack(pf),axis=0)
    np.savez_compressed(D/'predicciones_redes.npz',**output)
    (F/'entrenamiento_RTX_V06.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')


if __name__=='__main__':main()
