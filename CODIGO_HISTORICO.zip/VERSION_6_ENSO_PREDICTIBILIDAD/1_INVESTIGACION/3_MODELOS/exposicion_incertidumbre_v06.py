"""Cruce multiescala y propagación conjunta de residuos espaciales.

La exposición ponderada es a un estado de lluvia regional, no a agua física.
Cada realización usa un campo residual de una misma fecha histórica; no crea
millones de hogares independientes ni reduce la incertidumbre por tener píxeles.
"""
from pathlib import Path
import json
from contextlib import ExitStack
import numpy as np
import pandas as pd
import rasterio
from rasterio.windows import Window
from affine import Affine
from pyproj import Transformer

P=Path(__file__).resolve().parents[1]
ROOT=P.parents[2]
D=P/'2_DATOS/PROCESADOS'
F=P/'6_FINAL'
OLD=ROOT/'EXPOSICION_FEN_NINO/VERSION_5_QUITO_10M/1_INVESTIGACION'


def main():
    units=pd.read_csv(D/'unidades.csv',dtype={'unit':str});native=units[units.type=='QUITO_CELDA'].copy()
    g=json.loads((D/'grilla_lluvia.json').read_text(encoding='utf-8'));tr=Affine(*g['transform'][:6]);h,w=g['height'],g['width']
    local={str(c['id']):i for i,c in enumerate(g['cells'])}
    grid=np.full((h,w),-1,dtype=np.int32)
    for c in g['cells']:grid[c['row'],c['col']]=local[c['id']]
    count=np.zeros(len(native),dtype=np.int64);parishcount=np.zeros((66,len(native)),dtype=np.int64)
    critical={name:np.zeros(len(native),dtype=np.int64) for name in ['inundacion_lineal','inundacion_red','deslizamiento_lineal','deslizamiento_red']}
    project=Transformer.from_crs(32717,4326,always_xy=True)
    unmapped=0
    with ExitStack() as stack:
        land=stack.enter_context(rasterio.open(OLD/'2_DATOS/PROCESADOS/cobertura_municipal_2025_10m.tif'))
        mask=stack.enter_context(rasterio.open(OLD/'2_DATOS/PROCESADOS/mascara_quito_10m.tif'))
        parish=stack.enter_context(rasterio.open(OLD/'2_DATOS/PROCESADOS/parroquia_municipal_10m.tif'))
        layers={name:stack.enter_context(rasterio.open(OLD/f'6_FINAL/RASTERS_10M/prioridad_{name}_construido.vrt')) for name in critical}
        for row in range(0,land.height,128):
            win=Window(0,row,land.width,min(128,land.height-row));b=(land.read(1,window=win)==3)&(mask.read(1,window=win)==1)
            rr,cc=np.nonzero(b)
            if not len(rr):continue
            x=land.transform.c+(cc+.5)*10;y=land.transform.f-(row+rr+.5)*10
            lon,lat=project.transform(x,y);col=np.floor((lon-tr.c)/tr.a).astype(int);r=np.floor((lat-tr.f)/tr.e).astype(int)
            code=grid[r,col];valid=code>=0;unmapped+=int((~valid).sum())
            count+=np.bincount(code[valid],minlength=len(count))
            par=parish.read(1,window=win)[rr,cc].astype(int)
            parishcount+=np.bincount(par[valid]*len(count)+code[valid],minlength=66*len(count)).reshape(66,len(count))
            for name,src in layers.items():
                sel=valid&(src.read(1,window=win)[rr,cc]>90)
                critical[name]+=np.bincount(code[sel],minlength=len(count))
    if unmapped:raise ValueError('Construido sin celda meteorológica: '+str(unmapped)+'; no sustituir por cero')
    area=count*.01
    pd.DataFrame({'unit':native.unit.to_numpy(),'area_construida_ha':area,**{k+'_decil_ha':v*.01 for k,v in critical.items()}}).to_csv(F/'denominador_exposicion_nativo.csv',index=False)
    np.savez_compressed(D/'denominadores_area.npz',count=count,parishcount=parishcount,**critical)
    current=pd.read_csv(F/'pronostico_actualizado_nov2026_ene2027.csv');original=pd.read_csv(F/'pronostico_estacional_nov2026_ene2027.csv')
    estimates=pd.concat([current,original],ignore_index=True);estimates=estimates[estimates.tipo_unidad=='QUITO_CELDA']
    # Rain probabilities are published at native ~5 km, not in a fake 10 m raster.
    rasterdir=F/'RASTERS_REGIONALES';rasterdir.mkdir(parents=True,exist_ok=True)
    par=pd.read_csv(OLD/'6_FINAL/exposicion_parroquias_quito.csv')
    records=[]
    for model,group in estimates.groupby('modelo'):
        ordered=group.set_index('unit').reindex(native.unit)
        for variable in ['p_seco','p_humedo']:
            values=ordered[variable].to_numpy();a=np.full((h,w),-9999,dtype=np.float32)
            for c in g['cells']:a[c['row'],c['col']]=values[local[c['id']]]
            file=rasterdir/f'{model}_{variable}_nov2026_ene2027.tif'
            with rasterio.open(file,'w',driver='GTiff',height=h,width=w,count=1,dtype='float32',crs=4326,transform=tr,nodata=-9999,compress='deflate') as out:
                out.write(a,1);out.set_band_description(1,'probabilidad_estado_lluvia_regional_NO_inundacion')
                out.update_tags(model=model,start='2026-11',end='2027-01',native_degree=.05,not_pixel_flood_probability='true',experimental='true')
        for _,p in par.iterrows():
            pid=int(p.id_municipal);weights=parishcount[pid]*.01;den=weights.sum()
            records.append({'id_municipal':pid,'parroquia':p.parroquia,'modelo':model,'area_construida_ha':den,
                'area_ponderada_condicion_humeda_ha':float(weights@ordered.p_humedo.to_numpy()),
                'area_ponderada_condicion_seca_ha':float(weights@ordered.p_seco.to_numpy()),
                'p_humedo_promedio_area':float(weights@ordered.p_humedo.to_numpy()/den) if den else np.nan,
                'p_seco_promedio_area':float(weights@ordered.p_seco.to_numpy()/den) if den else np.nan,
                'interpretacion':'exposición a condición regional; NO hectáreas inundadas ni daños',
                'origen_lluvia':'0.05 grados','origen_exposicion':'Municipio Quito 2025 rasterizado 10 m'})
    pd.DataFrame(records).to_csv(F/'exposicion_climatica_parroquias.csv',index=False)
    # Joint draws preserve spatial dependence across cells sharing calibration dates.
    with np.load(D/'panel_v06.npz') as file:data={k:file[k] for k in file.files}
    future=np.load(D/'entrada_futura_nov2026.npz');res=np.load(D/'bancos_residuos_calibracion.npz')
    states=json.loads((D/'parametros_rolling_2026.json').read_text(encoding='utf-8'))
    pred0=np.load(D/'predicciones_ridge.npz');pred1=np.load(D/'predicciones_redes.npz')
    joint=[];rng=np.random.default_rng(6109);draws_saved={}
    for model in ['ridge_sin_ENSO','ridge_ENSO','red_sin_ENSO','red_ENSO','red_ENSO_reciente','rolling_ridge_sin_ENSO','rolling_ridge_ENSO']:
        draws=[];bankdates=None
        for u in native.index:
            if model.startswith('rolling'):
                st=states[model+'_'+str(u)];nf=len(st['beta'])
                pred=((future['X'][u,:nf]-np.array(st['mu']))/np.array(st['sd']))@np.array(st['beta'])+st['intercept']
                residual=np.array(st['residual']);dates=st['cal_months']
            else:
                pred=pred0[model+'_future'][u] if model.startswith('ridge') else pred1[model+'_future'][u]
                residual=res[model+'_'+str(u)];dates=data['months'][data['cal']&data['valid'][u]].tolist()
            if bankdates is None:bankdates=dates
            elif bankdates!=dates:raise ValueError('Residuos desalineados; no simular coherencia espacial')
            draws.append(np.maximum(np.expm1(future['mu'][u]+future['sd'][u]*(pred+residual)),0))
        values=np.stack(draws);draws_saved[model]=values
        for event in ['humedo','seco']:
            threshold=future['q80'][native.index.to_numpy()] if event=='humedo' else future['q20'][native.index.to_numpy()]
            indicator=values>threshold[:,None] if event=='humedo' else values<threshold[:,None]
            for domain,aa in [('construido_dmq',area),*[(k+'_decil',v*.01) for k,v in critical.items()]]:
                coherent=aa@indicator
                # Comparison benchmark deliberately destroys correlation, not the production result.
                randomindex=rng.integers(0,indicator.shape[1],size=(len(aa),5000))
                independent=(aa[:,None]*np.take_along_axis(indicator,randomindex,axis=1)).sum(axis=0)
                lo,hi=np.quantile(coherent,[.1,.9]);ilo,ihi=np.quantile(independent,[.1,.9])
                joint.append({'modelo':model,'estado_lluvia':event,'dominio_exposicion':domain,
                    'area_ponderada_media_ha':float(coherent.mean()),'rango80_campos_conjuntos_inf_ha':float(lo),
                    'rango80_campos_conjuntos_sup_ha':float(hi),'rango80_independencia_inf_ha':float(ilo),
                    'rango80_independencia_sup_ha':float(ihi),'n_campos_conjuntos':indicator.shape[1],
                    'definicion':'suelo bajo condición pluviométrica; NO superficie inundada',
                    'incertidumbre':'residuos históricos coherentes; no incertidumbre completa ni cobertura garantizada',
                    'ultimo_predictor':'2026-08','temporada':'2026-11 a 2027-01'})
    np.savez_compressed(D/'campos_lluvia_condicionados_futuros.npz',**draws_saved)
    pd.DataFrame(joint).to_csv(F/'incertidumbre_exposicion_campos_conjuntos.csv',index=False)
    meta={'area_construida_ha':float(area.sum()),'celdas_meteo':len(area),'pixel_exposicion_m':10,'pixel_lluvia_grados':.05,
          'construido_sin_asignacion_meteo':unmapped,'residuos_alineados_por_fecha':True,
          'no_usa_independencia_por_pixel_para_incertidumbre':True,'rango_no_es_intervalo_validado_futuro':True,
          'no_inundacion':True,'no_dolares':True,'no_sequia_hidrologica':True}
    (F/'control_exposicion_v06.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(meta,ensure_ascii=False),flush=True)
    print(pd.DataFrame(joint).query('dominio_exposicion=="construido_dmq" and estado_lluvia=="humedo"')[['modelo','area_ponderada_media_ha','rango80_campos_conjuntos_inf_ha','rango80_campos_conjuntos_sup_ha']].to_string(index=False),flush=True)


if __name__=='__main__':main()
