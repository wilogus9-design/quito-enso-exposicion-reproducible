"""Completa catálogo público y semántica de anomalías. No ejecuta código remoto."""
from pathlib import Path
import requests
import truststore
import json
import xml.etree.ElementTree as ET

P=Path(__file__).resolve().parents[1]
R=P/'2_DATOS/ORIGINALES/INSTRUMENTAL'
F=P/'6_FINAL'


def main():
    truststore.inject_into_ssl()
    j=json.loads((R/'inamhi_catalogo_api.txt').read_text(encoding='utf-8'));items=j['resources'];url=j['links']['next'];page=2
    while url:
        file=R/f'inamhi_catalogo_pagina{page}.json'
        if file.exists():j=json.loads(file.read_text(encoding='utf-8'))
        else:
            r=requests.get(url,timeout=(15,45));r.raise_for_status();j=r.json();file.write_text(json.dumps(j,ensure_ascii=False),encoding='utf-8')
        items+=j['resources'];url=j['links']['next'];page+=1
    summary=[{'title':a.get('title'),'type':a.get('resource_type'),'url':a.get('detail_url'),'layer':a.get('alternate'),'abstract':a.get('abstract')} for a in items]
    (F/'catalogo_publico_inamhi.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    url='https://geoservicios.inamhi.gob.ec/geoserver/ows'
    response=requests.get(url,params={'service':'WFS','request':'DescribeFeatureType','version':'2.0.0','typeNames':'geonode:anomalias_05oct2026'},timeout=(15,45));response.raise_for_status()
    (R/'anomalias_descripcion.xml').write_bytes(response.content)
    root=ET.fromstring(response.content)
    fields=[dict(e.attrib) for e in root.findall('.//{http://www.w3.org/2001/XMLSchema}element')]
    print('Recursos públicos',len(summary),flush=True)
    print('Campos de anomalías',json.dumps(fields,ensure_ascii=False),flush=True)
    print('Recursos distintos de mapas de anomalías:',json.dumps([a for a in summary if 'anomali' not in str(a['title']).lower()],ensure_ascii=False),flush=True)


if __name__=='__main__':main()
