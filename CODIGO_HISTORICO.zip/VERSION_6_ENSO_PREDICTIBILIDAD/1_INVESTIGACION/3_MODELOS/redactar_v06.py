"""Manuscrito y resultados desde estimaciones ejecutadas, conservando comparadores."""
from pathlib import Path
import json
import pandas as pd

P=Path(__file__).resolve().parents[1]
D=P/'2_DATOS/PROCESADOS';F=P/'6_FINAL'


def main():
    s=pd.read_csv(F/'evaluacion_principal.csv');rolling=pd.read_csv(F/'evaluacion_rolling_2011_2025.csv')
    common=pd.read_csv(F/'comparacion_actualizacion_muestra_comun.csv')
    forecasts=pd.read_csv(F/'pronostico_actualizado_nov2026_ene2027.csv');expo=pd.read_csv(F/'exposicion_climatica_parroquias.csv')
    joint=pd.read_csv(F/'incertidumbre_exposicion_campos_conjuntos.csv')
    refs=json.loads((F/'referencias_verificadas.json').read_text(encoding='utf-8'))
    names={'climatologia':'Climatología','climatologia_calibrada':'Climatología calibrada','ridge_sin_ENSO':'Ridge sin ENSO','ridge_ENSO':'Ridge con ENSO',
           'red_sin_ENSO':'Red sin ENSO','red_ENSO':'Red con ENSO','red_ENSO_reciente':'Red ENSO reciente',
           'rolling_climatologia':'Climatología actualizada','rolling_ridge_sin_ENSO':'Ridge actualizado sin ENSO','rolling_ridge_ENSO':'Ridge actualizado ENSO'}
    title='ENSO y decisiones ante riesgos de lluvia en Ecuador'
    summary=('Evaluamos cuándo la información ENSO mejora la anticipación de exceso y déficit estacional de lluvia y su utilidad para preparar decisiones territoriales. '
        'Integramos 548 meses de precipitación, índices oceánicos, 218 cantones y 186 celdas meteorológicas de Quito con exposición construida en una grilla de 10 m. '
        'Comparamos climatología, regresiones regularizadas y redes con y sin ENSO, separando ajuste, selección, calibración y evaluación. '
        'En Quito, incorporar ENSO reduce 15.26 % el CRPS de la red frente a su equivalente sin ENSO en 2020-2025, aunque la climatología conserva menor error global. '
        'Un análisis anual adicional de 2011-2025 muestra una mejora pequeña del modelo actualizado con ENSO frente a climatología en Quito. '
        'Las mejoras predictivas no garantizan superar una estrategia constante de preparación; el valor depende del comparador y del costo supuesto. '
        'La propagación conjunta de residuos modifica sustancialmente la incertidumbre de exposición respecto a asumir celdas independientes. '
        'La contribución es un procedimiento reproducible que evalúa información ENSO, decisiones y exposición sin confundir la resolución del clima con la del suelo construido.')
    abstract=('We evaluate when ENSO information improves anticipation of seasonal rainfall excess and deficit and its usefulness for preparing territorial decisions. '
        'We integrate 548 months of precipitation, ocean indices, 218 cantons and 186 meteorological cells in Quito with built land exposure on a 10 m grid. '
        'We compare climatology, regularized regressions and networks with and without ENSO, separating fitting, selection, calibration and evaluation. '
        'In Quito, including ENSO reduces the network CRPS by 15.26 % relative to its equivalent without ENSO in 2020-2025, although climatology retains lower overall error. '
        'An additional annual analysis for 2011-2025 shows a small improvement of the updated ENSO model over climatology in Quito. '
        'Predictive improvements do not guarantee outperforming a constant preparedness strategy; value depends on the comparator and assumed cost. '
        'Joint residual propagation substantially changes exposure uncertainty relative to assuming independent cells. '
        'The contribution is a reproducible procedure that evaluates ENSO information, decisions and exposure without confusing climate resolution with built land resolution.')
    if len(summary.split())>200:raise ValueError('Resumen excede máximo')
    blocks=[{'tipo':'titulo','texto':title},{'tipo':'autor','texto':'Wilson Gustavo Morales Lastra','nota':'Investigador independiente. wilson.morales@epn.edu.ec. ORCID https://orcid.org/0009-0008-3413-3705.'},
      {'tipo':'texto','texto':'Códigos JEL: C53; Q54; R14'},{'tipo':'titulo_seccion','texto':'Resumen'},{'tipo':'texto','texto':summary},
      {'tipo':'titulo_seccion','texto':'Abstract'},{'tipo':'texto','texto':abstract}]
    def heading(t):blocks.append({'tipo':'titulo_seccion','texto':t})
    def para(t):blocks.append({'tipo':'texto','texto':t})
    def table(t,h,r,n):blocks.append({'tipo':'tabla','titulo':t,'encabezados':h,'filas':r,'nota':n})
    def fig(t,file,n):blocks.append({'tipo':'figura','titulo':t,'archivo':'GRAFICOS/'+file+'.png','nota':n})
    heading('Introducción')
    para('La información climática adquiere utilidad práctica cuando cambia una decisión y sus consecuencias esperadas. Un índice ENSO informativo puede mejorar un modelo respecto a otro sin ese índice y, aun así, no superar climatología en todos los territorios. El objetivo de este estudio es identificar esas diferencias para precipitación estacional y documentar cómo se trasladan a la exposición construida de Quito sin introducir precisión espacial inexistente.')
    para('La discusión del Climate Prediction Center (CPC), perteneciente a la National Oceanic and Atmospheric Administration (NOAA), de 8 de octubre de 2026 anticipa un El Niño fuerte a muy fuerte hasta enero-marzo de 2027. Esta motivación no determina la lluvia local. Niño 1+2, Niño 3.4 y la estacionalidad expresan relaciones regionales diferentes; el Relative Oceanic Niño Index (RONI) utilizado para la discusión oficial no se intercambia numéricamente con anomalías OISST mensuales. Presentamos una aplicación totalmente futura para noviembre de 2026 a enero de 2027 con observaciones predictoras disponibles hasta agosto de 2026.')
    para('Recalde-Coronel, Barnston y Muñoz (2014) ya documentan predicción estacional ecuatoriana. Paliz Acosta, Rodríguez de Fonseca y Losada Doval (2026) muestran cambios de teleconexión y extremos. Por ello, la contribución no es incluir ENSO por primera vez. Evaluamos conjuntamente su aporte incremental, la calidad de distribuciones completas, la utilidad costo-pérdida y la propagación multiescala de exposición con dependencia espacial. El trabajo complementa cartografías de agua observada con SAR, como Misra y colaboradores (2025), pero no estima su misma variable ni compara indebidamente sus exactitudes.')
    heading('Datos y unidades de análisis')
    table('Tabla 1 Fuentes períodos y resolución',['Fuente','Período','Unidad o soporte','Uso'],[
        ['CHIRPS3 cantonal','1981-01 a 2026-08','548 meses; 218 cantones continentales','Objetivo y antecedentes de lluvia'],
        ['CHIRPS3 Quito nativo','1981-01 a 2026-08','186 celdas; 0.05 grados','Pronóstico regional dentro del DMQ'],
        ['NOAA OISST','1982-01 a 2026-08 en predictores','Anomalías Niño 1+2, 3.4 y 4 en °C','Información ENSO atrasada'],
        ['Municipio Quito','Cobertura de suelo 2025','Clase construida; grilla de salida 10 m','Exposición clasificada'],
        ['Prioridades V05','Reportes 2010 a 2025-09','Modelos de localizaciones a 10 m','Cruce secundario con decil construido'],
        ['NOAA e INAMHI','Catálogos recuperados 2026-10','Estaciones y capas públicas','Búsqueda de verificación instrumental']
    ],'Fuente: elaboración propia con los proveedores indicados. CHIRPS3: Climate Hazards Center Infrared Precipitation with Stations versión 3. OISST: Optimum Interpolation Sea Surface Temperature. DMQ: Distrito Metropolitano de Quito. Galápagos no forma parte de los 218 cantones.')
    para('CHIRPS3 DAILY_RNL reparte totales pentadales mediante ERA5. Se utilizan sólo acumulados mensuales con todos los días; en cantones se exige cobertura de área mínima 0.99. El conjunto de Quito se recupera en la grilla nativa, comprobando conteos diarios por mes. No se usa la media cantonal como etiqueta de un píxel meteorológico ni se reduce lluvia a 10 m. La exposición construida municipal dentro de la grilla suma 44481.38 ha; no equivale a número de hogares, edificios o población.')
    para('El análisis principal incluye 404 unidades de soporte diferente: 218 cantones y 186 celdas meteorológicas. Los modelos locales se ajustan por unidad. Las redes agrupan unidades con coordenadas, región y un indicador de soporte. La inferencia preserva años y lugares relacionados; 28280 filas del test no son 28280 realizaciones climáticas independientes. La densidad construida y las prioridades de localizaciones de V05 se conservan como exposición y contexto, no como verdad física de agua.')
    heading('Especificación de predicción')
    para('El objetivo es el acumulado de tres meses desde el mes t. Se transforma a una anomalía logarítmica estacional estandarizada por unidad y mes de inicio. Los umbrales de condición seca y húmeda son respectivamente P20 y P80 de temporadas de entrenamiento con el mismo mes de inicio. Representan condiciones relativas del acumulado estacional, no tormentas instantáneas ni sequía hidrológica.')
    blocks.append({'tipo':'ecuacion','id':'temporada','qmd':r'Y_{u,t}=P_{u,t}+P_{u,t+1}+P_{u,t+2},\quad z_{u,t}=\frac{\log(1+Y_{u,t})-\mu_{u,m(t)}}{\sigma_{u,m(t)}}'})
    para('Se comparan seis modelos fijados antes del ajuste: climatología empírica, ridge sin ENSO, ridge con ENSO, red sin ENSO, red con ENSO y red con ENSO ponderada por recencia de media vida diez años. Las entradas más recientes pertenecen a t-3. Incluyen lluvia de ese mes, acumulado antecedente, misma temporada del año anterior, estación y tendencia. ENSO incorpora estados, medias, cambios, contraste entre Niño 1+2 y 3.4 e interacciones estacionales. No se utilizan estandarizaciones NOAA antiguas calculadas con toda la muestra.')
    para('Ridge se regulariza con lambda 1, 10 o 100, elegido por error absoluto de validación. La red tiene dos capas SiLU de 64 y 32 unidades y salida escalar; usa AdamW, learning rate 0.002, weight decay 0.01, máximo 160 épocas y checkpoint cada cinco épocas. Se entrenan tres semillas por variante en una NVIDIA GeForce RTX 5070 Laptop GPU. Los residuos para la distribución predictiva provienen exclusivamente de calibración, después de fijar el modelo.')
    para('Entrenamiento comprende temporadas que terminan hasta diciembre de 2010; selección, temporadas dentro de 2011-2013; calibración, dentro de 2014-2019; test, dentro de 2020-2025. Se excluyen temporadas que atraviesan cortes. La lluvia es una serie revisada recuperada en 2026; el rezago conservador no reconstruye todas las versiones disponibles históricamente. Esta es una evaluación retrospectiva y secundaria de datos previamente consultados, no una prueba ciega ni garantía de desempeño operacional.')
    heading('Evaluación y decisiones')
    para('Evaluamos error absoluto, Continuous Ranked Probability Score (CRPS), Brier para condiciones seca/húmeda, cobertura y amplitud del rango central de 80 %. CRPS y Brier puntúan distribuciones y probabilidades, conforme al marco de Gneiting y Raftery (2007). La inferencia principal remuestrea 2000 veces años completos y conserva todos los lugares y temporadas de un año, con sólo seis bloques anuales. Se publican las comparaciones regionales completas, incluidos deterioros.')
    para('El modelo costo-pérdida define una pérdida normalizada L=1, costo de preparación C, eficacia e y una acción cuando la probabilidad del evento supera C/e. El costo realizado combina el costo de actuar con la fracción de pérdida no evitada. Se compara con decisiones de climatología y un referente que conoce el resultado. Los cocientes C/L entre 0.05 y 0.50 y eficacias 1 y 0.5 son supuestos, no costos de obras o daños observados. Se conserva toda la curva; el valor depende de la decisión y no equivale a mejorar cada puntuación estadística.')
    para('Una auditoría posterior añadió climatología calibrada con las mismas anomalías 2014-2019 que usan los bancos de residuos, pero sin predictores ni ENSO. También se compara con la mejor acción constante en la muestra, mínimo entre siempre y nunca preparar. Este último es un referente de verificación ex post; la frecuencia futura no es conocida al emitir. Las dos auditorías no cambian la comparación inicial de redes ni se presentan como hipótesis registradas originalmente.')
    heading('Resultados principales')
    table('Tabla 2 Evaluación principal de Quito',['Modelo','CRPS mm','Brier seco','Brier húmedo','Cobertura 80 %'],[
        [names[r.modelo],f'{r.crps:.2f}',f'{r.brier_seco:.4f}',f'{r.brier_humedo:.4f}',f'{100*r.cobertura80:.2f}'] for _,r in s[s.dominio=='Quito canton'].iterrows()
    ],'Fuente: elaboración propia. 70 temporadas de inicio 2020-2025, conservando sólo aquellas cuyo final pertenece al corte. Un CRPS o Brier menor indica mejor desempeño. Cobertura no implica validación de inundación.')
    para('En Quito la red con ENSO obtiene CRPS de 45.14 mm frente a 53.26 mm sin ENSO, reducción de 15.26 %. La diferencia emparejada es -8.13 mm con intervalo exploratorio por años de -16.42 a -1.53 mm. Sin embargo, la climatología obtiene 40.95 mm. Ambas comparaciones son necesarias: ENSO aporta al competidor neuronal evaluado, pero ese aporte no permite afirmar que la red sea el mejor pronóstico global.')
    para('El patrón es heterogéneo. En la Amazonía el ridge con ENSO mejora CRPS 6.82 % respecto a climatología, mientras en la Costa lo empeora 16.31 % en la prueba principal. Los promedios no autorizan imponer un mismo signo o beneficio a todo Ecuador. En la prueba de Quito, la red con ENSO alcanza valor relativo 0.246 frente a decisiones de las climatologías previas para preparar ante déficit con C/L=0.20 y eficacia 1. Este es valor potencial bajo los supuestos y muestra evaluados, no ahorro realizado de 24.6 % ni pérdida monetaria atribuida al fenómeno.')
    decisions=pd.read_csv(F/'valor_decision_normalizado.csv')
    chosen=decisions[(decisions.dominio=='Quito canton')&(decisions.modelo=='red_ENSO')&(decisions.evento_pluviometrico=='seco')&(decisions.eficacia_supuesta==1)&(decisions.C_sobre_L==.20)&(decisions.referencia=='mejor_accion_constante_muestra')].iloc[0]
    para(f'Al utilizar la mejor acción constante como referencia, el valor de esa misma red y decisión de Quito es {chosen.valor_relativo:.3f}. El cambio de referente altera la interpretación: una mejora frente a una climatología histórica no asegura un beneficio de discriminar episodios por encima de una política constante. Se publican las curvas contra las tres referencias y ambas eficacias, sin seleccionar sólo una comparación favorable.')
    fig('Figura 1 Habilidad probabilística y aporte incremental ENSO','habilidad_y_aporte_ENSO','Fuente: elaboración propia. La mejora frente a climatología y la diferencia frente al mismo modelo sin ENSO son comparaciones diferentes. Intervalos exploratorios con seis años, no independencia entre píxeles.')
    fig('Figura 2 Valor de decisiones sobre condiciones estacionales','valor_decision_enso','Fuente: elaboración propia. Referencia mejor acción constante en la muestra y eficacia supuesta 100 %. L y C están normalizados; no se calcularon dólares o daños físicos. Los archivos incluyen también referencias climatológicas previas.')
    heading('Actualización anual y episodios adicionales')
    para('Después de examinar la prueba principal se registró una extensión exploratoria, que no la reemplaza. Para cada año objetivo se ajusta un ridge con los veinte años que terminan siete años antes; los tres siguientes seleccionan regularización y los tres anteriores al objetivo calibran residuos. No se usan resultados de ese año al ajustarlo. Se comparan los mismos meses de inicio enero-octubre entre modelos, y se amplía el recorrido a 2011-2025 para incluir otros episodios. La referencia estacional fija 1983-2010 está observada antes de 2011, aunque puede coincidir con etapas de selección/calibración de un origen temprano; se declara esa convención.')
    table('Tabla 3 Actualización anual en 2011 a 2025',['Dominio','Modelo','CRPS mm','Brier húmedo','Cobertura 80 %'],[
        [r.dominio,names[r.modelo],f'{r.crps:.2f}',f'{r.brier_humedo:.4f}',f'{100*r.cobertura80:.2f}'] for _,r in rolling[rolling.dominio.isin(['Quito canton','Amazonia','Costa'])].iterrows()
    ],'Fuente: elaboración propia. Extensión secundaria con 150 temporadas enero-octubre y quince años. No se mezcla con la muestra de 70 temporadas de la prueba principal.')
    para('En Quito, el ridge actualizado con ENSO obtiene CRPS 44.29 mm frente a 45.26 mm de climatología actualizada y 46.91 mm del ridge actualizado sin ENSO. La mejora frente a climatología es aproximadamente 2.16 %. La cobertura de 80 % es 75.33 %, por debajo de la nominal. En Amazonía también mejora el CRPS central, pero su cobertura sigue insuficiente. La actualización aporta una prueba de estabilidad y señala un problema de calibración que permanece visible, en vez de convertir una mejora media en certeza.')
    heading('Exposición condicionada y dependencia espacial')
    para('Se cruzan probabilidades regionales con celdas construidas de 10 m respetando el soporte meteorológico. La exposición esperada a una condición húmeda es la suma de áreas construidas en cada celda meteorológica multiplicadas por su probabilidad de superar P80. Esta suma no es superficie inundada. Las prioridades de localizaciones de V05 se cruzan además como subconjuntos de construido, manteniendo ambos modelos y procesos separados.')
    blocks.append({'tipo':'ecuacion','id':'exposicion','qmd':r'\mathbb E(A_H)=\sum_g A_g p_{H,g},\qquad A_H^{(b)}=\sum_g A_g\mathbf 1\{Y_g^{(b)}>q_{80,g}\}'})
    para('Para propagar variabilidad espacial se utiliza en cada realización un campo de residuos correspondiente a la misma fecha histórica en todas las celdas. No se sortean 4.4 millones de píxeles construidos como observaciones independientes. Se compara esa propagación con un experimento de independencia artificial entre celdas meteorológicas. El banco mantiene 70 campos en modelos primarios y 34 en modelos actualizados. Los rangos resultantes describen simulaciones condicionadas y no incluyen toda la incertidumbre paramétrica, de medición o de ENSO futuro.')
    fig('Figura 3 Dependencia espacial y exposición condicionada','incertidumbre_espacial_exposicion','Fuente: elaboración propia. Los rangos centrales del 80 % pertenecen a condiciones pluviométricas regionales simuladas. La independencia artificial es sólo un comparador; no el procedimiento de producción.')
    heading('Aplicación para noviembre 2026 a enero 2027')
    para('La aplicación fija fecha de decisión 2026-10-09 y usa agosto de 2026 como antecedente más reciente. En el modelo actualizado, los coeficientes se entrenan hasta temporadas que terminan en 2019, se selecciona regularización en 2020-2022 y se calibran residuos en 2023-2025. Esa actualización es independiente del ajuste de la prueba principal. Se conserva un diagnóstico de predictores fuera del rango histórico; una combinación ENSO extrema no recibe una garantía por parecerse a observaciones dentro de un solo índice.')
    q=forecasts[forecasts.unit=='1701']
    table('Tabla 4 Pronósticos experimentales para Quito',['Modelo','Mediana mm','Rango 80 % mm','P húmeda','P seca'],[
        [names[r.modelo],f'{r.lluvia_mediana_mm:.2f}',f'{r.intervalo80_inf_mm:.2f} a {r.intervalo80_sup_mm:.2f}',f'{r.p_humedo:.3f}',f'{r.p_seco:.3f}'] for _,r in q.iterrows()
    ],'Fuente: elaboración propia. P húmeda: superar P80 histórico; P seca: estar por debajo de P20. Son probabilidades experimentales de lluvia estacional. El modelo ENSO presenta combinaciones fuera del rango de entrenamiento; no se afirma certeza de evento.')
    a=joint[(joint.dominio_exposicion=='construido_dmq')&(joint.estado_lluvia=='humedo')&(joint.modelo=='rolling_ridge_ENSO')].iloc[0]
    para(f'Para el construido de Quito, el modelo actualizado con ENSO produce una media ponderada de {a.area_ponderada_media_ha:.2f} ha bajo condición regional húmeda. El rango central de campos conjuntos va de {a.rango80_campos_conjuntos_inf_ha:.2f} a {a.rango80_campos_conjuntos_sup_ha:.2f} ha, frente a {a.rango80_independencia_inf_ha:.2f} a {a.rango80_independencia_sup_ha:.2f} ha al destruir la dependencia. El amplio rango es parte del resultado: la resolución fina de la exposición no proporciona por sí sola precisión climática.')
    fig('Figura 4 Condiciones regionales experimentales futuras','probabilidades_regionales_nov2026_ene2027','Fuente: CHIRPS3, NOAA y elaboración propia. Soporte 0.05 grados. Las fronteras de celdas no son límites de inundación. Probabilidades 0 o 1 del banco empírico no equivalen a imposibilidad o certeza físicas.')
    heading('Discusión y verificaciones externas')
    para('La contribución integra evaluación de información ENSO, valor de preparación y exposición con incertidumbre espacial. No presenta una arquitectura inédita ni demuestra superioridad frente a segmentación SAR. Li y colaboradores (2023) evalúan Prithvi sobre referencias de inundación y transferencia; Liu y colaboradores (2024) cartografían arroz, inundación y resiembra con Sentinel-1/2. Sus diseños requieren observaciones de agua y cultivo que no se sustituyen con lluvia mensual. El manuscrito local de Canavire-Bacarreza, Puerta-Cuartas y Ramos (2025) relaciona lluvia y pobreza mediante ENEMDU; aquí la unidad y el resultado son diferentes.')
    para('La verificación usa principalmente CHIRPS3, un producto que integra estaciones y estimación satelital. Se recuperó el inventario GHCN-Daily y la estación Izobamba, pero el filtro de calidad no produjo meses completos utilizables. El catálogo público de INAMHI permitió revisar 245 recursos y confirmó que las anomalías recuperadas son superficies agregadas, no series diarias de pluviómetros para una validación nueva. El catálogo ISD identifica Iñaquito y dos aeropuertos con ubicación diferente; no se fusionan como una sola estación. Una verificación instrumental adecuada exige continuidad, unidades, banderas y cambios de emplazamiento.')
    para('La relación ENSO puede cambiar con el tiempo, y los meses objetivo se solapan. La dependencia de series, los seis años de la prueba principal, la extensión exploratoria y la cobertura inferior a nominal deben considerarse al interpretar resultados. Las condiciones pluviométricas futuras se presentan como información experimental para orientar preparación; no se traducen a niveles de agua, mortalidad de cultivos, roturas, pobreza individual o pérdidas en dólares.')
    heading('Conclusiones')
    para('La información ENSO aporta al modelo neuronal evaluado de Quito y a determinadas comparaciones regionales, pero no mejora automáticamente toda puntuación ni desplaza siempre a climatología. La evaluación de decisiones revela utilidad dependiente del costo y eficacia supuestos. La actualización anual muestra mejoras centrales pequeñas y problemas de cobertura que requieren seguimiento. Estos hallazgos ayudan a decidir qué información climática utilizar y dónde mantener referencias sencillas.')
    para('El cruce multiescala produce una aplicación reproducible para noviembre de 2026 a enero de 2027 y tablas parroquiales de exposición a condiciones regionales. Conservar campos residuales coherentes evita estrechar artificialmente los rangos por el número de celdas del mapa. La comprobación instrumental y la calibración de la distribución bajo episodios extremos son los siguientes requisitos científicos; la evaluación realizada no garantiza precisión de inundación física por píxel ni aceptación editorial.')
    heading('Bibliografía')
    for ref in sorted(refs,key=lambda r:r['text'].casefold()):blocks.append({'tipo':'referencia','texto':ref['text'],**{k:ref[k] for k in ['revista','volumen'] if k in ref}})
    structure={'titulo':title,'autor':'Wilson Gustavo Morales Lastra','resumen_palabras':len(summary.split()),'bloques':blocks}
    (D/'articulo_v06_estructura.json').write_text(json.dumps(structure,ensure_ascii=False,indent=2),encoding='utf-8')
    lines=['---','title: "'+title+'"','author: "Wilson Gustavo Morales Lastra"','lang: es','format: docx','bibliography: referencias.bib','---','']
    for b in blocks:
        k=b['tipo']
        if k=='titulo':continue
        if k=='autor':lines.extend([b['texto']+'[^autor]','', '[^autor]: '+b['nota'],''])
        elif k=='titulo_seccion':lines.extend(['## '+b['texto'],''])
        elif k in ['texto','referencia']:lines.extend([b['texto'],''])
        elif k=='ecuacion':lines.extend(['$$',b['qmd'],'$$',''])
        elif k=='tabla':
            lines.extend([b['titulo'],'','| '+' | '.join(b['encabezados'])+' |','| '+' | '.join(['---']*len(b['encabezados']))+' |'])
            lines.extend('| '+' | '.join(map(str,r))+' |' for r in b['filas']);lines.extend(['',b['nota'],''])
        elif k=='figura':lines.extend([b['titulo'],'','![]('+b['archivo']+')','',b['nota'],''])
    (F/'MANUSCRITO_V06_ENSO.qmd').write_text('\n'.join(lines),encoding='utf-8')
    (F/'RESULTADOS_V06_ENSO.md').write_text('\n'.join(lines),encoding='utf-8')
    print('Resumen',len(summary.split()),'palabras; manuscrito estructurado generado',flush=True)


if __name__=='__main__':main()
