"""Ridge por unidad y ablation ENSO con regularización elegida sin test."""
from pathlib import Path
import json
import numpy as np

P=Path(__file__).resolve().parents[1]
D=P/'2_DATOS/PROCESADOS'
F=P/'6_FINAL'


def main():
    data=np.load(D/'panel_v06.npz');X=data['X'];z=data['z'];valid=data['valid']
    future=np.load(D/'entrada_futura_nov2026.npz')['X']
    states={};outputs={}
    for name,nf in [('ridge_sin_ENSO',int(data['n_base'])),('ridge_ENSO',X.shape[2])]:
        pred=np.full(z.shape,np.nan,dtype=np.float32);predfuture=np.full(len(z),np.nan,dtype=np.float32)
        st=[]
        for u in range(len(z)):
            train=valid[u]&data['train'];tune=valid[u]&data['tune']
            if train.sum()<100 or tune.sum()<20:raise ValueError('Sin muestra suficiente '+str(data['unit'][u]))
            xt=X[u,train,:nf].astype(float);yt=z[u,train]
            mu=xt.mean(axis=0);sd=xt.std(axis=0);sd=np.where(sd>1e-8,sd,1)
            xx=(xt-mu)/sd;zy=yt.mean();normal=xx.T@xx;rhs=xx.T@(yt-zy)
            choices=[]
            for lam in [1.,10.,100.]:
                beta=np.linalg.solve(normal+lam*np.eye(nf),rhs)
                pv=((X[u,tune,:nf]-mu)/sd)@beta+zy
                score=float(np.mean(np.abs(pv-z[u,tune])))
                choices.append((score,lam,beta))
            score,lam,beta=min(choices,key=lambda a:a[0])
            ok=np.isfinite(X[u,:,:nf]).all(axis=1)
            pred[u,ok]=((X[u,ok,:nf]-mu)/sd)@beta+zy
            predfuture[u]=((future[u,:nf]-mu)/sd)@beta+zy
            st.append({'unit':str(data['unit'][u]),'mu':mu.tolist(),'sd':sd.tolist(),'beta':beta.tolist(),
                       'intercept':float(zy),'lambda':lam,'mae_tune_z':score,'train_min':xt.min(axis=0).tolist(),'train_max':xt.max(axis=0).tolist()})
        outputs[name]=pred;outputs[name+'_future']=predfuture;states[name]=st
        print(name,'unidades ajustadas',len(st),flush=True)
    np.savez_compressed(D/'predicciones_ridge.npz',**outputs)
    (D/'parametros_ridge.json').write_text(json.dumps(states,ensure_ascii=False),encoding='utf-8')


if __name__=='__main__':main()
