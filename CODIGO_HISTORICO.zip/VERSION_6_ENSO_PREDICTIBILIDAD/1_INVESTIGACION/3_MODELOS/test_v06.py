"""Pruebas de fechas, puntuaciones y propagación; no certificación científica."""
from pathlib import Path
import unittest
import numpy as np
import pandas as pd
from evaluar_v06 import scores

P=Path(__file__).resolve().parents[1]
D=P/'2_DATOS/PROCESADOS'


class PruebasV06(unittest.TestCase):
    def test_crps_empirico_contra_formula_directa(self):
        a=np.array([[0.,1.],[2.,2.]])
        y=np.array([0.,2.]);r=scores(a,y,np.array([.2,.2]),np.array([.8,3.]))
        direct=np.abs(a-y[:,None]).mean(axis=1)-.5*np.abs(a[:,:,None]-a[:,None,:]).mean(axis=(1,2))
        np.testing.assert_allclose(r['crps'],direct)
        self.assertAlmostEqual(r['crps'][0],.25)

    def test_puntuaciones_perfectas(self):
        r=scores(np.array([[3.,3.,3.]]),np.array([3.]),np.array([1.]),np.array([2.]))
        self.assertEqual(r['crps'][0],0);self.assertEqual(r['brier_humedo'][0],0)

    def test_particiones_y_temporadas_no_cruzan(self):
        a=np.load(D/'panel_v06.npz');dates=pd.PeriodIndex(a['months'],freq='M');end=dates+2
        self.assertTrue((end[a['train']].year<=2010).all())
        self.assertTrue((dates[a['tune']].year>=2011).all());self.assertTrue((end[a['tune']].year<=2013).all())
        self.assertTrue((dates[a['cal']].year>=2014).all());self.assertTrue((end[a['cal']].year<=2019).all())
        self.assertTrue((dates[a['test']].year>=2020).all());self.assertTrue((end[a['test']].year<=2025).all())
        masks=np.stack([a[k] for k in ['train','tune','cal','test']]);self.assertTrue((masks.sum(axis=0)<=1).all())

    def test_futuro_solo_observaciones_agosto2026(self):
        a=np.load(D/'panel_v06.npz');f=np.load(D/'entrada_futura_nov2026.npz')
        self.assertTrue(np.isfinite(f['X']).all());self.assertEqual(a['months'][-1],'2026-08')
        # Niño indices match last observed row, not October or future values.
        np.testing.assert_allclose(f['X'][:,14],a['enso'][-1,0])
        np.testing.assert_allclose(f['X'][:,15],a['enso'][-1,1])

    def test_brier_respeta_limites(self):
        r=scores(np.array([[1.,3.],[0.,2.]]),np.array([2.,1.]),np.array([1.5,.5]),np.array([2.5,1.5]))
        self.assertTrue((r['brier_seco']>=0).all() and (r['brier_seco']<=1).all())

    def test_dependencia_no_reduce_artificialmente(self):
        area=np.array([100.,100.]);indicator=np.array([[0.,1.],[0.,1.]])
        joint=area@indicator
        self.assertEqual(joint.min(),0);self.assertEqual(joint.max(),200)
        self.assertEqual(joint.mean(),100)

    def test_json_numpy_sin_pickle(self):
        a=np.load(D/'panel_v06.npz')
        for k in a.files:self.assertNotEqual(a[k].dtype.kind,'O')


if __name__=='__main__':unittest.main()
