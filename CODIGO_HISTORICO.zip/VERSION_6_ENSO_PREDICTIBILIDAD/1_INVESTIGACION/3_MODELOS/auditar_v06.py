"""Auditoría técnica reproducible, separada de calidad científica/editorial."""
from pathlib import Path
import json
import hashlib
import zipfile
import subprocess
import sys
import importlib.metadata
import numpy as np
import pandas as pd
import rasterio

P=Path(__file__).resolve().parents[1]
D=P/'2_DATOS/PROCESADOS';F=P/'6_FINAL';V=P/'5_VERIFICACION';V.mkdir(parents=True,exist_ok=True)


def main():
    checks=[]
    def check(name,ok,detail=''):checks.append({'control':name,'aprobado':bool(ok),'detalle':detail})
    with np.load(D/'panel_v06.npz') as file:data={k:file[k] for k in file.files}
    check('404 unidades y26 entradas',data['X'].shape==(404,548,26))
    check('fechas nunca como object pickle',data['months'].dtype.kind!='O')
    control=json.loads((F/'control_panel_v06.json').read_text(encoding='utf-8'))
    check('separa218cantones186celdas',control['cantones']==218 and control['celdas_nativas_quito']==186)
    check('predictores futuros completos yprevios',control['forecast_inputs_complete'] and control['ultima_observacion_predictor_futuro']=='2026-08')
    training=json.loads((F/'entrenamiento_RTX_V06.json').read_text(encoding='utf-8'))
    check('9 redes entrenadas RTX real',len(training)==9 and all('5070' in a['device'] and not a['test_para_seleccion'] for a in training))
    check('checkpoint dentro160epocas',all(0<=a['best_epoch']<160 for a in training))
    obs=pd.read_parquet(D/'evaluacion_test_detalle.parquet')
    check('7comparadores completos en test',obs.modelo.nunique()==7 and len(obs)==404*70*7)
    check('sin duplicar clave unidad modelo temporada',not obs.duplicated(['unit','modelo','inicio_temporada']).any())
    check('CRPS no negativo',(obs.crps>=-1e-8).all())
    check('probabilidades dentro0y1',obs[['p_seco','p_humedo']].ge(0).all().all() and obs[['p_seco','p_humedo']].le(1).all().all())
    check('seca yhumeda no superponen probabilidades',((obs.p_seco+obs.p_humedo)<=1+1e-8).all())
    check('intervalos ordenados',(obs.intervalo80_inf_mm<=obs.intervalo80_sup_mm).all())
    year=json.loads((F/'control_actualizacion_anual.json').read_text(encoding='utf-8'))
    check('16origenes2011a2026 solo pasado',len(year)==16 and all(int(a['ultimo_final_cal'][:4])<a['origen_anio'] and not a['datos_anio_objetivo_en_ajuste'] for a in year))
    roll=pd.read_parquet(D/'evaluacion_rolling_detalle.parquet')
    check('150temporadas rolling',roll.inicio_temporada.nunique()==150 and roll.anio.nunique()==15)
    fs=pd.read_csv(F/'pronostico_actualizado_nov2026_ene2027.csv')
    check('futuro completamente posterior a decision',(fs.inicio_temporada=='2026-11').all() and (fs.fin_temporada=='2027-01').all())
    check('OOD ENSO se muestra','ENSO_fuera_rango_train' in fs.columns)
    area=json.loads((F/'control_exposicion_v06.json').read_text(encoding='utf-8'))
    check('denominador construido cierra',abs(area['area_construida_ha']-44481.38)<.001 and area['construido_sin_asignacion_meteo']==0)
    par=pd.read_csv(F/'exposicion_climatica_parroquias.csv');joint=pd.read_csv(F/'incertidumbre_exposicion_campos_conjuntos.csv')
    check('exposicion parroquial no excede construido',((par.area_ponderada_condicion_humeda_ha<=par.area_construida_ha+1e-6)&(par.area_ponderada_condicion_seca_ha<=par.area_construida_ha+1e-6)).all())
    check('propagacion coherente media cierra',all(abs(joint[(joint.modelo==m)&(joint.estado_lluvia=='humedo')&(joint.dominio_exposicion=='construido_dmq')].area_ponderada_media_ha.iloc[0]-par[par.modelo==m].area_ponderada_condicion_humeda_ha.sum())<.01 for m in joint.modelo.unique()))
    rasters=list((F/'RASTERS_REGIONALES').glob('*.tif'))
    check('rasters regionales no fingen10m',all(rasterio.open(file).crs.to_epsg()==4326 and abs(rasterio.open(file).res[0]-.05)<1e-6 for file in rasters))
    decision=pd.read_csv(F/'valor_decision_normalizado.csv')
    check('tres referentes de decision',decision.referencia.nunique()==3)
    check('no costos monetarios atribuidos',decision.no_son_dolares.all())
    check('valores normalizados referenciaigual0',np.allclose(decision[(decision.modelo==decision.referencia)].valor_relativo.dropna(),0))
    large=[str(f.relative_to(F)) for f in F.rglob('*') if f.is_file() and f.stat().st_size>10_000_000]
    check('cadaentregablehasta10MB',not large,str(large))
    article=json.loads((D/'articulo_v06_estructura.json').read_text(encoding='utf-8'))
    check('resumenhasta200',article['resumen_palabras']<=200)
    with zipfile.ZipFile(F/'MANUSCRITO_V06_ENSO.docx') as z:
        xml=z.read('word/document.xml').decode('utf-8')
        check('4tablas nativas editables',xml.count('<w:tbl>')==4)
        check('ecuaciones nativas','<m:oMath>' in xml)
        check('afiliacion real ysin placeholder','word/footnotes.xml' in z.namelist() and '[[FN]]' not in xml)
    p=subprocess.run([sys.executable,str(P/'3_MODELOS/test_v06.py')],capture_output=True,text=True,encoding='utf-8')
    (V/'pruebas_unitarias.txt').write_text(p.stdout+p.stderr,encoding='utf-8');check('7pruebas ejecutadas',p.returncode==0,p.stderr if p.returncode else '')
    manifest=[]
    files=[]
    for folder in [P/'0_PROTOCOLO',P/'1_LITERATURA',P/'2_DATOS',P/'3_MODELOS',F]:
        files.extend(f for f in folder.rglob('*') if f.is_file() and '__pycache__' not in str(f) and f.suffix!='.pyc')
    files.extend([P/'EJECUTAR_V06.py',P/'EJECUTAR_V06.bat',P/'LEEME_V06.md',
                  P.parents[2]/'EXPOSICION_FEN_NINO/VERSION_3/1_INVESTIGACION/2_DATOS/PROCESADOS/panel_lluvia_mensual.parquet'])
    for file in files:
        h=hashlib.sha256()
        with file.open('rb') as stream:
            for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
        manifest.append({'path':str(file.relative_to(P)) if file.is_relative_to(P) else str(file),'sha256':h.hexdigest(),'bytes':file.stat().st_size})
    (V/'manifiesto_datos_modelos_codigo.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    versions={'python':sys.version}
    for name in ['numpy','pandas','scipy','scikit-learn','rasterio','geopandas','pyproj','earthengine-api']:versions[name]=importlib.metadata.version(name)
    (V/'entorno_cientifico.json').write_text(json.dumps(versions,indent=2),encoding='utf-8')
    (V/'auditoria_tecnica.json').write_text(json.dumps({'controles':checks,'aprobados':sum(c['aprobado'] for c in checks),'total':len(checks),
       'alcance':'técnico, no validación física de inundación ni aceptación Q1'},ensure_ascii=False,indent=2),encoding='utf-8')
    for c in checks:
        if not c['aprobado']:print('FALLO',c['control'],c['detalle'],flush=True)
    print('Controles aprobados',sum(c['aprobado'] for c in checks),'/',len(checks),flush=True)
    if not all(c['aprobado'] for c in checks):raise SystemExit(1)


if __name__=='__main__':main()
