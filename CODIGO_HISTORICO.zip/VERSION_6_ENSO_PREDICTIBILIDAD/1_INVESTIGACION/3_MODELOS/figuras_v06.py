"""Figuras de habilidad, utilidad y dependencia espacial a partir de salidas reales."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

P=Path(__file__).resolve().parents[1]
ROOT=P.parents[2]
F=P/'6_FINAL';G=F/'GRAFICOS';G.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'Arial','font.size':8,'svg.fonttype':'none'})


def save(fig,name):
    fig.savefig(G/(name+'.png'),dpi=300,bbox_inches='tight');fig.savefig(G/(name+'.svg'),bbox_inches='tight');plt.close(fig)


def main():
    s=pd.read_csv(F/'evaluacion_principal.csv');interval=pd.read_csv(F/'comparaciones_enso_bootstrap_anios.csv')
    fig,axes=plt.subplots(1,2,figsize=(9,3.8),layout='constrained')
    domains=['Costa','Sierra','Amazonia','Quito canton','Quito grilla'];colors={'ridge_ENSO':'#2a6394','red_ENSO':'#be7a36','red_ENSO_reciente':'#37725b'}
    for model,col in colors.items():
        a=s[s.modelo==model].set_index('dominio').reindex(domains)
        axes[0].plot(a.skill_crps*100,np.arange(5),'o-',label=model,color=col)
    axes[0].axvline(0,color='black',lw=.6);axes[0].set_yticks(range(5),domains);axes[0].invert_yaxis();axes[0].set_xlabel('Mejora CRPS frente a climatología de entrenamiento (%)');axes[0].legend(fontsize=7);axes[0].set_title('Habilidad frente a climatología')
    for j,comparison in enumerate(['red_ENSO menos red_sin_ENSO','ridge_ENSO menos ridge_sin_ENSO']):
        a=interval[(interval.comparacion==comparison)&(interval.metrica=='crps')].set_index('dominio').reindex(domains)
        y=np.arange(5)+(j-.5)*.16
        axes[1].errorbar(a.diferencia_media,y,xerr=np.stack([a.diferencia_media-a.ic95_anios_inf,a.ic95_anios_sup-a.diferencia_media]),fmt='o',label=comparison.replace(' menos ',' − '))
    axes[1].set_yticks(range(5),domains);axes[1].invert_yaxis();axes[1].axvline(0,color='black',lw=.6);axes[1].set_xlabel('Diferencia CRPS (mm) negativo mejora');axes[1].set_title('Aporte de ENSO intervalos por años');axes[1].legend(fontsize=7)
    fig.supxlabel('Fuente: elaboración propia con CHIRPS3 y NOAA. Test 2020 a 2025. Seis años y temporadas solapadas.',fontsize=7)
    save(fig,'habilidad_y_aporte_ENSO')
    v=pd.read_csv(F/'valor_decision_normalizado.csv')
    fig,axes=plt.subplots(2,2,figsize=(8.3,6.1),layout='constrained')
    for ri,event in enumerate(['seco','humedo']):
      for ax,domain in zip(axes[ri],['Quito canton','Costa']):
        for model,color in [('red_ENSO','#be7a36'),('red_sin_ENSO','#777777'),('ridge_ENSO','#2a6394')]:
            a=v[(v.dominio==domain)&(v.evento_pluviometrico==event)&(v.eficacia_supuesta==1)&(v.modelo==model)&(v.referencia=='mejor_accion_constante_muestra')]
            ax.plot(a.C_sobre_L,a.valor_relativo,'o-',label=model,color=color)
        ax.set_title(domain+' '+('déficit' if event=='seco' else 'exceso')+' estacional');ax.axhline(0,color='black',lw=.6);ax.set_xlabel('Costo de acción / pérdida supuesta');ax.set_ylabel('Valor relativo normalizado');ax.legend(fontsize=7)
    fig.supxlabel('Fuente: elaboración propia. Referencia mejor acción constante en muestra. Eficacia 100 %. No son dólares.',fontsize=7)
    save(fig,'valor_decision_enso')
    # Future native rainfall probabilities, never a 10 m rainfall forecast.
    q=gpd.read_file(ROOT/'EXPOSICION_FEN_NINO/VERSION_5_QUITO_10M/1_INVESTIGACION/2_DATOS/PROCESADOS/quito_limite.geojson')
    fig,axes=plt.subplots(1,2,figsize=(8.3,5.1),layout='constrained')
    for ax,var,title in zip(axes,['p_seco','p_humedo'],['Déficit por debajo de P20','Exceso por encima de P80']):
        with rasterio.open(F/f'RASTERS_REGIONALES/rolling_ridge_ENSO_{var}_nov2026_ene2027.tif') as r:
            a=r.read(1,masked=True);b=r.bounds
            im=ax.imshow(a,extent=(b.left,b.right,b.bottom,b.top),cmap='YlOrRd',vmin=0,vmax=1,interpolation='none')
        q.boundary.plot(ax=ax,color='black',lw=.4);ax.set_xlabel('Longitud');ax.set_ylabel('Latitud');ax.set_title(title)
        fig.colorbar(im,ax=ax,shrink=.7,label='Probabilidad experimental de condición de lluvia')
    fig.suptitle('Quito noviembre 2026 a enero 2027 actualización estadística',fontsize=10)
    fig.supxlabel('Fuente: elaboración propia CHIRPS3 y NOAA. Predictores agosto 2026. Grilla 0.05 grados no inundación.',fontsize=7)
    save(fig,'probabilidades_regionales_nov2026_ene2027')
    joint=pd.read_csv(F/'incertidumbre_exposicion_campos_conjuntos.csv')
    joint=joint[(joint.dominio_exposicion=='construido_dmq')&(joint.estado_lluvia=='humedo')]
    names=['ridge_ENSO','red_ENSO','rolling_ridge_ENSO'];a=joint.set_index('modelo').reindex(names)
    fig,ax=plt.subplots(figsize=(8,3.5),layout='constrained')
    for i,(_,r) in enumerate(a.iterrows()):
        ax.plot([r.rango80_campos_conjuntos_inf_ha,r.rango80_campos_conjuntos_sup_ha],[i-.10,i-.10],lw=4,color='#2a6394',label='Campos históricos conjuntos' if i==0 else None)
        ax.plot([r.rango80_independencia_inf_ha,r.rango80_independencia_sup_ha],[i+.1,i+.1],lw=4,color='#be7a36',label='Independencia artificial entre celdas' if i==0 else None)
        ax.plot(r.area_ponderada_media_ha,i,'o',color='black')
    ax.set_yticks(range(3),names);ax.invert_yaxis();ax.set_xlabel('Suelo construido bajo condición regional húmeda (ha)');ax.legend(fontsize=7)
    ax.set_title('Dependencia espacial y amplitud de exposición condicionada')
    fig.supxlabel('Fuente: elaboración propia. Rangos centrales 80 % de simulaciones condicionadas no áreas inundadas ni cobertura garantizada.',fontsize=7)
    save(fig,'incertidumbre_espacial_exposicion')
    print('Cuatro figuras PNG y SVG',flush=True)


if __name__=='__main__':main()
