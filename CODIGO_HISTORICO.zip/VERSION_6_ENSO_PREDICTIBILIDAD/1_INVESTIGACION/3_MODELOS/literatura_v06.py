"""Bibliografía DOI y comparación de contribuciones comprobables."""
from pathlib import Path
import requests
import truststore
import json
import time
from concurrent.futures import ThreadPoolExecutor

P=Path(__file__).resolve().parents[1]
R=P/'1_LITERATURA/CROSSREF';F=P/'6_FINAL'
DOIS={'barnston2014':'10.1175/JAMC-D-13-0133.1','paliz2026':'10.54302/mausam.v77i4.7456',
      'gneiting2007':'10.1198/016214506000001437','misra2025':'10.1038/s41467-025-60973-1',
      'li2023':'10.1145/3615886.3627747','riskagenda2025':'10.1016/j.crm.2025.100770',
      'liu2024':'10.1016/j.isprsjprs.2024.08.010'}


def main():
    truststore.inject_into_ssl();R.mkdir(parents=True,exist_ok=True)
    def fetch(pair):
        key,doi=pair;file=R/(key+'.json')
        if file.exists():m=json.loads(file.read_text(encoding='utf-8'))
        else:
            for attempt in range(3):
                response=requests.get('https://api.crossref.org/works/'+doi,timeout=(15,40),headers={'User-Agent':'Investigaciones-Quito/0.6 academic-validation'})
                if response.status_code!=429:break
                print('Crossref limita frecuencia para',key,'espera breve',flush=True)
                time.sleep(10)
            response.raise_for_status();m=response.json()['message']
            file.write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8')
        if m['DOI'].lower()!=doi.lower():raise ValueError('DOI incompatible')
        return key,m
    with ThreadPoolExecutor(max_workers=2) as pool:items=list(pool.map(fetch,DOIS.items()))
    bib=[];refs=[]
    for key,m in items:
        names=' and '.join(a.get('family','')+', '+a.get('given','') for a in m.get('author',[]))
        apa_names=[a.get('family','')+', '+' '.join(v[0]+'.' for v in a.get('given','').split() if v) for a in m.get('author',[])]
        apa=', '.join(apa_names[:-1])+', & '+apa_names[-1] if len(apa_names)>1 else apa_names[0]
        year=m.get('published-print',m.get('published',m.get('issued')))['date-parts'][0][0]
        title=m['title'][0];journal=m.get('container-title',[''])[0];vol=m.get('volume','');issue=m.get('issue','');pages=m.get('page',m.get('article-number',''))
        text=f'{apa} ({year}). {title}. {journal}, {vol}'+('('+issue+')' if issue else '')+(', '+pages if pages else '')+'. https://doi.org/'+m['DOI']
        refs.append({'key':key,'text':text,'revista':journal,'volumen':vol,'doi':m['DOI']})
        bib.append(f'@article{{{key},\n author = {{{names}}},\n title = {{{{{title}}}}},\n year = {{{year}}},\n journal = {{{journal}}},\n volume = {{{vol}}},\n doi = {{{m["DOI"]}}}\n}}')
        print(key,year,title,flush=True)
    sources=[('noaa','National Oceanic and Atmospheric Administration','ENSO diagnostic discussion 8 October 2026','https://www.cpc.ncep.noaa.gov/products/analysis_monitoring/enso_advisory/ensodisc.shtml'),
        ('noaaindices','Climate Prediction Center','Monthly OISST Niño indices','https://www.cpc.ncep.noaa.gov/data/indices/sstoi.indices'),
        ('chirps','Climate Hazards Center','CHIRPS3 DAILY_RNL','https://developers.google.com/earth-engine/datasets/catalog/UCSB-CHC_CHIRPS_V3_DAILY_RNL'),
        ('quito','Municipio del Distrito Metropolitano de Quito','Geoportal Quito servicios geográficos','https://geoquito.quito.gob.ec/server/rest/services'),
        ('ecmwf','European Centre for Medium-Range Weather Forecasts','Forecast User Guide probabilistic data','https://confluence.ecmwf.int/spaces/FUG/pages/673551875/Section%2B12.B%2BStatistical%2BConcepts%2B-%2BProbabilistic%2BData'),
        ('inamhi','Instituto Nacional de Meteorología e Hidrología','Nodo geográfico público INAMHI','https://geoservicios.inamhi.gob.ec/')]
    for key,author,title,url in sources:
        refs.append({'key':key,'text':f'{author}. (s. f.). {title}. Recuperado el 9 de octubre de 2026, de {url}'})
        bib.append(f'@misc{{{key},\n author = {{{{{author}}}}},\n title = {{{{{title}}}}},\n url = {{{url}}},\n note = {{Consultado 2026-10-09}}\n}}')
    bib.append('@unpublished{canavire2025,\n author = {Canavire-Bacarreza, Gustavo and Puerta-Cuartas, Alejandro and Ramos, Andrey},\n title = {{Here Comes the Rain: Weather Shocks and Economic Outcomes in Ecuador}},\n year = {2025},\n note = {Manuscrito local fechado 28 de julio de 2025; DOI no verificado}\n}')
    refs.append({'key':'canavire2025','text':'Canavire-Bacarreza, G., Puerta-Cuartas, A., & Ramos, A. (2025). Here Comes the Rain: Weather Shocks and Economic Outcomes in Ecuador [Manuscrito local, 28 de julio; DOI no verificado].'})
    (F/'referencias.bib').write_text('\n\n'.join(bib),encoding='utf-8');(F/'referencias_verificadas.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2),encoding='utf-8')
    text='''# Contribución a contrastar frente a la literatura

Barnston y colaboradores (2014) ya evalúan predicción estacional ecuatoriana.
Paliz Acosta y colaboradores (2026) analizan cambios de teleconexión y extremos.
No es novedoso por sí mismo incluir ENSO o entrenar una red para lluvia.

La contribución propuesta es evaluar conjuntamente: aporte incremental ENSO
frente a modelos idénticos sin ENSO; habilidad de toda la distribución y de
decisiones costo-pérdida; actualización anual explícita; cruce de clima nativo
con exposición fina; propagación mediante campos residuales coherentes para
evitar falsa precisión por millones de píxeles. La novedad es empírica y del
flujo integrado en Ecuador, no una arquitectura neuronal inédita.

Misra y colaboradores (2025), revisado también en el PDF local, detectan agua
con SAR. Li y colaboradores (2023) comparan Prithvi con referencias físicas de
inundación. Sus métricas no son comparables con CRPS de lluvia estacional o
densidad de reportes. No se afirma vencer a sus modelos.

El estudio local de arroz de Liu y colaboradores usa Sentinel-1/2, fenología y
validación para cartografiar arroz, inundación y resiembra. No justifica asignar
pérdida total a una piscina/edificio ni convierte lluvia estacional en daño.
Canavire-Bacarreza, Puerta-Cuartas y Ramos relacionan lluvia y pobreza con
ENEMDU; V06 no replica esa relación ni interpreta el valor normalizado como
una variación monetaria de ingresos.

Antes de sostener novedad editorial fuerte faltan contraste externo de lluvia
y revisión de la dependencia y supuestos de decisión. Los resultados negativos
y los modelos de referencia permanecen en el manuscrito y sus anexos.
'''
    (F/'CONTRIBUCION_Y_LITERATURA.md').write_text(text,encoding='utf-8')


if __name__=='__main__':main()
