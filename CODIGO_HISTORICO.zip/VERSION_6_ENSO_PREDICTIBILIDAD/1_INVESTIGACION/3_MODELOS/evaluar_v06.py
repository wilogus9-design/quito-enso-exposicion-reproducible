"""Distribuciones, puntuaciones propias y decisiones sobre lluvia estacional.

Residuos de 2014-2019; 2020-2025 nunca calibra una distribución. Cada año se
mantiene unido al remuestrear regiones/celdas. No cuenta correlación como n independiente.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd

P=Path(__file__).resolve().parents[1]
D=P/'2_DATOS/PROCESADOS'
F=P/'6_FINAL'
MODELS=['climatologia','climatologia_calibrada','ridge_sin_ENSO','ridge_ENSO','red_sin_ENSO','red_ENSO','red_ENSO_reciente']


def scores(samples,truth,q20,q80):
    n=samples.shape[1];a=np.sort(samples,axis=1)
    point=np.median(a,axis=1)
    crps=np.abs(a-truth[:,None]).mean(axis=1)-(a@(2*np.arange(1,n+1)-n-1))/n**2
    pdry=(a<q20[:,None]).mean(axis=1);pwet=(a>q80[:,None]).mean(axis=1)
    lo,hi=np.quantile(a,[.1,.9],axis=1)
    return {'mediana_mm':point,'mae':np.abs(point-truth),'crps':crps,'p_seco':pdry,'p_humedo':pwet,
            'brier_seco':(pdry-(truth<q20))**2,'brier_humedo':(pwet-(truth>q80))**2,
            'intervalo80_inf_mm':lo,'intervalo80_sup_mm':hi,'cobertura80':((truth>=lo)&(truth<=hi)).astype(float),'amplitud80':hi-lo}


def main():
    with np.load(D/'panel_v06.npz') as archive:d={k:archive[k] for k in archive.files}
    units=pd.read_csv(D/'unidades.csv',dtype={'unit':str})
    linear=np.load(D/'predicciones_ridge.npz');nets=np.load(D/'predicciones_redes.npz')
    predictions={k:(linear[k] if k.startswith('ridge') else nets[k]) for k in MODELS[2:]}
    predictions['climatologia_calibrada']=np.zeros_like(d['z'])
    testids=np.flatnonzero(d['test']);months=d['months'];mo=np.array([int(a[5:]) for a in months]);future=np.load(D/'entrada_futura_nov2026.npz')
    records=[];future_rows=[];banks={};diagnostics=[]
    for u,unit in units.iterrows():
        if u%50==0:print('Evaluando unidad',u,'/',len(units),flush=True)
        test=testids[d['valid'][u,testids]];truth=d['y'][u,test]
        q20=d['q20'][u,mo[test]-1];q80=d['q80'][u,mo[test]-1]
        meta={'unit':unit.unit,'tipo_unidad':unit.type,'region':unit.region,'nombre':unit['name']}
        for model in MODELS:
            if model=='climatologia':
                # Train draws for each season start, not climatology estimated in test.
                samples=[]
                for t in test:
                    pool=d['y'][u,d['train']&(mo==mo[t])&d['valid'][u]]
                    if len(pool)<20:raise ValueError('Pocas temporadas de referencia')
                    samples.append(pool)
                # Different calendar sample counts are scored individually.
                arrays={k:[] for k in ['mediana_mm','mae','crps','p_seco','p_humedo','brier_seco','brier_humedo','intervalo80_inf_mm','intervalo80_sup_mm','cobertura80','amplitud80']}
                for i,a in enumerate(samples):
                    out=scores(a[None],truth[i:i+1],q20[i:i+1],q80[i:i+1])
                    for k,v in out.items():arrays[k].append(v[0])
                stat={k:np.array(v) for k,v in arrays.items()}
                forecast=d['y'][u,d['train']&(mo==11)&d['valid'][u]]
            else:
                cal=d['cal']&d['valid'][u]
                residual=d['z'][u,cal]-predictions[model][u,cal]
                if len(residual)<40:raise ValueError('Calibración incompleta')
                banks[model+'_'+str(u)]=residual
                zsample=predictions[model][u,test,None]+residual[None]
                samples=np.expm1(d['mu'][u,mo[test]-1,None]+d['sd'][u,mo[test]-1,None]*zsample)
                samples=np.maximum(samples,0)
                stat=scores(samples,truth,q20,q80)
                prednew=0 if model=='climatologia_calibrada' else linear[model+'_future'][u] if model.startswith('ridge') else nets[model+'_future'][u]
                forecast=np.maximum(np.expm1(future['mu'][u]+future['sd'][u]*(prednew+residual)),0)
            for i,t in enumerate(test):
                record={**meta,'modelo':model,'inicio_temporada':str(months[t]),'anio':int(months[t][:4]),
                        'lluvia_observada_mm':float(truth[i]),'seco':int(truth[i]<q20[i]),'humedo':int(truth[i]>q80[i]),
                        'nino34_antecedente':float(d['enso'][t-3,1]),'nino12_antecedente':float(d['enso'][t-3,0]),
                        'fase_antecedente':('calida' if d['enso'][t-3,1]>=.5 else 'fria' if d['enso'][t-3,1]<=-.5 else 'intermedia')}
                record.update({k:float(v[i]) for k,v in stat.items()});records.append(record)
            lo,med,hi=np.quantile(forecast,[.1,.5,.9])
            future_rows.append({**meta,'modelo':model,'inicio_temporada':'2026-11','fin_temporada':'2027-01',
                                'fecha_decision':'2026-10-09','ultimo_predictor':'2026-08',
                                'lluvia_mediana_mm':float(med),'intervalo80_inf_mm':float(lo),'intervalo80_sup_mm':float(hi),
                                'p_seco':float((forecast<future['q20'][u]).mean()),'p_humedo':float((forecast>future['q80'][u]).mean()),
                                'umbral_seco_mm':float(future['q20'][u]),'umbral_humedo_mm':float(future['q80'][u]),
                                'n_muestra_distribucion':len(forecast),'no_es':'no inundación física, profundidad ni dólares'})
    df=pd.DataFrame(records);df.to_parquet(D/'evaluacion_test_detalle.parquet',index=False)
    np.savez_compressed(D/'bancos_residuos_calibracion.npz',**banks)
    pd.DataFrame(future_rows).to_csv(F/'pronostico_estacional_nov2026_ene2027.csv',index=False)
    # Each downloadable model file is smaller than a combined multi-model CSV.
    dest=F/'PREDICCIONES_TEST';dest.mkdir(parents=True,exist_ok=True)
    for model,g in df.groupby('modelo'):g.to_parquet(dest/(model+'.parquet'),index=False)
    metrics=['mae','crps','brier_seco','brier_humedo','cobertura80','amplitud80']
    summary=[]
    masks={'Costa':(df.tipo_unidad=='CANTON')&(df.region=='Costa'),
           'Sierra':(df.tipo_unidad=='CANTON')&(df.region=='Sierra'),
           'Amazonia':(df.tipo_unidad=='CANTON')&df.region.isin(['Amazonía','Amazonia']),
           'Quito canton':df.unit=='1701','Quito grilla':df.tipo_unidad=='QUITO_CELDA',
           'Ecuador cantones':df.tipo_unidad=='CANTON'}
    for region,mask in masks.items():
        for model,g in df[mask].groupby('modelo'):
            summary.append({'dominio':region,'modelo':model,'filas_test':len(g),'fechas_test':g.inicio_temporada.nunique(),
                            'unidades':g.unit.nunique(),**g[metrics].mean().to_dict()})
    summ=pd.DataFrame(summary)
    for score in ['crps','brier_seco','brier_humedo']:
        base=summ[summ.modelo=='climatologia'].set_index('dominio')[score]
        summ['skill_'+score]=1-summ[score]/summ.dominio.map(base)
    summ.to_csv(F/'evaluacion_principal.csv',index=False)
    hetero=df.groupby(['tipo_unidad','region','modelo','fase_antecedente'])[metrics].agg(['mean','count'])
    hetero.columns=[a+'_'+b for a,b in hetero.columns]
    hetero.reset_index().to_csv(F/'heterogeneidad_enso.csv',index=False)
    # Paired year bootstrap: all months and units of one year stay together.
    rng=np.random.default_rng(6100);intervals=[]
    for region,mask in masks.items():
        a=df[mask]
        grouped=a.groupby(['anio','modelo'])[metrics].mean().unstack('modelo')
        year_n=a[a.modelo=='climatologia'].groupby('anio').size().reindex(grouped.index).to_numpy()
        n=len(grouped);draw=rng.integers(0,n,size=(2000,n))
        for lhs,rhs in [('ridge_ENSO','ridge_sin_ENSO'),('red_ENSO','red_sin_ENSO'),('red_ENSO_reciente','red_ENSO'),('ridge_ENSO','climatologia'),('red_ENSO','climatologia')]:
            for score in ['crps','brier_seco','brier_humedo']:
                delta=(grouped[(score,lhs)]-grouped[(score,rhs)]).to_numpy()
                boot=(delta[draw]*year_n[draw]).sum(axis=1)/year_n[draw].sum(axis=1)
                lo,hi=np.quantile(boot,[.025,.975])
                intervals.append({'dominio':region,'comparacion':lhs+' menos '+rhs,'metrica':score,
                                  'diferencia_media':float(np.average(delta,weights=year_n)),'ic95_anios_inf':float(lo),'ic95_anios_sup':float(hi),
                                  'anios_test':n,'replicas':2000,'interpretacion':'negativo mejora; seis años y ventanas solapadas limitan inferencia'})
    pd.DataFrame(intervals).to_csv(F/'comparaciones_enso_bootstrap_anios.csv',index=False)
    # Normalized economic value of anticipating rain condition; not dollars.
    decision=[]
    for region,mask in masks.items():
        a=df[mask]
        for reference in ['climatologia','climatologia_calibrada','mejor_accion_constante_muestra']:
            for event in ['seco','humedo']:
                ref_model=reference if reference!='mejor_accion_constante_muestra' else 'climatologia'
                truth=a[a.modelo==ref_model][event].to_numpy()
                cp=a[a.modelo==ref_model]['p_'+event].to_numpy()
                for eff in [1.,.5]:
                    for ratio in [.05,.10,.15,.20,.25,.30,.40,.50]:
                        cbase=np.mean(ratio*(cp>=ratio/eff)+truth*(1-eff*(cp>=ratio/eff)))
                        if reference=='mejor_accion_constante_muestra':cbase=min(float(truth.mean()),ratio+(1-eff)*float(truth.mean()))
                        perfect=np.mean(truth)*min(1.,ratio+1-eff)
                        den=cbase-perfect
                        for model,g in a.groupby('modelo'):
                            action=g['p_'+event].to_numpy()>=ratio/eff
                            cost=float(np.mean(ratio*action+g[event].to_numpy()*(1-eff*action)))
                            value=(cbase-cost)/den if den>1e-10 else np.nan
                            decision.append({'dominio':region,'evento_pluviometrico':event,'modelo':model,'referencia':reference,
                                             'eficacia_supuesta':eff,'C_sobre_L':ratio,'costo_normalizado':cost,'valor_relativo':value,'no_son_dolares':True})
    pd.DataFrame(decision).to_csv(F/'valor_decision_normalizado.csv',index=False)
    unit_summary=df.groupby(['unit','tipo_unidad','region','nombre','modelo'])[metrics].mean().reset_index()
    unit_summary.to_csv(F/'evaluacion_por_unidad.csv',index=False)
    print(summ[summ.dominio.isin(['Quito canton','Costa','Quito grilla'])][['dominio','modelo','crps','skill_crps','skill_brier_seco','skill_brier_humedo','cobertura80']].to_string(index=False),flush=True)


if __name__=='__main__':main()
