"""Busca pluviómetros públicos próximos a Quito, sin asumir cobertura completa.

GHCN Daily: PRCP está en décimas de mm. Rechaza flags de calidad no vacíos,
conserva faltantes y no suma meses incompletos como si fueran meses observados.
No se presupone independencia de las estaciones respecto al blend CHIRPS.
"""
from pathlib import Path
import json
import hashlib
from concurrent.futures import ThreadPoolExecutor
import requests
import truststore
import pandas as pd
import numpy as np

P=Path(__file__).resolve().parents[1]
R=P/'2_DATOS/ORIGINALES/GHCN'
F=P/'6_FINAL'
BASE='https://www.ncei.noaa.gov/pub/data/ghcn/daily/'


def main():
    truststore.inject_into_ssl();R.mkdir(parents=True,exist_ok=True)
    def get(name):
        file=R/name
        if not file.exists():
            response=requests.get(BASE+name,timeout=(20,180));response.raise_for_status()
            file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes(response.content)
        return file
    with ThreadPoolExecutor(max_workers=2) as pool:
        inventory,stations=list(pool.map(get,['ghcnd-inventory.txt','ghcnd-stations.txt']))
    inv=[]
    for line in inventory.read_text(encoding='utf-8').splitlines():
        ident=line[:11].strip()
        if not ident.startswith('EC'):continue
        lat=float(line[12:20]);lon=float(line[21:30]);element=line[31:35].strip()
        if element=='PRCP' and -.9<=lat<=.6 and -79.2<=lon<=-77.9:
            inv.append({'station':ident,'lat':lat,'lon':lon,'first_year':int(line[36:40]),'last_year':int(line[41:45])})
    names={line[:11].strip():{'name':line[41:71].strip(),'elevation_m':float(line[31:37])} for line in stations.read_text(encoding='utf-8').splitlines() if line.startswith('EC')}
    for r in inv:r.update(names.get(r['station'],{}))
    rows=[];status=[]
    for station in inv:
        ident=station['station']
        try:
            file=get('all/'+ident+'.dly')
            for line in file.read_text(encoding='utf-8').splitlines():
                if line[17:21]!='PRCP':continue
                year,month=int(line[11:15]),int(line[15:17])
                if year<1981:continue
                ndays=pd.Period(f'{year}-{month:02d}',freq='M').days_in_month
                for day in range(1,ndays+1):
                    part=line[21+(day-1)*8:21+day*8];v=int(part[:5]);quality=part[6:7]
                    value=v/10 if v!=-9999 and quality==' ' and v>=0 else np.nan
                    rows.append({'station':ident,'date':f'{year}-{month:02d}-{day:02d}','rain_mm':value,'quality_flag':quality.strip()})
            status.append({**station,'file_sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'downloaded':True})
        except Exception as e:status.append({**station,'downloaded':False,'error':type(e).__name__})
    (F/'estaciones_noaa_fuentes.json').write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8')
    pd.DataFrame(inv).to_csv(F/'estaciones_pluviometricas_candidatas.csv',index=False)
    if rows:
        daily=pd.DataFrame(rows);daily['date']=pd.to_datetime(daily.date)
        if daily.duplicated(['station','date']).any():raise ValueError('Fechas instrumentales duplicadas')
        daily.to_parquet(P/'2_DATOS/PROCESADOS/lluvia_gauge_diaria.parquet',index=False)
        daily['month']=daily.date.dt.to_period('M')
        monthly=daily.groupby(['station','month']).rain_mm.agg(['sum','count']).reset_index()
        monthly['expected_days']=monthly.month.dt.days_in_month
        monthly['complete']=monthly['count']==monthly.expected_days
        monthly['rain_full_month_mm']=monthly['sum'].where(monthly.complete)
        monthly.to_csv(F/'lluvia_instrumental_mensual.csv',index=False)
        print(monthly.groupby('station').agg(first=('month','min'),last=('month','max'),complete_months=('complete','sum')).to_string(),flush=True)
    print(json.dumps(status,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
