"""Metadatos públicos para próximas referencias instrumentales. No consulta DB privada."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import requests
import truststore
import pandas as pd
import json
import re

P=Path(__file__).resolve().parents[1]
R=P/'2_DATOS/ORIGINALES/INSTRUMENTAL'
F=P/'6_FINAL'
SOURCES={
 'inamhi_portal':'https://geoservicios.inamhi.gob.ec/',
 'inamhi_catalogo_api':'https://geoservicios.inamhi.gob.ec/api/v2/resources/?page_size=100',
 'inamhi_wfs':'https://geoservicios.inamhi.gob.ec/geoserver/ows?service=WFS&request=GetCapabilities',
 'inamhi_acceso_publico':'https://www.inamhi.gob.ec/info-liberada/',
 'noaa_isd_stations':'https://www.ncei.noaa.gov/pub/data/noaa/isd-history.csv',
 'ecmwf_valor':'https://confluence.ecmwf.int/spaces/FUG/pages/673551875/Section%2B12.B%2BStatistical%2BConcepts%2B-%2BProbabilistic%2BData'
}


def main():
    truststore.inject_into_ssl();R.mkdir(parents=True,exist_ok=True)
    def get(pair):
        name,url=pair;file=R/(name+('.csv' if name=='noaa_isd_stations' else '.txt'))
        try:
            if not file.exists():
                response=requests.get(url,timeout=(15,40));response.raise_for_status();file.write_bytes(response.content)
            obj={'fuente':name,'url':url,'descargado':True,'bytes':file.stat().st_size}
            if name=='inamhi_catalogo_api':
                raw=json.loads(file.read_text(encoding='utf-8'))
                obj['recursos']=[{'title':x.get('title'),'uuid':x.get('uuid'),'detail_url':x.get('detail_url'),'typename':x.get('alternate')} for x in raw.get('resources',raw.get('results',[]))]
            return obj
        except Exception as e:return {'fuente':name,'url':url,'descargado':False,'error':type(e).__name__}
    with ThreadPoolExecutor(max_workers=3) as pool:out=list(pool.map(get,SOURCES.items()))
    path=R/'noaa_isd_stations.csv'
    if path.exists():
        a=pd.read_csv(path,dtype={'USAF':str,'WBAN':str});a['LAT']=pd.to_numeric(a.LAT,errors='coerce');a['LON']=pd.to_numeric(a.LON,errors='coerce')
        a=a[a.LAT.between(-.9,.6)&a.LON.between(-79.2,-77.9)]
        a.to_csv(F/'estaciones_isd_cercanas_quito.csv',index=False)
        print(a[['USAF','WBAN','STATION NAME','LAT','LON','BEGIN','END']].to_string(index=False),flush=True)
    (F/'estado_busqueda_instrumental.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(out,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
