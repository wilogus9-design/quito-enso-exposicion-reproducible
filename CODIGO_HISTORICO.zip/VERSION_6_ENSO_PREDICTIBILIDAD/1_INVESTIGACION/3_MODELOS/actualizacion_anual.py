"""Análisis secundario prequential: cada año aprende sólo de su pasado.

La comparación primaria permanece intacta. La actualización no se elige por
sus resultados de test ni convierte lluvia estacional en agua física por píxel.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from evaluar_v06 import scores

P=Path(__file__).resolve().parents[1]
D=P/'2_DATOS/PROCESADOS'
F=P/'6_FINAL'


def main():
    with np.load(D/'panel_v06.npz') as file:d={k:file[k] for k in file.files}
    future=np.load(D/'entrada_futura_nov2026.npz');unit=pd.read_csv(D/'unidades.csv',dtype={'unit':str})
    date=pd.PeriodIndex(d['months'],freq='M');end=date+2;mo=date.month.to_numpy()
    rows=[];forecasts=[];audit=[];states={}
    for year in range(2011,2027):
        tr=(date.year>=year-26)&(end.year<=year-7)
        tune=(date.year>=year-6)&(end.year<=year-4)
        cal=(date.year>=year-3)&(end.year<=year-1)
        test=(date.year==year)&(end.year==year) if year<2026 else np.zeros(len(date),bool)
        audit.append({'origen_anio':year,'ultimo_final_train':str(end[tr][-1]),'ultimo_final_tune':str(end[tune][-1]),
                      'ultimo_final_cal':str(end[cal][-1]),'datos_anio_objetivo_en_ajuste':False})
        for u,meta in unit.iterrows():
            tt=tr&d['valid'][u];tv=tune&d['valid'][u];tc=cal&d['valid'][u];ids=np.flatnonzero(test&d['valid'][u])
            base={'unit':meta.unit,'tipo_unidad':meta.type,'region':meta.region,'nombre':meta['name']}
            for name,nf in [('rolling_climatologia',0),('rolling_ridge_sin_ENSO',int(d['n_base'])),('rolling_ridge_ENSO',d['X'].shape[2])]:
                if nf==0:
                    for t in ids:
                        a=d['y'][u,tt&(mo==mo[t])]
                        result=scores(a[None],d['y'][u,t:t+1],d['q20'][u,mo[t]-1:mo[t]],d['q80'][u,mo[t]-1:mo[t]])
                        rows.append({**base,'modelo':name,'anio':year,'inicio_temporada':str(date[t]),'lluvia_observada_mm':float(d['y'][u,t]),
                                     **{k:float(v[0]) for k,v in result.items()}})
                    if year==2026:
                        a=d['y'][u,tt&(mo==11)]
                        lo,med,hi=np.quantile(a,[.1,.5,.9])
                        forecasts.append({**base,'modelo':name,'lluvia_mediana_mm':med,'intervalo80_inf_mm':lo,'intervalo80_sup_mm':hi,
                                          'p_seco':float((a<future['q20'][u]).mean()),'p_humedo':float((a>future['q80'][u]).mean()),'n_cal':len(a)})
                    continue
                a=d['X'][u,tt,:nf].astype(float);target=d['z'][u,tt];mu=a.mean(axis=0);sd=a.std(axis=0);sd=np.where(sd>1e-6,sd,1)
                a=(a-mu)/sd;intercept=target.mean();normal=a.T@a;rhs=a.T@(target-intercept)
                options=[]
                for lam in [1.,10.,100.]:
                    beta=np.linalg.solve(normal+lam*np.eye(nf),rhs)
                    val=((d['X'][u,tv,:nf]-mu)/sd)@beta+intercept
                    options.append((float(np.mean(np.abs(val-d['z'][u,tv]))),lam,beta))
                _,lam,beta=min(options,key=lambda q:q[0])
                predcal=((d['X'][u,tc,:nf]-mu)/sd)@beta+intercept
                residual=d['z'][u,tc]-predcal
                if len(residual)<24:raise ValueError('Calibración reciente insuficiente')
                if len(ids):
                    pred=((d['X'][u,ids,:nf]-mu)/sd)@beta+intercept
                    samples=np.maximum(np.expm1(d['mu'][u,mo[ids]-1,None]+d['sd'][u,mo[ids]-1,None]*(pred[:,None]+residual[None])),0)
                    result=scores(samples,d['y'][u,ids],d['q20'][u,mo[ids]-1],d['q80'][u,mo[ids]-1])
                    for i,t in enumerate(ids):
                        rows.append({**base,'modelo':name,'anio':year,'inicio_temporada':str(date[t]),'lluvia_observada_mm':float(d['y'][u,t]),
                                     **{k:float(v[i]) for k,v in result.items()}})
                if year==2026:
                    pred=((future['X'][u,:nf]-mu)/sd)@beta+intercept
                    draw=np.maximum(np.expm1(future['mu'][u]+future['sd'][u]*(pred+residual)),0)
                    lo,med,hi=np.quantile(draw,[.1,.5,.9])
                    ood=np.flatnonzero((future['X'][u,:nf]<d['X'][u,tt,:nf].min(axis=0))|(future['X'][u,:nf]>d['X'][u,tt,:nf].max(axis=0)))
                    predictors=[str(d['feature_names'][v]) for v in ood if v>=int(d['n_base'])]
                    forecasts.append({**base,'modelo':name,'lluvia_mediana_mm':med,'intervalo80_inf_mm':lo,'intervalo80_sup_mm':hi,
                                      'p_seco':float((draw<future['q20'][u]).mean()),'p_humedo':float((draw>future['q80'][u]).mean()),
                                      'n_cal':len(residual),'ENSO_fuera_rango_train':bool(predictors),'variables_ENSO_fuera_rango':';'.join(predictors)})
                    # Sensitivity to ENSO covariates, not a causal counterfactual.
                    neutral=future['X'][u,:nf].copy()
                    if nf>int(d['n_base']):neutral[int(d['n_base']):]=0
                    pn=((neutral-mu)/sd)@beta+intercept
                    neutraldraw=np.maximum(np.expm1(future['mu'][u]+future['sd'][u]*(pn+residual)),0)
                    forecasts[-1]['p_humedo_enso_cero_sensibilidad']=float((neutraldraw>future['q80'][u]).mean())
                    forecasts[-1]['p_seco_enso_cero_sensibilidad']=float((neutraldraw<future['q20'][u]).mean())
                    states[name+'_'+str(u)]={'mu':mu.tolist(),'sd':sd.tolist(),'beta':beta.tolist(),'intercept':float(intercept),
                                               'lambda':lam,'residual':residual.tolist(),'train_end':'2019-12','tune_end':'2022-12','cal_end':'2025-12'}
                    states[name+'_'+str(u)]['cal_months']=d['months'][tc].tolist()
        print('Actualización completada',year,flush=True)
    df=pd.DataFrame(rows);df.to_parquet(D/'evaluacion_rolling_detalle.parquet',index=False)
    fs=pd.DataFrame(forecasts);fs['inicio_temporada']='2026-11';fs['fin_temporada']='2027-01';fs['ultimo_predictor']='2026-08';fs['estado']='experimental no inundación física'
    fs.to_csv(F/'pronostico_actualizado_nov2026_ene2027.csv',index=False)
    # Same target dates and units for primary versus updating comparison.
    primary=pd.read_parquet(D/'evaluacion_test_detalle.parquet')
    primary=primary[primary.inicio_temporada.str[5:].astype(int)<=10]
    combined=pd.concat([df[df.anio>=2020],primary],ignore_index=True)
    summary=[];metrics=['mae','crps','brier_seco','brier_humedo','cobertura80','amplitud80']
    for label,mask in {'Costa':(combined.tipo_unidad=='CANTON')&(combined.region=='Costa'),
                        'Sierra':(combined.tipo_unidad=='CANTON')&(combined.region=='Sierra'),
                        'Amazonia':(combined.tipo_unidad=='CANTON')&combined.region.isin(['Amazonia','Amazonía']),
                        'Quito canton':combined.unit=='1701','Quito grilla':combined.tipo_unidad=='QUITO_CELDA'}.items():
        for model,g in combined[mask].groupby('modelo'):
            summary.append({'dominio':label,'modelo':model,'n':len(g),'fechas':g.inicio_temporada.nunique(),**g[metrics].mean().to_dict()})
    summ=pd.DataFrame(summary);summ.to_csv(F/'comparacion_actualizacion_muestra_comun.csv',index=False)
    expanded=[]
    for label,mask in {'Costa':(df.tipo_unidad=='CANTON')&(df.region=='Costa'),
                        'Sierra':(df.tipo_unidad=='CANTON')&(df.region=='Sierra'),
                        'Amazonia':(df.tipo_unidad=='CANTON')&df.region.isin(['Amazonia','Amazonía']),
                        'Quito canton':df.unit=='1701','Quito grilla':df.tipo_unidad=='QUITO_CELDA'}.items():
        for model,g in df[mask].groupby('modelo'):
            expanded.append({'dominio':label,'modelo':model,'n':len(g),'fechas':g.inicio_temporada.nunique(),**g[metrics].mean().to_dict()})
    pd.DataFrame(expanded).to_csv(F/'evaluacion_rolling_2011_2025.csv',index=False)
    (F/'control_actualizacion_anual.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
    (D/'parametros_rolling_2026.json').write_text(json.dumps(states,ensure_ascii=False),encoding='utf-8')
    print(summ[summ.dominio.isin(['Quito canton','Costa'])][['dominio','modelo','crps','brier_seco','brier_humedo','cobertura80']].to_string(index=False),flush=True)


if __name__=='__main__':main()
