"""Construye predictores atrasados y temporadas futuras, sin estandarizar con test."""
from pathlib import Path
import json
import hashlib
import numpy as np
import pandas as pd

P=Path(__file__).resolve().parents[1]
ROOT=P.parents[2]
D=P/'2_DATOS/PROCESADOS'
F=P/'6_FINAL'
BASE_NAMES=['sin1','cos1','sin2','cos2','tendencia','latitud','longitud','costa','sierra','amazonia',
            'celda_nativa','lluvia_mes_tmenos3_z','lluvia_tmenos5_tmenos3_z','lluvia_misma_temporada_anterior_z']
ENSO_NAMES=['nino12_tmenos3','nino34_tmenos3','nino4_tmenos3','nino12_media3','nino34_media3',
            'nino12_cambio2','nino34_cambio2','contraste12_34','nino12_sin1','nino12_cos1','nino34_sin1','nino34_cos1']


def main():
    rain=pd.read_parquet(ROOT/'EXPOSICION_FEN_NINO/VERSION_3/1_INVESTIGACION/2_DATOS/PROCESADOS/panel_lluvia_mensual.parquet')
    rain['month']=pd.PeriodIndex(rain.month,freq='M')
    dates=pd.period_range('1981-01','2026-08',freq='M')
    units=rain[['canton','region','name','latitude','longitude']].drop_duplicates('canton').sort_values('canton').copy()
    units.columns=['unit','region','name','lat','lon'];units['type']='CANTON'
    wide=rain.pivot(index='month',columns='canton',values='rain_mm').reindex(index=dates,columns=units.unit)
    cover=rain.pivot(index='month',columns='canton',values='observed_area_fraction').reindex(index=dates,columns=units.unit)
    arr=wide.to_numpy(copy=True).T;arr[(cover.to_numpy().T<.99)|(~np.isfinite(arr))|(arr<0)]=np.nan
    native=np.load(D/'lluvia_nativa_quito.npz')
    if not np.array_equal(native['months'],dates.astype(str).to_numpy()):raise ValueError('Fechas nativas incompatibles')
    qu=pd.DataFrame({'unit':native['unit'],'region':'Quito grilla','name':native['unit'],'lat':native['lat'],'lon':native['lon'],'type':'QUITO_CELDA'})
    units=pd.concat([units,qu],ignore_index=True);arr=np.concatenate([arr,native['rain'].T])
    U,T=arr.shape
    # Seasonal targets with complete observations, no sum of partial months.
    y=np.full((U,T),np.nan);past=np.full((U,T),np.nan)
    y[:,:T-2]=arr[:,:T-2]+arr[:,1:T-1]+arr[:,2:]
    past[:,2:]=arr[:,:T-2]+arr[:,1:T-1]+arr[:,2:]
    month=dates.month.to_numpy();end=dates+2
    train=(end.year<=2010)&(dates.year>=1983)
    tune=(dates>=pd.Period('2011-01','M'))&(end<=pd.Period('2013-12','M'))
    cal=(dates>=pd.Period('2014-01','M'))&(end<=pd.Period('2019-12','M'))
    test=(dates>=pd.Period('2020-01','M'))&(end<=pd.Period('2025-12','M'))
    mu=np.full((U,12),np.nan);sd=mu.copy();q20=mu.copy();q80=mu.copy();pastmu=mu.copy();pastsd=mu.copy();onemu=mu.copy();onesd=mu.copy()
    for m in range(1,13):
        a=np.log1p(y[:,train&(month==m)]);mu[:,m-1]=np.nanmean(a,axis=1);sd[:,m-1]=np.maximum(np.nanstd(a,axis=1),.1)
        q20[:,m-1]=np.nanquantile(y[:,train&(month==m)],.2,axis=1);q80[:,m-1]=np.nanquantile(y[:,train&(month==m)],.8,axis=1)
        hist=(dates.year>=1981)&(dates.year<=2010)&(month==m)
        one=np.log1p(arr[:,hist]);pa=np.log1p(past[:,hist]);onemu[:,m-1]=np.nanmean(one,axis=1);onesd[:,m-1]=np.maximum(np.nanstd(one,axis=1),.1)
        pastmu[:,m-1]=np.nanmean(pa,axis=1);pastsd[:,m-1]=np.maximum(np.nanstd(pa,axis=1),.1)
    if not np.isfinite(mu).all():raise ValueError('Unidad sin referencia suficiente')
    raw=pd.read_csv(P/'2_DATOS/ORIGINALES/noaa_oisst_mensual.txt',sep=r'\s+',skiprows=1,
                    names=['year','month','sst12','n12','sst3','n3','sst4','n4','sst34','n34'])
    raw=raw[(raw.year>=1981)&(raw.year<=2026)].copy()
    raw.index=pd.PeriodIndex(pd.to_datetime({'year':raw.year.astype(int),'month':raw.month.astype(int),'day':1}),freq='M')
    if raw.index.has_duplicates:raise ValueError('NOAA meses duplicados')
    enso=raw[['n12','n34','n4']].reindex(dates).to_numpy(copy=True);enso[np.abs(enso)>10]=np.nan
    X=np.full((U,T,len(BASE_NAMES)+len(ENSO_NAMES)),np.nan,dtype=np.float32)
    for i in range(12,T):
        m=month[i];m3=month[i-3];s=np.sin(2*np.pi*m/12);c=np.cos(2*np.pi*m/12)
        old=(np.log1p(y[:,i-12])-mu[:,m-1])/sd[:,m-1]
        base=np.column_stack([np.full(U,v) for v in [s,c,np.sin(4*np.pi*m/12),np.cos(4*np.pi*m/12),(dates[i].year-2000)/10]])
        region=units.region
        nativeflag=(units.type=='QUITO_CELDA').to_numpy()
        base=np.column_stack([base,units.lat/5,(units.lon+78)/5,(region=='Costa').astype(float),
                              ((region=='Sierra')|nativeflag).astype(float),region.isin(['Amazonía','Amazonia']).astype(float),nativeflag,
             (np.log1p(arr[:,i-3])-onemu[:,m3-1])/onesd[:,m3-1],
             (np.log1p(past[:,i-3])-pastmu[:,m3-1])/pastsd[:,m3-1],old])
        n12,n34,n4=enso[i-3];mean=np.mean(enso[i-5:i-2],axis=0)
        extra=np.array([n12,n34,n4,mean[0],mean[1],n12-enso[i-5,0],n34-enso[i-5,1],n12-n34,n12*s,n12*c,n34*s,n34*c])
        X[:,i]=np.column_stack([base,np.broadcast_to(extra,(U,len(extra)))])
    z=(np.log1p(y)-mu[:,month-1])/sd[:,month-1]
    valid=np.isfinite(X).all(axis=2)&np.isfinite(z)
    units.to_csv(D/'unidades.csv',index=False)
    np.savez_compressed(D/'panel_v06.npz',X=X,z=z,y=y,valid=valid,months=np.array(dates.astype(str),dtype=str),
                        train=train,tune=tune,cal=cal,test=test,mu=mu,sd=sd,q20=q20,q80=q80,
                        feature_names=np.array(BASE_NAMES+ENSO_NAMES),n_base=len(BASE_NAMES),unit=units.unit.to_numpy(dtype=str),
                        unit_type=units.type.to_numpy(dtype=str),region=units.region.to_numpy(dtype=str),enso=enso)
    # Build a future row explicitly from past observations; no synthetic weather observations.
    idx=len(dates)+2 # 2026-11 after last observed 2026-08 (index T+2)
    target=pd.Period('2026-11','M');m=target.month;m3=8;s=np.sin(2*np.pi*m/12);c=np.cos(2*np.pi*m/12)
    oldindex=dates.get_loc(target-12)
    old=(np.log1p(y[:,oldindex])-mu[:,m-1])/sd[:,m-1]
    flag=(units.type=='QUITO_CELDA').to_numpy();region=units.region
    base=np.column_stack([np.full(U,v) for v in [s,c,np.sin(4*np.pi*m/12),np.cos(4*np.pi*m/12),(target.year-2000)/10]])
    base=np.column_stack([base,units.lat/5,(units.lon+78)/5,(region=='Costa').astype(float),((region=='Sierra')|flag).astype(float),region.isin(['Amazonía','Amazonia']).astype(float),flag,
        (np.log1p(arr[:,-1])-onemu[:,m3-1])/onesd[:,m3-1],(np.log1p(past[:,-1])-pastmu[:,m3-1])/pastsd[:,m3-1],old])
    n12,n34,n4=enso[-1];mean=np.mean(enso[-3:],axis=0)
    extra=np.array([n12,n34,n4,mean[0],mean[1],n12-enso[-3,0],n34-enso[-3,1],n12-n34,n12*s,n12*c,n34*s,n34*c])
    future=np.column_stack([base,np.broadcast_to(extra,(U,len(extra)))])
    np.savez_compressed(D/'entrada_futura_nov2026.npz',X=future,mu=mu[:,m-1],sd=sd[:,m-1],q20=q20[:,m-1],q80=q80[:,m-1])
    summary={'unidades':U,'cantones':int((units.type=='CANTON').sum()),'celdas_nativas_quito':int(flag.sum()),'meses':T,
             'periodo_datos':[str(dates[0]),str(dates[-1])],'n_train':int((valid&train).sum()),'n_tune':int((valid&tune).sum()),
             'n_cal':int((valid&cal).sum()),'n_test':int((valid&test).sum()),'variables':BASE_NAMES+ENSO_NAMES,
             'ultima_observacion_predictor_futuro':'2026-08','temporada_futura':['2026-11','2027-01'],
             'forecast_inputs_complete':bool(np.isfinite(future).all()),'test_no_usado_normalizacion':True,
             'perdidas_fisicas_generadas':False,'fase_enso_no_es_RONI':'Anomalías OISST mensuales originales; campos z antiguos no usados'}
    (F/'control_panel_v06.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
