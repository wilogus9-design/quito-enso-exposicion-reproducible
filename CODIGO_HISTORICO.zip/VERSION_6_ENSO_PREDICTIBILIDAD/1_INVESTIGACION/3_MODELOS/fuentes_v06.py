"""Fuentes públicas actuales y lluvia mensual nativa de Quito, con caché y hashes."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json
import hashlib
import datetime as dt
import requests
import truststore
import ee
import geopandas as gpd
import rasterio
from rasterio.windows import from_bounds,Window
import numpy as np

P=Path(__file__).resolve().parents[1]
ROOT=P.parents[2]
R=P/'2_DATOS/ORIGINALES'
D=P/'2_DATOS/PROCESADOS'
F=P/'6_FINAL'
URLS={
 'cpc_discusion_20261008':'https://www.cpc.ncep.noaa.gov/products/analysis_monitoring/enso_advisory/ensodisc.shtml',
 'cpc_fuerza_roni':'https://cpc.ncep.noaa.gov/products/analysis_monitoring/enso/roni/strengths/',
 'noaa_oisst_mensual':'https://www.cpc.ncep.noaa.gov/data/indices/sstoi.indices',
 'mausam2026':'https://mausamjournal.imd.gov.in/index.php/MAUSAM/article/view/7456',
 'barnston2014':'https://journals.ametsoc.org/view/journals/apme/53/6/jamc-d-13-0133.1.xml',
 'forecastvalor':'https://www.ecmwf.int/en/forecasts/documentation-and-support/verification/verification-scores/probabilistic-forecast-evaluation'
}


def main():
    truststore.inject_into_ssl();R.mkdir(parents=True,exist_ok=True);D.mkdir(parents=True,exist_ok=True);F.mkdir(parents=True,exist_ok=True)
    sources=[]
    def public(pair):
        name,url=pair;file=R/(name+'.txt')
        try:
            if not file.exists():
                r=requests.get(url,timeout=(15,40));r.raise_for_status()
                if name=='cpc_discusion_20261008' and '8 October 2026' not in r.text:
                    raise ValueError('La discusión corriente cambió; requiere archivo de emisión 2026-10-08')
                file.write_bytes(r.content)
            return {'nombre':name,'url':url,'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'bytes':file.stat().st_size}
        except Exception as e:return {'nombre':name,'url':url,'error':type(e).__name__}
    with ThreadPoolExecutor(max_workers=3) as pool:sources=list(pool.map(public,URLS.items()))
    # Native rainfall grid is snapped to the same .05-degree forecast grid as V05.
    template=ROOT/'EXPOSICION_FEN_NINO/VERSION_5_QUITO_10M/1_INVESTIGACION/6_FINAL/lluvia_7dias_nativa_005_grados.tif'
    with rasterio.open(template) as s:tr=s.transform;width=s.width;height=s.height
    ee.Initialize(project='verdant-art-479615-c4')
    col=ee.ImageCollection('UCSB-CHC/CHIRPS/V3/DAILY_RNL').select('precipitation')
    # One year per download keeps tasks small, restartable, and under request limits.
    def year_download(year):
        folder=R/'CHIRPS3_QUITO';folder.mkdir(parents=True,exist_ok=True);file=folder/(str(year)+'.tif')
        if file.exists():return year,'cache'
        images=[];months=12 if year<2026 else 8
        for month in range(1,months+1):
            start=dt.date(year,month,1);end=dt.date(year+1,1,1) if month==12 else dt.date(year,month+1,1)
            c=col.filterDate(str(start),str(end))
            images.extend([c.sum().rename(f'r{month:02d}'),c.count().rename(f'n{month:02d}')])
        image=ee.Image.cat(*images).toFloat()
        url=image.getDownloadURL({'crs':'EPSG:4326','crs_transform':[tr.a,0,tr.c,0,tr.e,tr.f],
            'dimensions':[width,height],'format':'GEO_TIFF','filePerBand':False})
        response=requests.get(url,timeout=(20,180));response.raise_for_status();file.write_bytes(response.content)
        meta={'dataset':'UCSB-CHC/CHIRPS/V3/DAILY_RNL','year':year,'months':months,'resolution_degree':tr.a,
              'bands':'alternating rain_mm and valid_days','sha256':hashlib.sha256(file.read_bytes()).hexdigest()}
        file.with_suffix('.fuente.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
        return year,'downloaded'
    with ThreadPoolExecutor(max_workers=3) as pool:
        for a,b in pool.map(year_download,range(1981,2027)):print('Quito lluvia',a,b,flush=True)
    q=gpd.read_file(ROOT/'EXPOSICION_FEN_NINO/VERSION_5_QUITO_10M/1_INVESTIGACION/2_DATOS/PROCESADOS/quito_limite.geojson').to_crs(4326)
    # Retain all native cells intersecting Quito, rather than fabricate 10 m rain.
    from shapely.geometry import box
    cells=[];geo=q.geometry.union_all()
    for r in range(height):
        for c in range(width):
            x0,y0=tr*(c,r);x1,y1=tr*(c+1,r+1);poly=box(x0,y1,x1,y0)
            if poly.intersects(geo):cells.append({'id':f'Q{r:02d}_{c:02d}','row':r,'col':c,'lon':(x0+x1)/2,'lat':(y0+y1)/2})
    arrays=[];dates=[]
    for year in range(1981,2027):
        with rasterio.open(R/'CHIRPS3_QUITO'/(str(year)+'.tif')) as s:a=s.read()
        for month in range(1,1+a.shape[0]//2):
            days=(dt.date(year+1,1,1) if month==12 else dt.date(year,month+1,1))-dt.date(year,month,1)
            values=a[2*(month-1)][tuple(np.array([(c['row'],c['col']) for c in cells]).T)]
            count=a[2*(month-1)+1][tuple(np.array([(c['row'],c['col']) for c in cells]).T)]
            values=np.where((count==days.days)&np.isfinite(values)&(values>=0),values,np.nan)
            arrays.append(values);dates.append(f'{year}-{month:02d}')
    np.savez_compressed(D/'lluvia_nativa_quito.npz',rain=np.stack(arrays),months=np.array(dates),
                        unit=np.array([c['id'] for c in cells]),lat=np.array([c['lat'] for c in cells]),lon=np.array([c['lon'] for c in cells]))
    (D/'grilla_lluvia.json').write_text(json.dumps({'transform':list(tr),'width':width,'height':height,'cells':cells,'native_degree':tr.a},indent=2),encoding='utf-8')
    (F/'fuentes_recuperadas.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Meses',len(dates),'celdas Quito',len(cells),'faltantes',int(np.isnan(np.stack(arrays)).sum()),flush=True)


if __name__=='__main__':main()
