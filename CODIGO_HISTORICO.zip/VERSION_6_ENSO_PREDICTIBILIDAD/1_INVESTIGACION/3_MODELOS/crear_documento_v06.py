"""Word con tablas nativas, ecuaciones editables y afiliación en nota real."""
from pathlib import Path
import json
import importlib.util
import sys
import zipfile
from lxml import etree
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_ALIGN_VERTICAL
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

P=Path(__file__).resolve().parents[1];ROOT=P.parents[2]
S=Path.home()/'.codex/plugins/cache/openai-primary-runtime/documents/26.1007.11041/skills/documents'
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m


def table(doc,b):
    cap=doc.add_paragraph(b['titulo']);cap.paragraph_format.keep_with_next=True
    for r in cap.runs:r.font.size=Pt(10)
    n=len(b['encabezados']);widths=[1.7,1.5,1.65,1.65] if n==4 else [2.,.95,1.3,1.1,1.15]
    if b['titulo'].startswith('Tabla 3'):widths=[1.25,1.9,1.,1.1,1.25]
    t=doc.add_table(rows=1,cols=n);t.autofit=False;t.alignment=WD_TABLE_ALIGNMENT.CENTER
    borders=OxmlElement('w:tblBorders')
    for key in ['top','left','bottom','right','insideH','insideV']:
        e=OxmlElement('w:'+key);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
    t._tbl.tblPr.append(borders)
    for i,col in enumerate(t.columns):col.width=Inches(widths[i])
    for ri,values in enumerate([b['encabezados'],*b['filas']]):
        row=t.rows[0] if ri==0 else t.add_row();pr=row._tr.get_or_add_trPr();pr.append(OxmlElement('w:cantSplit'))
        if ri==0:pr.append(OxmlElement('w:tblHeader'))
        for i,(cell,value) in enumerate(zip(row.cells,values)):
            cell.width=Inches(widths[i]);cell.text=str(value);cell.vertical_alignment=WD_ALIGN_VERTICAL.CENTER
            cp=cell._tc.get_or_add_tcPr();pad=OxmlElement('w:tcMar')
            for key in ['top','bottom','left','right']:
                e=OxmlElement('w:'+key);e.set(qn('w:w'),'85');e.set(qn('w:type'),'dxa');pad.append(e)
            cp.append(pad)
            if ri==0:
                sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'E9EEF4');cp.append(sh)
            for p in cell.paragraphs:
                p.alignment=WD_ALIGN_PARAGRAPH.LEFT if i==0 or n==4 else WD_ALIGN_PARAGRAPH.CENTER
                p.paragraph_format.space_after=Pt(0);p.paragraph_format.line_spacing=1
                # Keep a header with at least one data row. Small forecast tables
                # stay together so a caption/header cannot become orphaned.
                if ri==0 or len(b['filas'])<=4:p.paragraph_format.keep_with_next=True
                for r in p.runs:r.font.size=Pt(9);r.font.name='Arial'
    p=doc.add_paragraph(b['nota']);p.paragraph_format.keep_together=True
    for r in p.runs:r.font.size=Pt(9)


def main():
    data=json.loads((P/'2_DATOS/PROCESADOS/articulo_v06_estructura.json').read_text(encoding='utf-8'))
    h=module('math_components',ROOT/'EXPOSICION_FEN_NINO/VERSION_5_QUITO_10M/1_INVESTIGACION/3_MODELOS/componentes_word.py')
    doc=Document();sec=doc.sections[0];sec.page_width=Inches(8.5);sec.page_height=Inches(11)
    sec.left_margin=sec.right_margin=Inches(1);sec.top_margin=sec.bottom_margin=Inches(.8)
    for name in ['Normal','Title','Heading 1']:
        st=doc.styles[name];st.font.name='Arial';st.font.color.rgb=RGBColor(0,0,0)
        st.font.size=Pt(11 if name=='Normal' else 16 if name=='Title' else 12)
        st.paragraph_format.space_after=Pt(7);st.paragraph_format.line_spacing=1.1
        st.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY if name=='Normal' else WD_ALIGN_PARAGRAPH.LEFT
    for b in data['bloques']:
        k=b['tipo']
        if k=='titulo':doc.add_paragraph(b['texto'],style='Title')
        elif k=='autor':doc.add_paragraph(b['texto']+'[[FN]]').alignment=WD_ALIGN_PARAGRAPH.LEFT;note=b['nota']
        elif k=='titulo_seccion':
            if b['texto']=='Introducción':doc.add_page_break()
            doc.add_heading(b['texto'],level=1)
        elif k=='texto':doc.add_paragraph(b['texto'])
        elif k=='tabla':table(doc,b)
        elif k=='ecuacion':
            if b['id']=='temporada':
                h.math_paragraph(doc,[('Y','u,t'),' = ',('P','u,t'),' + ',('P','u,t+1'),' + ',('P','u,t+2')])
                h.math_paragraph(doc,[('z','u,t'),' = [log(1 + ',('Y','u,t'),') − ',('μ','u,m'),'] / ',('σ','u,m')])
            else:h.math_paragraph(doc,['E(',('A','H'),') = ',('Σ','g'),' ',('A','g'),' ',('p','H,g')])
        elif k=='figura':
            p=doc.add_paragraph(b['titulo']);p.paragraph_format.keep_with_next=True
            for r in p.runs:r.font.size=Pt(10)
            p=doc.add_paragraph();p.paragraph_format.keep_with_next=True;p.add_run().add_picture(str(P/'6_FINAL'/b['archivo']),width=Inches(6.3))
            node=p._p.find('.//'+qn('wp:docPr'))
            if node is not None:node.set('descr',b['titulo']+'. '+b['nota'])
            p=doc.add_paragraph(b['nota']);p.paragraph_format.keep_together=True
            for r in p.runs:r.font.size=Pt(9)
        elif k=='referencia':
            p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.LEFT;p.paragraph_format.left_indent=Inches(.25);p.paragraph_format.first_line_indent=Inches(-.25)
            if b.get('revista'):
                a,rest=b['texto'].split(b['revista'],1);p.add_run(a);p.add_run(b['revista']+', '+b['volumen']).italic=True;p.add_run(rest[len(', '+b['volumen']):])
            else:p.add_run(b['texto'])
            for r in p.runs:r.font.size=Pt(10)
    doc.core_properties.author=data['autor'];doc.core_properties.title=data['titulo']
    fmt=OxmlElement('w:footnotePr');x=OxmlElement('w:numFmt');x.set(qn('w:val'),'chicago');fmt.append(x);sec._sectPr.append(fmt)
    base=P/'2_DATOS/PROCESADOS/manuscrito_base.docx';doc.save(base)
    output=P/'6_FINAL/MANUSCRITO_V06_ENSO.docx'
    helper=module('notes_helper',S/'scripts/insert_note.py');helper.insert_note(str(base),str(output),'footnote','[[FN]]',note)
    with zipfile.ZipFile(output) as z:entries={i.filename:z.read(i.filename) for i in z.infolist()}
    document=etree.fromstring(entries['word/document.xml'])
    for ref in document.findall('.//{'+W+'}footnoteReference'):
        run=ref.getparent();pr=etree.Element('{'+W+'}rPr');el=etree.SubElement(pr,'{'+W+'}vertAlign');el.set('{'+W+'}val','superscript');run.insert(0,pr)
    sanitizer=module('title_sanitize',S/'scripts/google_docs_title_sanitize.py');style=etree.fromstring(entries['word/styles.xml'])
    sanitizer.sanitize_styles(style);sanitizer.sanitize_document_part(document,leading_nonempty_paragraphs=6)
    entries['word/styles.xml']=etree.tostring(style,xml_declaration=True,encoding='UTF-8',standalone=True)
    entries['word/document.xml']=etree.tostring(document,xml_declaration=True,encoding='UTF-8',standalone=True)
    notes=etree.fromstring(entries['word/footnotes.xml'])
    for p in notes.findall('.//{'+W+'}p'):
        pr=etree.Element('{'+W+'}pPr');el=etree.SubElement(pr,'{'+W+'}jc');el.set('{'+W+'}val','left');p.insert(0,pr)
    entries['word/footnotes.xml']=etree.tostring(notes,xml_declaration=True,encoding='UTF-8',standalone=True)
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
        for name,content in entries.items():z.writestr(name,content)
    print('Word creado',output,flush=True)


if __name__=='__main__':main()
