"""Lee PDF locales relevantes y conserva páginas/citas, sin copiar artículos al manuscrito."""
from pathlib import Path
import json
import hashlib
from pypdf import PdfReader

P=Path(__file__).resolve().parents[1]
ROOT=P.parents[2]
R=P/'1_LITERATURA/PAPERS_LOCALES';R.mkdir(parents=True,exist_ok=True)
FILES=['Canavire_Ramos_Puerta_Ecuador.pdf','s41467-025-60973-1.pdf',
       'Tracking-paddy-rice-acreage-flooding-impacts-and-mitigations-during-El-Ni-o-flooding-events.pdf','3615886.3627747.pdf']


def main():
    inventory=[]
    for name in FILES:
        file=ROOT/'1_INVESTIGACION/PAPERS REFERENCIA'/name
        r=PdfReader(file);texts=[(p.extract_text() or '') for p in r.pages]
        selected=[i for i,t in enumerate(texts) if i==0 or any(s in t.lower() for s in ['validation','conclusion','data availability','methodology'])]
        # Reading cache, not a publication of the complete article.
        (R/(file.stem+'.txt')).write_text('\n\n'.join(f'PÁGINA {i+1}\n'+texts[i] for i in selected),encoding='utf-8')
        inventory.append({'file':str(file),'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),
                          'pages':len(texts),'pages_read':[i+1 for i in selected],'header':texts[0][:2500]})
        print(name,'páginas',len(texts),'\n',texts[0][:1900],flush=True)
    (R/'inventario.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2),encoding='utf-8')


if __name__=='__main__':main()
