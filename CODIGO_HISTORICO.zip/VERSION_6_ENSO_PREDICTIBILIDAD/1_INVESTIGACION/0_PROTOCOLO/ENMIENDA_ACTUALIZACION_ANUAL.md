# Análisis secundario de actualización

Motivo: la prueba primaria mantiene coeficientes entrenados hasta 2010 y muestra
heterogeneidad de capacidad predictiva. No se elimina esa prueba ni se cambia
su calibración. Esta enmienda se escribe después de ver esa evaluación primaria
y antes de ejecutar la actualización. Por ello es exploratoria, no confirmatoria.

Comparadores fijados para actualización: climatología de entrenamiento, ridge
sin ENSO y ridge con ENSO. No se buscan nuevas redes ni modelos por p-valores.

Por año objetivo Y de 2020 a 2025:

- Entrenamiento con veinte años: inicio Y-26, final de temporadas <=Y-7.
  Se ajusta este intervalo por inclusión: desde enero (Y-26) hasta temporadas
  cuyo final es diciembre (Y-7). Son veinte años calendario nominales.
- Selección de lambda entre 1,10,100: temporadas dentro de Y-6 a Y-4.
- Distribución de residuos: temporadas dentro de Y-3 a Y-1.
- Evaluación: temporadas enero a octubre del año Y, todas terminan en Y.
- Usar la misma referencia de umbrales de lluvia de 1983-2010 para conservar el
  significado del extremo. La evaluación primaria se compara en esos mismos
  meses, sin confundir muestras diferentes.
- Nunca usar una observación del año objetivo al ajustar ese año. Reportar
  cobertura de los intervalos incluso si la actualización la empeora.

Aplicación 2026: mismo esquema de entrenamiento, selección y calibración,
aplicado a la temporada completamente futura noviembre 2026 a enero 2027,
con predictores observados hasta agosto 2026. El pronóstico mantiene la
etiqueta experimental y su referencia pluviométrica; no se llama inundación.

Las ventanas solapadas y dependencia espacial se preservan al remuestrear años.
El análisis no permite seleccionar después de evaluar una única región ganadora
y descartar silenciosamente las demás.

## Extensión exploratoria por episodios

Se amplía adicionalmente el recorrido anual a 2011-2025 para incluir episodios
2015-2016 y el calentamiento costero de 2017, insuficientemente representados
por seis años. No modifica la prueba primaria. La referencia fija 1983-2010
ya está completamente observada antes del primer año objetivo 2011; puede
estar dentro de la etapa de calibración de un origen temprano y por ello esta
extensión no tiene una climatología reestimada sólo en su entrenamiento.
Se informa esa convención. Ninguna estadística usa lluvia del año objetivo
al ajustar su pronóstico. Son 150 temporadas enero-octubre de quince años.
La extensión es secundaria después de los resultados iniciales y se conserva
íntegra, sin elegir a posteriori un episodio con mejor desempeño.
