# ENSO predictibilidad y exposición en Quito

Diseño fijado antes de ajustar V06. V05 y el lago de datos permanecen intactos.
Fecha de decisión 2026-10-09. El cuartil de una revista no es una validación
científica ni una propiedad que pueda garantizarse por entrenamiento.

## Pregunta y contribución a contrastar

¿Cuánto aporta conocer ENSO a anticipar exceso y déficit de lluvia, con fechas
de disponibilidad conservadoras, y dónde ese aporte sirve para priorizar suelo
construido de Quito? Se distingue la escala atmosférica nativa de la exposición
de 10 m. Se evalúan calibración, transferencia temporal y utilidad de decisiones,
no sólo correlaciones. No se obliga a que El Niño aumente lluvia en Quito.

El artículo comparará esta contribución con previsión estacional ecuatoriana,
estudios de teleconexión no estacionaria y mapas estáticos de exposición. No se
reivindica ser el primer estudio ENSO ni superar detectores SAR de otro objeto.

## Datos y fechas

- CHIRPS3 mensual, cantones del Ecuador continental: 1981-01 a 2026-08.
- Quito: recuperar también la grilla mensual nativa de 0.05 grados; no bajar
  lluvia a 10 m ni entrenar un píxel con la media cantonal como si fuera su verdad.
- Índices mensuales NOAA OISST Niño 1+2, 3.4 y 4: desde 1982. Se usan anomalías
  originales, nunca columnas z estandarizadas con toda la muestra.
- RONI se conserva para contexto de la discusión NOAA, sin intercambiarlo con
  Niño 3.4 OISST. El pronóstico de fuerza oficial no es un pronóstico local de agua.
- Covariables predictivas más recientes del mes de inicio t: t-3. Este desfase
  evita usar el mes todavía no publicado. Es backtest retrospectivo con series
  revisadas, no un archivo completo de vintages operacionales.

## Objetivo y particiones

Objetivo: acumulado de lluvia de tres meses desde t, en mm. Clasificación seca
si está por debajo de P20, húmeda si por encima de P80 de la climatología de
entrenamiento para el mismo mes de inicio. Son extremos relativos estacionales,
no sequía hidrológica, tormenta instantánea o extensión inundada.

- Entrenamiento: temporadas que terminan a más tardar 2010-12.
- Selección de regularización/parada temprana: inicio >=2011-01 y fin <=2013-12.
- Distribución de residuos: inicio >=2014-01 y fin <=2019-12.
- Test: inicio >=2020-01 y fin <=2025-12. Se eliminan ventanas que cruzan cortes.
- La V06 es análisis secundario de datos previamente consultados. No se presenta
  el test como ciego o jamás examinado. No se cambiarán candidatos por sus p-valores.
- Adicionalmente: informar períodos cálidos/fríos y 2023-2024 como estratos
  descriptivos. Los meses solapados no son muestras independientes.

## Comparadores fijados

1. Climatología estacional empírica.
2. Ridge con lluvia antecedente, estación y tendencia, sin ENSO.
3. Mismo ridge incorporando ENSO y sus interacciones estacionales.
4. Red sin ENSO; red con ENSO; red con ENSO y ponderación temporal de media vida
   10 años. Mantener todas, aunque una red más compleja empeore.

Ridge: lambda 1, 10, 100; elección por error de validación 2011-2013. Las redes
usan tres semillas, dos capas SiLU de 64 y 32 unidades, máximo 160 épocas,
checkpoint por validación. No se añaden arquitecturas al ver el test.

Distribución predictiva: media de modelo en anomalía estacional logarítmica más
residuos de calibración por unidad, convertidos a mm. No se proclama garantía
conformal bajo dependencia temporal/espacial. Se comprueba cobertura empírica.

## Métricas e inferencia

MAE en mm, CRPS, Brier para húmedo/seco, cobertura y amplitud de intervalos 80 %.
Comparación emparejada por fecha y unidad; bootstrap de años completos (2000
réplicas), conservando todos los lugares de un mismo año juntos. Informar por
Costa, Sierra, Amazonía y Quito. No contar cada celda correlacionada como año.

Valor de decisión: modelo costo-pérdida normalizado, C/L 0.05 a 0.50 y
eficacia supuesta 1 y 0.5. Es utilidad de anticipar el evento pluviométrico,
no dólares de daños de hogares ni una pérdida económica observada.

## Salidas futuras y límites

Primera temporada totalmente futura: noviembre 2026 a enero 2027, empleando
últimos predictores observados agosto 2026. No insertar ENSO futuro observado
en el backtest. Cruzar probabilidades regionales con área construida municipal,
preservando cobertura y grilla. El área ponderada por probabilidad se denomina
exposición a condición pluviométrica regional, nunca hectáreas inundadas.

Si un modelo no mejora o no está calibrado, mantenerlo visible y reducir el
alcance operativo. No se simulan pérdidas, profundidad ni aluviones a partir de
lluvia mensual. V05 sigue aportando prioridades de reportes y altura experimental.
