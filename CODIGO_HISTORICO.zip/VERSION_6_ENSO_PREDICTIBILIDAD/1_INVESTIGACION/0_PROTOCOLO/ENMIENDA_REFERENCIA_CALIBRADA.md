# Auditoría del presupuesto de información

Después de la prueba inicial se detectó que los modelos usan residuos 2014-2019,
pero climatología empírica original usa sólo entrenamiento hasta 2010. El valor
de decisión relativo a esa referencia puede reflejar actualizar frecuencias,
además de discriminación predictiva. No se elimina la referencia original.

Se añade una referencia sin predictores, climatología calibrada, usando la
distribución de anomalías estacionales z de 2014-2019 con media de modelo cero.
El mismo banco, meses y unidades que las distribuciones calibradas de regresiones
y redes. No se escoge un ajuste mirando el test ni se emplea lluvia 2020-2025.

Se recalculan las curvas costo-pérdida contra las dos referencias y se indica
explícitamente cuál sostiene cada cifra. Añadir un comparador más exigente no
convierte esta auditoría posterior en una hipótesis registrada originalmente.
La comparación de redes con/sin ENSO y su intervalo principal no cambia.

La auditoría incluye además el referente estándar de mejor acción constante
evaluado con la frecuencia observada en la muestra: mínimo entre nunca actuar
y siempre actuar. Es un referente de verificación ex post, no una frecuencia
futura conocida al decidir. Se distinguen su valor potencial y las decisiones
realizables de climatologías previas. No se presenta un beneficio frente a
climatología antigua como si superara necesariamente ese referente.
