# Integración territorial y social con el modelo V11

Esta versión aplica el modelo temporal residual con vías y FABDEM de la V11 a todos los píxeles clasificados como construido por WorldCover 2021 dentro de Quito. Se conserva su ancla lineal acotada como comparador. La elección de esta variante responde al mecanismo de escorrentía y es una aplicación retrospectiva posterior a observar V10/V11, no una nueva prueba ciega ni una selección del mejor resultado de test.

1. Se mantienen pesos, estandarización, recorte de soporte y tres semillas de V11. No se reentrena con NBI ni con los resultados de aplicación.
2. Se calcula el score directamente en cada píxel construido de la malla de 10 m, con terreno y escorrentía de soporte nativo 30 m. No se interpolan las 60000 muestras de cuadratura ni se aumenta la resolución informativa del terreno.
3. Se fija el decil superior del construido por área, con empates incluidos. El umbral no se ajusta para capturar reportes del test. Otros percentiles son análisis de sensibilidad, no selección de un mejor umbral.
4. Para cada parroquia y celda meteorológica se cuentan construido y construido del decil superior. Se conservan faltantes y superficie sin asignación por separado.
5. El área prioritaria ponderada por probabilidad de trimestre húmedo se obtiene con pronósticos NDJ 2026–2027 ya congelados en V07. No equivale a superficie inundada ni a probabilidad de inundación por píxel.
6. Se pondera ese área por la tasa parroquial de NBI. Saneamiento, agua y hacinamiento son objetivos separados; no se suman con NBI por solapamiento conceptual y diferencias de denominador.
7. Se comparan dos modelos territoriales y tres meteorológicos. Un presupuesto ilustrativo máximo de 13 parroquias permite medir cuánto modifica NBI la selección. Empates en el límite se muestran, sin selección alfabética de ceros.
8. El summarize usa las 65 parroquias: N, media no ponderada, desviación estándar muestral, mínimo y máximo. No representa estadísticas de hogares individuales.
9. Las cantidades de población de la capa municipal no se transforman en personas afectadas: persiste la divergencia de universos censales documentada en V09. Las tasas se utilizan con esa limitación de versión.
10. Se entregan mapas de susceptibilidad sobre construido, tasas sociales, prioridad combinada y sensibilidad entre modelos, con fuentes, unidades y soporte explícitos. No se afirma validación de agua, profundidad, daños, pobreza futura ni aceptación editorial Q1.
