"""Aplica los tres pesos propios V11 a todas las covariables del construido.

No reentrena ni selecciona por resultados del mapa o NBI. El score de ensamble
normaliza cada semilla sobre TODO el construido válido, no sobre muestras.
"""
from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import sys
import json
import math
import io
import pickle
import zipfile
from collections import OrderedDict
import numpy as np

P=Path(__file__).resolve().parents[1];ROOT=P.parents[2]
P11=ROOT/'EXPOSICION_FEN_NINO/VERSION_11_RED_REGULARIZADA_PAPER/1_INVESTIGACION'
D=P/'2_DATOS/PROCESADOS'


def own_checkpoint(path):
    """Lector restringido de nuestros pesos float32, sin importar Torch.

    Solo admite tres globales necesarios del archivo propio V11. No habilita
    importaciones arbitrarias de pickle. Se comprueba equivalencia numérica
    con los scores guardados por PyTorch antes de aplicar el modelo.
    """
    class FloatStorage:pass
    def rebuild(storage,offset,size,stride,requires_grad,hooks,metadata=None):
        if any(v<0 for v in stride):raise ValueError('Stride no soportado')
        return np.ndarray(tuple(size),dtype=np.float32,buffer=storage,
                          offset=offset*4,strides=tuple(v*4 for v in stride)).copy()
    with zipfile.ZipFile(path)as archive:
        name=next(k for k in archive.namelist()if k.endswith('/data.pkl'));prefix=name[:-8]
        if archive.read(prefix+'byteorder').decode()!='little':raise ValueError('Byteorder no soportado')
        class Reader(pickle.Unpickler):
            def find_class(self,module,name):
                allowed={('torch._utils','_rebuild_tensor_v2'):rebuild,
                         ('torch','FloatStorage'):FloatStorage,('collections','OrderedDict'):OrderedDict}
                if (module,name)not in allowed:raise pickle.UnpicklingError('Global no autorizado')
                return allowed[module,name]
            def persistent_load(self,pid):
                typ,storage,key,location,size=pid
                if typ!='storage'or storage is not FloatStorage:raise ValueError('Storage no soportado')
                values=np.frombuffer(archive.read(prefix+'data/'+str(key)),dtype='<f4')
                if len(values)!=size:raise ValueError('Storage truncado')
                return values
        return Reader(io.BytesIO(archive.read(name))).load()


def forward(X,state):
    w=state['state_dict'];h=X
    for layer in [0,3]:
        h=h@w[f'layers.{layer}.weight'].T+w[f'layers.{layer}.bias']
        e=np.exp(-np.abs(h));h=h*np.where(h>=0,1/(1+e),e/(1+e))
    g=(h@w['layers.6.weight'].T+w['layers.6.bias']).reshape(-1)
    anchor=(X*w['anchor']).sum(-1)
    return anchor+state['bound']*np.tanh(g),anchor


def main():
    meta=json.loads((D/'control_aplicacion.json').read_text(encoding='utf-8'));key=meta['key'];n=meta['n_generated']
    X=np.load(D/'covariables_construido.npy',mmap_mode='r')
    selected=json.loads((P11/'2_DATOS/PROCESADOS/seleccion_residual.json').read_text(encoding='utf-8'))[key]
    bound=selected['bound_selected_by_calibration'];label=str(bound).replace('.','p')
    raw=np.lib.format.open_memmap(D/'scores_semillas_y_ancla.npy',mode='w+',dtype=np.float32,shape=(n,4))
    audit=[]
    for j,seed in enumerate([5101,5102,5103]):
        path=P11/f'2_DATOS/PROCESADOS/residual_{key}_B{label}_{seed}.pt'
        state=own_checkpoint(path)
        assert state['bound']==bound and state['n_features']==25
        with np.load(P11/f'2_DATOS/PROCESADOS/entrada_{key}.npz')as data:
            sample=data['Xb'][:1000]
        predicted,_=forward(sample,state)
        with np.load(P11/f'2_DATOS/PROCESADOS/scores_{key}_B{label}_{seed}.npz')as expected:
            error=float(np.max(np.abs(predicted-expected['fb'][:1000])))
        if error>5e-5:raise ValueError('La inferencia no replica los scores PyTorch: '+str(error))
        maxcorrection=0
        for start in range(0,n,16384):
                xb=np.array(X[start:min(n,start+16384)],copy=True)
                score,ancla=forward(xb,state)
                raw[start:start+len(xb),j]=score
                if j==0:raw[start:start+len(xb),3]=ancla
                maxcorrection=max(maxcorrection,float(np.max(np.abs(score-ancla))))
        assert maxcorrection<=bound+1e-4
        audit.append({'seed':seed,'bound':bound,'selected_epoch':state['epoch'],
                      'max_raw_correction':maxcorrection,'weights':path.name,
                      'max_difference_from_saved_pytorch_scores':error})
        print('Inferencia completa semilla',seed,flush=True)
    raw.flush()
    normalizers=[]
    for j in range(4):
        maximum=float(np.max(raw[:,j]));total=0.
        for start in range(0,n,262144):total+=np.exp(raw[start:start+262144,j].astype(float)-maximum).sum()
        normalizers.append(maximum+math.log(total/n))
    out=np.lib.format.open_memmap(D/'scores_aplicacion.npy',mode='w+',dtype=np.float32,shape=(n,2))
    for start in range(0,n,262144):
        a=raw[start:start+262144,:3].astype(float)-np.array(normalizers[:3])[None,:]
        top=a.max(1);out[start:start+len(a),0]=top+np.log(np.exp(a-top[:,None]).mean(1))
        out[start:start+len(a),1]=raw[start:start+len(a),3]-normalizers[3]
    out.flush()
    (D/'control_inferencia.json').write_text(json.dumps({'n_pixels':n,'models':['red_residual','ancla_acotada'],
        'key':key,'bound_selected_by_calibration':bound,'seeds':audit,
        'normalizers_built_conditioned':normalizers,'no_retraining':True,
        'interpretation':'Densidad relativa condicionada al construido; no probabilidad de inundacion'},indent=2),encoding='utf-8')
    print('Scores completos guardados para',n,'pixeles',flush=True)


if __name__=='__main__':main()
