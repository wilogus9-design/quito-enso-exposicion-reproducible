"""Inventario trazable de bibliografía previa y PDFs de la biblioteca del autor.

Extraer metadatos no equivale a revisar íntegramente cada paper. Se explicita
la profundidad de lectura y no se añade automáticamente toda referencia.
"""
from pathlib import Path
import re
import json
import hashlib
from pypdf import PdfReader

P=Path(__file__).resolve().parents[1];ROOT=P.parents[2];L=P/'1_LITERATURA'


def main():
    L.mkdir(exist_ok=True);items={};sources=[]
    for bib in sorted((ROOT/'EXPOSICION_FEN_NINO').rglob('*.bib')):
        if 'VERSION_12_'in str(bib):continue
        text=bib.read_text(encoding='utf-8',errors='replace')
        dois=re.findall(r'\bdoi\s*=\s*\{([^}]+)\}',text,re.I)
        for doi in dois:
            key=doi.strip().lower();items.setdefault(key,{'doi':key,'bibliografias_previas':[]})['bibliografias_previas'].append(str(bib.relative_to(ROOT)))
    for pdf in sorted((ROOT/'1_INVESTIGACION/PAPERS REFERENCIA').glob('*.pdf')):
        record={'archivo':pdf.name,'ruta_relativa':str(pdf.relative_to(ROOT)),
                'sha256':hashlib.sha256(pdf.read_bytes()).hexdigest()}
        try:
            reader=PdfReader(pdf);text='\n'.join(page.extract_text()or''for page in reader.pages[:2])
            record.update({'paginas':len(reader.pages),'texto_extraido_paginas':[1,2],
                'lectura':'Identificación y primeras dos páginas; no revisión íntegra automática',
                'doi_candidatos':sorted(set(re.findall(r'10\.\d{4,9}/[^\s<>"\]{}]+',text)))})
            (L/(pdf.stem+'.primeras_paginas.txt')).write_text(text,encoding='utf-8')
        except Exception as e:record['error']=str(e)
        sources.append(record)
    (L/'inventario_bibliografias_previas.json').write_text(json.dumps(list(items.values()),ensure_ascii=False,indent=2),encoding='utf-8')
    (L/'inventario_papers_biblioteca.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2),encoding='utf-8')
    print('DOI distintos en versiones previas:',len(items),'PDF identificados:',len(sources),flush=True)


if __name__=='__main__':main()
