"""Extrae covariables reales del construido en ventanas, sin interpolar muestras.

El runtime geoespacial no importa Torch. Se comunica con la inferencia mediante
matrices .npy mapeadas a disco, para mantener acotado el uso de memoria.
"""
from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
os.environ['GDAL_CACHEMAX']='8'
import sys
import json
import numpy as np
import rasterio
from rasterio.windows import Window
from pyproj import Transformer
from affine import Affine

P=Path(__file__).resolve().parents[1];ROOT=P.parents[2]
P5=ROOT/'EXPOSICION_FEN_NINO/VERSION_5_QUITO_10M/1_INVESTIGACION'
P6=ROOT/'EXPOSICION_FEN_NINO/VERSION_6_ENSO_PREDICTIBILIDAD/1_INVESTIGACION'
P9=ROOT/'EXPOSICION_FEN_NINO/VERSION_9_INTEGRACION_SOCIAL/1_INVESTIGACION'
P10=ROOT/'EXPOSICION_FEN_NINO/VERSION_10_ESCORRENTIA_LOCAL/1_INVESTIGACION'
P11=ROOT/'EXPOSICION_FEN_NINO/VERSION_11_RED_REGULARIZADA_PAPER/1_INVESTIGACION'
D=P/'2_DATOS/PROCESADOS';F=P/'6_FINAL'
KEY='temporal__vias_fabdem'


class BuiltFeatures:
    """Mismas 20 transformaciones V05, materializadas SOLO para construido.

    Evita importar geopandas, scipy y matplotlib y evita X de todos los píxeles
    de cada ventana. Los índices 10 m//3 replican window_features de V05.
    """
    def __init__(self):
        source=P5/'2_DATOS/PROCESADOS'
        self.wc=rasterio.open(source/'worldcover_2021_10m.tif')
        self.mask=rasterio.open(source/'mascara_quito_10m.tif')
        self.terrain=rasterio.open(source/'derivados_30m.tif')
        self.density=rasterio.open(source/'densidad_construida_10m.tif')

    def window_built(self,row,rows=12):
        width=self.wc.width;win=Window(0,row,width,min(rows,self.wc.height-row))
        wc=self.wc.read(1,window=win).reshape(-1)
        built=(wc==50)&(self.mask.read(1,window=win).reshape(-1)>0)
        ids=np.flatnonzero(built);rr=row+ids//width;cc=ids%width
        if not len(ids):return np.empty((0,20),np.float32),ids,win,0
        r30=rr//3;c30=cc//3
        tw=Window(0,int(r30.min()),self.terrain.width,int(r30.max()-r30.min()+1))
        t=self.terrain.read(window=tw)[:,r30-int(r30.min()),c30]
        good=np.isfinite(t).all(0);excluded=int((~good).sum())
        ids=ids[good];t=t[:,good]
        d=self.density.read(window=win).reshape(2,-1)[:,ids]
        classes=[10,20,30,40,50,60,70,80,90,95,100]
        raw=np.stack([t[0]/1000,t[1],t[2],t[3],np.log1p(t[4]/10),np.log1p(t[5]/10),
                      np.log1p(t[6]/10),d[0],d[1],*[(wc[ids]==v).astype(np.float32)for v in classes]],axis=1)
        return raw,ids,win,excluded


def main():
    D.mkdir(parents=True,exist_ok=True);F.mkdir(parents=True,exist_ok=True)
    st=json.loads((P11/'2_DATOS/PROCESADOS/parametros_ancla.json').read_text(encoding='utf-8'))[KEY]
    with np.load(P11/f'2_DATOS/PROCESADOS/entrada_{KEY}.npz')as z:
        lo=z['lo'];hi=z['hi']
    mu=np.asarray(st['mu'],np.float32);sd=np.asarray(st['sd'],np.float32)
    grid=json.loads((P6/'2_DATOS/PROCESADOS/grilla_lluvia.json').read_text(encoding='utf-8'))
    cellmap=np.full((grid['height'],grid['width']),-1,dtype=np.int16)
    for j,c in enumerate(grid['cells']):cellmap[c['row'],c['col']]=j
    wt=Affine(*grid['transform'][:6]);tf=Transformer.from_crs(32717,4326,always_xy=True)
    features=BuiltFeatures();width=features.wc.width;height=features.wc.height
    capacity=0
    for row in range(0,height,128):
        win=Window(0,row,width,min(128,height-row))
        capacity+=int(((features.wc.read(1,window=win)==50)&(features.mask.read(1,window=win)>0)).sum())
    print('Construido WorldCover a procesar:',capacity,'pixeles',flush=True)
    def mmap(name,dtype,shape):return np.lib.format.open_memmap(D/(name+'.npy'),mode='w+',dtype=dtype,shape=shape)
    X=mmap('covariables_construido',np.float32,(capacity,25))
    flat=mmap('indice_pixel',np.int64,(capacity,));pid=mmap('id_parroquia',np.uint8,(capacity,))
    wid=mmap('id_lluvia',np.int16,(capacity,));clip=mmap('soporte_recortado',np.uint8,(capacity,))
    edge=mmap('borde_hidrologico',np.uint8,(capacity,))
    n=0;excluded=0;nonfinite=0;unassigned=0
    with rasterio.open(P10/'2_DATOS/PROCESADOS/escorrentia_fabdem_30m.tif')as hydro, \
         rasterio.open(P9/'2_DATOS/PROCESADOS/parroquias_censo_10m.tif')as par:
        assert hydro.width*3==width and hydro.height*3==height
        assert hydro.transform.a==30 and hydro.transform.c==features.wc.transform.c
        for row in range(0,height,12):
            raw,ids,win,bad=features.window_built(row,12)
            excluded+=bad
            rr=row+ids//width;cc=ids%width
            r30=rr//3;c30=cc//3
            if not len(ids):continue
            tw=Window(0,int(r30.min()),hydro.width,int(r30.max()-r30.min()+1))
            h=hydro.read([1,2,3,4,5,6],window=tw)[:,r30-int(r30.min()),c30]
            local=np.concatenate([raw,np.log1p(h[5]/10)[:,None],h[:4].T],axis=1)
            good=np.isfinite(local).all(1);nonfinite+=int((~good).sum())
            ids=ids[good];rr=rr[good];cc=cc[good];h=h[:,good];local=local[good]
            norm=(local-mu)/sd
            clips=((norm<lo)|(norm>hi)).any(1)
            values=np.clip(norm,lo,hi).astype(np.float32)
            lon,lat=tf.transform(features.wc.transform.c+(cc+.5)*10,
                                 features.wc.transform.f-(rr+.5)*10)
            gr=np.floor((lat-wt.f)/wt.e).astype(int);gc=np.floor((lon-wt.c)/wt.a).astype(int)
            if (gr<0).any()or(gc<0).any()or(gr>=cellmap.shape[0]).any()or(gc>=cellmap.shape[1]).any():
                raise ValueError('Construido fuera de grilla meteorologica')
            weather=cellmap[gr,gc]
            if (weather<0).any():raise ValueError('Construido sin celda meteorologica')
            parish=par.read(1,window=win).reshape(-1)[ids]
            unassigned+=int((parish==0).sum())
            end=n+len(ids);X[n:end]=values;flat[n:end]=rr*width+cc
            pid[n:end]=parish;wid[n:end]=weather;clip[n:end]=clips;edge[n:end]=h[4]>0
            n=end
            if row%960==0:print('Filas',row,'de',height,'pixeles válidos',n,flush=True)
    for a in [X,flat,pid,wid,clip,edge]:a.flush()
    info={'key':KEY,'n_generated':n,'capacity':capacity,'excluded_base_features':excluded,
          'excluded_nonfinite_hydro':nonfinite,'unassigned_parish_pixels':unassigned,
          'fraction_any_clipped':float(clip[:n].mean()),'fraction_hydro_external_edge':float(edge[:n].mean()),
          'height':height,'width':width,'transform':list(features.wc.transform)[:6],
          'crs':'EPSG:32717','weather_units':[c['id']for c in grid['cells']],
          'names':st['names'],'terrain_native_m':30,'analysis_grid_m':10,
          'no_interpolation_of_quadrature':True,'built_year':2021}
    (D/'control_aplicacion.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(info,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
