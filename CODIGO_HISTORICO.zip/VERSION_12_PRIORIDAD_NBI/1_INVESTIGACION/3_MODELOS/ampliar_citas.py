"""Une fundamentos con afirmaciones concretas, bibliografía APA y BibTeX.

Usa metadatos verificados. Una entrada no se incluye por estar en el inventario,
sino porque tiene un papel identificado en el artículo. No modifica resultados.
"""
from pathlib import Path
import json
import re
import csv
import html
import unicodedata

P=Path(__file__).resolve().parents[1];D=P/'2_DATOS/PROCESADOS';F=P/'6_FINAL';L=P/'1_LITERATURA'
SELECTION={
 'canavire2026':('10.1016/j.worlddev.2026.107468','Lluvia y resultados económicos en Ecuador'),
 'rentschler2022':('10.1038/s41467-022-30727-4','Exposición y pobreza como dimensiones distintas'),
 'nearing2024':('10.1038/s41586-024-07145-1','Pronóstico hidrológico no equivale a segmentación urbana'),
 'misra2025':('10.1038/s41467-025-60973-1','Segmentación SAR observada y máscaras urbanas'),
 'fox2024':('10.1038/s41467-024-47394-2','Índice de exposición ajustada por vulnerabilidad'),
 'mester2025':('10.1038/s41467-025-64015-8','Vulnerabilidad al desplazamiento y contexto social'),
 'hawker2022':('10.1088/1748-9326/ac4d4f','FABDEM y soporte nativo 30 m'),
 'watson2022':('10.5194/nhess-22-1699-2022','Antecedente territorial y desigualdad de acceso en Quito'),
 'warton2010':('10.1214/10-AOAS331','Presencia, cuadratura y no interpretación de pseudoausencias'),
 'bentivoglio2022':('10.5194/hess-26-4345-2022','Susceptibilidad, agua observada y amenaza hidráulica'),
 'barnes2014':('10.1016/j.cageo.2013.04.024','Relleno digital Priority-Flood'),
 'ocallaghan1984':('10.1016/S0734-189X(84)80011-0','Extracción de redes de drenaje desde elevación'),
 'roberts2017':('10.1111/ecog.02881','Validación temporal y espacial estructurada'),
 'meyer2021':('10.1111/2041-210X.13650','Dominio de aplicación; recorte no valida transferencia'),
 'elfwing2018':('10.1016/j.neunet.2017.12.012','Activación SiLU'),
 'gneiting2007':('10.1198/016214506000001437','Evaluación probabilística con reglas propias'),
 'gneiting2013':('10.1214/13-EJS823','Transformación beta de distribuciones predictivas'),
 'kirtman2014':('10.1175/BAMS-D-12-00050.1','Fundamento NMME'),
 'becker2016':('10.1175/JCLI-D-14-00862.1','Verificación probabilística de pronósticos NMME'),
 'recalde2014':('10.1175/JAMC-D-13-0133.1','Predictibilidad de lluvia heterogénea entre Costa y Andes'),
 'funk2026':('10.1038/s41597-026-07096-4','Fuente CHIRPS versión 3 y subcaptación'),
 'izawong2026':('10.1002/asl.70002','Validación de precipitación en terreno complejo de Ecuador'),
 'hubermagoffin2023':('10.3390/rs15245713','Diferencias entre agregación diaria y mensual en Ecuador'),
 'arechua2025':('10.3390/hydrology12090225','Referencia Andina Ambato y métricas según aplicación'),
 'llerenapinto2025':('10.1016/j.worlddev.2025.107107','Choques recurrentes, ingreso y pobreza rural de Ecuador'),
 'rosales2018':('10.1016/j.jhealeco.2018.07.003','El Niño ecuatoriano y resultados de hogares y capital humano'),
 'cutter2003':('10.1111/1540-6237.8402002','Vulnerabilidad social multidimensional'),
 'robinson1950':('10.2307/2087176','Límite de inferencia de unidades agregadas a individuos'),
 'tellman2021':('10.1038/s41586-021-03695-w','Observación satelital de inundación y exposición'),
 'li2023':('10.1145/3615886.3627747','Modelo Prithvi como antecedente de segmentación no usado aquí'),
 'liu2024':('10.1016/j.isprsjprs.2024.08.010','Separación de uso de suelo, inundación e impacto agrícola')}


def clean(text):return re.sub(r'\s+',' ',html.unescape(re.sub(r'<[^>]*>','',text))).strip().rstrip('*').strip()
def normalized(text):return re.sub(r'[^a-z0-9]','',unicodedata.normalize('NFKD',text).encode('ascii','ignore').decode().lower())
def year(m):return m.get('published-print',m.get('published',m['issued']))['date-parts'][0][0]
def family(a):return clean(a.get('family',a.get('name',''))).replace('‐','-')
def initials(g):
    return ' '.join(x[0]+'.'for x in re.split(r'[\s-]+',clean(g))if x)
def authors_apa(m):
    a=[family(p)+', '+initials(p.get('given',''))+(', '+p['suffix']if p.get('suffix')else'')for p in m['author']]
    if len(a)>20:return ', '.join(a[:19])+', … '+a[-1]
    if len(a)==1:return a[0]
    return ', '.join(a[:-1])+', & '+a[-1]
def citation(m):
    a=m['author'];name=family(a[0])
    if len(a)==2:name+=' & '+family(a[1])
    elif len(a)>2:name+=' et al.'
    return name+', '+str(year(m))
def apa(m):
    journal=clean(m['container-title'][0]);vol=m.get('volume','');issue=m.get('issue','')
    locator=clean(m.get('page',m.get('article-number','')))
    if journal in ['Nature Communications','Scientific Data','Hydrology','Remote Sensing','Atmospheric Science Letters']or(locator.isdigit()and len(locator)>=5):locator='Article '+locator
    issue='('+issue+')'if issue and issue.lower()not in ['none','null']and journal not in ['Nature Communications','Scientific Data']else''
    if m.get('type')=='proceedings-article':
        return f'{authors_apa(m)} ({year(m)}). {clean(m["title"][0])}. In {journal} (pp. {locator}). {m.get("publisher","ACM")}. https://doi.org/{m["DOI"]}'
    return f'{authors_apa(m)} ({year(m)}). {clean(m["title"][0])}. {journal}, {vol}{issue}, {locator}. https://doi.org/{m["DOI"]}'
def bibtex(key,m):
    author=' and '.join(family(a)+', '+clean(a.get('given',''))+(', '+a['suffix']if a.get('suffix')else'')for a in m['author'])
    typ='inproceedings'if m.get('type')=='proceedings-article'else'article'
    container='booktitle'if typ=='inproceedings'else'journal'
    fields={'author':author,'year':str(year(m)),'title':clean(m['title'][0]),container:clean(m['container-title'][0]),'doi':m['DOI']}
    for original,target in [('volume','volume'),('issue','number'),('page','pages')]:
        if m.get(original)and str(m[original]).lower()not in ['none','null']:fields[target]=m[original]
    return '@'+typ+'{'+key+',\n'+',\n'.join(' '+k+'={'+v+'}'for k,v in fields.items())+'\n}\n'


def main():
    rows=json.loads((L/'auditoria_crossref_completa.json').read_text(encoding='utf-8'))
    bydoi={r['doi_solicitado'].lower():r for r in rows}
    refs={key:bydoi[doi.lower()]['metadatos']for key,(doi,purpose)in SELECTION.items()}
    title_case={
        'cutter2003':'Social vulnerability to environmental hazards',
        'gneiting2007':'Strictly proper scoring rules, prediction, and estimation',
        'recalde2014':'Predictability of December–April rainfall in coastal and Andean Ecuador',
        'becker2016':'Probabilistic seasonal forecasts in the North American Multimodel Ensemble: A baseline skill assessment',
        'kirtman2014':'The North American Multimodel Ensemble: Phase-1 seasonal-to-interannual prediction; Phase-2 toward developing intraseasonal prediction',
        'robinson1950':'Ecological correlations and the behavior of individuals',
        'arechua2025':'Assessment of satellite precipitation products in an Andean catchment: Ambato River basin, Ecuador',
        'hubermagoffin2023':'Evaluating the performance of satellite derived temperature and precipitation datasets in Ecuador',
        'izawong2026':'Evaluation of precipitation observations across Ecuador'}
    for key,title in title_case.items():refs[key]={**refs[key],'title':[title]}
    refs['robinson1950']={**refs['robinson1950'],'page':'351-357'}
    content=json.loads((D/'contenido_paper.json').read_text(encoding='utf-8'))
    # The base is rebuilt before this stage. Never append twice to edited text.
    index=next(i for i,b in enumerate(content['blocks'])if b['type']=='heading'and b['text']=='Referencias')
    body=content['blocks'][:index]
    use={key:[]for key in refs}
    def paragraph(text,keys):
        return {'type':'paragraph','text':text+' ('+'; '.join(citation(refs[k])for k in keys)+').','citation_keys':keys}
    def after(prefix,text,keys):
        matches=[i for i,b in enumerate(body)if b['type']=='paragraph'and prefix in b['text']]
        if len(matches)!=1:raise ValueError('Ancla textual no unívoca: '+prefix)
        i=matches[0]
        body.insert(i+1,paragraph(text,keys))
    after('La contribución se concentra',
        'Los antecedentes locales ya integran satélites, peligros y desigualdad territorial: Watson y colaboradores estudian la expansión de Quito y el acceso a espacios de reducción de riesgo. La evidencia económica ecuatoriana examina choques recurrentes de precipitación e ingreso rural, y efectos de exposición temprana a inundaciones de El Niño sobre capital humano. Estos resultados justifican diferenciar preparación territorial y bienestar observado, sin trasladar directamente sus coeficientes a un índice construido de NBI',
        ['watson2022','llerenapinto2025','rosales2018'])
    after('Las 20 covariables iniciales',
        'CHIRPS3 combina información infrarroja, climatología y estaciones, e incorpora corrección de subcaptación. Las evaluaciones de productos de precipitación en Ecuador muestran que el desempeño cambia con la topografía, el agregado temporal y el objetivo de uso. Un resultado mensual o estacional no garantiza representar extremos horarios urbanos; los contrastes andinos se consideran antecedentes de medición, no validaciones sustitutas de nuestras celdas',
        ['funk2026','izawong2026','hubermagoffin2023','arechua2025'])
    after('La conectividad se calcula',
        'El relleno de depresiones y la extracción de direcciones de drenaje cuentan con algoritmos establecidos. Nuestra implementación utiliza esa base geomorfológica para construir covariables; no reproduce un solver de aguas someras ni convierte diferencias del DEM en profundidades observadas',
        ['barnes2014','ocallaghan1984'])
    after('Cada reporte se representa',
        'La distinción entre presencia y fondo se fundamenta en modelos de proceso puntual, que evitan tratar la cuadratura como pseudoausencias físicas. Aquí se estima la distribución espacial condicional de los reportes y se integra incertidumbre de posición. La extensión de ese marco a reportes institucionales requiere reconocer el proceso de observación y su posible sesgo',
        ['warton2010'])
    after('C(x) denota',
        'La activación SiLU multiplica su entrada por una sigmoide. Dropout elimina unidades durante el ajuste y se desactiva en inferencia. AdamW separa la penalización de pesos del paso adaptativo del optimizador. Se emplean estos componentes como instrumentos de regularización; las amplitudes y tasas del experimento son decisiones declaradas de nuestro protocolo, no valores científicamente garantizados por sus artículos originales',
        ['elfwing2018'])
    after('Se evalúa la log densidad',
        'La evaluación con estructura espacial y temporal responde al riesgo de que particiones aleatorias compartan información dependiente y subestimen error de transferencia. El tamaño del bloque es una decisión operativa que requiere sensibilidad y no elimina automáticamente la dependencia por episodio. La lectura de puntuaciones probabilísticas mantiene un estimando explícito; mejorar ranking, densidad o cobertura son resultados diferentes',
        ['roberts2017','gneiting2007'])
    after('De 3022395 píxeles',
        'El recorte univariado limita extrapolaciones extremas, pero no demuestra que las combinaciones de covariables estén representadas en entrenamiento. Un análisis multidimensional de área de aplicación es una extensión distinta del recorte empleado aquí. Las máscaras de soporte y los rangos entre semillas se interpretan con esa restricción',
        ['meyer2021'])
    after('La capa municipal del Censo',
        'La vulnerabilidad social comprende dimensiones distintas de exposición y renta. Por eso se conservan objetivos separados de NBI y servicios. Una correlación o tasa calculada para parroquias no identifica qué hogar de una zona susceptible presenta esa privación; asignar resultados de unidades agregadas a individuos incurriría en una inferencia ecológica injustificada',
        ['cutter2003','robinson1950'])
    i=next(i for i,b in enumerate(body)if b['type']=='paragraph'and b['text'].startswith('La capa municipal del Censo'))
    body.insert(i+1,{'type':'paragraph','text':'La metodología censal NBI del Instituto Nacional de Estadística y Censos (INEC) distingue privaciones de vivienda, servicios básicos, dependencia económica, escolaridad y hacinamiento. La clasificación del hogar por al menos una privación se comparte con sus miembros. Los componentes de servicios pueden solaparse con la NBI; por ello, no se suman sus porcentajes para crear un total de personas privadas. Las denominaciones de agua y saneamiento aquí utilizadas corresponden a los alias publicados de pc_FSA y pc_SH de la capa municipal, sin afirmar una prueba instrumental de calidad del agua (INEC, 2024).','citation_keys':['inec_nbi']})
    after('El componente meteorológico conserva',
        'El marco estacional reconoce que la predictibilidad de lluvia ligada a ENSO difiere entre la Costa y los Andes. NMME ofrece un competidor dinámico con verificación propia; la combinación y recalibración de distribuciones puede mejorar su adecuación, pero debe evaluarse fuera del ajuste. La transformación beta utilizada conserva esa separación',
        ['recalde2014','kirtman2014','becker2016','gneiting2013'])
    after('La comparación SAR sigue',
        'La literatura distingue segmentación de inundación observada, susceptibilidad y mapas de amenaza con profundidad. Tellman y colaboradores analizan inundaciones observadas por satélite y su exposición; Li y colaboradores evalúan Prithvi para segmentación en escenarios no vistos. El estudio agrícola de Liu y colaboradores separa cobertura de arroz, inundación y respuesta posterior con Sentinel-1/2. Esos antecedentes, incluidos en la biblioteca del autor, informan el diseño de una futura validación física, pero sus pesos y etiquetas no se aplicaron al modelo territorial de Quito. Un pronóstico hidrológico en cuencas tampoco constituye validación automática de agua urbana a 10 m',
        ['bentivoglio2022','tellman2021','li2023','liu2024','nearing2024'])
    after('La integración de vulnerabilidad social',
        'Los índices ajustados por vulnerabilidad y los modelos de desplazamiento emplean medidas y resultados distintos. Incorporar privación permite cambiar el objetivo distributivo, pero no convierte nuestro índice de hectáreas ponderadas en desplazamiento observado, consumo perdido o bienestar futuro. Se preserva esa diferencia al interpretar prioridades',
        ['fox2024','rentschler2022','mester2025'])
    # Original citations are retained; identify their use without fuzzy author matching.
    plain='\n'.join(b.get('text','')for b in body if b['type']=='paragraph')
    for key,m in refs.items():
        for i,b in enumerate(body):
            if key in b.get('citation_keys',[]):use[key].append(i)
        if not use[key]and family(m['author'][0])in plain and str(year(m))in plain:use[key]=['cita original conservada']
        if not use[key]:raise ValueError('Referencia sin uso concreto: '+key)
    extras=[
        ('dropout2014','Srivastava, N., Hinton, G., Krizhevsky, A., Sutskever, I., & Salakhutdinov, R. (2014). Dropout: A simple way to prevent neural networks from overfitting. Journal of Machine Learning Research, 15, 1929–1958. https://jmlr.org/papers/v15/srivastava14a.html',
         '@article{dropout2014, author={Srivastava, Nitish and Hinton, Geoffrey and Krizhevsky, Alex and Sutskever, Ilya and Salakhutdinov, Ruslan}, year={2014}, title={Dropout: A simple way to prevent neural networks from overfitting}, journal={Journal of Machine Learning Research}, volume={15}, pages={1929--1958}, url={https://jmlr.org/papers/v15/srivastava14a.html}}'),
        ('adamw2019','Loshchilov, I., & Hutter, F. (2019). Decoupled weight decay regularization. International Conference on Learning Representations. https://openreview.net/forum?id=Bkg6RiCqY7',
         '@inproceedings{adamw2019, author={Loshchilov, Ilya and Hutter, Frank}, year={2019}, title={Decoupled weight decay regularization}, booktitle={International Conference on Learning Representations}, url={https://openreview.net/forum?id=Bkg6RiCqY7}}')]
    regularization=next(b for b in body if b['type']=='paragraph'and b['text'].startswith('La activación SiLU'))
    regularization['text']=regularization['text'][:-2]+'; Srivastava et al., 2014; Loshchilov & Hutter, 2019).'
    # Institutional/data entries: retain eight source records from the base.
    previous=content['blocks'][index+1:]
    institutional=[b for b in previous if 'https://doi.org/'not in b['text']or'10.5281/zenodo.7254221'in b['text']]
    institutional.append({'type':'reference','citation_key':'inec_nbi','text':'Instituto Nacional de Estadística y Censos. (2024). Pobreza por necesidades básicas insatisfechas Una mirada desde el Censo 2022. https://www.ecuadorencifras.gob.ec/documentos/web-inec/Censo2022/Documento_NBI_24.09.25.pdf'})
    source_keys={'10.5281/zenodo.7254221':'worldcover2021','dataspace.copernicus.eu':'copernicusdem',
        'plan_de_uso_y_gestion_del_suelo_2024':'pugs2024','s_nbi_porcentaje_personas':'nbi2022',
        'UCSB-CHC_CHIRPS':'chirps3','sstoi.indices':'noaaindices','NMME/realtime_anom':'nmme',
        'sgrportal.gestionderiesgos':'sngr'}
    for b in institutional:
        if 'citation_key'not in b:b['citation_key']=next(key for pattern,key in source_keys.items()if pattern in b['text'])
    cpc=sorted([b for b in institutional if b['text'].startswith('Climate Prediction Center.')],key=lambda b:b['text'])
    for suffix,b in zip(['a','b'],cpc):b['text']=b['text'].replace('(s. f.)',f'(s. f.-{suffix})')
    biblio=[{'type':'reference','text':apa(m),'citation_key':key}for key,m in refs.items()]
    biblio.extend({'type':'reference','text':text,'citation_key':key}for key,text,_ in extras)
    # Preserve surname boundaries: Li precedes Liu (removing punctuation would
    # incorrectly sort "Li, W." after "Liu, R.").
    biblio+=institutional
    biblio.sort(key=lambda b:unicodedata.normalize('NFKD',b['text']).encode('ascii','ignore').decode().casefold())
    # Avoid a half-empty page before the social map while keeping figure order.
    social_figure=next(b for b in body if b['type']=='figure'and b['title'].startswith('Figura 4.'))
    main_result=next(b for b in body if b['type']=='paragraph'and b['text'].startswith('Con un presupuesto ilustrativo'))
    body.remove(social_figure);body.remove(main_result)
    target=next(i for i,b in enumerate(body)if b['type']=='figure'and b['title'].startswith('Figura 5.'))
    body[target:target]=[social_figure,main_result]
    content['blocks']=body+[{'type':'heading','text':'Referencias'}]+biblio
    (D/'contenido_paper.json').write_text(json.dumps(content,ensure_ascii=False,indent=2),encoding='utf-8')
    # Preserve non-article source entries, replacing all journal entries canonically.
    oldbib=(F/'referencias_paper.bib').read_text(encoding='utf-8')
    misc='\n'.join('@misc'+part.split('\n@')[0]for part in oldbib.split('@misc')[1:])
    misc+='\n@techreport{inec_nbi, author={{Instituto Nacional de Estadística y Censos}}, year={2024}, title={Pobreza por necesidades básicas insatisfechas: Una mirada desde el Censo 2022}, institution={INEC}, url={https://www.ecuadorencifras.gob.ec/documentos/web-inec/Censo2022/Documento_NBI_24.09.25.pdf}, note={Año sugerido en créditos; portada septiembre 2025. Discrepancia de fecha conservada en auditoría.}}\n'
    bibliography='\n'.join(bibtex(key,m)for key,m in refs.items())+'\n'+'\n'.join(b for _,_,b in extras)+'\n'+misc
    (F/'referencias_paper.bib').write_text(bibliography,encoding='utf-8')
    lines=['---',f'title: "{content["title"]}"','lang: es','format: docx','---','',content['author']+'[^autor]','',
        '[^autor]: '+content['footnote'],'','Códigos JEL: '+content['JEL'],'']
    for b in content['blocks']:
        typ=b['type']
        if typ=='heading':lines+=['## '+b['text'],'']
        elif typ in ['paragraph','reference']:lines+=[b['text'],'']
        elif typ=='equation':lines+=['$$'+b['latex']+'$$','']
        elif typ=='figure':lines+=[b['title'],'',f'![](GRAFICOS/{b["file"]})','',b['note'],'']
        elif typ=='table':
            lines+=[b['title'],'','| '+' | '.join(b['headers'])+' |','| '+' | '.join(['---']*len(b['headers']))+' |']
            lines+=['| '+' | '.join(map(str,row))+' |'for row in b['rows']];lines+=['',b['note'],'']
    text='\n'.join(lines);(F/'MANUSCRITO_QUITO_V12.qmd').write_text(text,encoding='utf-8')
    with(F/'matriz_afirmaciones_fuentes.csv').open('w',encoding='utf-8',newline='')as f:
        w=csv.DictWriter(f,fieldnames=['clave','doi','afirmacion_o_funcion','cita_en_texto','tipo_verificacion','url_primaria']);w.writeheader()
        for key,(doi,purpose)in SELECTION.items():w.writerow({'clave':key,'doi':doi,'afirmacion_o_funcion':purpose,
            'cita_en_texto':citation(refs[key]),'tipo_verificacion':'Identidad Crossref; contenido pertinente revisado, no replicación del paper',
            'url_primaria':'https://doi.org/'+doi})
        for key,ref,_ in extras:w.writerow({'clave':key,'afirmacion_o_funcion':'Componente de regularización neuronal',
            'cita_en_texto':key,'tipo_verificacion':'Fuente primaria sin DOI obligatorio','url_primaria':ref.rsplit(' ',1)[-1]})
        for ref in institutional:
            w.writerow({'clave':ref.get('citation_key','fuente_institucional'),'afirmacion_o_funcion':ref['text'].split('https://')[0],
                'cita_en_texto':'Fuente de datos o definición en cuerpo y tablas','tipo_verificacion':'Fuente primaria institucional; conserva versiones y limitaciones',
                'url_primaria':'https://'+ref['text'].split('https://',1)[1]})
    cited=set(SELECTION)
    corpus=[]
    for row in rows:
        included=next((key for key,(doi,purpose)in SELECTION.items()if doi.lower()==row['doi_solicitado'].lower()),None)
        if 'metadatos_datacite'in row:reason='Producto de datos de ramas previas; no es un dato de entrada del modelo V12'
        elif 'Author Correction'in row.get('titulo',''):reason='Corrección editorial revisada por separado; usar versión HTML/PDF actualizada'
        elif 'Bolivia'in row.get('titulo',''):reason='Otro país y otro peligro; no sustenta resultados locales de inundación de Quito'
        elif any(x in row.get('titulo','')for x in ['NDWI','Water Index','water index']):reason='Método óptico no ejecutado en V12; reservado para futura validación física'
        elif 'CHIRPS'in row.get('titulo','')and'Version 3'not in row.get('titulo',''):reason='Producto o versión diferente; no se presenta como implementación CHIRPS3'
        elif 'slope stability'in row.get('titulo',''):reason='Deslizamientos, no etiquetas de inundación para esta red'
        else:reason='Antecedente conservado; evitar presentar técnicas o productos no ejecutados como parte del resultado V12'
        corpus.append({'doi':row['doi_solicitado'],'titulo':row.get('titulo',''),'verificacion':row['estado'],
            'uso':'Citado en artículo Quito'if included else 'Conservado en auditoría, no requerido para este estimando',
            'justificacion':SELECTION[included][1]if included else reason,
            'clave_articulo':included or'','bibliografias_previas':' | '.join(row.get('bibliografias_previas',[]))})
    with(F/'decision_referencias_del_corpus.csv').open('w',encoding='utf-8',newline='')as f:
        w=csv.DictWriter(f,fieldnames=corpus[0].keys());w.writeheader();w.writerows(corpus)
    control=json.loads((F/'control_redaccion.json').read_text(encoding='utf-8'))
    control.update({'references_total':len(biblio),'research_references':len(refs)+len(extras),
        'institutional_data_references':len(institutional),'DOI_audited':len(rows),
        'DOI_verified_crossref':sum('metadatos'in r for r in rows),
        'DOI_verified_datacite':sum('metadatos_datacite'in r for r in rows),'words_manuscript_approx':len(text.split()),
        'all_added_references_have_body_use':True,'bibliography_validation_not_scopus_or_model_validation':True})
    (F/'control_redaccion.json').write_text(json.dumps(control,ensure_ascii=False,indent=2),encoding='utf-8')
    (L/'control_fuentes_sin_DOI.json').write_text(json.dumps([
        {'clave':'dropout2014','titulo':'Dropout: A simple way to prevent neural networks from overfitting',
         'autores':['Nitish Srivastava','Geoffrey Hinton','Alex Krizhevsky','Ilya Sutskever','Ruslan Salakhutdinov'],
         'year':2014,'fuente_verificada':'https://jmlr.org/papers/v15/srivastava14a.html','no_DOI_inventado':True},
        {'clave':'adamw2019','titulo':'Decoupled weight decay regularization','autores':['Ilya Loshchilov','Frank Hutter'],
         'year':2019,'fuente_verificada':'https://arxiv.org/abs/1711.05101',
         'publicacion':'ICLR 2019, versión de conferencia; preprint inicial 2017','no_DOI_inventado':True}],ensure_ascii=False,indent=2),encoding='utf-8')
    (L/'control_correccion_Fox.json').write_text(json.dumps({'doi_original':'10.1038/s41467-024-47394-2',
        'doi_correccion':'10.1038/s41467-025-56676-2','fecha_correccion':'2025-02-07',
        'tipo':'Referencias internas a figuras corregidas en HTML y PDF',
        'no_es_una_retractacion':True,'url_primaria':'https://www.nature.com/articles/s41467-025-56676-2'},ensure_ascii=False,indent=2),encoding='utf-8')
    (L/'control_definiciones_NBI.json').write_text(json.dumps({'organizacion':'Instituto Nacional de Estadística y Censos',
        'url':'https://www.ecuadorencifras.gob.ec/documentos/web-inec/Censo2022/Documento_NBI_24.09.25.pdf',
        'paginas_revisadas':'Créditos p. 2 y metodología pp. 6–10, numeración física del PDF',
        'fecha_portada':'Septiembre 2025','ano_sugerido_para_cita_por_documento':2024,
        'ambiguedad_fecha_documentada':True,'alias_pc_FSA':'Acceso limitado a agua potable segura (%)',
        'alias_pc_SH':'Acceso insuficiente a saneamiento básico (%)',
        'fuente_alias':'Metadatos capa municipal NBI conservados en V09',
        'no_calidad_agua_instrumental':True},ensure_ascii=False,indent=2),encoding='utf-8')
    (L/'ajustes_APA_sobre_metadatos.json').write_text(json.dumps({
        'case_titles':'Títulos ajustados a formato de oración; identidad DOI sin cambio',
        'gneiting2013':'Crossref issue=none es ausencia de fascículo, no número literal de edición',
        'robinson1950':'Rango 351-357 verificado en copia del artículo original de siete páginas; Crossref solo registra primera página 351',
        'robinson_source':'https://fisher.stats.uwo.ca/faculty/aim/2015/9938/articles/Robinson1950AmericanSociologicalReview.pdf',
        'alphabetical':'Se conservan límites de apellidos para ordenar Li antes de Liu',
        'long_author_lists':'APA primeras 19 personas, puntos suspensivos y último autor cuando hay más de 20',
        'no_date_sources':'Sufijos a/b para dos títulos sin fecha del Climate Prediction Center'},ensure_ascii=False,indent=2),encoding='utf-8')
    print('Bibliografía ampliada:',control,flush=True)


if __name__=='__main__':main()
