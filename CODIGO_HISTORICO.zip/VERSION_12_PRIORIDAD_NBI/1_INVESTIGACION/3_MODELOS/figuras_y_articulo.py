"""Mapas calculados y manuscrito centrado en la integración territorial social."""
from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
os.environ['GDAL_CACHEMAX']='8'
import json
import re
import shutil
import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from scipy.ndimage import maximum_filter
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize,ListedColormap,BoundaryNorm
from matplotlib.patches import Patch

P=Path(__file__).resolve().parents[1];ROOT=P.parents[2]
P11=ROOT/'EXPOSICION_FEN_NINO/VERSION_11_RED_REGULARIZADA_PAPER/1_INVESTIGACION'
D=P/'2_DATOS/PROCESADOS';F=P/'6_FINAL';G=F/'GRAFICOS'


def map_decor(ax,bounds,scale=20000,scale_y=.06):
    xmin,ymin,xmax,ymax=bounds
    ax.set_xlim(xmin,xmax);ax.set_ylim(ymin,ymax);ax.set_aspect('equal');ax.set_axis_off()
    x=xmin+(xmax-xmin)*.06;y=ymin+(ymax-ymin)*scale_y
    ax.plot([x,x+scale],[y,y],color='black',lw=1)
    ax.text(x+scale/2,y+(ymax-ymin)*.012,f'{scale/1000:g} km',ha='center',fontsize=8)
    ax.annotate('N',xy=(.91,.95),xytext=(.91,.85),xycoords='axes fraction',ha='center',
                arrowprops={'arrowstyle':'->','linewidth':.6},fontsize=8)


def main():
    G.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.family':'Arial','font.size':8,'svg.fonttype':'none','axes.titlesize':8})
    geo=gpd.read_file(F/'prioridad_integrada_quito.geojson').to_crs(32717)
    view=geo.copy();view.geometry=view.geometry.simplify(40)
    bounds=geo.total_bounds;pad=1500;bounds=[bounds[0]-pad,bounds[1]-pad,bounds[2]+pad,bounds[3]+pad]
    result=json.loads((F/'control_integracion.json').read_text(encoding='utf-8'))
    application=json.loads((D/'control_aplicacion.json').read_text(encoding='utf-8'))
    def save(fig,name):
        fig.savefig(G/(name+'.svg'),bbox_inches='tight');fig.savefig(G/(name+'.png'),dpi=300,bbox_inches='tight');plt.close(fig)
    for name in ['figura_1_arquitectura','figura_2_aporte_residual']:
        for suffix in ['svg','png']:shutil.copy2(P11/'6_FINAL/GRAFICOS'/f'{name}.{suffix}',G/f'{name}.{suffix}')
    # Generalización de visualización explícita: se muestra si hay al menos
    # un pixel prioritario en cada bloque 80 m. Nunca se usa para estimar áreas.
    scores=np.load(D/'scores_aplicacion.npy',mmap_mode='r')
    flat=np.load(D/'indice_pixel.npy',mmap_mode='r')[:application['n_generated']]
    width=application['width'];height=application['height'];factor=8
    small=np.zeros(((height+factor-1)//factor,(width+factor-1)//factor),np.uint8)
    rr=flat//width;cc=flat%width;builtkey=(rr//factor)*small.shape[1]+cc//factor
    np.maximum.at(small.reshape(-1),builtkey,1)
    chosen=scores[:,0]>=result['thresholds']['red_residual']
    np.maximum.at(small.reshape(-1),builtkey[chosen],2)
    tr=application['transform'];extent=[tr[2],tr[2]+small.shape[1]*80,tr[5]-small.shape[0]*80,tr[5]]
    fig,axes=plt.subplots(1,2,figsize=(6.3,3.65))
    cmap=ListedColormap(['white','#c9d1d9','#ad271e'])
    for ax in axes:
        view.boundary.plot(ax=ax,color='#777777',linewidth=.22)
        ax.imshow(small,extent=extent,origin='upper',cmap=cmap,vmin=0,vmax=2,interpolation='nearest',rasterized=True)
    map_decor(axes[0],bounds,20000);axes[0].set_title('a. Distrito Metropolitano de Quito',loc='left')
    core=[765000,9960000,805000,10008000];map_decor(axes[1],core,10000,scale_y=.88)
    axes[1].set_title('b. Núcleo urbano y valles',loc='left')
    for name in ['GUAMANI','CALDERÓN','TURUBAMBA','AMAGUAÑA']:
        r=geo[geo.nombre==name].iloc[0];pt=r.geometry.representative_point()
        if core[0]<pt.x<core[2]and core[1]<pt.y<core[3]:
            offset={'GUAMANI':(-18,13),'TURUBAMBA':(25,-14),'CALDERÓN':(10,5)}.get(name,(0,0))
            axes[1].annotate({'GUAMANI':'Guamaní'}.get(name,name.title()),xy=(pt.x,pt.y),xytext=offset,textcoords='offset points',
                fontsize=8,ha='center',bbox={'facecolor':'white','alpha':.8,'edgecolor':'none','pad':.3},
                arrowprops={'arrowstyle':'-','color':'black','linewidth':.5})
    fig.legend(handles=[Patch(color='#c9d1d9',label='Construido analizado'),Patch(color='#ad271e',label='Decil superior del score')],loc='lower center',ncol=2,frameon=False,bbox_to_anchor=(.5,-.015))
    fig.subplots_adjust(wspace=.12,bottom=.12);save(fig,'figura_3_construido_prioritario')
    del rr,cc,builtkey,chosen,small
    fig,axes=plt.subplots(2,2,figsize=(6.3,5.6))
    for ax,(field,title,cmap)in zip(axes.flat,[('pc_pnbi','a. Personas con NBI (%)','YlOrRd'),
        ('pc_SH','b. Saneamiento inadecuado (%)','YlOrRd'),
        ('pc_FSA','c. Acceso limitado a agua segura (%)','YlGnBu'),
        ('pc_HAC','d. Hacinamiento (%)','PuRd')]):
        view.plot(column=field,ax=ax,cmap=cmap,edgecolor='#707070',linewidth=.25,
                  legend=True,legend_kwds={'shrink':.7,'pad':.02,'fraction':.035})
        ax.set_title(title,loc='left');map_decor(ax,bounds,20000)
    fig.subplots_adjust(wspace=.17,hspace=.13);save(fig,'figura_4_privacion_social')
    fig,axes=plt.subplots(1,2,figsize=(6.3,3.65))
    for ax,(field,title,label)in zip(axes,[('area_prioritaria_ponderada_humedad_ha','a. Prioridad por área','ha ponderadas por humedad'),
        ('indice_NBI_ha_ponderadas','b. Prioridad con NBI','ha ponderadas por humedad y NBI')]):
        view.plot(column=field,ax=ax,cmap='YlOrRd',edgecolor='#777777',linewidth=.25,legend=True,
                  legend_kwds={'shrink':.7,'pad':.02,'fraction':.035,'label':label})
        ax.set_title(title,loc='left');map_decor(ax,bounds,20000)
    fig.subplots_adjust(wspace=.17);save(fig,'figura_5_prioridad_integrada')
    fig,axes=plt.subplots(1,2,figsize=(6.3,3.65))
    cmap=plt.get_cmap('YlGnBu',7);norm=BoundaryNorm(np.arange(-.5,7.5),7)
    view.plot(column='selecciones_NBI_de_6',ax=axes[0],cmap=cmap,norm=norm,edgecolor='#777777',linewidth=.25)
    bar=fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap=cmap),ax=axes[0],shrink=.7,pad=.02,fraction=.035,ticks=range(7));bar.set_label('Selecciones de 6')
    axes[0].set_title('a. Estabilidad entre modelos',loc='left');map_decor(axes[0],bounds,20000)
    view['cambio']=np.where((view.ranking_NBI<=13)&~(view.ranking_area<=13),'Incorpora NBI',
        np.where((view.ranking_area<=13)&~(view.ranking_NBI<=13),'Prioridad solo por área',
        np.where((view.ranking_area<=13)&(view.ranking_NBI<=13),'Prioridad compartida','Resto de parroquias')))
    colors={'Incorpora NBI':'#b2182b','Prioridad solo por área':'#2166ac','Prioridad compartida':'#f3c77b','Resto de parroquias':'#ececec'}
    for category,color in colors.items():view[view.cambio==category].plot(ax=axes[1],color=color,edgecolor='#777777',linewidth=.25)
    axes[1].set_title('b. Cambio al incluir NBI',loc='left');map_decor(axes[1],bounds,20000)
    fig.legend(handles=[Patch(color=color,label=label)for label,color in colors.items()],loc='lower center',ncol=2,frameon=False,bbox_to_anchor=(.5,-.055))
    fig.subplots_adjust(wspace=.17,bottom=.17);save(fig,'figura_6_estabilidad_social')
    (G/'CONTROL_CARTOGRAFICO.json').write_text(json.dumps({'boundary_simplification_display_m':40,
        'figure3_display_block_m':80,'figure3_rule':'max class; visualization only; no area calculation',
        'analysis_grid_m':10,'terrain_support_m':30,'social_support':'parroquia',
        'weather_native_degrees':.05,'projection':'EPSG:32717','figures':6,
        'not_future_flood_extent':True},indent=2),encoding='utf-8')
    content=json.loads((P11/'2_DATOS/PROCESADOS/contenido_paper.json').read_text(encoding='utf-8'))
    blocks=content['blocks']
    summary=('Este estudio integra susceptibilidad geoespacial, pronósticos estacionales de lluvia y privación social para orientar la preparación ante inundaciones en Quito. '
        'Se aplica una red neuronal residual regularizada y un comparador lineal a 2993619 píxeles construidos, y se cruzan sus prioridades con necesidades básicas insatisfechas (NBI), agua, saneamiento y hacinamiento de 65 parroquias. '
        'La red se evalúa con reportes históricos y particiones temporales y espaciales; el cruce social conserva los distintos soportes de medición. '
        'En el escenario principal para noviembre 2026–enero 2027, incluir NBI modifica dos de 13 parroquias prioritarias, mientras saneamiento modifica cinco. '
        'Guamaní, La Ecuatoriana, Quitumbe, Amaguaña, Conocoto y San Antonio permanecen seleccionadas en seis combinaciones de modelos. '
        'Las prioridades físicas de la red y del ancla lineal presentan un índice de Jaccard de 0.983. '
        'El aporte es una regla territorial reproducible que explicita cómo los objetivos distributivos cambian la asignación de preparación. '
        'Las áreas ponderadas son índices de prioridad y los indicadores sociales son parroquiales; no equivalen a superficie inundada ni a población afectada localizada.')
    abstract=('This study integrates geospatial susceptibility, seasonal rainfall forecasts and social deprivation to guide flood preparedness in Quito. '
        'A regularized residual neural network and a linear comparator are applied to 2993619 built-up pixels, and their priorities are combined with unmet basic needs (UBN), water, sanitation and overcrowding in 65 parishes. '
        'The network is evaluated using historical reports and temporal and spatial partitions; the social integration preserves the different measurement supports. '
        'In the main scenario for November 2026–January 2027, including UBN changes two of 13 priority parishes, whereas sanitation changes five. '
        'Guamaní, La Ecuatoriana, Quitumbe, Amaguaña, Conocoto and San Antonio remain selected in six combinations of models. '
        'The physical priorities of the network and the linear anchor have a Jaccard index of 0.983. '
        'The contribution is a reproducible territorial rule that makes explicit how distributional objectives change preparedness allocation. '
        'Weighted areas are priority indices and social indicators are parish-level; they do not equal flooded area or geographically identified affected population.')
    assert len(summary.split())<=200
    blocks[1]['text']=summary;blocks[3]['text']=abstract
    blocks[5]['text']='La preparación ante inundaciones requiere identificar dónde se concentra la susceptibilidad y quién dispone de menores recursos o servicios para responder. Una selección basada únicamente en superficie puede priorizar territorios diferentes de una selección orientada a privación social. Este estudio cuantifica esa diferencia en Quito, integrando cobertura satelital, conectividad superficial, reportes históricos, pronósticos regionales de lluvia y tasas parroquiales de necesidades básicas insatisfechas (NBI).'
    blocks[8]['text']='La contribución se concentra en la integración multiescala y su sensibilidad: una regla explícita permite comparar prioridades por área, NBI, agua, saneamiento y hacinamiento, conservando un comparador lineal y escenarios meteorológicos alternativos. El entrenamiento neuronal es un instrumento metodológico, no el resultado distributivo. No se atribuye novedad a combinar amenaza y pobreza en general, que cuenta con antecedentes (Rentschler et al., 2022; Fox et al., 2024). Se aporta una aplicación local reproducible y se mide cuánto cambia la selección ante objetivos y modelos distintos.'
    blocks[12]['text']=blocks[12]['text'].replace('WorldCover proporciona cobertura a 10 m','WorldCover proporciona cobertura a 10 m (Zanaga et al., 2022)')
    blocks[11]['rows'].extend([
        ['CHIRPS3 RNL','1981-01 a 2026-08','Mensual, 0.05 grados','Lluvia y climatología estacional'],
        ['Índices OISST NOAA','1982-01 a 2026-08','Mensual, grados Celsius','Antecedentes ENSO'],
        ['NMME archivado','2013-12 a 2026-10','Inicializaciones mensuales, 1 grado','Escenario dinámico con ajuste local']])
    blocks[11]['note']='Fuente: Servicio Nacional de Gestión de Riesgos (SNGR), European Space Agency (ESA), Copernicus, FABDEM, Municipio de Quito, Climate Hazards Center y National Oceanic and Atmospheric Administration (NOAA). Elaboración propia. ENSO: El Niño–Southern Oscillation; NMME: North American Multimodel Ensemble; OISST: Optimum Interpolation Sea Surface Temperature. Fechas observacionales, excepto NMME que indica inicializaciones. Las versiones cartográficas no certifican disponibilidad histórica por fecha.'
    blocks[6]['text']=blocks[6]['text'].replace('La segmentación SAR','La segmentación con radar de apertura sintética (SAR, por su sigla en inglés)')
    blocks[13]['text']=blocks[13]['text'].replace('Las 20 covariables iniciales','Copernicus representa un modelo digital de superficie (DSM, por su sigla en inglés), mientras FABDEM busca retirar edificios y vegetación. Las 20 covariables iniciales')
    before=blocks[:37]
    new=[]
    def h(text):new.append({'type':'heading','text':text})
    def p(text):new.append({'type':'paragraph','text':text})
    def figure(title,file,note):new.append({'type':'figure','title':title,'file':file,'width':6.3,'note':note})
    def table(title,headers,rows,widths,note):new.append({'type':'table','title':title,'headers':headers,'rows':rows,'widths':widths,'note':note})
    h('7 Integración geoespacial y prioridades sociales')
    p('El modelo residual temporal con vías y FABDEM se aplica directamente sobre el construido WorldCover 2021, sin interpolar puntos de cuadratura. La elección responde al mecanismo de conectividad y es posterior a examinar las versiones anteriores; esta aplicación no constituye una nueva validación ciega. Se utiliza el ancla acotada de la misma variante como comparador, sin reentrenar con NBI. Cada semilla se normaliza sobre todo el construido válido y el ensamble promedia sus densidades relativas. La malla de salida es de 10 m; relieve y escorrentía conservan soporte nativo de 30 m.')
    p(f'De 3022395 píxeles construidos de la fuente, {application["n_generated"]} cuentan con soporte de covariables. Se excluyen {application["excluded_base_features"]} píxeles ({application["excluded_base_features"]*.01:.2f} ha), sin interpretarlos como áreas seguras. Existen 0.84 ha de construido analizado sin asignación parroquial, mantenidas fuera de las estadísticas parroquiales. El {application["fraction_any_clipped"]*100:.2f} % del construido válido requiere recorte de alguna covariable al soporte de entrenamiento. Tababela presenta la menor cobertura, 82.32 %, por lo que su índice requiere especial cautela.')
    p(f'Se fija el decil superior por área del construido válido, con empates incluidos y sin modificar el umbral para capturar reportes del test. La selección de la red abarca {result["priority_area_red_ha"]:.2f} ha. Esta superficie expresa un presupuesto territorial de revisión, no extensión de inundación. La concordancia de los deciles de red y ancla alcanza Jaccard {result["jaccard_pixel_priorities_red_anchor"]:.3f}; por tanto, las dos metodologías producen áreas prioritarias muy similares, aunque sus puntuaciones predictivas no son idénticas.')
    figure('Figura 3. Construido analizado y decil superior de susceptibilidad','figura_3_construido_prioritario.png',
        'Fuente: ESA WorldCover 2021, covariables y modelo residual V11. Elaboración propia. Para lectura, cada bloque de 80 m se colorea si contiene un píxel prioritario; áreas e índices se calculan con píxeles de 10 m. Blanco: fuera del construido o sin soporte, no ausencia de riesgo.')
    p('La capa municipal del Censo 2022 aporta porcentajes de personas con NBI y porcentajes de privación de agua, saneamiento y hacinamiento con sus propios denominadores. NBI no es pobreza monetaria ENEMDU. Sus tasas se reconcilian con los numeradores y denominadores de la propia capa; las cantidades agregadas exceden el control cantonal del lago en 119116 personas del universo NBI y 23375 personas NBI. No se reescalan ni se presentan conteos oficiales de afectados. La NBI se conserva como atributo parroquial y no se asigna a personas o viviendas de cada píxel.')
    summarize=pd.read_csv(F/'summarize_parroquias.csv')
    short={'construido_ha':'Construido analizado (ha)','area_prioritaria_ha':'Decil superior (ha)',
        'prioritario_red_residual_pct':'Decil superior (%)','pc_pnbi':'Personas con NBI (%)',
        'pc_SH':'Saneamiento inadecuado (%)','pc_FSA':'Agua limitada (%)','pc_HAC':'Hacinamiento (%)',
        'p_humedo_media_construido':'Probabilidad húmeda (0–1)',
        'area_prioritaria_ponderada_humedad_ha':'Área ponderada por humedad (ha)',
        'indice_NBI_ha_ponderadas':'Índice NBI (ha ponderadas)',
        'soporte_recortado_pct':'Covariable recortada (%)','borde_externo_pct':'Influencia de borde (%)',
        'construido_excluido_ha':'Construido excluido (ha)','cobertura_construido_pct':'Cobertura de construido (%)'}
    rows=[[short[r.variable],str(r.N),*[f'{r[k]:.2f}'for k in ['media','desv_estandar','minimo','maximo']]]for _,r in summarize.iterrows()]
    table('Tabla 5. Resumen estadístico de las parroquias',['Variable','N','Media','DE','Mínimo','Máximo'],rows,[2.35,.35,.85,.85,.9,1.0],
        'Fuente: WorldCover 2021, cartografía municipal Censo 2022, aplicación V11 y pronóstico V07. Elaboración propia. DE: desviación estándar muestral. Cada parroquia pesa igual; no son medias de personas u hogares. Índices meteorológicos y NBI: red residual con red ENSO. Unidades y denominadores completos en el CSV adjunto.')
    figure('Figura 4. Privación social por parroquia','figura_4_privacion_social.png',
        'Fuente: capa municipal basada en Censo 2022 INEC. Elaboración propia. Porcentajes con denominadores propios, no sumables. Escalas de color distintas entre paneles; los polígonos mantienen soporte parroquial.')
    p('Para cada parroquia p y celda meteorológica j se cuenta el área S del decil construido. Su suma ponderada por probabilidad de trimestre húmedo P define H. El índice NBI multiplica H por la proporción parroquial n de personas con NBI. Se utiliza el pronóstico congelado de noviembre 2026–enero 2027, donde húmedo significa superar el percentil 80 histórico estacional del componente meteorológico. El resultado es una medida de preparación bajo ese estado de lluvia, no una función hidráulica.')
    new.append({'type':'equation','name':'priority','latex':r'H_p=\sum_j S_{pj}P_j(\mathrm{humedo}),\qquad I_{p,\mathrm{NBI}}=H_p n_p'})
    p('Los índices de agua, saneamiento y hacinamiento reemplazan n por la proporción correspondiente, sin sumarse entre sí ni con NBI. La carencia de saneamiento se usa como contexto de vulnerabilidad social, no como medición de capacidad de colectores o taponamiento. La precipitación tiene soporte nativo de 0.05 grados y la tasa social es parroquial; no se generan pronósticos de lluvia o pobreza independientes para millones de píxeles.')
    p('El componente meteorológico conserva los ajustes de la V07 y es distinto de la red territorial residual. Se usan lluvia CHIRPS3 RNL y antecedentes mensuales OISST con datos hasta agosto 2026, una climatología calibrada y NMME archivado. El banco de residuos 2014–2016, la recalibración beta del probability integral transform (PIT) en 2017–2019 y la evaluación 2020–2025 se mantienen separados. NMME acumula tasas según días y unidades, se interpola desde 1 grado y se corrige con errores históricos locales; su dispersión no representa los miembros originales del ensamble. La emisión congelada tiene fecha de decisión 9 de octubre de 2026. No se actualizan modelos ni probabilidades tras observar las prioridades sociales.')
    figure('Figura 5. Prioridad territorial y prioridad ponderada por NBI','figura_5_prioridad_integrada.png',
        'Fuente: construido prioritario residual, probabilidades húmedas red ENSO V07 y NBI municipal 2022. Elaboración propia. Hectáreas ponderadas para preparación, no superficie inundada ni número de personas afectadas.')
    p('Con un presupuesto ilustrativo de 13 de 65 parroquias, NBI incorpora El Condado y Tumbaco en lugar de Iñaquito y Kennedy. Guamaní pasa del tercer lugar por área al primero con NBI; Amaguaña pasa del lugar 13 al sexto. La ponderación modifica el objetivo distributivo sin demostrar mayor precisión de detección física. La selección NBI aumenta el índice social agregado 1.21 % respecto a la selección por área y reduce 3.51 % el área ponderada cubierta; se trata de un tradeoff calculado por construcción, no de beneficios observados ni de una ganancia predictiva.')
    primary=pd.read_csv(F/'prioridades_NBI_ordenadas.csv').head(13)
    rows=[[{'GUAMANI':'Guamaní'}.get(r.nombre,r.nombre.title()),f'{r.pc_pnbi:.2f}',f'{r.area_prioritaria_ponderada_humedad_ha:.2f}',
           f'{r.indice_NBI_ha_ponderadas:.2f}',f'{int(r.ranking_area)}',f'{int(r.selecciones_NBI_de_6)}/6']for _,r in primary.iterrows()]
    table('Tabla 6. Parroquias priorizadas por NBI en el escenario principal',
        ['Parroquia','NBI (%)','H (ha pond.)','Índice NBI','Orden por área','Acuerdo'],rows,[1.65,.75,.95,1.0,1.05,.9],
        'Fuente: integración V12. Elaboración propia. Filas ordenadas por índice NBI. H: área prioritaria ponderada por humedad; pond.: ponderadas. Acuerdo: selección entre dos modelos territoriales y tres meteorológicos, no probabilidad ni intervalo de confianza.')
    comparisons=pd.read_csv(F/'cambio_prioridad_por_contexto_social.csv')
    chosen=comparisons[(comparisons.modelo_territorial=='red_residual')&(comparisons.modelo_lluvia=='red_ENSO__beta_PIT')]
    label={'NBI':'NBI','saneamiento':'Saneamiento','agua':'Agua','hacinamiento':'Hacinamiento'}
    table('Tabla 7. Cambio de prioridades según el objetivo social',
        ['Objetivo','Comunes con área','Parroquias incorporadas','Jaccard'],
        [[label[r.objetivo],str(r.comunes),str(r.cambios_por_ponderacion),f'{r.jaccard_area_social:.3f}']for _,r in chosen.iterrows()],
        [1.8,1.5,1.7,1.3],
        'Fuente: integración V12. Elaboración propia. Cada selección comprende 13 parroquias. Jaccard: intersección dividida por unión de seleccionadas; no métrica de agua segmentada.')
    p('La prioridad orientada a saneamiento reemplaza cinco parroquias de la selección por área e incorpora El Condado, Alangasí, Llano Chico, Pomasqui y Tumbaco. Agua y hacinamiento reemplazan dos cada uno. La heterogeneidad evidencia que un mapa de superficie susceptible no determina por sí solo un objetivo de inversión social. Las tasas representan situaciones censales de 2022 y no certifican condiciones actuales de cada vivienda.')
    p('Se conservan seis combinaciones: red residual o ancla acotada, cruzadas con red ENSO, climatología calibrada o pronóstico dinámico NMME. Guamaní, La Ecuatoriana, Quitumbe, Amaguaña, Conocoto y San Antonio se seleccionan en las seis. La variación meteorológica produce diferencias de prioridad incluso con fuerte concordancia entre los mapas físicos. NMME extrapola fuera de su rango local histórico de calibración en el escenario cantonal NDJ, por lo que su inclusión informa sensibilidad y no certifica una alternativa superior. Probabilidades meteorológicas estimadas como cero no prueban ausencia de amenaza.')
    figure('Figura 6. Estabilidad y redistribución de prioridades sociales','figura_6_estabilidad_social.png',
        'Fuente: seis combinaciones de modelos y comparación de selecciones con 13 parroquias. Elaboración propia. El panel b corresponde al escenario red residual y red ENSO. Acuerdo de modelos, no certeza de daños.')
    p('Las sensibilidades adicionales mantienen percentiles territoriales 80, 90 y 95 y presupuestos de 5, 10, 13 y 20 parroquias. Se entregan sus áreas e índices, sin escoger la combinación que maximiza un resultado favorable. La incertidumbre de parámetros, geocodificación, cobertura, versión censal y capacidad real de drenaje permanece fuera de los rangos descriptivos entre modelos.')
    h('8 Discusión')
    p('El resultado principal es la cuantificación del cambio distributivo de prioridades al combinar susceptibilidad y servicios. La estabilidad neuronal sobre el ancla evita presentar complejidad como una contribución automática: sus deciles coinciden ampliamente, mientras elegir entre superficie, NBI y saneamiento sí modifica la asignación territorial. La integración complementa estudios de lluvia y pobreza, pero no replica un modelo de pobreza monetaria ni estima variaciones futuras de bienestar (Canavire-Bacarreza et al., 2026).')
    p('La integración de vulnerabilidad social y exposición cuenta con antecedentes internacionales. Fox et al. (2024) muestran la importancia de sostener ambos componentes; Rentschler et al. (2022) describen la distribución social de exposición. La aportación local es conservar el soporte multiescala y expresar las reglas de selección, cobertura y tradeoff, junto con comparadores y resultados desfavorables de transferencia. La utilidad operacional requiere evaluación prospectiva de prioridades y verificación de nuevos episodios.')
    p('La NBI no se incorpora como etiqueta para entrenar detección de inundación. Tampoco se ha demostrado que incluir indicadores sociales mejore la localización de reportes: en el experimento retrospectivo parroquia por trimestre de V09, la fusión social obtuvo log score −4.070 frente a −4.057 del construido, con diferencias exploratorias compatibles con cero. Aquel estimando describe distribución condicional de reportes y es distinto del modelo espacial V11. Las dos piezas se mantienen separadas: predicción de localización y objetivo social de preparación.')
    p('Persisten sesgos de reporte y geocodificación. Las vías de 2024 y la capa censal no fueron certificadas a cada fecha histórica; la evaluación es retrospectiva. Las depresiones y rutas D8 representan conectividad superficial potencial, no conducción real en colectores. La capa de saneamiento residencial no sustituye información instrumental sobre sumideros. Las áreas sin soporte y parroquias con menor cobertura requieren revisión específica antes de usarse operativamente.')
    p('La comparación SAR sigue siendo complementaria: Misra et al. (2025) segmentan agua observada con pares radar y máscaras, incluyendo exclusiones urbanas relevantes. Aquí se aprende concentración relativa de reportes y se prioriza construido; captura de reportes y F1 de agua no son métricas comparables. Para delimitar inundación física de Quito se necesitan referencias pre, durante y post independientes, además de lluvia de corta duración y drenaje. Ni densidad relativa ni probabilidad de trimestre húmedo validan profundidad futura por píxel.')
    h('9 Conclusiones')
    p('La integración de susceptibilidad con NBI modifica dos de 13 prioridades del escenario principal; priorizar saneamiento modifica cinco. Seis parroquias permanecen seleccionadas entre los seis escenarios considerados. El resultado permite distinguir objetivos de preparación y localizar diferencias territoriales sin sumar indicadores superpuestos ni confundir NBI parroquial con pobreza por píxel.')
    p('La red residual conserva mejor desempeño que la red libre en los contrastes examinados, sin superar uniformemente las referencias lineales. Su fuerte acuerdo espacial con el ancla hace necesario mantener ambos modelos. El producto final ofrece mapas georreferenciados, estadísticas descriptivas y sensibilidades reproducibles para revisión territorial. La comprobación de agua, drenaje y cantidades censales debe acompañar cualquier ampliación a personas afectadas, daños o predicción hidráulica.')
    h('Disponibilidad de datos y código')
    p('Se adjuntan tablas CSV, capas GeoJSON, rásteres de percentiles, gráficos editables SVG, parámetros y un ejecutor único de las etapas V12. Los pesos y datos previos se conservan y se referencian mediante rutas relativas a la investigación. Los derivados FABDEM mantienen CC BY-NC-SA 4.0 y atribución; las demás fuentes conservan sus términos. Los registros de ejecución se separan del texto científico. Los datos sociales proceden de la capa municipal basada en Censo 2022 y no de una nueva encuesta de hogares.')
    references=blocks[52:]
    # Explicit source for the satellite land cover used by the analysis.
    wc_ref='Zanaga, D., Van De Kerchove, R., Daems, D., De Keersmaecker, W., Brockmann, C., Kirches, G., Wevers, J., Cartus, O., Santoro, M., Fritz, S., Lesiv, M., Herold, M., Tsendbazar, N. E., Xu, P., Ramoino, F., & Arino, O. (2022). ESA WorldCover 10 m 2021 v200 [Conjunto de datos]. Zenodo. https://doi.org/10.5281/zenodo.7254221'
    references.append({'type':'reference','text':wc_ref})
    source_refs=[
        ('chirps3','Climate Hazards Center','CHIRPS3 daily rainfall RNL','https://developers.google.com/earth-engine/datasets/catalog/UCSB-CHC_CHIRPS_V3_DAILY_RNL'),
        ('noaaindices','Climate Prediction Center','Monthly OISST Niño indices','https://www.cpc.ncep.noaa.gov/data/indices/sstoi.indices'),
        ('nmme','Climate Prediction Center','North American Multimodel Ensemble archived real-time anomalies','https://ftp.cpc.ncep.noaa.gov/NMME/realtime_anom/ENSMEAN/'),
        ('sngr','Servicio Nacional de Gestión de Riesgos','Histórico de eventos peligrosos Ecuador','https://sgrportal.gestionderiesgos.gob.ec/server/rest/services/Hosted/eventos_historicos/FeatureServer/0')]
    references.extend({'type':'reference','text':f'{author}. (s. f.). {title}. {url}'}for key,author,title,url in source_refs)
    for b in references[1:]:
        b['text']=re.sub(r'(Nature Communications, \d+, )(\d+)\.',r'\1Article \2.',b['text'])
    references=references[:1]+sorted(references[1:],key=lambda b:b['text'].casefold())
    content['blocks']=before+new+references
    content['title']='Susceptibilidad geoespacial y prioridades sociales ante inundaciones en Quito'
    content['JEL']='C45; C53; I32; Q54; R14'
    (D/'contenido_paper.json').write_text(json.dumps(content,ensure_ascii=False,indent=2),encoding='utf-8')
    bibliography=(P11/'6_FINAL/referencias_paper.bib').read_text(encoding='utf-8')
    bibliography+='''\n@misc{worldcover2021,
 title={ESA WorldCover 10 m 2021 v200},
 author={Zanaga, Daniele and Van De Kerchove, Ruben and Daems, Dirk and De Keersmaecker, Wanda and Brockmann, Carsten and Kirches, Grit and Wevers, Jan and Cartus, Oliver and Santoro, Maurizio and Fritz, Steffen and Lesiv, Myroslava and Herold, Martin and Tsendbazar, Nandin-Erdene and Xu, Peng and Ramoino, Fabrizio and Arino, Olivier},
 year={2022}, publisher={Zenodo}, doi={10.5281/zenodo.7254221}
}
@misc{copernicusdem,
 author={{Copernicus}}, title={Copernicus DEM Global and European Digital Elevation Model},
 url={https://dataspace.copernicus.eu/explore-data/data-collections/copernicus-contributing-missions/collections-description/COP-DEM}
}
@misc{pugs2024,
 author={{Municipio del Distrito Metropolitano de Quito}}, year={2024},
 title={Cartografía del Plan de uso y gestión del suelo},
 url={https://geoquito.quito.gob.ec/server/rest/services/web_reference_dmot/plan_de_uso_y_gestion_del_suelo_2024/MapServer}
}
@misc{nbi2022,
 author={{Municipio del Distrito Metropolitano de Quito}},
 title={Personas pobres por NBI Parroquias Censo 2022},
 url={https://geoquito.quito.gob.ec/server/rest/services/web_service/s_nbi_porcentaje_personas_con_pobreza_por_nbi_2022/MapServer/2}
}
'''
    bibliography+='\n'.join('@misc{'+key+',\n author={{'+author+'}},\n title={'+title+'},\n url={'+url+'}\n}\n'for key,author,title,url in source_refs)
    (F/'referencias_paper.bib').write_text(bibliography,encoding='utf-8')
    lines=['---',f'title: "{content["title"]}"','lang: es','format: docx','---','',content['author']+'[^autor]','',
        '[^autor]: '+content['footnote'],'','Códigos JEL: '+content['JEL'],'']
    for b in content['blocks']:
        if b['type']=='heading':lines+=['## '+b['text'],'']
        elif b['type']in ['paragraph','reference']:lines+=[b['text'],'']
        elif b['type']=='equation':lines+=['$$'+b['latex']+'$$','']
        elif b['type']=='figure':lines+=[b['title'],'',f'![](GRAFICOS/{b["file"]})','',b['note'],'']
        elif b['type']=='table':
            lines+=[b['title'],'','| '+' | '.join(b['headers'])+' |','| '+' | '.join(['---']*len(b['headers']))+' |']
            lines+=['| '+' | '.join(map(str,row))+' |'for row in b['rows']];lines+=['',b['note'],'']
    text='\n'.join(lines)
    if re.search(r'RTX|5070|\bGPU\b|\bCPU\b',text):raise ValueError('Referencia al hardware en manuscrito')
    (F/'MANUSCRITO_QUITO_V12.qmd').write_text(text,encoding='utf-8')
    control={'words_summary':len(summary.split()),'words_abstract':len(abstract.split()),
        'words_manuscript_approx':len(text.split()),'figures':6,'native_tables_planned':7,
        'no_hardware_in_manuscript':True,'integration_uses_actual_V11_weights':True}
    (F/'control_redaccion.json').write_text(json.dumps(control,indent=2),encoding='utf-8')
    print('Seis figuras y manuscrito integrado:',control,flush=True)


if __name__=='__main__':main()
