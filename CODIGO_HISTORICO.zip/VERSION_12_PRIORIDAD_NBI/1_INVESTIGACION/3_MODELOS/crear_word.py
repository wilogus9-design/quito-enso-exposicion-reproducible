"""Reutiliza el constructor probado V11 con datos y destino V12 separados."""
from pathlib import Path
import importlib.util
import sys
import json
import zipfile
import re
from lxml import etree

P=Path(__file__).resolve().parents[1];ROOT=P.parents[2]
P11=ROOT/'EXPOSICION_FEN_NINO/VERSION_11_RED_REGULARIZADA_PAPER/1_INVESTIGACION'


def main():
    spec=importlib.util.spec_from_file_location('word_v12_base',P11/'3_MODELOS/crear_word.py')
    builder=importlib.util.module_from_spec(spec);sys.modules[spec.name]=builder;spec.loader.exec_module(builder)
    builder.P=P;builder.D=P/'2_DATOS/PROCESADOS';builder.F=P/'6_FINAL'
    original=builder.equation
    def equation(doc,name):
        if name=='priority':
            builder.math.math_paragraph(doc,[('H','p'),' = Σ',('S','pj'),' ',('P','j'),
                '(húmedo),    ',('I','p,NBI'),' = ',('H','p'),' ',('n','p')])
        else:original(doc,name)
    builder.equation=equation;builder.main()
    produced=builder.F/'MANUSCRITO_QUITO_V11.docx';output=builder.F/'MANUSCRITO_QUITO_V12.docx'
    produced.replace(output)
    # Completa cursivas APA para las revistas añadidas, sin tocar estilos del
    # cuerpo, pie de autor ni tablas. El constructor V11 solo conocía 4 revistas.
    content=json.loads((builder.D/'contenido_paper.json').read_text(encoding='utf-8'))
    bibliography=json.loads((P/'1_LITERATURA/auditoria_crossref_completa.json').read_text(encoding='utf-8'))
    journals={r['metadatos']['container-title'][0]for r in bibliography if'metadatos'in r and r['metadatos'].get('container-title')}
    journals.add('Journal of Machine Learning Research')
    reftexts={b['text']:b.get('citation_key','')for b in content['blocks']if b['type']=='reference'}
    institution_keys={'worldcover2021','copernicusdem','pugs2024','nbi2022','chirps3','noaaindices','nmme','sngr','inec_nbi'}
    with zipfile.ZipFile(output)as z:parts={i.filename:z.read(i.filename)for i in z.infolist()}
    root=etree.fromstring(parts['word/document.xml']);W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
    for paragraph in root.findall('.//{'+W+'}p'):
        text=''.join(paragraph.findall('.//{'+W+'}t')[i].text or''for i in range(len(paragraph.findall('.//{'+W+'}t'))))
        if text not in reftexts:continue
        match=None
        for journal in sorted(journals,key=len,reverse=True):
            candidate=re.search(re.escape(journal)+r', \d+',text)
            if candidate:match=candidate;break
        span=None if match is None else(match.start(),match.end())
        if span is None and reftexts[text]in institution_keys:
            date=re.search(r'\((?:\d{4}|s\. f\.(?:-[ab])?)\)\. ',text)
            if date:
                start=date.end()
                stop=text.find(' [Conjunto de datos]',start)
                if stop<0:stop=text.find('. https://',start)
                if stop>start:span=(start,stop)
        if span is None and reftexts[text]=='li2023':
            start=text.index('In ')+3;stop=text.index(' (pp.',start);span=(start,stop)
        if span is None and reftexts[text]=='adamw2019':
            start=text.index('International Conference');stop=text.index('. https://',start);span=(start,stop)
        if span is None:continue
        for run in list(paragraph.findall('{'+W+'}r')):paragraph.remove(run)
        for segment,italic in [(text[:span[0]],False),(text[span[0]:span[1]],True),(text[span[1]:],False)]:
            run=etree.SubElement(paragraph,'{'+W+'}r');pr=etree.SubElement(run,'{'+W+'}rPr')
            size=etree.SubElement(pr,'{'+W+'}sz');size.set('{'+W+'}val','20')
            if italic:etree.SubElement(pr,'{'+W+'}i')
            t=etree.SubElement(run,'{'+W+'}t');t.set('{http://www.w3.org/XML/1998/namespace}space','preserve');t.text=segment
    parts['word/document.xml']=etree.tostring(root,xml_declaration=True,encoding='UTF-8',standalone=True)
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED)as z:
        for name,value in parts.items():z.writestr(name,value)
    control=json.loads((builder.F/'control_redaccion.json').read_text(encoding='utf-8'))
    control.update({'docx':output.name,'native_tables':7,'native_equations':3,'figures':6})
    (builder.F/'control_redaccion.json').write_text(json.dumps(control,indent=2),encoding='utf-8')
    print('Manuscrito V12 con siete tablas editables, tres ecuaciones y seis figuras.',flush=True)


if __name__=='__main__':main()
