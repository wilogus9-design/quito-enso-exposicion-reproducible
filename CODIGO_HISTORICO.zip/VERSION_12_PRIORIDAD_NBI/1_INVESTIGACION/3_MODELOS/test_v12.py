"""Controles reproducibles de integración y entrega; no validación científica."""
from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
os.environ['GDAL_CACHEMAX']='8'
import json
import re
import zipfile
import xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
import rasterio
from rasterio.windows import Window

P=Path(__file__).resolve().parents[1];ROOT=P.parents[2]
P5=ROOT/'EXPOSICION_FEN_NINO/VERSION_5_QUITO_10M/1_INVESTIGACION'
P9=ROOT/'EXPOSICION_FEN_NINO/VERSION_9_INTEGRACION_SOCIAL/1_INVESTIGACION'
P10=ROOT/'EXPOSICION_FEN_NINO/VERSION_10_ESCORRENTIA_LOCAL/1_INVESTIGACION'
P11=ROOT/'EXPOSICION_FEN_NINO/VERSION_11_RED_REGULARIZADA_PAPER/1_INVESTIGACION'
D=P/'2_DATOS/PROCESADOS';F=P/'6_FINAL';Q=P/'5_VERIFICACION'


def main():
    Q.mkdir(exist_ok=True);passed=[]
    def check(name,condition):
        if not bool(condition):raise AssertionError(name)
        passed.append(name)
    meta=json.loads((D/'control_aplicacion.json').read_text(encoding='utf-8'));n=meta['n_generated']
    info=json.loads((F/'control_integracion.json').read_text(encoding='utf-8'))
    inference=json.loads((D/'control_inferencia.json').read_text(encoding='utf-8'))
    check('Denominador completo y exclusiones explícitas',n+meta['excluded_base_features']+meta['excluded_nonfinite_hydro']==meta['capacity'])
    check('Inferencia reproduce pesos propios y scores PyTorch',inference['no_retraining']and all(x['max_difference_from_saved_pytorch_scores']<=5e-5 for x in inference['seeds']))
    check('Amplitud residual fijada por calibración',inference['bound_selected_by_calibration']==.25 and all(x['max_raw_correction']<=.2501 for x in inference['seeds']))
    # Comprobación independiente de los 25 features en 20 píxeles distribuidos.
    flat=np.load(D/'indice_pixel.npy',mmap_mode='r')[:n];X=np.load(D/'covariables_construido.npy',mmap_mode='r')
    st=json.loads((P11/'2_DATOS/PROCESADOS/parametros_ancla.json').read_text(encoding='utf-8'))[meta['key']]
    with np.load(P11/f'2_DATOS/PROCESADOS/entrada_{meta["key"]}.npz')as z:lo=z['lo'];hi=z['hi']
    mu=np.asarray(st['mu'],np.float32);sd=np.asarray(st['sd'],np.float32)
    source=P5/'2_DATOS/PROCESADOS';err=0
    with rasterio.open(source/'derivados_30m.tif')as terrain, \
         rasterio.open(source/'densidad_construida_10m.tif')as density, \
         rasterio.open(P10/'2_DATOS/PROCESADOS/escorrentia_fabdem_30m.tif')as hydro:
        for index in np.linspace(0,n-1,20).astype(int):
            row,col=divmod(int(flat[index]),meta['width']);w=Window(col//3,row//3,1,1)
            t=terrain.read(window=w).reshape(-1);d=density.read(window=Window(col,row,1,1)).reshape(-1)
            h=hydro.read([1,2,3,4,6],window=w).reshape(-1)
            raw=np.array([t[0]/1000,t[1],t[2],t[3],np.log1p(t[4]/10),np.log1p(t[5]/10),np.log1p(t[6]/10),
                d[0],d[1],*[float(v==50)for v in [10,20,30,40,50,60,70,80,90,95,100]],np.log1p(h[4]/10),*h[:4]],np.float32)
            expected=np.clip((raw-mu)/sd,lo,hi)
            err=max(err,float(np.max(np.abs(expected-X[index]))))
    check('Extracción por ventanas coincide con lecturas independientes',err<1e-5)
    with np.load(D/'intersecciones_V12.npz')as z:
        check('Conteos multiescala conservan todos los píxeles',z['construido'].sum()==n)
        check('Dos modelos y 186 unidades de lluvia',len(z['unit'])==186 and z['red_residual_q90'].shape==(66,186))
        check('Superficie prioritaria dentro del construido',np.all(z['red_residual_q90']<=z['construido'])and np.all(z['ancla_acotada_q90']<=z['construido']))
    panel=pd.read_csv(F/'prioridad_integrada_NDJ2026_2027.csv',dtype={'parroquia':str})
    check('65 parroquias por seis escenarios, sin duplicados',len(panel)==390 and not panel.duplicated(['parroquia','modelo_lluvia','modelo_territorial']).any())
    check('Índices conservan objetivos y unidades',np.allclose(panel.indice_NBI_ha_ponderadas,panel.area_prioritaria_ponderada_humedad_ha*panel.pc_pnbi/100)and np.all(panel.area_prioritaria_ponderada_humedad_ha<=panel.area_prioritaria_ha+1e-8))
    check('Ceros no seleccionados por orden alfabético',np.all(panel.loc[panel.indice_NBI_ha_ponderadas==0,'top13_NBI']==0))
    primary=pd.read_csv(F/'parroquias_integradas_resumen.csv',dtype={'parroquia':str})
    old=pd.read_csv(P9/'6_FINAL/territorio_vulnerabilidad_parroquias.csv',dtype={'parroquia':str}).set_index('parroquia').reindex(primary.parroquia)
    check('Tasas censales preservadas sin crear pobreza por píxel',all(np.allclose(primary[k],old[k])for k in ['pc_pnbi','pc_SH','pc_FSA','pc_HAC']))
    summary=pd.read_csv(F/'summarize_parroquias.csv')
    check('Summarize usa parroquias y DE muestral',all(r.N==65 and np.isclose(r.media,primary[r.variable].mean())and np.isclose(r.desv_estandar,primary[r.variable].std(ddof=1))for _,r in summary.iterrows()))
    check('Cambios de selección calculados y no heredados V09',set(info['enter_top13_by_NBI'])=={'EL CONDADO','TUMBACO'}and len(info['robust_selected_all_6'])==6)
    for path in (F/'RASTERS_10M').glob('*.tif'):
        with rasterio.open(path)as src:
            count=0
            for row in range(0,src.height,12):
                a=src.read(1,window=Window(0,row,src.width,min(12,src.height-row)))
                good=a!=65535;count+=int(good.sum())
                if good.any():assert a[good].max()<=10000
            check('Raster '+path.stem+' respeta soporte y nodata',count==n and src.transform.a==10 and src.crs.to_epsg()==32717)
    text=(F/'MANUSCRITO_QUITO_V12.qmd').read_text(encoding='utf-8')
    redaction=json.loads((F/'control_redaccion.json').read_text(encoding='utf-8'))
    check('Extensión y hardware en manuscrito',redaction['words_summary']<=200 and redaction['words_manuscript_approx']<=10000 and re.search(r'RTX|5070|\bGPU\b|\bCPU\b',text)is None)
    with zipfile.ZipFile(F/'MANUSCRITO_QUITO_V12.docx')as z:
        doc=ET.fromstring(z.read('word/document.xml'));foot=ET.fromstring(z.read('word/footnotes.xml'))
        ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
        check('Word con siete tablas y tres ecuaciones editables',len(doc.findall('.//w:tbl',ns))==7 and len(doc.findall('.//m:oMathPara',ns))==3)
        check('Autor y afiliación real con pie',len(doc.findall('.//w:footnoteReference',ns))==1 and 'Investigador independiente' in ''.join(foot.itertext()))
    check('Seis figuras con formatos originales',len(list((F/'GRAFICOS').glob('*.svg')))==6 and len(list((F/'GRAFICOS').glob('*.png')))==6)
    corpus=json.loads((P/'1_LITERATURA/auditoria_crossref_completa.json').read_text(encoding='utf-8'))
    check('53 DOI comprobados por registro adecuado',len(corpus)==53 and all('metadatos'in r or'metadatos_datacite'in r for r in corpus))
    content=json.loads((D/'contenido_paper.json').read_text(encoding='utf-8'))
    refblocks=[b for b in content['blocks']if b['type']=='reference']
    check('42 referencias y 33 fundamentos de investigación',len(refblocks)==42 and redaction['research_references']==33)
    bib=(F/'referencias_paper.bib').read_text(encoding='utf-8')
    entries=re.findall(r'@\w+\{([^,]+),',bib)
    check('BibTeX completo sin claves duplicadas',len(entries)==42 and len(set(entries))==42)
    used=set(k for b in content['blocks']if b['type']=='paragraph'for k in b.get('citation_keys',[]))
    scholarly={b['citation_key']for b in refblocks if b.get('citation_key')and b['citation_key']!='inec_nbi'}
    check('Referencias añadidas enlazadas a afirmaciones',len(used)>20 and redaction['all_added_references_have_body_use'])
    check('Cada archivo final menor a 10 MB',all(p.stat().st_size<=10_000_000 for p in F.rglob('*')if p.is_file()))
    result={'passed':len(passed),'checks':passed,'max_independent_feature_error':err,
            'interpretation':'Controles técnicos; no validación de inundación física o certeza futura'}
    (Q/'controles_tecnicos.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)


if __name__=='__main__':main()
