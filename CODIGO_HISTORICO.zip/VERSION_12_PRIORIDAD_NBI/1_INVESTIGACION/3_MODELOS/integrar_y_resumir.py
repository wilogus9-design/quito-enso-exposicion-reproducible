"""Cruza píxeles modelados, lluvia nativa y tasas parroquiales de privación.

Los índices son áreas ponderadas para preparación, no personas localizadas,
superficies inundadas ni pérdidas. El summarize describe parroquias.
"""
from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
os.environ['GDAL_CACHEMAX']='8'
import json
import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from rasterio.windows import Window

P=Path(__file__).resolve().parents[1];ROOT=P.parents[2]
P5=ROOT/'EXPOSICION_FEN_NINO/VERSION_5_QUITO_10M/1_INVESTIGACION'
P7=ROOT/'EXPOSICION_FEN_NINO/VERSION_7_CALIBRACION_NMME/1_INVESTIGACION'
P9=ROOT/'EXPOSICION_FEN_NINO/VERSION_9_INTEGRACION_SOCIAL/1_INVESTIGACION'
D=P/'2_DATOS/PROCESADOS';F=P/'6_FINAL'
MODELS=['red_residual','ancla_acotada']
OBJECTIVES={'NBI':'pc_pnbi','saneamiento':'pc_SH','agua':'pc_FSA','hacinamiento':'pc_HAC'}


def main():
    meta=json.loads((D/'control_aplicacion.json').read_text(encoding='utf-8'));n=meta['n_generated'];nc=len(meta['weather_units'])
    flat=np.load(D/'indice_pixel.npy',mmap_mode='r')[:n]
    pid=np.load(D/'id_parroquia.npy',mmap_mode='r')[:n].astype(np.int32)
    wid=np.load(D/'id_lluvia.npy',mmap_mode='r')[:n]
    score=np.load(D/'scores_aplicacion.npy',mmap_mode='r')
    counts={'construido':np.bincount(pid*nc+wid,minlength=66*nc).reshape(66,nc)}
    thresholds={};qcontrols=[]
    sorted_scores=[]
    for j,model in enumerate(MODELS):
        order=np.sort(score[:,j]);sorted_scores.append(order)
        for q in [.80,.90,.95]:
            threshold=float(np.quantile(order,q));use=score[:,j]>=threshold
            counts[f'{model}_q{int(q*100)}']=np.bincount(pid[use]*nc+wid[use],minlength=66*nc).reshape(66,nc)
            qcontrols.append({'modelo':model,'percentil_corte':q*100,'umbral_log_densidad':threshold,
                              'pixeles_seleccionados':int(use.sum()),'area_ha':float(use.sum()*.01),
                              'fraccion_construido':float(use.mean()),'empates_umbral':int((score[:,j]==threshold).sum())})
            if q==.90:thresholds[model]=threshold
    np.savez_compressed(D/'intersecciones_V12.npz',unit=np.asarray(meta['weather_units']),**counts)
    pd.DataFrame(qcontrols).to_csv(F/'sensibilidad_umbral_territorial.csv',index=False)
    union=((score[:,0]>=thresholds[MODELS[0]])|(score[:,1]>=thresholds[MODELS[1]])).sum()
    intersect=((score[:,0]>=thresholds[MODELS[0]])&(score[:,1]>=thresholds[MODELS[1]])).sum()
    # Raster de percentiles: nodata fuera del construido válido. NO se pinta
    # el resto del territorio como ausencia de riesgo.
    rasterdir=F/'RASTERS_10M';rasterdir.mkdir(exist_ok=True)
    with rasterio.open(P5/'2_DATOS/PROCESADOS/worldcover_2021_10m.tif')as source:
        profile=source.profile.copy();profile.update(count=1,dtype='uint16',nodata=65535,
            compress='LZW',predictor=2,tiled=True,blockxsize=256,blockysize=256)
        for j,model in enumerate(MODELS):
            with rasterio.open(rasterdir/f'percentil_construido_{model}_10m.tif','w',**profile)as output:
                output.update_tags(description='Percentil de score sobre construido válido; valor/100 en porcentaje',
                    terrain_support='30 m',built_source='ESA WorldCover 2021',
                    no_data='Fuera de construido o falta de soporte; no ausencia de riesgo',
                    threshold='Decil superior por área, fijado sin usar test')
                output.set_band_description(1,'Percentil de susceptibilidad x 100')
                for row in range(0,source.height,12):
                    rows=min(12,source.height-row);start=np.searchsorted(flat,row*source.width);end=np.searchsorted(flat,(row+rows)*source.width)
                    arr=np.full(rows*source.width,65535,np.uint16)
                    s=score[start:end,j]
                    percentile=(np.searchsorted(sorted_scores[j],s,'left')+np.searchsorted(sorted_scores[j],s,'right'))/(2*n)*100
                    arr[flat[start:end]-row*source.width]=np.rint(percentile*100).astype(np.uint16)
                    output.write(arr.reshape(rows,source.width),1,window=Window(0,row,source.width,rows))
    territory=pd.read_csv(P9/'6_FINAL/territorio_vulnerabilidad_parroquias.csv',dtype={'parroquia':str})
    territory=territory.sort_values('id_censo').reset_index(drop=True)
    assert len(territory)==65 and np.array_equal(territory.id_censo,np.arange(1,66))
    table=territory[['parroquia','nom_par','id_censo',*OBJECTIVES.values()]].copy()
    table=table.rename(columns={'nom_par':'nombre'})
    table['construido_ha']=counts['construido'][1:].sum(1)*.01
    fullcounts=np.zeros(66,np.int64)
    with rasterio.open(P5/'2_DATOS/PROCESADOS/worldcover_2021_10m.tif')as wc, \
         rasterio.open(P5/'2_DATOS/PROCESADOS/mascara_quito_10m.tif')as mask, \
         rasterio.open(P9/'2_DATOS/PROCESADOS/parroquias_censo_10m.tif')as parish:
        for row in range(0,wc.height,12):
            win=Window(0,row,wc.width,min(12,wc.height-row))
            built=(wc.read(1,window=win)==50)&(mask.read(1,window=win)>0)
            fullcounts+=np.bincount(parish.read(1,window=win)[built],minlength=66)
    assert fullcounts.sum()==meta['capacity']
    table['construido_fuente_ha']=fullcounts[1:]*.01
    table['construido_excluido_ha']=(fullcounts[1:]-counts['construido'][1:].sum(1))*.01
    table['cobertura_construido_pct']=100*table.construido_ha/table.construido_fuente_ha
    clipped=np.load(D/'soporte_recortado.npy',mmap_mode='r')[:n]
    edges=np.load(D/'borde_hidrologico.npy',mmap_mode='r')[:n]
    den=counts['construido'].sum(1)
    table['soporte_recortado_pct']=100*np.bincount(pid,weights=clipped,minlength=66)[1:]/den[1:]
    table['borde_externo_pct']=100*np.bincount(pid,weights=edges,minlength=66)[1:]/den[1:]
    for model in MODELS:
        table[f'prioritario_{model}_ha']=counts[f'{model}_q90'][1:].sum(1)*.01
        table[f'prioritario_{model}_pct']=100*table[f'prioritario_{model}_ha']/table.construido_ha
    wet=[]
    fixed=pd.read_csv(P7/'6_FINAL/pronostico_calibracion_fija_nov2026_ene2027.csv')
    for model in ['red_ENSO__beta_PIT','climatologia_calibrada__beta_PIT']:
        h=fixed[(fixed.tipo_unidad=='QUITO_CELDA')&(fixed.modelo==model)].set_index('unit').reindex(meta['weather_units'])
        wet.append((model,h.p_humedo.to_numpy()))
    dynamical=pd.read_csv(P7/'6_FINAL/pronostico_NMME_local_nov2026_ene2027.csv')
    h=dynamical[(dynamical.dominio=='Quito grilla')&(dynamical.modelo=='NMME_local__beta_PIT')].set_index('unit').reindex(meta['weather_units'])
    wet.append(('NMME_local__beta_PIT',h.p_humedo.to_numpy()))
    rows=[];comparisons=[]
    for weather,prob in wet:
        if not np.isfinite(prob).all()or((prob<0)|(prob>1)).any():raise ValueError('Pronostico incompleto')
        for model in MODELS:
            current=table.copy();current['modelo_territorial']=model;current['modelo_lluvia']=weather
            area=counts[f'{model}_q90'][1:]@prob*.01
            current['area_prioritaria_ponderada_humedad_ha']=area
            current['p_humedo_media_construido']=counts['construido'][1:]@prob/den[1:]
            current['area_prioritaria_ha']=current[f'prioritario_{model}_ha']
            current['ranking_area']=current.area_prioritaria_ponderada_humedad_ha.where(area>0).rank(ascending=False,method='min')
            aset=set(current.loc[(current.ranking_area<=13)&(area>0),'parroquia'])
            for objective,field in OBJECTIVES.items():
                values=area*current[field].to_numpy()/100
                current[f'indice_{objective}_ha_ponderadas']=values
                current[f'ranking_{objective}']=pd.Series(values).where(values>0).rank(ascending=False,method='min')
                current[f'top13_{objective}']=((current[f'ranking_{objective}']<=13)&(values>0)).astype(int)
                bset=set(current.loc[current[f'top13_{objective}']==1,'parroquia'])
                comparisons.append({'modelo_territorial':model,'modelo_lluvia':weather,'objetivo':objective,
                    'seleccionadas_area':len(aset),'seleccionadas_social':len(bset),'comunes':len(aset&bset),
                    'cambios_por_ponderacion':len(bset-aset),
                    'jaccard_area_social':len(aset&bset)/len(aset|bset)if aset|bset else np.nan,
                    'empate_limite_presupuesto':len(bset)>13})
            rows.append(current)
    panel=pd.concat(rows,ignore_index=True)
    panel.to_csv(F/'prioridad_integrada_NDJ2026_2027.csv',index=False)
    pd.DataFrame(comparisons).to_csv(F/'cambio_prioridad_por_contexto_social.csv',index=False)
    stability=panel.groupby('parroquia').agg(selecciones_NBI_de_6=('top13_NBI','sum'),
        indice_NBI_min=('indice_NBI_ha_ponderadas','min'),indice_NBI_max=('indice_NBI_ha_ponderadas','max'))
    primary=panel[(panel.modelo_territorial=='red_residual')&(panel.modelo_lluvia=='red_ENSO__beta_PIT')].copy()
    primary=primary.merge(stability,on='parroquia',validate='one_to_one')
    physical=primary.ranking_area<=13;social=primary.ranking_NBI<=13
    gain=primary.loc[social,'indice_NBI_ha_ponderadas'].sum()/primary.loc[physical,'indice_NBI_ha_ponderadas'].sum()-1
    area_change=primary.loc[social,'area_prioritaria_ponderada_humedad_ha'].sum()/primary.loc[physical,'area_prioritaria_ponderada_humedad_ha'].sum()-1
    budget=[]
    # Sensibilidad sin reoptimizar por desempeño del test ni llamar ganancia
    # predictiva al objetivo que por construcción optimiza su propio índice.
    for q in [80,90,95]:
        prob=wet[0][1];area=counts[f'red_residual_q{q}'][1:]@prob*.01
        objective=area*table.pc_pnbi.to_numpy()/100
        rank_area=pd.Series(area).where(area>0).rank(ascending=False,method='min')
        rank_social=pd.Series(objective).where(objective>0).rank(ascending=False,method='min')
        for k in [5,10,13,20]:
            a=(rank_area<=k).to_numpy();b=(rank_social<=k).to_numpy()
            budget.append({'percentil_territorial':q,'presupuesto':k,
                'seleccionadas_area':int(a.sum()),'seleccionadas_NBI':int(b.sum()),
                'cambios_por_NBI':int((b&~a).sum()),'area_seleccion_area_ha_ponderadas':float(area[a].sum()),
                'area_seleccion_NBI_ha_ponderadas':float(area[b].sum()),
                'indice_NBI_seleccion_area':float(objective[a].sum()),
                'indice_NBI_seleccion_NBI':float(objective[b].sum()),
                'interpretacion':'Tradeoff descriptivo de objetivos; no prueba predictiva ni beneficio causal'})
    pd.DataFrame(budget).to_csv(F/'sensibilidad_umbral_presupuesto_NBI.csv',index=False)
    primary.to_csv(F/'parroquias_integradas_resumen.csv',index=False)
    primary.sort_values('ranking_NBI',na_position='last').to_csv(F/'prioridades_NBI_ordenadas.csv',index=False)
    variables=[('construido_ha','Construido WorldCover 2021','ha'),
        ('area_prioritaria_ha','Construido en decil superior','ha'),
        ('prioritario_red_residual_pct','Construido en decil superior','%'),
        ('pc_pnbi','Personas con NBI','% de personas del universo NBI'),
        ('pc_SH','Saneamiento inadecuado','% del universo SH'),
        ('pc_FSA','Acceso limitado a agua segura','% del universo FSA'),
        ('pc_HAC','Hacinamiento','% del universo HAC'),
        ('p_humedo_media_construido','Probabilidad húmeda ponderada por construido','0 a 1'),
        ('area_prioritaria_ponderada_humedad_ha','Área prioritaria ponderada por humedad','ha ponderadas'),
        ('indice_NBI_ha_ponderadas','Índice de prioridad NBI','ha ponderadas por humedad y NBI'),
        ('soporte_recortado_pct','Construido con covariable recortada','%'),
        ('borde_externo_pct','Construido con influencia del borde hidrológico','%')]
    variables.extend([('construido_excluido_ha','Construido excluido por soporte','ha'),
                      ('cobertura_construido_pct','Cobertura del construido fuente','%')])
    summary=[]
    for key,label,unit in variables:
        x=primary[key].dropna()
        summary.append({'variable':key,'descripcion':label,'unidad':unit,'N':len(x),'media':x.mean(),
                        'desv_estandar':x.std(ddof=1),'minimo':x.min(),'maximo':x.max()})
    summarize=pd.DataFrame(summary);summarize.to_csv(F/'summarize_parroquias.csv',index=False)
    geo=gpd.read_file(P9/'2_DATOS/PROCESADOS/geometria_censal.geojson')[['parroquia','geometry']]
    geo['parroquia']=geo.parroquia.astype(str).str.zfill(6)
    geo=geo.merge(primary,on='parroquia',validate='one_to_one')
    geo['interpretacion']='Prioridad parroquial; NBI no localizado por pixel; area no equivale a inundacion'
    geo.to_file(F/'prioridad_integrada_quito.geojson',driver='GeoJSON')
    result={'n_parroquias':65,'n_pixels':n,'built_area_ha':n*.01,
        'unassigned_built_area_ha':int(den[0])*.01,'thresholds':thresholds,
        'priority_area_red_ha':int(counts['red_residual_q90'].sum())*.01,
        'priority_area_anchor_ha':int(counts['ancla_acotada_q90'].sum())*.01,
        'jaccard_pixel_priorities_red_anchor':float(intersect/union),
        'ensemble_density_mean':float(np.exp(score[:,0]).mean()),
        'n_scenarios':6,'n_forecast_cells':nc,'primary':'red_residual + red_ENSO__beta_PIT',
        'no_summed_social_objectives':True,'summary_unit':'parroquia no ponderada',
        'top_primary_NBI':primary.sort_values('ranking_NBI').head(13)[['nombre','indice_NBI_ha_ponderadas','selecciones_NBI_de_6']].to_dict('records'),
        'robust_selected_all_6':primary.loc[primary.selecciones_NBI_de_6==6,'nombre'].tolist(),
        'enter_top13_by_NBI':primary.loc[social&~physical,'nombre'].tolist(),
        'exit_top13_by_NBI':primary.loc[physical&~social,'nombre'].tolist(),
        'NBI_index_gain_at_top13_pct':float(gain*100),
        'weighted_area_change_at_top13_pct':float(area_change*100),
        'comparisons':comparisons,
        'forecast_snapshot':'V07, decision 2026-10-09, NDJ 2026-2027, not refreshed',
        'census_count_discrepancy':'Municipal NBI universe exceeds cantonal lake by 119116 people; no affected-person estimates'}
    (F/'control_integracion.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(summarize.to_string(index=False),flush=True)
    print(primary.sort_values('ranking_NBI')[['nombre','ranking_area','ranking_NBI','indice_NBI_ha_ponderadas','selecciones_NBI_de_6']].head(15).to_string(index=False),flush=True)


if __name__=='__main__':main()
