"""Verifica DOI de las versiones previas y referencias metodológicas pertinentes.

Crossref valida identidad bibliográfica, no resultados, calidad o indexación
Scopus. Cada inclusión en el artículo requiere además sustento de contenido.
"""
from pathlib import Path
import json
import hashlib
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote
import csv
import argparse
import requests
import truststore

P=Path(__file__).resolve().parents[1];L=P/'1_LITERATURA';F=P/'6_FINAL'
ADDED={
    'roberts2017':'10.1111/ecog.02881',
    'meyer2021':'10.1111/2041-210X.13650',
    'barnes2014':'10.1016/j.cageo.2013.04.024',
    'ocallaghan1984':'10.1016/S0734-189X(84)80011-0',
    'bentivoglio2022':'10.5194/hess-26-4345-2022',
    'tellman2021':'10.1038/s41586-021-03695-w',
    'cutter2003':'10.1111/1540-6237.8402002',
    'robinson1950':'10.2307/2087176',
    'elfwing2018':'10.1016/j.neunet.2017.12.012'}


def main():
    truststore.inject_into_ssl();cache=L/'CROSSREF';cache.mkdir(parents=True,exist_ok=True)
    parser=argparse.ArgumentParser();parser.add_argument('--resolver-pendientes',action='store_true');args=parser.parse_args()
    previous=json.loads((L/'inventario_bibliografias_previas.json').read_text(encoding='utf-8'))
    requested={r['doi'].lower():r for r in previous}
    for key,doi in ADDED.items():requested.setdefault(doi.lower(),{'doi':doi,'bibliografias_previas':[]})['clave_nueva']=key
    def fetch(pair):
        doi,origin=pair;name=hashlib.sha256(doi.encode()).hexdigest()[:20]+'.json';file=cache/name
        row={**origin,'doi_solicitado':doi,'fecha_verificacion':'2026-10-09','fuente':'Crossref REST API',
             'indexacion_scopus':'No comprobada por esta consulta','archivo_cache':str(file.relative_to(P))}
        try:
            if file.exists():message=json.loads(file.read_text(encoding='utf-8'));row['consulta']='cache de esta verificación'
            else:
                r=requests.get('https://api.crossref.org/works/'+quote(doi,safe='/'),timeout=(15,40),
                    headers={'User-Agent':'Investigaciones-Quito/1.2 (bibliographic metadata validation)'})
                r.raise_for_status();message=r.json()['message']
                file.write_text(json.dumps(message,ensure_ascii=False,indent=2),encoding='utf-8');row['consulta']='consulta pública recuperada'
            if message['DOI'].lower()!=doi:raise ValueError('DOI de respuesta no coincide')
            row.update({'estado':'identidad DOI verificada','doi_resuelto':message['DOI'],
                'titulo':message['title'][0],'autores':' | '.join(x.get('family','x')+', '+x.get('given','')for x in message.get('author',[])),
                'ano':message.get('published-print',message.get('published',message['issued']))['date-parts'][0][0],
                'tipo':message.get('type'),'revista':message.get('container-title',[''])[0],
                'editorial':message.get('publisher'),'metadatos':message})
        except Exception as e:row.update({'estado':'no verificado en esta consulta','error':str(e)})
        return row
    with ThreadPoolExecutor(max_workers=3)as pool:
        rows=[]
        for row in pool.map(fetch,requested.items()):
            rows.append(row);print(row['estado'],row['doi_solicitado'],flush=True)
    if args.resolver_pendientes:
        # Una consulta secuencial adicional por fallo, sin insistir en paralelo
        # tras 429. Crossref no registra todos los DOI de datos: usar DataCite.
        for i,row in enumerate(rows):
            if 'metadatos'in row:continue
            doi=row['doi_solicitado']
            if '429'in row.get('error',''):
                rows[i]=fetch((doi,requested[doi]))
            elif '404'in row.get('error',''):
                try:
                    r=requests.get('https://api.datacite.org/dois/'+quote(doi,safe='/'),timeout=(15,40));r.raise_for_status()
                    m=r.json()['data']['attributes']
                    if m['doi'].lower()!=doi:raise ValueError('DOI DataCite no coincide')
                    rows[i]={**row,'estado':'identidad DOI verificada en DataCite','fuente':'DataCite REST API',
                        'doi_resuelto':m['doi'],'titulo':m['titles'][0]['title'],'ano':m.get('publicationYear'),
                        'autores':' | '.join(a['name']for a in m.get('creators',[])),
                        'metadatos_datacite':m,'observacion':'DOI de datos registrado fuera de Crossref; no referencia inválida por 404 Crossref'}
                    rows[i].pop('error',None)
                except Exception as e:rows[i]['error_datacite']=str(e)
            print('Resolver:',rows[i]['estado'],doi,flush=True)
    (L/'auditoria_crossref_completa.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
    small=[{k:v for k,v in r.items()if k not in ['metadatos','metadatos_datacite','bibliografias_previas']}for r in rows]
    fields=sorted(set().union(*(r.keys()for r in small)))
    with(F/'auditoria_bibliografia_DOI.csv').open('w',encoding='utf-8',newline='')as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(small)
    print('Verificados',sum('metadatos'in r or'metadatos_datacite'in r for r in rows),'de',len(rows),flush=True)


if __name__=='__main__':main()
